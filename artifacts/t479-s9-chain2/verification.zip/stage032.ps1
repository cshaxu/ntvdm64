$ErrorActionPreference='Stop'
$r='O:/repos.hobby/ntvdm64';Set-Location $r;$d="$r/build/t479-s9-display"
if((Get-Content "$d/full031.exit" -Raw).Trim() -ne '0'){throw 'Full031 must pass before transition run'}
. "$r/tests/observation/isolated_package_cleanup.ps1"
$runtime=New-PhysicalRuntimeStage "$d/r031-package"
$rows=@(Get-Content "$runtime/product-system32-manifest.json" -Raw|ConvertFrom-Json)
if($rows.Count -ne 11){throw 'Expected eleven images'}
foreach($row in $rows){if((Get-FileHash (Join-Path $runtime $row.RelativePath)).Hash -ne $row.Sha256){throw 'Stage hash mismatch'}}
$guest='O:/tmp/w479m'
$files=@('SYSTEM.INI','WIN.INI','PATCH/INSIGNIA.386','PATCH/NTVDM64.386')
$hashes=@($files|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash "$guest/$_").Hash}})
[ordered]@{runtime=$runtime;package=$rows[0].PackageId;images=$rows.Count;guest=$guest;guestInputs=$hashes;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$d/stage032.json"
'PASS fresh stage; no guest or addon modification'

$leaf=Split-Path $runtime -Leaf
$source=[IO.File]::ReadAllText("$r/build/t479-s9-display/key025.c").Replace('n828',$leaf)
[IO.File]::WriteAllText("$d/key032.c",$source)
& cmd.exe /d /c 'build\t479-s9-display\key032.cmd'
if($LASTEXITCODE){throw 'Owned window input probe build failed'}
