@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 goto done
ninja -C build\.ninja\msvc-x86-release\worker cvidc-vector-binding-fixture.exe
if errorlevel 1 goto done
build\.ninja\msvc-x86-release\worker\cvidc-vector-binding-fixture.exe
:done
set result=%errorlevel%
echo %result% >build\t479-s9-display\rules033.exit
exit /b %result%









