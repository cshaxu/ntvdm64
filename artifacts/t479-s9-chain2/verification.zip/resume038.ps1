$ErrorActionPreference='Stop'
$d='O:/repos.hobby/ntvdm64/build/t479-s9-display'
New-Item -ItemType Directory -Force "$d/inspect038"|Out-Null
. 'O:/repos.hobby/ntvdm64/tests/observation/inspect-session-windows.ps1' -ProcessIds @(25140) -BuildRoot "$d/inspect038"
for($i=0;$i -lt 6;$i++){
 [WindowInspector]::Read([int[]]@(25140),'Default',$true,$false,$false)
 Start-Sleep -Seconds 1
}
Start-Sleep -Seconds 8
& "$d/resume036.ps1"