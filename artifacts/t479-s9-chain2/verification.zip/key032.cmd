@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cl /nologo /O2 /W3 /Fe:build\t479-s9-display\key032.exe /Fo:build\t479-s9-display\key032.obj build\t479-s9-display\key032.c user32.lib
exit /b %errorlevel%