@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
cl /nologo /std:c11 /I src tests\observation\window_surface_snapshot.c /Fe:build\t479-s6-livecmd\surface.exe /Fo:build\t479-s6-livecmd\surface.obj user32.lib