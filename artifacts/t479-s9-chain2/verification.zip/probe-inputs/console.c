#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
int main(int n,char**v){if(n<2)return 64;FreeConsole();if(!AttachConsole(strtoul(v[1],0,10)))return 65;HANDLE o=CreateFileA("CONOUT$",GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,0,0);CONSOLE_SCREEN_BUFFER_INFO b;if(!GetConsoleScreenBufferInfo(o,&b))return 66;FILE*f=fopen(v[2],"wb");for(int y=b.srWindow.Top;y<=b.srWindow.Bottom;y++){char s[1024];DWORD c;COORD p={0,(SHORT)y};ReadConsoleOutputCharacterA(o,s,min(b.dwSize.X,1023),p,&c);fwrite(s,1,c,f);fputc('\n',f);}fclose(f);CloseHandle(o);FreeConsole();return 0;}