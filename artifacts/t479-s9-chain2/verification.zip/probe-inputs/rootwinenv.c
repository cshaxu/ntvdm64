/*
 * Explorer-equivalent COMMAND.COM probe.  The target starts in a fresh
 * Console; this observer detaches from its caller only after that launch, so
 * Run16's initial single-member decision has already occurred.  It then
 * drives real CONIN$/CONOUT$ records and records whether a native-command
 * result reaches the direct root Console.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define WAIT_LIMIT_MS 600000u

static BOOL write_text(HANDLE input, const char *text)
{
    INPUT_RECORD records[256]; DWORD count = 0, done; size_t index;
    for (index = 0; text[index]; ++index) {
        SHORT translated;
        WORD key, scan;
        DWORD modifiers = NUMLOCK_ON;
        INPUT_RECORD *down, *up;
        if (count + 2 > ARRAYSIZE(records)) return FALSE;
        if (text[index] == '\r') {
            key = VK_RETURN;
        } else {
            translated = VkKeyScanA(text[index]);
            if (translated == -1) return FALSE;
            key = LOBYTE(translated);
            if (HIBYTE(translated) & 1) modifiers |= SHIFT_PRESSED;
        }
        scan = (WORD)MapVirtualKeyW(key, MAPVK_VK_TO_VSC);
        if (!scan) return FALSE;
        down = &records[count++]; ZeroMemory(down, sizeof(*down));
        down->EventType = KEY_EVENT; down->Event.KeyEvent.bKeyDown = TRUE;
        down->Event.KeyEvent.wRepeatCount = 1;
        down->Event.KeyEvent.wVirtualKeyCode = key;
        down->Event.KeyEvent.wVirtualScanCode = scan;
        down->Event.KeyEvent.uChar.AsciiChar = text[index];
        down->Event.KeyEvent.dwControlKeyState = modifiers;
        up = &records[count++]; *up = *down;
        up->Event.KeyEvent.bKeyDown = FALSE;
        up->Event.KeyEvent.uChar.AsciiChar = 0;
    }
    return WriteConsoleInputA(input, records, count, &done) && done == count;
}

/* The NTCOn presentation can replace the active screen buffer after this
 * observer attaches.  Reopen CONOUT$ at each observation point: an older
 * handle remains valid, but no longer describes what a direct-console user
 * sees.  Prompt discovery is only a test input milestone; it is not a new
 * product readiness protocol. */
static DWORD active_console_count(HANDLE fallback, const char *needle)
{
    HANDLE output;
    CONSOLE_SCREEN_BUFFER_INFO info;
    DWORD cells, read = 0;
    char *text;
    DWORD found = 0;

    output = CreateFileW(L"CONOUT$", GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (output == INVALID_HANDLE_VALUE) output = fallback;
    if (output == INVALID_HANDLE_VALUE || !GetConsoleScreenBufferInfo(output, &info) ||
        info.dwSize.X <= 0 || info.dwSize.Y <= 0 ||
        (uint64_t)info.dwSize.X * (uint64_t)info.dwSize.Y > 1024u * 1024u) goto done;
    cells = (DWORD)info.dwSize.X * (DWORD)info.dwSize.Y;
    text = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, (SIZE_T)cells + 1);
    if (!text) goto done;
    if (ReadConsoleOutputCharacterA(output, text, cells, (COORD){ 0, 0 }, &read)) {
        text[read] = 0;
        const char *match=text;
        while((match=strstr(match,needle))!=NULL){++found;match+=strlen(needle);}
    }
    HeapFree(GetProcessHeap(), 0, text);
done:
    if (output != fallback && output != INVALID_HANDLE_VALUE) CloseHandle(output);
    return found;
}

static DWORD stage_frontend_process(const WCHAR *root,const FILETIME *started)
{
    WCHAR expected[MAX_PATH * 2], image[MAX_PATH * 2];
    HANDLE snapshot;
    PROCESSENTRY32W entry;
    DWORD result = 0;
    if (!root || swprintf_s(expected, ARRAYSIZE(expected), L"%ls\\system32\\ntcon.exe", root) < 0)
        return 0;
    snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) return 0;
    ZeroMemory(&entry, sizeof(entry)); entry.dwSize = sizeof(entry);
    if (Process32FirstW(snapshot, &entry)) do {
        HANDLE process; DWORD length = ARRAYSIZE(image);
        FILETIME created,ended,kernel,user;
        if (_wcsicmp(entry.szExeFile, L"ntcon.exe")) continue;
        process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, entry.th32ProcessID);
        if (process && GetProcessTimes(process,&created,&ended,&kernel,&user) &&
            CompareFileTime(&created,started)>=0 &&
            QueryFullProcessImageNameW(process, 0, image, &length) &&
            !_wcsicmp(image, expected)) result = entry.th32ProcessID;
        if (process) CloseHandle(process);
        if (result) break;
    } while (Process32NextW(snapshot, &entry));
    CloseHandle(snapshot);
    return result;
}

/* COMMAND.COM's launch environment is guest input. Keep this direct-root
 * fixture equivalent to an Explorer invocation instead of inheriting a build
 * shell's unrelated toolchain variables. */
static BOOL direct_environment(const WCHAR *root, WCHAR *block, size_t capacity)
{
    WCHAR system_root[MAX_PATH], windir[MAX_PATH], comspec[MAX_PATH];
    size_t used = 0, index;
    const WCHAR *values[5];
    WCHAR path[MAX_PATH * 2];
    if (!root || !block || !capacity ||
        !GetEnvironmentVariableW(L"SystemRoot", system_root, ARRAYSIZE(system_root)) ||
        !GetEnvironmentVariableW(L"WINDIR", windir, ARRAYSIZE(windir)) ||
        !GetEnvironmentVariableW(L"COMSPEC", comspec, ARRAYSIZE(comspec)) ||
        swprintf_s(path, ARRAYSIZE(path), L"PATH=%ls\\system32;%ls\\System32", root, system_root) < 0)
        return FALSE;
    values[0] = system_root; values[1] = windir; values[2] = comspec;
    for (index = 0; index != ARRAYSIZE(values); ++index) {
        const WCHAR *name = index == 0 ? L"SystemRoot=" : index == 1 ? L"WINDIR=" :
            index == 2 ? L"COMSPEC=" : index == 3 ? L"PATHEXT=.COM;.EXE;.BAT;.CMD" :
            index == 4 ? path : L"";
        const WCHAR *value = index < 3 ? values[index] : NULL;
        int written = value ? swprintf_s(block + used, capacity - used, L"%ls%ls", name, value) :
            swprintf_s(block + used, capacity - used, L"%ls", name);
        if (written < 0 || (size_t)written + 1 >= capacity - used) return FALSE;
        used += (size_t)written + 1;
    }
    block[used] = 0;
    return TRUE;
}

/* The direct-root contract is visual: the frame must reach NTCOn's real
 * Window, not merely a Console buffer that happens to be attached to this
 * test process.  Use the same disposable private-desktop discipline as the
 * regular Console observer, never the user's desktop. */
static int private_desktop_observer(void)
{
    WCHAR name[80], *command;
    HDESK desktop;
    STARTUPINFOW startup = { sizeof(startup) };
    PROCESS_INFORMATION child = { 0 };
    DWORD code = 69, wait;

    if (swprintf_s(name, ARRAYSIZE(name), L"NTVDMConsoleTest-Direct-%lu",
                   GetCurrentProcessId()) < 0) return 69;
    desktop = CreateDesktopW(name, NULL, NULL, 0, GENERIC_ALL, NULL);
    if (!desktop) return 69;
    command = _wcsdup(GetCommandLineW());
    if (!command) { CloseDesktop(desktop); return 69; }
    startup.lpDesktop = name;
    startup.dwFlags = STARTF_USESHOWWINDOW;
    startup.wShowWindow = SW_HIDE;
    SetEnvironmentVariableW(L"MVDM_DIRECT_PRIVATE_DESKTOP", NULL);
    if (CreateProcessW(NULL, command, NULL, NULL, FALSE, CREATE_NEW_CONSOLE,
                       NULL, NULL, &startup, &child)) {
        CloseHandle(child.hThread);
        wait = WaitForSingleObject(child.hProcess, WAIT_LIMIT_MS + 20000u);
        if (wait == WAIT_OBJECT_0) GetExitCodeProcess(child.hProcess, &code);
        else {
            TerminateProcess(child.hProcess, 69);
            WaitForSingleObject(child.hProcess, 1000);
        }
        CloseHandle(child.hProcess);
    }
    free(command);
    CloseDesktop(desktop);
    return (int)code;
}

int wmain(int argc,WCHAR **argv){if((argc<3||argc>4))return 64;if(GetEnvironmentVariableW(L"MVDM_DIRECT_PRIVATE_DESKTOP",NULL,0))return private_desktop_observer();WCHAR command[4096],environment[8192];STARTUPINFOW si={sizeof(si)};PROCESS_INFORMATION p={0};FILE*f;_wfopen_s(&f,argv[2],L"w");if(!f)return 65;swprintf_s(command,4096,L"\"%ls\\system32\\run16.exe\" %ls",argv[1],argc==4?argv[3]:L"O:\\w31\\patch\\win386.cmd");if(!CreateProcessW(NULL,command,NULL,NULL,FALSE,CREATE_NEW_CONSOLE|CREATE_UNICODE_ENVIRONMENT,NULL,L"O:\\w31",&si,&p)){fprintf(f,"create-error=%lu\n",GetLastError());fclose(f);return 66;}fprintf(f,"pid=%lu\n",p.dwProcessId);fflush(f);CloseHandle(p.hThread);DWORD wait=WaitForSingleObject(p.hProcess,600000),code=0;GetExitCodeProcess(p.hProcess,&code);fprintf(f,"wait=%lu exit=%lu\n",wait,code);fclose(f);CloseHandle(p.hProcess);return wait==WAIT_OBJECT_0?0:1;}