$ErrorActionPreference='Stop'
$r='O:/repos.hobby/ntvdm64';$d="$r/build/t479-s9-display";$helpers="$r/build/t479-s6-livecmd"
$stage=(Get-Content "$d/stage032.json" -Raw|ConvertFrom-Json).runtime
$observer=[int](Get-Content "$d/root032.pid" -Raw)
$p=Get-Process -Id $observer
$roots=@(Get-CimInstance Win32_Process|Where-Object{$_.ParentProcessId -eq $observer -and $_.Name -eq 'run16.exe'})
if($roots.Count -ne 1){throw 'Cannot identify existing owned root'}
$script:root=[int]$roots[0].ProcessId
function Key([int]$value,[int]$control=0) {
 & "$d/key032.exe" $script:front Default $value $control
 if($LASTEXITCODE){throw "Owned key failed: $value"}
 Start-Sleep -Milliseconds 120
}
function Frame([string]$name) {
 & "$helpers/surface.exe" $script:front Default "$d/$name.bmp"
 if($LASTEXITCODE){throw "Frame failed: $name"}
}
function ConsoleFrame([string]$name) {
 & "$helpers/console.exe" $script:root "$d/$name.txt"
 if($LASTEXITCODE){throw "Console read failed: $name"}
}
$rows=@(Get-CimInstance Win32_Process|Where-Object{$_.ExecutablePath -like "$stage\system32\*"})
$fronts=@($rows|Where-Object{$_.Name -eq 'ntcon.exe'})
if($fronts.Count -ne 1){throw 'Expected one owned frontend'}
$script:front=[int]$fronts[0].ProcessId
ConsoleFrame 'initial032'
& "$helpers/altenter-full.exe" $script:root
if($LASTEXITCODE){throw 'Initial full-to-window failed'}
Start-Sleep -Seconds 3
Frame 'window032'
foreach($value in @(69,67,72,79,32,67,72,65,73,78,50)){Key $value}
Start-Sleep -Seconds 2
Frame 'typed032'
Key 13
Start-Sleep -Seconds 2
Frame 'echo032'
Key 13 2
Start-Sleep -Seconds 3
ConsoleFrame 'full032'
& "$helpers/altenter-full.exe" $script:root
if($LASTEXITCODE){throw 'Second full-to-window failed'}
Start-Sleep -Seconds 3
Frame 'back032'
foreach($case in @(@{name='dir';keys=@(68,73,82,13)},@{name='ver';keys=@(86,69,82,13)},@{name='cls';keys=@(67,76,83,13)})){
 foreach($value in $case.keys){Key $value}
 Start-Sleep -Seconds 4
 Frame ("command032-"+$case.name)
}
foreach($value in @(69,88,73,84,13)){Key $value}
Start-Sleep -Seconds 3
Frame 'dos-exit032'
foreach($value in @(121,70,88)){Key $value;Start-Sleep -Milliseconds 500}
Start-Sleep -Seconds 1
Frame 'exit-dialog032'
Key 13
if(!$p.WaitForExit(30000)){throw 'Normal Windows exit not observed in diagnostic budget'}
$p.WaitForExit()
$record=[IO.File]::ReadAllText("$d/root032.txt")
if($record -notmatch 'wait=0 exit=0'){throw "Normal root exit failed: $record"}
[IO.File]::WriteAllText("$d/root032.exit",'0')
'PASS normal Windows and Run16 exit; images require visual review'

[IO.File]::WriteAllText("$d/live036.exit",'0')
