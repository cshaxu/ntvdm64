Set-Location O:/repos.hobby/ntvdm64
& cmd /d /c build\t483\cmd-header-layout\run.cmd
[IO.File]::WriteAllText('O:/repos.hobby/ntvdm64/build/t483/cmd-header-layout/exit.txt', [string]$LASTEXITCODE)
exit $LASTEXITCODE