@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
cl @O:\repos.hobby\ntvdm64\build\t483\cmd-header-layout\current.rsp
if errorlevel 1 exit /b %errorlevel%
cl @O:\repos.hobby\ntvdm64\build\t483\cmd-header-layout\restored.rsp
exit /b %errorlevel%
