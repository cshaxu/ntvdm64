#include "O:/repos.hobby/ntvdm64/src/mvdm-host/dos/command/cmd.h"

#include <stddef.h>
_Static_assert(sizeof(void *) == 4, "x86 only");
_Static_assert(sizeof(PARAMBLOCK) == 14, "guest param");
_Static_assert(sizeof(SCSINFO) == 207, "guest scs");
_Static_assert(sizeof(STD_HANDLES) == 12, "guest std");
_Static_assert(sizeof(PIPE_INPUT) == 68, "input size");
_Static_assert(offsetof(PIPE_INPUT,CriticalSection) == 44, "critical offset");
_Static_assert(sizeof(PIPE_OUTPUT) == 24, "output size");
_Static_assert(offsetof(PIPE_OUTPUT,Buffer) == 20, "output buffer offset");
_Static_assert(sizeof(REDIRCOMPLETE_INFO) == 44, "redir size");
_Static_assert(sizeof(VDMENVBLK) == 12, "env size");
