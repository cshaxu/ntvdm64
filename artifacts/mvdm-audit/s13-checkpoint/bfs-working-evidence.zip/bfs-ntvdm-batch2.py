import pathlib,re,json,subprocess,shutil,importlib.util,hashlib,concurrent.futures
root=pathlib.Path.cwd();out=root/'build/t473-s13/bfs-depth1-ntvdm-batch2';out.mkdir(exist_ok=True);spec=importlib.util.spec_from_file_location('audit','build/t473-s13/bfs-live/audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit);folder=root/'build/.ninja/msvc-x86-release/worker';entries=json.loads(subprocess.check_output([str(audit.NINJA),'-C',str(folder),'-t','compdb'],text=True));env=audit.env_for('x86');cl=shutil.which('cl.exe',path=env.get('PATH',env.get('Path','')));q=json.load(open('build/t473-s13/bfs/baseline-and-queue.json',encoding='utf8'));paths=sorted({g['path'] for g in q['groups'] if g.get('role')=='current' and g.get('depth')==1 and g['path'].endswith('.c') and any(a['status']=='pending' and a['kind']=='ifndef' and a.get('expression')=='NTVDM' for a in g['arms'])}); targets=[]
for path in paths:
 es=[e for e in entries if e.get('file','').replace('\\','/').lower().endswith('/'+path.lower())]
 if len(es)==1:targets.append((path,es[0]))
 else:print('NO UNIQUE PRODUCT CONTEXT',path,len(es),flush=True)
def run(pair):
 path,e=pair;cmd=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1];cmd=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',cmd);cmd=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',cmd);r=subprocess.run('"'+cl+'" /Zs /showIncludes '+cmd,cwd=folder,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=r.stdout+r.stderr;(out/(pathlib.Path(path).stem+'.log')).write_bytes(raw);txt=raw.decode('mbcs',errors='replace');incs=[]
 for line in txt.splitlines():
  m=re.search(r'(?i)including file:\s*(.*)$',line)
  if m and pathlib.Path(m.group(1).strip()).is_file():incs.append(pathlib.Path(m.group(1).strip()))
 undefs=[]
 for f in [root/path]+incs:
  try:
   for n,line in enumerate(f.read_bytes().decode('latin1').split('\n'),1):
    if re.match(r'^\s*#\s*undef\s+NTVDM\b',line):undefs.append([str(f),n])
  except OSError:undefs.append([str(f),'unreadable'])
 host=[str(f) for f in incs if f.name.lower()=='host_def.h'];rec={'path':path,'exit':r.returncode,'source_sha256':hashlib.sha256((root/path).read_bytes()).hexdigest(),'included_files':len(incs),'host_def':host,'undef_ntvdm':undefs,'flags_include_ntvdm':bool(re.search(r'(?i)(?:/|-d)NTVDM(?:\s|=|$)',cmd))};print(path,'exit',r.returncode,'host_def',bool(host),'undefs',len(undefs),'flag',rec['flags_include_ntvdm'],flush=True);return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(run,targets))
(out/'include-trace.json').write_text(json.dumps(records,indent=2)+'\n');print('finished',len(records),'eligible',sum(r['exit']==0 and r['host_def'] and not r['undef_ntvdm'] and r['flags_include_ntvdm'] for r in records),flush=True)

