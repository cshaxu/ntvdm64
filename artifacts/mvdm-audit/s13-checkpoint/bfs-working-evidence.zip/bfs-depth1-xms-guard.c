#ifdef i386
#error DIVERGENCE MVDM-HOST-DIV-594: historical i386 XMS path is not selected
#else
SELECTED_PATH
#endif
