#line 83


typedef struct 
{
#if defined(CPU_40_STYLE) && defined(C_VID)
	/* DIVERGENCE MVDM-HOST-DIV-089: selected C-video EVID glue uses the
	 * exact IU32 offset/count contract below.  The historical ULONG carrier
	 * only matched it by 32-bit typedef coincidence. */
	IU32 (*b_read) IPT1(IU32, eaOff); LINE_MARK __LINE__
	IU32 (*w_read) IPT1(IU32, eaOff); LINE_MARK __LINE__
#else
#line 98
	IU32 (*b_read) IPT1(ULONG, offset); LINE_MARK __LINE__
	IU32 (*w_read) IPT1(ULONG, offset); LINE_MARK __LINE__
#endif
#ifndef	NO_STRING_OPERATIONS
#if defined(CPU_40_STYLE) && defined(C_VID)
#line 95
	void (*str_read) IPT3(IU8 *, dest, IU32, eaOff, IU32, count); LINE_MARK __LINE__
#else
#line 102
	void (*str_read) IPT3(IU8 *, dest, ULONG, offset, ULONG, count); LINE_MARK __LINE__
#endif
#endif	/* NO_STRING_OPERATIONS */
#line 105

} READ_POINTERS; END_MARK __LINE__
