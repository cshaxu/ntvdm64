

typedef struct 
{
#if defined(CPU_40_STYLE) && defined(C_VID)
	/* DIVERGENCE MVDM-HOST-DIV-089: selected C-video EVID glue uses the
	 * exact IU32 offset/count contract below.  The historical ULONG carrier
	 * only matched it by 32-bit typedef coincidence. */
	IU32 (*b_read) IPT1(IU32, eaOff);
	IU32 (*w_read) IPT1(IU32, eaOff);

#ifndef	NO_STRING_OPERATIONS
	void (*str_read) IPT3(IU8 *, dest, IU32, eaOff, IU32, count);
#endif	/* NO_STRING_OPERATIONS */
#else
	IU32 (*b_read) IPT1(ULONG, offset);
	IU32 (*w_read) IPT1(ULONG, offset);

#ifndef	NO_STRING_OPERATIONS
	void (*str_read) IPT3(IU8 *, dest, ULONG, offset, ULONG, count);
#endif	/* NO_STRING_OPERATIONS */
#endif

} READ_POINTERS;
