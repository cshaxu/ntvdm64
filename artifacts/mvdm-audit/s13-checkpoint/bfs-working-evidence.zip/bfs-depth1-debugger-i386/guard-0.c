#ifdef i386
#error DIVERGENCE MVDM-HOST-DIV-588: historical i386 debugger branch is not selected
#endif
int selected;
