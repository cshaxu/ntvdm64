import pathlib,re,json,hashlib,collections
root=pathlib.Path('.');q=json.load(open('build/t473-s13/bfs/baseline-and-queue.json'));specs={'src/mvdm-host/softpc.new/base/comms/com.c':[(599,630,630,637,631),(1634,1655,1664,2002,None)],'src/mvdm-host/softpc.new/base/system/timer.c':[(953,964,964,1025,964),(1640,1681,1681,1737,1681),(2247,2315,2315,2455,2310),(2396,2427,2427,2614,None)]}; records=[];prepared={};h=lambda b:hashlib.sha256(b).hexdigest();scratch=root/'build/t473-s13/bfs-ntvdm-before';scratch.mkdir(exist_ok=True)
def clean_text(s):return re.sub(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()) if m.group().startswith('/') else m.group(),s)
def bounds(lines,start):
 d=1;cut=None
 for i in range(start,len(lines)):
  m=re.match(r'^\s*#\s*(if|ifdef|ifndef|else|elif|endif)\b',lines[i])
  if not m:continue
  op=m.group(1)
  if op in ('if','ifdef','ifndef'):d+=1
  elif op=='endif':
   d-=1
   if d==0:return (cut if cut is not None else i),i
  elif d==1 and cut is None:cut=i
 raise ValueError(start)
for path,items in specs.items():
 p=root/path;b=p.read_bytes();m=next(f for f in q['files'] if f['path']==path);assert h(b)==m.get('working_sha256',m['current_sha256']);o=pathlib.Path(m['original']).read_bytes();assert h(o)==m['original_sha256']; lines=b.decode('latin1').split('\n');cl=clean_text(b.decode('latin1')).split('\n');ol=o.decode('latin1').split('\n');oc=clean_text(o.decode('latin1')).split('\n');iscrlf=b.count(b'\r\n')==b.count(b'\n') and b.count(b'\n')>0;cr='\r' if iscrlf else '';assert not (b'\r\n' in b and not iscrlf)
 (scratch/(p.stem+'-before.c')).write_bytes(b)
 for start,expectedcut,expectedend,orig,logical in items:
  assert cl[start-1].strip()=='#ifndef NTVDM';cut,end=bounds(cl,start);assert (cut+1,end+1)==(expectedcut,expectedend);assert oc[orig-1].strip()=='#ifndef NTVDM';ocut,oend=bounds(oc,orig)
  local='\n'.join(s.rstrip('\r') for s in lines[start:cut]).encode('latin1');original='\n'.join(s.rstrip('\r') for s in ol[orig:ocut]).encode('latin1');assert local.strip() and not local.lstrip().startswith(b'#error'); ids=dict(collections.Counter(re.findall(r'MVDM-HOST-DIV-\d+|OPENNT-HOST-\d+',local.decode('latin1'))));rec={'path':path,'before_sha256':h(b),'original':m['original'],'original_sha256':h(o),'local_arm_lines':[start,cut+1],'original_arm_lines':[orig,ocut+1],'removed_local_body_sha256':h(local),'original_body_sha256':h(original),'removed_local_body_lines':cut-start,'same_original_after_newlines':local==original,'subsumed_existing_markers':ids,'retained_sibling':cut!=end,'following_logical_line':logical,'status':'pending selected-path and negative verification'};records.append(rec)
 new=lines[:]
 for start,expectedcut,expectedend,orig,logical in sorted(items,reverse=True):
  marker='#error Excluded unsupported non-NTVDM '+('serial' if p.name=='com.c' else 'timer')+' profile'+cr
  # Replace only the current top-level arm; its sibling and closing directive stay intact.
  new[start:expectedcut-1]=[marker]
  removed=(expectedcut-start-1)-1;new_end=(expectedend-1)-removed
  if logical is not None:new.insert(new_end+1,'#line '+str(logical)+cr)
 prepared[path]='\n'.join(new).encode('latin1')
for path,b in prepared.items(): (root/path).write_bytes(b)
for r in records:r['after_sha256']=h(prepared[r['path']])
(root/'artifacts/mvdm-audit/s13-bfs-depth1-ntvdm-arms.json').write_text(json.dumps(records,indent=2)+'\n')
print('top-level arms replaced',len(records),'removed body lines',sum(r['removed_local_body_lines'] for r in records),'source files',len(prepared))
