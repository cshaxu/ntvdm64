import pathlib,re,json,subprocess,shutil,importlib.util,hashlib,concurrent.futures
root=pathlib.Path.cwd();out=root/'build/t473-s13/bfs-depth1-dbg-fixtures';out.mkdir(exist_ok=True);spec=importlib.util.spec_from_file_location('audit','build/t473-s13/bfs-live/audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit);env=audit.env_for('x86');cl=shutil.which('cl.exe',path=env.get('PATH',env.get('Path','')));jobs=[]
for dirname in ['msvc-x86-release/worker','msvc-x64-release/worker-reference-x86']:
 folder=root/'build/.ninja'/dirname;entries=json.loads(subprocess.check_output([str(audit.NINJA),'-C',str(folder),'-t','compdb'],text=True))
 for provider,fixtures in [('src/mvdm-host/dos/dem/demsrch.c',['tests/mvdm-host/dem_directory_reset_test.c']),('src/mvdm-host/dpmi32/int21map.c',['tests/observation/dpmi_pointer_trace.c','tests/observation/dpmi_ioctl_boundary.c'])]:
  es=[e for e in entries if e.get('file','').replace('\\','/').lower().endswith('/'+provider.lower())];assert len(es)==1
  for fixture in fixtures:jobs.append((folder,provider,fixture,es[0]))
def run(job):
 folder,provider,fixture,e=job;cmd=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1];cmd=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',cmd);cmd=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',cmd);src=e['file'];cmd=cmd.replace(src,str(root/fixture).replace('\\','/'));assert cmd!=e['command']; extra=' /DDPMI_TRACE_LOG=\\"O:/repos.hobby/ntvdm64/build/t473-s13/bfs-depth1-dbg-fixtures/trace.log\\"' if 'dpmi_' in fixture else '';r=subprocess.run('"'+cl+'" /Zs /showIncludes '+extra+' '+cmd,cwd=folder,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);txt=(r.stdout+r.stderr).decode('mbcs',errors='replace');incs=[]
 for line in txt.splitlines():
  m=re.search(r'(?i)including file:\s*(.*)$',line)
  if m and pathlib.Path(m.group(1).strip()).is_file():incs.append(pathlib.Path(m.group(1).strip()))
 defs=[]
 for f in [root/fixture]+incs:
  for n,line in enumerate(f.read_bytes().decode('latin1').split('\n'),1):
   if re.match(r'^\s*#\s*(?:define|undef)\s+DBG\b',line):defs.append([str(f),n,line.strip()])
 flags=re.findall(r'(?i)(?:/D|-D)DBG(?:=[^\s"]+)?',cmd+extra);rec={'fixture':fixture,'provider':provider,'graph':str(folder.relative_to(root)).replace('\\','/'),'exit':r.returncode,'fixture_sha256':hashlib.sha256((root/fixture).read_bytes()).hexdigest(),'provider_included':any(f.name.lower()==pathlib.Path(provider).name.lower() for f in incs),'includes':len(incs),'dbg_definitions':defs,'dbg_flags':flags,'errors':txt[-600:] if r.returncode else ''};print(fixture,folder.name,'exit',r.returncode,'provider',rec['provider_included'],'defs',len(defs),flush=True);return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(run,jobs))
(out/'trace.json').write_text(json.dumps(records,indent=2)+'\n');print('finished',len(records),'failures',sum(x['exit']!=0 for x in records),flush=True)
