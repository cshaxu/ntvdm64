#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-590: non-PROD branch is not selected
#endif
int selected;
