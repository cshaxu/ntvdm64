#ifdef DEBUG_OR_WOWPROFILE // define symbols for API profiling only (debugger extension)
#error Excluded unsupported WOW profiling configuration
#endif // WOWPROFILE
int selected;
