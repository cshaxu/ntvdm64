#ifdef WOWPROFILE  // for MSG profiling only (debugger extension)
#error Excluded unsupported WOW profiling configuration
#endif
int selected;
