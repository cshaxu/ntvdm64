#ifdef WOWPROFILE
#error Excluded unsupported WOW profiling configuration
#endif
int selected;
