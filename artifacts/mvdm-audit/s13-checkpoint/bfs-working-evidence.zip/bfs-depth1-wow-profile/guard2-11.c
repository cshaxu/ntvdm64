#ifdef DEBUG_OR_WOWPROFILE
#error Excluded unsupported WOW profiling configuration
#endif
int selected;
