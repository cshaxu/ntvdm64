#ifdef WOWPROFILE // For API profiling only (debugger extension)
#error Excluded unsupported WOW profiling configuration
#endif // WOWPROFILE
int selected;
