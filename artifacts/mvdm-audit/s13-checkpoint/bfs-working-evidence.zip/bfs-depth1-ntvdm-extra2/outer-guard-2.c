#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-591: non-NTVDM branch is not selected
#endif
int selected;
