import csv,hashlib,json,pathlib,re,subprocess,collections
root=pathlib.Path('.'); out=root/'build/t473-s13/bfs';out.mkdir(parents=True,exist_ok=True)
rows=list(csv.DictReader(open(root/'build/t473-s13/mirror-counts/files.csv',encoding='utf-8')))
rows=[r for r in rows if r['group'] in ('mvdm-host','non-mvdm') and pathlib.Path(r['path']).suffix.lower() in ('.c','.h','.cpp') and pathlib.Path(r['path']).is_file() and pathlib.Path(r['original']).is_file()]
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
manifest=[]; failures=[]; groups=[]
def parse(path,role):
 text=pathlib.Path(path).read_bytes().decode('latin1'); lines=text.split('\n'); logical=[]; cur=''; start=0
 for n,line in enumerate(lines,1):
  if not cur:start=n
  v=line.rstrip('\r\n')
  if v.endswith('\\'):cur+=v[:-1];continue
  logical.append((start,cur+v));cur=''
 if cur:failures.append([path,role,start,'dangling continuation'])
 inblock=False; stack=[]
 for n,line in logical:
  clean=[];i=0;quote=None
  while i<len(line):
   c=line[i]; nxt=line[i:i+2]
   if inblock:
    if nxt=='*/':inblock=False;i+=2
    else:i+=1
    continue
   if quote:
    clean.append(c)
    if c=='\\' and i+1<len(line):clean.append(line[i+1]);i+=2;continue
    if c==quote:quote=None
    i+=1;continue
   if nxt=='/*':inblock=True;clean.append(' ');i+=2;continue
   if nxt=='//':break
   if c in ('\"',"'"):quote=c
   clean.append(c);i+=1
  m=re.match(r'^\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b(.*)$',''.join(clean))
  if not m:continue
  op,arg=m.group(1),m.group(2).strip()
  if op in ('if','ifdef','ifndef'):
   group={'path':path,'role':role,'line':n,'depth':len(stack)+1,'parent':stack[-1]['line'] if stack else None,'arms':[{'kind':op,'expression':arg,'line':n,'status':'unreviewed'}]};groups.append(group);stack.append(group)
  elif op in ('elif','else'):
   if not stack or any(x['kind']=='else' for x in stack[-1]['arms']):failures.append([path,role,n,'unmatched or post-else '+op]);continue
   stack[-1]['arms'].append({'kind':op,'expression':arg,'line':n,'status':'unreviewed'})
  elif not stack:failures.append([path,role,n,'unmatched endif'])
  else:stack.pop()
 if stack or inblock:failures.append([path,role,len(lines),'unclosed condition/comment'])
for r in rows:
 d={'path':r['path'],'current_sha256':digest(r['path']),'original':r['original'],'original_sha256':digest(r['original']),'pinned_expected_sha256':r['original_sha256']};d['original_matches_pinned']=d['original_sha256'].lower()==d['pinned_expected_sha256'].lower();manifest.append(d)
 parse(r['path'],'current');parse(r['original'],'original')
base={'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'git_status_sha256':hashlib.sha256(subprocess.check_output(['git','status','--porcelain=v1','-z'])).hexdigest(),'files':manifest,'parse_failures':failures,'groups':groups}
(out/'baseline-and-queue.json').write_text(json.dumps(base,ensure_ascii=True,indent=2),encoding='utf-8')
for role in ('current','original'):
 c=collections.Counter(g['depth'] for g in groups if g['role']==role);print(role,'groups',sum(c.values()),'by_depth',dict(sorted(c.items())))
print('files',len(manifest),'original_hash_mismatches',sum(not x['original_matches_pinned'] for x in manifest),'parse_failures',len(failures))
