#include "insignia.h"
#include "host_def.h"
/*
 * SoftPC Version 3.0
 *
 * Title	: com.c
 *
 * Description	: Asynchronous Adaptor I/O functions.
 *
 * Notes	: Refer to the PC-XT Tech Ref Manual Section 1-185
 *		  For a detailed description of the Asynchronous Adaptor Card.
 *
 */

#ifdef SCCSID
#error DIVERGENCE MVDM-HOST-DIV-518: SCCSID identification strings are not selected; see mirror register.
#endif

#ifdef SEGMENTATION
#error Excluded unsupported SEGMENTATION configuration





#endif

/*
 *    O/S include files.
 */
#include <stdio.h>
#include <ctype.h>
#if defined(NTVDM) && defined(MONITOR)
#error DIVERGENCE MVDM-HOST-DIV-541: unselected compound host branch; see mirror register.
#endif
#include TypesH
#include StringH

/*
 * SoftPC include files
 */
#include "xt.h"
#include CpuH
#include "sas.h"
#include "bios.h"
#include "ios.h"
#include "rs232.h"
#include "trace.h"
#include "error.h"
#include "config.h"
#include "host_com.h"
#include "ica.h"
#include "debug.h"
#include "timer.h"
#include "quick_ev.h"
#include "idetect.h"
#include "ckmalloc.h"
#ifdef GISP_CPU
#error DIVERGENCE MVDM-HOST-DIV-522: GISP_CPU platform branch is not selected; see mirror register.
#endif /* GISP_CPU */

LOCAL UTINY selectBits[4] = { 0x1f, 0x3f, 0x7f, 0xff } ;
/*
 * =====================================================================
 * The rs232 adaptor state
 * =====================================================================
 */

/*
 * batch_size, current_count 
 *	The IRET_HOOKS parameters batch_size and curr_count are used to prevent
 *	the number of interrupts that are emulated in one batch getting too
 *	large. When we reach the batch size we'll unhook the interrupt, and
 *	wait a while.
 * batch_running, qev_running
 *	These variables are used to prevent multiple quick events or batches
 *	running at once on a single adapter.
 */
static struct ADAPTER_STATE
{
	BUFFER_REG tx_buffer;
	BUFFER_REG rx_buffer;
	DIVISOR_LATCH divisor_latch;
	INT_ENABLE_REG int_enable_reg;
	INT_ID_REG int_id_reg;
	LINE_CONTROL_REG line_control_reg;
	MODEM_CONTROL_REG modem_control_reg;
	LINE_STATUS_REG line_status_reg;
	MODEM_STATUS_REG modem_status_reg;
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration





#endif
	half_word scratch;      /* scratch register */

	int break_state;        /* either OFF or ON */
	int loopback_state;     /* either OFF or ON */
	int dtr_state;          /* either OFF or ON */
	int rts_state;          /* either OFF or ON */
	int out1_state;         /* either OFF or ON */
	int out2_state;         /* either OFF or ON */

	int receiver_line_status_interrupt_state;
	int data_available_interrupt_state;
	int tx_holding_register_empty_interrupt_state;
	int modem_status_interrupt_state;
	int hw_interrupt_priority;
	int com_baud_ind;
	int had_first_read;
#ifdef IRET_HOOKS
#error DIVERGENCE MVDM-HOST-DIV-525: IRET_HOOKS platform branch is not selected; see mirror register.
#endif /* IRET_HOOKS */
#ifdef NTVDM
    MODEM_STATUS_REG last_modem_status_value;
    int modem_status_changed;
#endif
} adapter_state[NUM_SERIAL_PORTS];


#ifdef NTVDM
#define MODEM_STATE_CHANGE()	asp->modem_status_changed = TRUE;
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif


#ifdef IRET_HOOKS
#error DIVERGENCE MVDM-HOST-DIV-525: IRET_HOOKS platform branch is not selected; see mirror register.
#endif /* IRET_HOOKS */

/*
 * For synchronisation of adapter input.
 * Note this code is essential for the VMS equivalent of the async
 * event manager.  Removing it causes characters to be lost on reception.
 */
static int com_critical[NUM_SERIAL_PORTS];
#define is_com_critical(adapter)	(com_critical[adapter] != 0)
#define com_critical_start(adapter)	(++com_critical[adapter])
#define com_critical_end(adapter)	(--com_critical[adapter])
#define com_critical_reset(adapter)	(com_critical[adapter] = 0)


/*
 * Used to determine whether a flush input is needed for a LCR change
 */
static LINE_CONTROL_REG LCRFlushMask;

/*
 *	Please note that the following arrays have been made global in order
 *	that they can be accessed from some SUN_VA code. Please do not make
 *	them static.
 */

#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration
#endif

/*
 * The delay needed in microseconds between receiving 2 characters
 * note this time is about 10% less than the time for actual reception.
 *
 * These delays have been heavily fudged and are now based on the idea that
 * most of the comms interrupt handlers can handle 9600 baud.  So as a
 * result the delays between 2 characters are now always set for 9600 baud.
 * Also note the delays of the faster baud rates have been decreased to
 * 1/2 of original delays, again this is to try to empty the host buffers
 * quickly enough to avoid buffer overflows.
 * NB these figures are heuristic.
 *
 * Finally it may be possible that the transmit delays will have to
 * be similarly fudged.
 */
unsigned long RX_delay[] =
{
	34, /* 115200 baud */
	67, /* 57600 baud */
	103, /* 38400 baud */
	900, /* 19200 baud */
	900, /* 9600 baud */
	900, /* 7200 baud */
	900, /* 4800 baud */
	900, /* 3600 baud */
	900, /* 2400 baud */
	900, /* 2000 baud */
	900, /* 1800 baud */
	900, /* 1200 baud */
	900, /* 600 baud */
	900, /* 300 baud */
	900, /* 150 baud */
	900, /* 134 baud */
	900, /* 110 baud */
	900, /* 75 baud */
	900  /* 50 baud */
};

/*
 * the delay needed in microseconds between transmitting 2 characters
 * note this time is about 10% more than the time for actual transmission.
 */
unsigned long TX_delay[] =
{
	83, /* 115200 baud */
	165, /* 57600 baud */
	253, /* 38400 baud */
	495, /* 19200 baud */
	1100, /* 9600 baud */
	1375, /* 7200 baud */
	2063, /* 4800 baud */
	2750, /* 3600 baud */
	4125, /* 2400 baud */
	5042, /* 2000 baud */
	5500, /* 1800 baud */
	8250, /* 1200 baud */
	16500, /* 600 baud */
	33000, /* 300 baud */
	66000, /* 150 baud */
	73920, /* 134 baud */
	89980, /* 110 baud */
	132000, /* 75 baud */
	198000  /* 50 baud */
};

#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif /* !PROD */
/*
 * =====================================================================
 * Other variables
 * =====================================================================
 */

#if !defined(PROD) || defined(SHORT_TRACE)
static char buf[80];    /* Buffer for diagnostic prints */
#endif /* !PROD || SHORT_TRACE */

#ifdef PS_FLUSHING
#error DIVERGENCE MVDM-HOST-DIV-530: PS_FLUSHING platform branch is not selected; see mirror register.
#endif	/* PS_FLUSHING */

/* Control TX pacing */
IBOOL tx_pacing_enabled = FALSE;

/*
 * =====================================================================
 * Static forward declarations
 * =====================================================================
 */
static void raise_rls_interrupt IPT1(struct ADAPTER_STATE *, asp);
static void raise_rda_interrupt IPT1(struct ADAPTER_STATE *, asp);
static void raise_ms_interrupt IPT1(struct ADAPTER_STATE *,asp);
static void raise_thre_interrupt IPT1(struct ADAPTER_STATE *, asp);
static void generate_iir IPT1(struct ADAPTER_STATE *, asp);
static void raise_interrupt IPT1(struct ADAPTER_STATE *, asp);
static void clear_interrupt IPT1(struct ADAPTER_STATE *, asp);
static void com_flush_input IPT1(int, adapter);
static void com_send_not_finished IPT1(int, adapter);
#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
void   com_inb IPT2(io_addr, port, half_word *, value);
void   com_outb IPT2(io_addr, port, half_word, value);
void   com_recv_char IPT1(int, adapter);
GLOBAL void recv_char IPT1(long, adapter);
void   com_modem_change IPT1(int, adapter);
static void modem_change IPT1(int, adapter);
static void set_recv_char_status IPT1(struct ADAPTER_STATE *, asp);
static void set_xmit_char_status IPT1(struct ADAPTER_STATE *, asp);
static void set_break IPT1(int, adapter);
static void set_baud_rate IPT1(int, adapter);
static void set_line_control IPT2(int, adapter, int, value);
static void set_dtr IPT1(int, adapter);
static void set_rts IPT1(int, adapter);
static void set_out1 IPT1(int, adapter);
static void set_out2 IPT1(int, adapter);
static void set_loopback IPT1(int, adapter);
static void super_trace IPT1(char *, string);
void   com1_flush_printer IPT0();
void   com2_flush_printer IPT0();
static void com_reset IPT1(int, adapter);
GLOBAL VOID com_init IPT1(int, adapter);
void   com_post IPT1(int, adapter);
void   com_close IPT1(int, adapter);
LOCAL void next_batch IPT1(long, l_adapter);
#ifdef NTVDM
static void lsr_change(struct ADAPTER_STATE *asp, unsigned int error);
#ifdef FIFO_ON
#error DIVERGENCE MVDM-HOST-DIV-525: FIFO_ON platform branch is not selected; see mirror register.
#endif
#endif

/*
 * =====================================================================
 * Subsidiary functions - for interrupt emulation
 * =====================================================================
 */

static void raise_rls_interrupt IFN1(struct ADAPTER_STATE *, asp)
{
	/*
	 * Follow somewhat dubious advice on Page 1-188 of XT Tech Ref
	 * regarding the adapter card sending interrupts to the system.
	 * Apparently confirmed by the logic diagram.
	 */
	if ( asp->modem_control_reg.bits.OUT2 == 0 )
		return;
	
	/*
	 * Check if receiver line status interrupt is enabled
	 */
	if ( asp->int_enable_reg.bits.rx_line == 0 )
		return;
	
	/*
	 * Raise interrupt
	 */
	raise_interrupt(asp);
	asp->receiver_line_status_interrupt_state = ON;
}

static void raise_rda_interrupt IFN1(struct ADAPTER_STATE *, asp)
{
	if (( asp->modem_control_reg.bits.OUT2 == 0 ) &&
		( asp->loopback_state == OFF ))
		return;
	
	/*
	 * Check if data available interrupt is enabled
	 */
	if ( asp->int_enable_reg.bits.data_available == 0 )
		return;
	
	/*
	 * Raise interrupt
	 */
	raise_interrupt(asp);
	asp->data_available_interrupt_state = ON;
}

static void raise_ms_interrupt IFN1(struct ADAPTER_STATE *, asp)
{
	if ( asp->modem_control_reg.bits.OUT2 == 0 )
		return;
	
	/*
	 * Check if modem status interrupt is enabled
	 */
	if ( asp->int_enable_reg.bits.modem_status == 0 )
		return;
	
	/*
	 * Raise interrupt
	 */
	raise_interrupt(asp);
	asp->modem_status_interrupt_state = ON;
}

static void raise_thre_interrupt IFN1(struct ADAPTER_STATE *, asp)
{
	if ( asp->modem_control_reg.bits.OUT2 == 0 )
		return;
	
	/*
	 * Check if tx holding register empty interrupt is enabled
	 */
	if ( asp->int_enable_reg.bits.tx_holding == 0 )
		return;
	
	/*
	 * Raise interrupt
	 */
	raise_interrupt(asp);
	asp->tx_holding_register_empty_interrupt_state = ON;
}

static void generate_iir IFN1(struct ADAPTER_STATE *, asp)
{
	/*
	 * Set up interrupt identification register with highest priority
	 * pending interrupt.
	 */
	
	if ( asp->receiver_line_status_interrupt_state == ON )
	{
		asp->int_id_reg.bits.interrupt_ID = RLS_INT;
		asp->int_id_reg.bits.no_int_pending = 0;
	}
	else if ( asp->data_available_interrupt_state == ON )
	{
		asp->int_id_reg.bits.interrupt_ID = RDA_INT;
		asp->int_id_reg.bits.no_int_pending = 0;
	}
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration




#endif
	else if ( asp->tx_holding_register_empty_interrupt_state == ON )
	{
		asp->int_id_reg.bits.interrupt_ID = THRE_INT;
		asp->int_id_reg.bits.no_int_pending = 0;
	}
	else if ( asp->modem_status_interrupt_state == ON )
	{
		asp->int_id_reg.bits.interrupt_ID = MS_INT;
		asp->int_id_reg.bits.no_int_pending = 0;
	}
	else
	{
		/* clear interrupt */
		asp->int_id_reg.bits.no_int_pending = 1;
		asp->int_id_reg.bits.interrupt_ID = 0;
	}
}

static void raise_interrupt IFN1(struct ADAPTER_STATE *, asp)
{
	/*
	 * Make sure that some thing else has not raised an interrupt
	 * already.
	 */
	if ( ( asp->receiver_line_status_interrupt_state      == OFF )
	&&   ( asp->data_available_interrupt_state            == OFF )
	&&   ( asp->tx_holding_register_empty_interrupt_state == OFF )
	&&   ( asp->modem_status_interrupt_state              == OFF ) 
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration
#endif
       )
	{
#ifndef DELAYED_INTS
		ica_hw_interrupt(0, asp->hw_interrupt_priority, 1);
#else
		ica_hw_interrupt_delay(0, asp->hw_interrupt_priority, 1,
			HOST_COM_INT_DELAY);
#endif
	}
}

static void clear_interrupt IFN1(struct ADAPTER_STATE *, asp)
{
	/*
	 * Make sure that some thing else has not raised an interrupt
	 * already.  If so then we cant drop the line.
	 */
	if ( ( asp->receiver_line_status_interrupt_state      == OFF )
	&&   ( asp->data_available_interrupt_state            == OFF )
	&&   ( asp->tx_holding_register_empty_interrupt_state == OFF )
	&&   ( asp->modem_status_interrupt_state              == OFF ) 
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration
#endif
       )
	{
		ica_clear_int(0, asp->hw_interrupt_priority);
	}
}
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration


















#endif



/*
 * =====================================================================
 * The Adaptor functions
 * =====================================================================
 */

static void com_flush_input IFN1(int, adapter)
{
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	int finished, error_mask;
	long input_ready = 0; 

	sure_note_trace1(RS232_VERBOSE, "flushing the input for COM%c",
		adapter+'1');
	finished=FALSE;
	while(!finished) 
	{
		host_com_ioctl(adapter, HOST_COM_INPUT_READY,
			(long)&input_ready);
		if (input_ready) 
		{
			host_com_read(adapter, (UTINY *)&asp->rx_buffer,
				&error_mask);
		}
		else
		{
			finished=TRUE;
		}
	}
	set_xmit_char_status(asp);
}

static void com_send_not_finished IFN1(int, adapter)
{
	struct ADAPTER_STATE *asp = &adapter_state[adapter];

	asp->line_status_reg.bits.tx_holding_empty=0;
	asp->line_status_reg.bits.tx_shift_empty=0;
}


#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif


void com_inb IFN2(io_addr, port, half_word *, value)
{
	int adapter = adapter_for_port(port);
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	long input_ready = 0;
	boolean adapter_was_critical;

#ifdef NTVDM
    if((port & 0x7) != RS232_MSR) host_com_lock(adapter);
#endif /* NTVDM */

	switch(port & 0x7)
	{
	case RS232_TX_RX:
		IDLE_comlpt();
		if (asp->line_control_reg.bits.DLAB == 0)
		{
			/*
			 * Read of rx buffer
			 */
#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#else /* NTVDM is defined */
            //Flushing on first read removes characters from
            //the communications system that are needed !!!!
            //This assumes that the first read from the comms
            //system will return one character only. This is
            //a false assumption under NT windows.
#endif /* !NTVDM */
			*value = asp->rx_buffer;
		
			adapter_was_critical =
				(asp->line_status_reg.bits.data_ready == 1);
		
			asp->line_status_reg.bits.data_ready = 0;
			asp->data_available_interrupt_state = OFF;
			clear_interrupt(asp);

			if ( asp->loopback_state == OFF )
			{
				/*
				 * Adapter out of critical region,
				 * check for further input.  For IRET_HOOKS
				 * we don't need to do this, as receipt
				 * of the next character is kicked off
				 * by the IRET, however we do something
				 * else instead.  If this is the first
				 * character of a batch, we kick off a quick
				 * event for what will eventually be the
				 * start of the next batch (assuming there
				 * isn't already a quick event running).
				 * In any case we increment the count of
				 * characters in this batch.
				 */
				if (adapter_was_critical)
				{
#ifdef NTVDM
#ifdef FIFO_ON
#error DIVERGENCE MVDM-HOST-DIV-525: FIFO_ON platform branch is not selected; see mirror register.
#else /* !FIFO_ON */
                    host_com_char_read(adapter,
                    asp->int_enable_reg.bits.data_available
                    );
#endif /* !FIFO_ON */
#endif /* NTVDM */

#ifndef NTVDM
#ifdef IRET_HOOKS
#error Excluded unsupported IRET_HOOKS configuration














#else /* IRET_HOOKS */
					host_com_ioctl(adapter, HOST_COM_INPUT_READY,
						(long)&input_ready);
					if (input_ready)
#ifdef DELAYED_INTS
						recv_char((long)adapter);
#else
						add_q_event_t(recv_char,
							RX_delay[asp->com_baud_ind],
							adapter);
#endif /* DELAYED_INTS */
					else
						com_critical_reset(adapter);
#endif /* IRET_HOOKS */
#endif /* !NTVDM */
				}


			}
			else
			{
				set_xmit_char_status(asp);
			}
#ifdef IRET_HOOKS
#error DIVERGENCE MVDM-HOST-DIV-525: IRET_HOOKS platform branch is not selected; see mirror register.
#endif /* IRET_HOOKS */
		}
		else
			*value = asp->divisor_latch.byte.LSByte;
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
																		
	case RS232_IER:
		if (asp->line_control_reg.bits.DLAB == 0)
			*value = asp->int_enable_reg.all;
		else
			*value = asp->divisor_latch.byte.MSByte;
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;

	case RS232_IIR:
		generate_iir(asp);
		*value = asp->int_id_reg.all;

		if ( asp->int_id_reg.bits.interrupt_ID == THRE_INT )
		{
			asp->tx_holding_register_empty_interrupt_state = OFF;
			clear_interrupt(asp);
		}

#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
	
	case RS232_LCR:
#ifdef NTVDM
        /* Before returning the information on the current configuation
           of the serial link make sure the System comms port is open */

        {
            extern int host_com_open(int adapter);

            host_com_open(adapter);
        }
#endif


		*value = asp->line_control_reg.all;
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
	
	case RS232_MCR:
		*value = asp->modem_control_reg.all;
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
	
	case RS232_LSR:
		*value = asp->line_status_reg.all;
	
		asp->line_status_reg.bits.overrun_error = 0;
		asp->line_status_reg.bits.parity_error = 0;
		asp->line_status_reg.bits.framing_error = 0;
		asp->line_status_reg.bits.break_interrupt = 0;
		asp->receiver_line_status_interrupt_state = OFF;
		clear_interrupt(asp);
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration
#endif
	
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
	
	case RS232_MSR:

#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#else
		if(!asp->modem_status_changed && asp->loopback_state == OFF)
		{
		    *value = asp->last_modem_status_value.all;
		}
		else
		{
		    host_com_lock(adapter);
		    asp->modem_status_changed = TRUE;

		    /* if the adapter is not opened yet, just return POST
		       value.
		     */
		    if (host_com_check_adapter(adapter)) {
			if(asp->loopback_state == OFF)
			{
			    com_modem_change(adapter);
			    asp->modem_status_changed = FALSE;

			}
			else
			{
			    asp->modem_status_reg.bits.CTS = asp->modem_control_reg.bits.RTS;
			    asp->modem_status_reg.bits.DSR = asp->modem_control_reg.bits.DTR;
			    asp->modem_status_reg.bits.RI = asp->modem_control_reg.bits.OUT1;
			    asp->modem_status_reg.bits.RLSD = asp->modem_control_reg.bits.OUT2;
			}
		    }

		    *value = asp->modem_status_reg.all;

		    asp->modem_status_reg.bits.delta_CTS = 0;
		    asp->modem_status_reg.bits.delta_DSR = 0;
		    asp->modem_status_reg.bits.delta_RLSD = 0;
		    asp->modem_status_reg.bits.TERI = 0;
		    asp->modem_status_interrupt_state = OFF;
		    host_com_msr_callback (adapter, asp->modem_status_reg.all);
		    clear_interrupt(asp);
		    asp->last_modem_status_value.all = asp->modem_status_reg.all;
		    host_com_unlock(adapter);
		}
#endif /* ifndef NTVDM */


#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;

/*
 * Scratch register.  Just output the value stored.
 */
	case RS232_SCRATCH:
		*value = asp->scratch;
		break;
	
	}

#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif

#ifdef NTVDM
	if((port & 0x7) != RS232_MSR) host_com_unlock(adapter);
#endif NTVDM
}


void com_outb IFN2(io_addr, port, half_word, value)
{
	int adapter = adapter_for_port(port);
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	int	i;

#ifdef NTVDM
	host_com_lock(adapter);
#endif NTVDM


#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
	
	switch(port & 0x7)
	{
	case RS232_TX_RX:
		IDLE_comlpt();
		if (asp->line_control_reg.bits.DLAB == 0)
		{
			/*
			 * Write char from tx buffer
			 */
			asp->tx_holding_register_empty_interrupt_state = OFF;
			clear_interrupt(asp);
			asp->tx_buffer = value;
			asp->line_status_reg.bits.tx_holding_empty = 0;
			asp->line_status_reg.bits.tx_shift_empty = 0;
			if ( asp->loopback_state == OFF )
			{
#ifdef PS_FLUSHING
#error DIVERGENCE MVDM-HOST-DIV-530: PS_FLUSHING platform branch is not selected; see mirror register.
#endif	/* PS_FLUSHING */
				host_com_write(adapter, asp->tx_buffer);
#if defined (DELAYED_INTS) || defined (NTVDM)
				set_xmit_char_status(asp);
#else
					if(tx_pacing_enabled) 
						add_q_event_t(do_wait_on_send,
					            TX_delay[asp->com_baud_ind], adapter);
					else
						do_wait_on_send(adapter);

#endif /* DELAYED_INTS || NTVDM */
#ifdef PS_FLUSHING
#error DIVERGENCE MVDM-HOST-DIV-530: PS_FLUSHING platform branch is not selected; see mirror register.
#endif	/* PS_FLUSHING */
			}
			else
			{	/* Loopback case requires masking off */
				/* of bits based upon word length.    */
				asp->rx_buffer = asp->tx_buffer & selectBits[asp->line_control_reg.bits.word_length] ;
				set_xmit_char_status(asp);
				set_recv_char_status(asp);
			}
		}
		else
		{
			asp->divisor_latch.byte.LSByte = value;
#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
		}
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
																		
	case RS232_IER:
		if (asp->line_control_reg.bits.DLAB == 0)
		{
#ifdef NTVDM
            int org_da = asp->int_enable_reg.bits.data_available;
#endif
			asp->int_enable_reg.all = value & 0xf;
			/*
			 * Kill off any pending interrupts for those items
			 * which are set now as disabled
			 */
			if ( asp->int_enable_reg.bits.data_available == 0 )
				asp->data_available_interrupt_state = OFF;
			if ( asp->int_enable_reg.bits.tx_holding == 0 )
				asp->tx_holding_register_empty_interrupt_state =
					OFF;
			if ( asp->int_enable_reg.bits.rx_line == 0 )
				asp->receiver_line_status_interrupt_state = OFF;
			if ( asp->int_enable_reg.bits.modem_status == 0 )
				asp->modem_status_interrupt_state = OFF;
			
			/*
			 * Check for immediately actionable interrupts
			 * If you change these, change the code for out2 as well.
			 */
			if ( asp->line_status_reg.bits.data_ready == 1 )
				raise_rda_interrupt(asp);
			if ( asp->line_status_reg.bits.tx_holding_empty == 1 )
				raise_thre_interrupt(asp);

			/* lower int line if no outstanding interrupts */
			clear_interrupt(asp);

#ifdef NTVDM
		       // Inform the host interface if the status of the
		       // data available interrupt has changed

		       if(org_da != asp->int_enable_reg.bits.data_available)
		       {
			       host_com_da_int_change(adapter,
					   asp->int_enable_reg.bits.data_available,
					   asp->line_status_reg.bits.data_ready);
		       }
#endif /* NTVDM */
		}
		else
		{
			asp->divisor_latch.byte.MSByte = value;
#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif /* NTVDM */
		}
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
		
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration


























#else /* !(NTVDM && FIFO_ON) */
	case RS232_IIR:
		/* 
		 * Essentially a READ ONLY register
		 */
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
#endif /* NTVDM && FIFO_ON */

	case RS232_LCR:
#ifdef NTVDM
        /* The NT host code attempts to distinguish between applications
           that probe the UART and those that use it. Probes of the UART
           will not cause the systems comms port to be opened. The NT
           host code inherits the line settings from NT when the system
           comms port is opened. Therefore before an application reads
           or writes to the divisor bytes or the LCR the system
           comms port must be opened. This prevents the application
           reading incorrect values for the divisor bytes and writes
           to the divisor bytes getting overwritten by the system
           defaults. */

        {
            extern int host_com_open(int adapter);

            host_com_open(adapter);
        }
#endif /* NTVDM */

		if ((value & LCRFlushMask.all)
		!= (asp->line_control_reg.all & LCRFlushMask.all))
			com_flush_input(adapter);

		set_line_control(adapter, value);
		set_break(adapter);
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
		
	case RS232_MCR:
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
		/*
		 * Optimisation - DOS keeps re-writing this register
		 */
		if ( asp->modem_control_reg.all == value )
			break;
		
		asp->modem_control_reg.all = value;
		asp->modem_control_reg.bits.pad = 0;

		/* Must be called before set_dtr */
		set_loopback(adapter);
		set_dtr(adapter);
		set_rts(adapter);
		set_out1(adapter);
		set_out2(adapter);
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
		
	case RS232_LSR:
		i = asp->line_status_reg.bits.tx_shift_empty;   /* READ ONLY */
		asp->line_status_reg.all = value;
		asp->line_status_reg.bits.tx_shift_empty = i;
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		break;
		
	case RS232_MSR:
		/*
		 * Essentially a READ ONLY register.
		 */
#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
		/* DrDOS writes to this reg after setting int on MSR change
		 * and expects to get an interrupt back!!! So we will oblige.
		 * Writing to this reg only seems to affect the delta bits 
		 * (bits 0-3) of the reg.
		 */
		if ((value & 0xf) != (asp->modem_status_reg.all & 0xf))
		{
			asp->modem_status_reg.all &= 0xf0;
			asp->modem_status_reg.all |= value & 0xf;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			if (asp->loopback_state == OFF)
				raise_ms_interrupt(asp);

			MODEM_STATE_CHANGE();
		}
		break;

/*
 * Scratch register.  Just store the value.
 */
	case RS232_SCRATCH:
		asp->scratch = value;
		break;
	
	}


#ifdef NTVDM
	host_com_unlock(adapter);
#endif
}


#ifdef IRET_HOOKS
#error Excluded unsupported IRET_HOOKS configuration















































































































#endif /* of ifdef IRET_HOOKS */

/*
 * =====================================================================
 * Subsidiary functions - for transmitting characters
 * =====================================================================
 */

#ifdef  NTVDM
// This code has been added for the MS project!!!!!!!


void com_recv_char(int adapter)
{
    struct ADAPTER_STATE *asp = &adapter_state[adapter];
    int error;

#ifdef FIFO_ON
#error DIVERGENCE MVDM-HOST-DIV-525: FIFO_ON platform branch is not selected; see mirror register.
#endif

    {
    error = 0;
    host_com_read(adapter, (char *)&asp->rx_buffer, &error);
    if (error != 0)
    {
        lsr_change(asp, error);
                raise_rls_interrupt(asp);
        }
    set_recv_char_status(asp);
    }
}
#ifdef FIFO_ON
#error DIVERGENCE MVDM-HOST-DIV-525: FIFO_ON platform branch is not selected; see mirror register.
#endif

#else /* NTVDM */
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif /* NTVDM */

/*
 * BCN 2151 - recv_char must use long param to match add_event function prototype
 */
GLOBAL void 
recv_char IFN1(long, adapt_long)
{
	int adapter = adapt_long;

	/*
	 * Character available on input device, read char, format char
	 * checking for parity and overrun errors, raise the appropriate
	 * interrupt.
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	int error_mask = 0;
	
	host_com_read(adapter, (UTINY *)&asp->rx_buffer, &error_mask);
	
	if (error_mask)
	{
		/*
		 * Set line status register and raise line status interrupt
		 */
		if (error_mask & HOST_COM_OVERRUN_ERROR)
			asp->line_status_reg.bits.overrun_error = 1;
		
		if (error_mask & HOST_COM_FRAMING_ERROR)
			asp->line_status_reg.bits.framing_error = 1;
		
		if (error_mask & HOST_COM_PARITY_ERROR)
			asp->line_status_reg.bits.parity_error = 1;
		
		if (error_mask & HOST_COM_BREAK_RECEIVED)
			asp->line_status_reg.bits.break_interrupt = 1;
		
		raise_rls_interrupt(asp);
	}
	
	set_recv_char_status(asp);
	
#ifdef DOCUMENTATION
#error DIVERGENCE MVDM-HOST-DIV-529: DOCUMENTATION platform branch is not selected; see mirror register.
#endif
}
#ifdef NTVDM
static void lsr_change(struct ADAPTER_STATE *asp, unsigned int new_lsr)
{
    if (new_lsr & HOST_COM_OVERRUN_ERROR)
    asp->line_status_reg.bits.overrun_error = 1;
    if (new_lsr & HOST_COM_FRAMING_ERROR)
    asp->line_status_reg.bits.framing_error = 1;
    if (new_lsr & HOST_COM_PARITY_ERROR)
    asp->line_status_reg.bits.parity_error = 1;
    if (new_lsr & HOST_COM_BREAK_RECEIVED)
    asp->line_status_reg.bits.break_interrupt = 1;
/* we have no control of serial driver fifo enable/disabled states
   we may receive a fifo error even the application doesn't enable it.
   fake either framing or parity error
*/
    if (new_lsr & HOST_COM_FIFO_ERROR)
#ifdef FIFO_ON
#error DIVERGENCE MVDM-HOST-DIV-525: FIFO_ON platform branch is not selected; see mirror register.
#else
    if (asp->line_control_reg.bits.parity_enabled == PARITYENABLE_OFF)
        asp->line_status_reg.bits.framing_error = 1;
    else
        asp->line_status_reg.bits.parity_error = 1;
#endif

}

void com_lsr_change(int adapter)
{
    int new_lsr;
    struct ADAPTER_STATE *asp = &adapter_state[adapter];

    new_lsr = -1;
    host_com_ioctl(adapter, HOST_COM_LSR, (long)&new_lsr);
    if (new_lsr !=  -1)
    lsr_change(asp, new_lsr);
}

#endif /* NTVDM */

/*
 * One of the modem control input lines has changed state
 */
void com_modem_change IFN1(int, adapter)
{
	modem_change(adapter);
}

static void modem_change IFN1(int, adapter)
{
	/*
	 * Update the modem status register after a change to one of the
	 * modem control input lines
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	long modem_status = 0;
	int cts_state, dsr_state, rlsd_state, ri_state;
	
	if (asp->loopback_state == OFF)
	{
		/* get current modem input state */
		host_com_ioctl(adapter, HOST_COM_MODEM, (long)&modem_status);
		cts_state  = (modem_status & HOST_COM_MODEM_CTS)  ? ON : OFF;
		dsr_state  = (modem_status & HOST_COM_MODEM_DSR)  ? ON : OFF;
		rlsd_state = (modem_status & HOST_COM_MODEM_RLSD) ? ON : OFF;
		ri_state   = (modem_status & HOST_COM_MODEM_RI)   ? ON : OFF;
		
		/*
		 * Establish CTS state
		 */
		switch(change_state(cts_state, asp->modem_status_reg.bits.CTS))
		{
		case ON:
			asp->modem_status_reg.bits.CTS = ON;
			asp->modem_status_reg.bits.delta_CTS = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
			MODEM_STATE_CHANGE();
			break;
		
		case OFF:
			asp->modem_status_reg.bits.CTS = OFF;
			asp->modem_status_reg.bits.delta_CTS = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
			MODEM_STATE_CHANGE();
			break;
		
		case LEAVE_ALONE:
			break;
		}
		
		/*
		 * Establish DSR state
		 */
		switch(change_state(dsr_state, asp->modem_status_reg.bits.DSR))
		{
		case ON:
			asp->modem_status_reg.bits.DSR = ON;
			asp->modem_status_reg.bits.delta_DSR = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
			MODEM_STATE_CHANGE();
			break;
		
		case OFF:
			asp->modem_status_reg.bits.DSR = OFF;
			asp->modem_status_reg.bits.delta_DSR = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
			MODEM_STATE_CHANGE();
			break;
		
		case LEAVE_ALONE:
			break;
		}
		
		/*
		 * Establish RLSD state
		 */
		switch(change_state(rlsd_state,
			asp->modem_status_reg.bits.RLSD))
		{
		case ON:
			asp->modem_status_reg.bits.RLSD = ON;
			asp->modem_status_reg.bits.delta_RLSD = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
			MODEM_STATE_CHANGE();
			break;
		
		case OFF:
			asp->modem_status_reg.bits.RLSD = OFF;
			asp->modem_status_reg.bits.delta_RLSD = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
			MODEM_STATE_CHANGE();
			break;
		
		case LEAVE_ALONE:
			break;
		}
		
		/*
		 * Establish RI state
		 */
		switch(change_state(ri_state, asp->modem_status_reg.bits.RI))
		{
		case ON:
			asp->modem_status_reg.bits.RI = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);
			MODEM_STATE_CHANGE();
			break;
		
		case OFF:
			asp->modem_status_reg.bits.RI = OFF;
			asp->modem_status_reg.bits.TERI = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
			MODEM_STATE_CHANGE();
			break;
		
		case LEAVE_ALONE:
			break;
		}
	}
}

static void set_recv_char_status IFN1(struct ADAPTER_STATE *, asp)
{
	/*
	 * Check for data overrun and set up correct interrupt
	 */
	if ( asp->line_status_reg.bits.data_ready == 1 )
	{
		sure_note_trace0(RS232_VERBOSE, "overrun error in set_recv_char_status");
		asp->line_status_reg.bits.overrun_error = 1;
		raise_rls_interrupt(asp);
	}
	else
	{
		asp->line_status_reg.bits.data_ready = 1;
		raise_rda_interrupt(asp);
	}
}

static void set_xmit_char_status IFN1(struct ADAPTER_STATE *, asp)
{
	/*
	 * Set line status register and raise interrupt
	 */
	asp->line_status_reg.bits.tx_holding_empty = 1;
	asp->line_status_reg.bits.tx_shift_empty = 1;
	raise_thre_interrupt(asp);
}

#ifdef NTVDM
GLOBAL void tx_shift_register_empty(int adapter)
{
    struct ADAPTER_STATE *asp = &adapter_state[adapter];
    asp->line_status_reg.bits.tx_shift_empty = 1;
}
GLOBAL void tx_holding_register_empty(int adapter)
{
    struct ADAPTER_STATE *asp = &adapter_state[adapter];
    asp->line_status_reg.bits.tx_holding_empty = 1;
    raise_thre_interrupt(asp);
}
#endif

/*
 * =====================================================================
 * Subsidiary functions - for setting comms parameters
 * =====================================================================
 */

static void set_break IFN1(int, adapter)
{
	/*
	 * Process the set break control bit. Bit 6 of the Line Control
	 * Register.
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	
	switch ( change_state((int)asp->line_control_reg.bits.set_break,
		asp->break_state) )
	{
	case ON:
		asp->break_state = ON;
		host_com_ioctl(adapter, HOST_COM_SBRK, 0);
		break;
	
	case OFF:
		asp->break_state = OFF;
		host_com_ioctl(adapter, HOST_COM_CBRK, 0);
		break;
	
	case LEAVE_ALONE:
		break;
	}
}

/*
 * The following table is derived from page 1-200 of the XT Tech Ref 1st Ed
 * (except rates above 9600 which are not OFFICIALLY supported on the XT and
 * AT, but are theoretically possible) */

static word valid_latches[] =
{ 
	1, 	2, 	3, 	6, 	12, 	16, 	24, 	32, 
	48, 	58, 	64, 	96, 	192,	384, 	768, 	857, 
	1047, 	1536, 	2304 
};

#if !defined(PROD) || defined(IRET_HOOKS)
static IUM32 bauds[] =
{
	115200, /* 115200 baud */
	57600, /* 57600 baud */
	38400, /* 38400 baud */
	19200, /* 19200 baud */
	9600, /* 9600 baud */
	7200, /* 7200 baud */
	4800, /* 4800 baud */
	3600, /* 3600 baud */
	2400, /* 2400 baud */
	2000, /* 2000 baud */
	1800, /* 1800 baud */
	1200, /* 1200 baud */
	600, /* 600 baud */
	300, /* 300 baud */
	150, /* 150 baud */
	134, /* 134 baud */
	110, /* 110 baud */
	75, /* 75 baud */
	50  /* 50 baud */
};
#endif /* !PROD or IRET_HOOKS*/

static word speeds[] =
{ 
	HOST_COM_B115200, 
	HOST_COM_B57600, 
	HOST_COM_B38400, 
	HOST_COM_B19200, 
	HOST_COM_B9600, 
	HOST_COM_B7200, 
	HOST_COM_B4800, 
	HOST_COM_B3600,
	HOST_COM_B2400, 
	HOST_COM_B2000, 
	HOST_COM_B1800, 
	HOST_COM_B1200, 
	HOST_COM_B600, 
	HOST_COM_B300, 
	HOST_COM_B150, 
	HOST_COM_B134, 
	HOST_COM_B110,
	HOST_COM_B75, 
	HOST_COM_B50 
};

static int no_valid_latches = 
	(int)(sizeof(valid_latches)/sizeof(valid_latches[0]));

static void set_baud_rate IFN1(int, adapter)
{
	/*
	 * Map divisor latch into a valid line speed and set our Unix
	 * device accordingly. Note as the sixteen bit divisor latch is
	 * likely to be written in two eight bit bytes, we ignore illegal
	 * values of the sixteen bit divisor latch - hoping a second
	 * byte will be written to produce a legal value. In addition
	 * the reset value (0) is illegal!
	 *
	 * For IRET hooks, we need to determine the batch size from
	 * the line speed, and an idea of how many quick events
	 * we can get per second. We add one to alow us to catch-up!
	 * Hence 
	 * batch size = line_speed (in bits per second)
	 *	/ number of bits in a byte
	 *	* number of quick events ticks per second (normally 1000000)
	 *	/ the length in quick event ticks of a batch
	 *	+ 1
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	int i;

	com_flush_input(adapter);

#ifndef NTVDM

	/*
	 * Check for valid divisor latch
	 */
	for (i = 0; i < no_valid_latches && asp->divisor_latch.all !=
		valid_latches[i]; i++)
			;
	
	if (i < no_valid_latches)	/* ie map found */
	{
		host_com_ioctl(adapter, HOST_COM_BAUD, speeds[i]);
		asp->com_baud_ind = i;
		sure_note_trace3(RS232_VERBOSE,
			" delay for baud %d RX:%d TX:%d", bauds[i],
			RX_delay[i], TX_delay[i]);
#ifdef IRET_HOOKS
#error DIVERGENCE MVDM-HOST-DIV-525: IRET_HOOKS platform branch is not selected; see mirror register.
#endif /* IRET_HOOKS */
#line 1653
	}
#else /* NTVDM */
#line 1655
    //The host is not limited in the baud rates that it supports

    if(asp->divisor_latch.all)
        /* baudrate = clock frequency / (diviso * 16) by taking
           frequency as 1.8432 MHZ
        */
        host_com_ioctl(adapter,HOST_COM_BAUD,115200/asp->divisor_latch.all);
#endif /* NTVDM */
#line 1663
}

static void set_line_control IFN2(int, adapter, int, value)
{
	/*
	 * Set Number of data bits
	 *     Parity bits
	 *     Number of stop bits
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	LINE_CONTROL_REG newLCR;
	int newParity, parity;
	
	newLCR.all = value;

	/*
	 * Set up the number of data bits
	 */
	if (asp->line_control_reg.bits.word_length != newLCR.bits.word_length)
		host_com_ioctl(adapter, HOST_COM_DATABITS,
			newLCR.bits.word_length + 5);
	
	/*
	 * Set up the number of stop bits
	 */
	if (asp->line_control_reg.bits.no_of_stop_bits
	!= newLCR.bits.no_of_stop_bits)
		host_com_ioctl(adapter, HOST_COM_STOPBITS,
			newLCR.bits.no_of_stop_bits + 1);

	/* What are new settings to check for a difference */
#ifdef NTVDM
	if (newLCR.bits.parity_enabled == PARITYENABLE_OFF)
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
	{
		newParity = HOST_COM_PARITY_NONE;
	}
	else if (newLCR.bits.stick_parity == PARITY_STICK)
	{
#ifdef NTVDM
		newParity = newLCR.bits.even_parity == EVENPARITY_ODD ?
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
			HOST_COM_PARITY_MARK : HOST_COM_PARITY_SPACE;
	}
	else /* regular parity */
	{
#ifdef NTVDM
		newParity = newLCR.bits.even_parity == EVENPARITY_ODD ?
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
			HOST_COM_PARITY_ODD : HOST_COM_PARITY_EVEN;
	}

	/*
	 * Try to make sense of the current parity setting
	 */
#ifdef NTVDM
	if (asp->line_control_reg.bits.parity_enabled == PARITYENABLE_OFF)
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
	{
		parity = HOST_COM_PARITY_NONE;
	}
	else if (asp->line_control_reg.bits.stick_parity == PARITY_STICK)
	{
#ifdef NTVDM
		parity = asp->line_control_reg.bits.even_parity == EVENPARITY_ODD ?
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
			HOST_COM_PARITY_MARK : HOST_COM_PARITY_SPACE;
	}
	else /* regular parity */
	{
#ifdef NTVDM
		parity = asp->line_control_reg.bits.even_parity == EVENPARITY_ODD ?
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif
			HOST_COM_PARITY_ODD : HOST_COM_PARITY_EVEN;
	}

	if (newParity != parity)
		host_com_ioctl(adapter, HOST_COM_PARITY, newParity);

#ifdef NTVDM
    //Change in the status of the DLAB selection bit, now is the time
    //to change the baud rate.

    if(!newLCR.bits.DLAB && asp->line_control_reg.bits.DLAB)
        set_baud_rate(adapter);
#endif

	/* finally update the current line control settings */
	asp->line_control_reg.all = value;
}

static void set_dtr IFN1(int, adapter)
{
	/*
	 * Process the DTR control bit, Bit 0 of the Modem Control
	 * Register.
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	
	switch ( change_state((int)asp->modem_control_reg.bits.DTR,
				asp->dtr_state) )
	{
	case ON:
		asp->dtr_state = ON;
		if (asp->loopback_state == OFF)
		{
			/* set the real DTR modem output */
			host_com_ioctl(adapter, HOST_COM_SDTR, 0);
		}
		else
		{
			/*
			 * loopback the DTR modem output into the
			 * DSR modem input
			 */
			asp->modem_status_reg.bits.DSR = ON;
			asp->modem_status_reg.bits.delta_DSR = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case OFF:
		asp->dtr_state = OFF;
		if (asp->loopback_state == OFF)
		{
			/* clear the real DTR modem output */
			host_com_ioctl(adapter, HOST_COM_CDTR, 0);
		}
		else
		{
			/*
			 * loopback the DTR modem output into the
			 * DSR modem input
			 */
			asp->modem_status_reg.bits.DSR = OFF;
			asp->modem_status_reg.bits.delta_DSR = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case LEAVE_ALONE:
		break;
	}
}

static void set_rts IFN1(int, adapter)
{
	/*
	 * Process the RTS control bit, Bit 1 of the Modem Control
	 * Register.
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	
	switch ( change_state((int)asp->modem_control_reg.bits.RTS,
				asp->rts_state) )
	{
	case ON:
		asp->rts_state = ON;
		if (asp->loopback_state == OFF)
		{
			/* set the real RTS modem output */
			host_com_ioctl(adapter, HOST_COM_SRTS, 0);
		}
		else
		{
			/* loopback the RTS modem out into the CTS modem in */
			asp->modem_status_reg.bits.CTS = ON;
			asp->modem_status_reg.bits.delta_CTS = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case OFF:
		asp->rts_state = OFF;
		if (asp->loopback_state == OFF)
		{
			/* clear the real RTS modem output */
			host_com_ioctl(adapter, HOST_COM_CRTS, 0);
		}
		else
		{
			/* loopback the RTS modem out into the CTS modem in */
			asp->modem_status_reg.bits.CTS = OFF;
			asp->modem_status_reg.bits.delta_CTS = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case LEAVE_ALONE:
		break;
	}
}

static void set_out1 IFN1(int, adapter)
{
	/*
	 * Process the OUT1 control bit, Bit 2 of the Modem Control
	 * Register.
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	
	switch ( change_state((int)asp->modem_control_reg.bits.OUT1,
				asp->out1_state) )
	{
	case ON:
		asp->out1_state = ON;
		if (asp->loopback_state == OFF)
		{
			/* 
			 * In the real adapter, this modem control output
			 * signal is not connected; so no real modem
			 * control change is required
			 */
		}
		else
		{
			/* loopback the OUT1 modem out into the RI modem in */
			asp->modem_status_reg.bits.RI = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case OFF:
		asp->out1_state = OFF;
		if (asp->loopback_state == OFF)
		{
			/* 
			 * In the real adapter, this modem control output
			 * signal is not connected; so no real modem control
			 * change is required
			 */
		}
		else
		{
			/* loopback the OUT1 modem out into the RI modem in */
			asp->modem_status_reg.bits.RI = OFF;
			asp->modem_status_reg.bits.TERI = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case LEAVE_ALONE:
		break;
	}
}

static void set_out2 IFN1(int, adapter)
{
	/*
	 * Process the OUT2 control bit, Bit 3 of the Modem Control
	 * Register.
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	
	switch ( change_state((int)asp->modem_control_reg.bits.OUT2,
				asp->out2_state) )
	{
	case ON:
		asp->out2_state = ON;
		if (asp->loopback_state == OFF)
		{
			/* 
			 * In the real adapter, this modem control output
			 * signal is used to determine whether the
			 * communications card should send interrupts; so
			 * check for immediately actionable interrupts.
			 * If you change this code, change the equivalent code
			 * for the interrupt enable register.
			 */
			if ( asp->line_status_reg.bits.data_ready == 1 )
				raise_rda_interrupt(asp);
			if ( asp->line_status_reg.bits.tx_holding_empty == 1 )
				raise_thre_interrupt(asp);
		}
		else
		{
			/* loopback the OUT2 modem output into the RLSD modem input */
			asp->modem_status_reg.bits.RLSD = ON;
			asp->modem_status_reg.bits.delta_RLSD = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case OFF:
		asp->out2_state = OFF;
		if (asp->loopback_state == OFF)
		{
			/* 
			 * In the real adapter, this modem control output signal
			 * is used to determine whether the communications
			 * card should send interrupts; so no real modem
			 * control change is required
			 */
		}
		else
		{
			/* loopback the OUT2 modem out into the RLSD modem in */
			asp->modem_status_reg.bits.RLSD = OFF;
			asp->modem_status_reg.bits.delta_RLSD = ON;
			host_com_msr_callback (adapter, asp->modem_status_reg.all);

			raise_ms_interrupt(asp);
		}
		MODEM_STATE_CHANGE();
		break;
	
	case LEAVE_ALONE:
		break;
	}
}

static void set_loopback IFN1(int, adapter)
{
	/*
	 * Process the loopback control bit, Bit 4 of the Modem Control
	 * Register.
	 */
	struct ADAPTER_STATE *asp = &adapter_state[adapter];
	
	switch ( change_state((int)asp->modem_control_reg.bits.loop,
				asp->loopback_state) )
	{
		case ON:
		asp->loopback_state = ON;
		/*
		 * Subsequent calls to set_dtr(), set_rts(), set_out1() and
		 * set_out2() will cause the modem control inputs to be set
		 * according to the the modem control outputs
		 */
		break;
	
	case OFF:
		asp->loopback_state = OFF;
		/*
		 * Set the modem control inputs according to the real
		 * modem state
		 */
		modem_change(adapter);
		break;
	
	case LEAVE_ALONE:
		break;
	}
}

#ifdef SHORT_TRACE
#error DIVERGENCE MVDM-HOST-DIV-527: SHORT_TRACE branch is not selected; see mirror register.
#endif


void com1_flush_printer IFN0()
{
#ifdef NTVDM
	host_com_lock(COM1);
#endif

	host_com_ioctl(COM1, HOST_COM_FLUSH, 0);

#ifdef NTVDM
       host_com_unlock(COM1);
#endif
}

void com2_flush_printer IFN0()
{
#ifdef NTVDM
	host_com_lock(COM2);
#endif

       host_com_ioctl(COM2, HOST_COM_FLUSH, 0);

#ifdef NTVDM
       host_com_unlock(COM2);
#endif
}


#ifdef SEGMENTATION
#error Excluded unsupported SEGMENTATION configuration





#endif

static void com_reset IFN1(int, adapter)
{
	struct ADAPTER_STATE *asp = &adapter_state[adapter];

	/* setup the LCRFlushMask if it has not already been setup */
	if (!LCRFlushMask.all)
	{
		LCRFlushMask.all = ~0;	 /* turn all bits on */

		/*
		 * Now turn off the bits that should NOT cause the input
		 * to be flushed.  Note set_break is handled seperately by
		 * the set_break() routine.
		 */
		LCRFlushMask.bits.DLAB = 0;
		LCRFlushMask.bits.no_of_stop_bits = 0;
		LCRFlushMask.bits.set_break = 0;
	}
		
	/*
	 * Set default state of all adapter registers
	 */
	asp->int_enable_reg.all = 0;

#ifdef NTVDM
        // Tell host side the state of the data available interrupt
    host_com_da_int_change(adapter,asp->int_enable_reg.bits.data_available,0);
#endif /* NTVDM */

	
	asp->int_id_reg.all = 0;
	asp->int_id_reg.bits.no_int_pending = 1;
	
	/* make sure a change occurs to 0 */
	asp->line_control_reg.all = ~0;
	
	/*
	 * set up modem control reg so next set_dtr etc.
	 * Will produce required status
	 */
	asp->modem_control_reg.all = 0;
	asp->modem_control_reg.bits.DTR = ON;
	asp->modem_control_reg.bits.RTS = ON;
	asp->modem_control_reg.bits.OUT1 = ON;
	asp->modem_control_reg.bits.OUT2 = ON;
	host_com_ioctl(adapter, HOST_COM_SDTR, 0);
	host_com_ioctl(adapter, HOST_COM_SRTS, 0);

	asp->line_status_reg.all = 0;
	asp->line_status_reg.bits.tx_holding_empty = 1;
	asp->line_status_reg.bits.tx_shift_empty = 1;
	
	asp->modem_status_reg.all = 0;
	MODEM_STATE_CHANGE();
	host_com_msr_callback (adapter, asp->modem_status_reg.all);
	
	/*
	 * Set up default state of our state variables
	 */
	asp->receiver_line_status_interrupt_state = OFF;
	asp->data_available_interrupt_state = OFF;
	asp->tx_holding_register_empty_interrupt_state = OFF;
	asp->modem_status_interrupt_state = OFF;
	asp->break_state = OFF;
	asp->loopback_state = OFF;
	asp->dtr_state = ON;
	asp->rts_state = ON;
	asp->out1_state = ON;
	asp->out2_state = ON;
#if defined(NTVDM) && defined(FIFO_ON)
#error Excluded unsupported FIFO_ON configuration






#endif
		
	/*
	 * Reset adapter synchronisation
	 */
	com_critical_reset(adapter);

	/*
	 * Set Unix devices to default state
	 */
	set_baud_rate(adapter);
	set_line_control(adapter, 0);
	set_break(adapter);

	/* Must be called before set_dtr */
	set_loopback(adapter);
	set_dtr(adapter);
	set_rts(adapter);
	set_out1(adapter);
	set_out2(adapter);

#ifdef IRET_HOOKS
#error DIVERGENCE MVDM-HOST-DIV-525: IRET_HOOKS platform branch is not selected; see mirror register.
#endif /* IRET_HOOKS */
}

#ifndef COM3_ADAPTOR
#define COM3_ADAPTOR 0
#endif
#ifndef COM4_ADAPTOR
#define COM4_ADAPTOR 0
#endif

static int com_adaptor[4] = {COM1_ADAPTOR,COM2_ADAPTOR,
                             COM3_ADAPTOR,COM4_ADAPTOR};
static int port_start[4] = {RS232_COM1_PORT_START,
				RS232_COM2_PORT_START,
				RS232_COM3_PORT_START,
				RS232_COM4_PORT_START};
static int port_end[4] = {RS232_COM1_PORT_END,
                          RS232_COM2_PORT_END,
                          RS232_COM3_PORT_END,
                          RS232_COM4_PORT_END};
static int int_pri[4] = {CPU_RS232_PRI_INT,
                         CPU_RS232_SEC_INT,
                         CPU_RS232_PRI_INT,
                         CPU_RS232_SEC_INT};
static int timeout[4] = {RS232_COM1_TIMEOUT,
                         RS232_COM2_TIMEOUT,
                         RS232_COM3_TIMEOUT,
                         RS232_COM4_TIMEOUT};


GLOBAL VOID com_init IFN1(int, adapter)
{
	io_addr i;

#ifdef NTVDM
	host_com_lock(adapter);
	host_com_disable_open(adapter,TRUE);
#endif

	adapter_state[adapter].had_first_read = FALSE;
	
	/* Set up the IO chip select logic for this adaptor */
#ifdef NTVDM
    {
        extern BOOL VDMForWOW;
        extern void wow_com_outb(io_addr port, half_word value);
        extern void wow_com_inb(io_addr port, half_word *value);

            io_define_inb(com_adaptor[adapter],VDMForWOW ? wow_com_inb: com_inb)
;
            io_define_outb(com_adaptor[adapter],VDMForWOW ? wow_com_outb: com_outb);
        }
#else
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#endif /* NTVDM */
 
	for(i = port_start[adapter]; i <= port_end[adapter]; i++)
		io_connect_port(i, com_adaptor[adapter], IO_READ_WRITE);
         

	adapter_state[adapter].hw_interrupt_priority = int_pri[adapter];
 
	/* reset adapter state */
	host_com_reset(adapter);

	/* reset adapter state */
	com_reset(adapter);

#ifndef NTVDM
#error DIVERGENCE MVDM-HOST-DIV-537: non-NTVDM branch is not selected; see mirror register.
#else /* not NTVDM */
	host_com_disable_open(adapter,FALSE);
	host_com_unlock(adapter);
#endif

	return;
}

void com_post IFN1(int, adapter)
{
        /* Set up BIOS data area. */
	sas_storew( BIOS_VAR_START + (2*adapter), port_start[adapter]);
	sas_store(timeout[adapter] , (half_word)1 );
}
 
void com_close IFN1(int, adapter)
{
#ifdef NTVDM
	host_com_lock(adapter);
#endif

#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif
	/* reset host specific communications channel */
	config_activate(C_COM1_NAME + adapter, FALSE);

#ifdef NTVDM
	host_com_unlock(adapter);
#endif
}

#ifdef NTVDM

/*********************************************************/
/* Com extentions - DAB (MS-project) */

GLOBAL void SyncBaseLineSettings(int adapter,DIVISOR_LATCH *divisor_latch,
                 LINE_CONTROL_REG *LCR_reg)
{
    register struct ADAPTER_STATE *asp = &adapter_state[adapter];

    //Setup baud rate control register
    asp->divisor_latch.all = (*divisor_latch).all;

    //Setup line control settings
    asp->line_control_reg.bits.word_length = (*LCR_reg).bits.word_length;
    asp->line_control_reg.bits.no_of_stop_bits = (*LCR_reg).bits.no_of_stop_bits
;
    asp->line_control_reg.bits.parity_enabled = (*LCR_reg).bits.parity_enabled;
    asp->line_control_reg.bits.stick_parity = (*LCR_reg).bits.stick_parity;
    asp->line_control_reg.bits.even_parity = (*LCR_reg).bits.even_parity;
}

GLOBAL void setup_RTSDTR(int adapter)
{
    struct ADAPTER_STATE *asp = &adapter_state[adapter];

    host_com_ioctl(adapter,asp->dtr_state == ON ? HOST_COM_SDTR : HOST_COM_CDTR,
0);
    host_com_ioctl(adapter,asp->rts_state == ON ? HOST_COM_SRTS : HOST_COM_CRTS,
0);
}

GLOBAL int AdapterReadyForCharacter(int adapter)
{
    BOOL AdapterReady = FALSE;

    /*......................................... Are RX interrupts enabled */

    if(adapter_state[adapter].line_status_reg.bits.data_ready == 0 &&
       adapter_state[adapter].data_available_interrupt_state == OFF)
    {
        AdapterReady = TRUE;
    }

    return(AdapterReady);
}

// This function returns the ICA controller and line used to generate
// interrupts on a adapter. This information is used to register a EOI
// hook.


GLOBAL void com_int_data(int adapter,int *controller, int *line)
{
    struct ADAPTER_STATE *asp = &adapter_state[adapter];

    *controller = 0;                            // Controller ints raised on
    *line = (int) asp->hw_interrupt_priority;   // Line ints raised on
}

#endif /* NTVDM */

#ifdef PS_FLUSHING
#error DIVERGENCE MVDM-HOST-DIV-530: PS_FLUSHING platform branch is not selected; see mirror register.
#endif	/* PS_FLUSHING */



/********************************************************/
/* Com debugging shell - Ade Brownlow / Ian Wellock
 * NB: This stuff only works for COM1. It is called from yoda using 'cd'
 * - comdebug - from the yoda command line....
 */
#ifndef PROD
#error DIVERGENCE MVDM-HOST-DIV-500: non-PROD debug branch is not selected; see mirror register.
#endif /* !PROD */
/********************************************************/
