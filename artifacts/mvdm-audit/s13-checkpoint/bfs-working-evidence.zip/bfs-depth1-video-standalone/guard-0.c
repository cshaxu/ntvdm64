#if ( defined(NTVDM) && defined(MONITOR) && !defined(MVDM_STANDALONE_SAS_VIDEO) ) || defined( GISP_SVGA )
#error DIVERGENCE MVDM-HOST-DIV-581: standalone SAS excludes direct video memory writes
#endif
int selected;
