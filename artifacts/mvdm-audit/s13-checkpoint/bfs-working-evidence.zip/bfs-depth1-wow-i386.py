import pathlib,re,json,subprocess,shutil,importlib.util,hashlib,concurrent.futures,functools
root=pathlib.Path.cwd();out=root/'build/t473-s13/bfs-depth1-wow-i386';out.mkdir(exist_ok=True);spec=importlib.util.spec_from_file_location('audit','build/t473-s13/bfs-live/audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit);envs={x:audit.env_for(x) for x in ('x86','x64')};compilers={x:shutil.which('cl.exe',path=envs[x].get('PATH',envs[x].get('Path',''))) for x in envs};paths=['src/mvdm-host/wow32/wkgthunk.c', 'src/mvdm-host/wow32/wgprnset.c', 'src/mvdm-host/wow32/wkmem.c', 'src/mvdm-host/wow32/wow32.c'];jobs=[]
for arch in ('x86','x64'):
 for graph in (root/'build/.ninja'/('msvc-'+arch+'-release')).rglob('build.ninja'):
  folder=graph.parent;result=subprocess.run([str(audit.NINJA),'-C',str(folder),'-t','compdb'],capture_output=True,text=True)
  if result.returncode:continue
  for e in json.loads(result.stdout):
   src=e.get('file','').replace('\\','/').lower()
   for path in paths:
    if src.endswith('/'+path.lower()):jobs.append((folder,path,e,'x86' if folder.name=='worker-reference-x86' else arch))
@functools.lru_cache(maxsize=5000)
def definitions(name):
 try:
  result=[]
  for n,line in enumerate(pathlib.Path(name).read_bytes().decode('latin1').split('\n'),1):
   if re.match(r'^\s*#\s*(?:define|undef)\s+i386\b',line):result.append([name,n,line.strip()])
  return result
 except OSError:return [[name,'unreadable','']]
def run(job):
 folder,path,e,arch=job;env=envs[arch];cl=compilers[arch];cmd=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1];cmd=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',cmd);cmd=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',cmd);r=subprocess.run('"'+cl+'" /Zs /showIncludes '+cmd,cwd=folder,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=r.stdout+r.stderr;txt=raw.decode('mbcs',errors='replace');incs=[]
 for line in txt.splitlines():
  m=re.search(r'(?i)including file:\s*(.*)$',line)
  if m and pathlib.Path(m.group(1).strip()).is_file():incs.append(pathlib.Path(m.group(1).strip()))
 defs=[]
 for f in [root/path]+incs:defs.extend(definitions(str(f)))
 flags=re.findall(r'(?i)(?:/D|-D)i386(?:=[^\s"]+)?',cmd);rec={'path':path,'graph':str(folder.relative_to(root)).replace('\\','/'),'exit':r.returncode,'source_sha256':hashlib.sha256((root/path).read_bytes()).hexdigest(),'includes':len(incs),'i386_definitions':defs,'i386_flags':flags,'errors':txt[-300:] if r.returncode else ''};print(path,folder.name,'exit',r.returncode,'definitions',len(defs),'flags',flags,flush=True);return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(run,jobs))
(out/'include-trace.json').write_text(json.dumps(records,indent=2)+'\n');print('finished',len(records),'failures',sum(x['exit']!=0 for x in records),flush=True)
