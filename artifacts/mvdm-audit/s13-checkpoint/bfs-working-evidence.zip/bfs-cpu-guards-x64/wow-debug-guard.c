#ifdef DEBUG
#error Excluded unsupported DEBUG WOW profile
#endif
#line 2290
int following_line = __LINE__;
