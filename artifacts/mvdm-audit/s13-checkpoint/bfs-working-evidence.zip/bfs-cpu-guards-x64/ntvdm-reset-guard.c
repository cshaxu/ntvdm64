#ifndef NTVDM	/* No signon for NTVDM - transparent integration */
#error Excluded unsupported non-NTVDM BIOS signon profile
#endif	/* NTVDM */
#line 898
int following_line = __LINE__;
