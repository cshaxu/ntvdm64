#ifdef NTVDM
int selected = 1;
#else
#error Excluded unsupported non-NTVDM alternative
#endif
#line 2238
int following_line = __LINE__;
