#if (defined(i386) || defined(_M_IX86)) && !defined(CPU_40_STYLE)
#error Excluded unsupported non-CPU40 i386 memory-size profile
#else
#line 464
int selected_line = __LINE__;
#endif
