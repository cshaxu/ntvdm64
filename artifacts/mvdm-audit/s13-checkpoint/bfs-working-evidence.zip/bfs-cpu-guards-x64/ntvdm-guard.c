#ifndef NTVDM
#error Excluded unsupported non-NTVDM timer profile
#endif
#line 2421
int selected_line = __LINE__;
