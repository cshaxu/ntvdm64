#ifndef NTVDM
#error Excluded unsupported non-NTVDM PIC profile
#endif
#line 1539
int following_line = __LINE__;
