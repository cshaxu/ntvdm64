#ifndef NTVDM
#error Excluded unsupported non-NTVDM timer profile
#else   /* NTVDM */
#line 1816
int selected_line = __LINE__;
#endif
#line 1959
int following_line = __LINE__;
