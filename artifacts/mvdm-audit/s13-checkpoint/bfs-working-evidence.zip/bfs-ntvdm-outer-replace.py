import pathlib,json,hashlib,re,collections
root=pathlib.Path('.');qp=root/'build/t473-s13/bfs/baseline-and-queue.json';q=json.loads(qp.read_text(encoding='utf8'));candidates=json.load(open('build/t473-s13/bfs-ntvdm-outer-candidates.json'));tr=json.load(open('build/t473-s13/bfs-depth1-ntvdm-extra/include-trace.json'))+json.load(open('build/t473-s13/bfs-depth1-ntvdm-extra2/include-trace.json'));assert len(tr)==18 and all(not x['exit'] and '/DNTVDM' in x['ntvdm_flags'] and all('#undef' not in d[2] for d in x['ntvdm_definitions']) for x in tr);logical={(x['path'],x['after_physical_line']):x['logical_next_line'] for x in json.load(open('build/t473-s13/bfs-ntvdm-outer-lines/baseline-lines.json'))};specs=collections.defaultdict(list)
for r in candidates:specs[r['path']].append(r)
h=lambda b:hashlib.sha256(b).hexdigest();records=[];prepared={};remaps={};pruned=collections.Counter();scratch=root/'build/t473-s13/bfs-ntvdm-outer-before';scratch.mkdir(exist_ok=True)
for path,items in specs.items():
 p=root/path;f=next(x for x in q['files'] if x['path']==path);old=p.read_bytes();o=pathlib.Path(f['original']).read_bytes();assert h(old)==f.get('working_sha256',f['current_sha256'])==items[0]['source_sha256'] and h(o)==f['original_sha256']==items[0]['original_sha256'];ls=old.split(b'\n');ol=o.replace(b'\r\n',b'\n').split(b'\n');(scratch/p.name).write_bytes(old)
 for x in items:
  n,cut,e,orig,ocut=x['start'],x['cut'],x['end'],x['original_start'],x['original_cut'];assert re.match(rb'^\s*#\s*ifndef\s+NTVDM\b',ls[n-1]) and re.match(rb'^\s*#\s*(else|endif)\b',ls[cut-1]) and re.match(rb'^\s*#\s*endif\b',ls[e-1]) and re.match(rb'^\s*#\s*ifndef\s+NTVDM\b',ol[orig-1]);body=b'\n'.join(y.rstrip(b'\r') for y in ls[n:cut-1]);obody=b'\n'.join(ol[orig:ocut-1]);assert (path,e) in logical and (not x['has_else'] or (path,cut) in logical);records.append({'path':path,'before_sha256':h(old),'original':f['original'],'original_sha256':h(o),'local_group_before':n,'local_cut_before':cut,'local_end_before':e,'original_group':orig,'original_cut':ocut,'original_end':x['original_end'],'removed_body_sha256':h(body),'original_body_sha256':h(obody),'removed_body_lines':cut-n-1,'subsumed_markers':x['markers'],'selected_alternative_line':logical[(path,cut)] if x['has_else'] else None,'following_line':logical[(path,e)],'preceding_anchor':x['preceding_anchor'],'following_anchor':x['following_anchor'],'status':'unverified','registration':'MVDM-HOST-DIV-591'})
 new=ls[:]
 for x in sorted(items,key=lambda z:z['start'],reverse=True):
  n,cut,e=x['start'],x['cut'],x['end'];cr=b'\r' if ls[n-1].endswith(b'\r') else b'';new[n:cut-1]=[b'#error DIVERGENCE MVDM-HOST-DIV-591: non-NTVDM branch is not selected'+cr];removed=(cut-n-1)-1;newcut=(cut-1)-removed
  if x['has_else']:new.insert(newcut+1,('#line '+str(logical[(path,cut)])).encode()+cr)
  newend=(e-1)-removed+(1 if x['has_else'] else 0);new.insert(newend+1,('#line '+str(logical[(path,e)])).encode()+cr)
 out=b'\n'.join(new);prepared[path]=out;f['working_sha256']=h(out)
 def move(n,entries=tuple((x['start'],x['cut'],x['end']) for x in items)):
  delta=0
  for start,cut,e in entries:
   if n>=cut:delta+=2-(cut-start)
   if cut!=e and n>cut:delta+=1
   if n>e:delta+=1
  return n+delta
 remaps[path]=move;groups=[]
 for g in q['groups']:
  if g.get('role')!='current' or g['path']!=path:groups.append(g);continue
  n=g['line']
  if any(x['start']<n<x['cut'] for x in items):
   assert g['depth']>1 and all(a['status']=='unreviewed' for a in g['arms']);pruned[path]+=1;continue
  if any(n==x['start'] for x in items):
   assert g['depth']==1 and g['arms'][0]['status']=='pending';g['arms'][0]['status']='newly-excluded';g['arms'][0]['evidence']='DIV-591; s13-bfs-depth1-ntvdm-outer-batch.json';g['arms'][0].pop('pending_reason',None)
  g['line']=move(n)
  if isinstance(g.get('parent'),int):g['parent']=move(g['parent'])
  for a in g['arms']:a['line']=move(a['line'])
  groups.append(g)
 q['groups']=groups
 for r in records:
  if r['path']==path:r['current_start_line']=move(r['local_group_before']);r['current_cut_line']=move(r['local_cut_before']);r['current_end_line']=move(r['local_end_before']);r['after_sha256']=h(out)
rp=root/'artifacts/mvdm-audit/s13-rejected-legacy-branches.json';ledger=json.loads(rp.read_text(encoding='utf8'));subsumed=0
for x in ledger:
 path=x.get('path');items=specs.get(path)
 if not items:continue
 n=x.get('line')
 if isinstance(n,int) and any(z['start']<n<z['cut'] for z in items):x['disposition']='subsumed-depth1-nonntvdm';x['subsumed_before_line']=n;subsumed+=1
 else:
  for k in ['line','body_end']:
   if isinstance(x.get(k),int):x[k]=remaps[path](x[k])
 x['final_sha256']=h(prepared[path])
for path,out in prepared.items():(root/path).write_bytes(out)
qp.write_text(json.dumps(q,indent=2,ensure_ascii=False)+'\n',encoding='utf8');rp.write_text(json.dumps(ledger,indent=2,ensure_ascii=False)+'\n',encoding='utf8');(root/'artifacts/mvdm-audit/s13-bfs-depth1-ntvdm-outer-batch.json').write_text(json.dumps(records,indent=2)+'\n');print('replaced',len(records),'files',len(prepared),'removed body lines',sum(x['removed_body_lines'] for x in records),'pruned unreviewed groups',sum(pruned.values()),'subsumed ledger',subsumed,'root',dict(collections.Counter(a['status'] for g in q['groups'] if g.get('role')=='current' and g.get('depth')==1 for a in g['arms'])))
