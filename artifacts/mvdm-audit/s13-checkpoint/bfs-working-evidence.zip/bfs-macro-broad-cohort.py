import json,csv,pathlib,re,hashlib,collections,subprocess
root=pathlib.Path('.');qp=root/'build/t473-s13/bfs/baseline-and-queue.json';q=json.loads(qp.read_text(encoding='utf8'));macros={'FE_IME', 'PC_CONFIG', 'macintosh', 'NEVER', 'SOFTWIN_API', 'FIFO_ON', 'NOT_NEEDED', 'CGAMONO', 'LICENSING', 'GISP_CPU', 'HUNTER', 'MOUSE_16_BIT', 'CDEBUG', 'GISP_SVGA', 'PIG', 'OS2_32', 'SUN_VA', 'SETUID_ROOT', 'UNDO_CLEANUP', 'SUN4', 'GORE', 'SECURE', 'KOREA', 'JOKER', 'NOTUSED', 'IRET_HOOKS', 'SLAVEPC', 'MAC68K', 'SCCSID', 'A2CPU', 'EGATEST', 'DBCS', 'FE_SB', 'REAL_VGA', 'SYNCH_TIMERS', 'DOCUMENTATION', 'WOW', 'PROFILE', 'SEGMENTATION', 'LATER', 'SHORT_TRACE', 'DUMB_TERMINAL', 'SOFTWINDOWS', 'SFELLOW', 'SWIN_SNDBLST_NULL', 'SYSMODALWINDOWS', 'INCLUDE_IO_BUFFER_SIZE_TABLE', 'REAL_KBD', 'H2INC', 'MEMPHIS_MENUS', 'BOGUS', 'SWIN_HAW', 'SWIN_HFX', 'VR_DIAGNOSE', 'WASWIN31', 'BACK_M', 'HERC', 'A3CPU', 'OS2_16', 'BIT_ORDER1', 'KANJI', 'BSD4_2', 'SWINAPI', 'NOVELL', 'PS_FLUSHING', 'REAL_ROM', 'DOS_APP_LIC', 'BIGEND', 'SIGNAL_PROFILING', 'NOLOG', 'PIG_DONT_CHECK_OTHER_WORD_ON_STACK', 'CHECK_IT_LATER', '_USERK_', 'EGA_DUMP'};graph=json.load(open('build/t473-s13/bfs-macro-broad-graph.json'));assert not graph['errors'] and all(graph['flag_counts'].get(x,0)==0 for x in macros);rr=subprocess.run(['rg','-n',r'^\s*#\s*(?:define|undef)\s+(?:A2CPU|A3CPU|BACK_M|BIGEND|BIT_ORDER1|BOGUS|BSD4_2|CDEBUG|CGAMONO|CHECK_IT_LATER|DBCS|DOCUMENTATION|DOS_APP_LIC|DUMB_TERMINAL|EGATEST|EGA_DUMP|FE_IME|FE_SB|FIFO_ON|GISP_CPU|GISP_SVGA|GORE|H2INC|HERC|HUNTER|INCLUDE_IO_BUFFER_SIZE_TABLE|IRET_HOOKS|JOKER|KANJI|KOREA|LATER|LICENSING|MAC68K|MEMPHIS_MENUS|MOUSE_16_BIT|NEVER|NOLOG|NOTUSED|NOT_NEEDED|NOVELL|OS2_16|OS2_32|PC_CONFIG|PIG|PIG_DONT_CHECK_OTHER_WORD_ON_STACK|PROFILE|PS_FLUSHING|REAL_KBD|REAL_ROM|REAL_VGA|SCCSID|SECURE|SEGMENTATION|SETUID_ROOT|SFELLOW|SHORT_TRACE|SIGNAL_PROFILING|SLAVEPC|SOFTWINDOWS|SOFTWIN_API|SUN4|SUN_VA|SWINAPI|SWIN_HAW|SWIN_HFX|SWIN_SNDBLST_NULL|SYNCH_TIMERS|SYSMODALWINDOWS|UNDO_CLEANUP|VR_DIAGNOSE|WASWIN31|WOW|_USERK_|macintosh)\b','src','tests','tools','--glob','*.{c,h,cpp,inc,ps1,py}'],capture_output=True,text=True);assert rr.returncode==1 and not rr.stdout
h=lambda b:hashlib.sha256(b).hexdigest();paths={g['path'] for g in q['groups'] if g.get('role')=='current' and g.get('depth')==1 and g['arms'][0]['kind']=='ifdef' and g['arms'][0].get('expression') in macros and g['arms'][0]['status']=='pending'};contexts=collections.defaultdict(list);failed=collections.Counter();input_hashes={}
for d in ['bfs-live','bfs-depth1-alltests','bfs-depth1-tests']:
 folder=root/'build/t473-s13'/d;bp=folder/'branches.csv';cp=folder/'contexts.json';input_hashes[d]={'branches_sha256':h(bp.read_bytes()),'contexts_sha256':h(cp.read_bytes())};rows=list(csv.DictReader(bp.open(encoding='utf8')));ids={};hashes={}
 for r in rows:ids.setdefault(r['path'],len(ids));hashes.setdefault(r['path'],r['sha256'])
 eligible={p:i for p,i in ids.items() if p in paths and pathlib.Path(p).is_file() and h(pathlib.Path(p).read_bytes())==hashes[p]}
 for x in json.loads(cp.read_text(encoding='utf8')):
  marks=set(x.get('files',[]))
  for p,i in eligible.items():
   if i not in marks:continue
   if x.get('exit')!=0:failed[p]+=1
   else:contexts[p].append({'scan':d,'arch':x['arch'],'file':x['file'],'directory':x.get('directory','')})
idx=collections.defaultdict(list)
for g in q['groups']:
 if g.get('depth')==1:idx[(g.get('role'),g['path'])].append(g)
def prep(s):return re.sub(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()) if m.group().startswith('/') else m.group(),s).split('\n')
def end(lines,start):
 d=1
 for i in range(start,len(lines)):
  m=re.match(r'^\s*#\s*(if|ifdef|ifndef|endif)\b',lines[i]);
  if not m:continue
  if m.group(1) in ('if','ifdef','ifndef'):d+=1
  else:
   d-=1
   if not d:return i+1
 raise ValueError('unbalanced')
def after(lines,n):return tuple([t for t in (x.strip() for x in lines[n:]) if t and not t.startswith(('#line','//','/*','*','*/'))][:3])
def before(lines,n):return tuple([t for i in range(n-2,-1,-1) if (t:=lines[i].strip()) and not t.startswith(('#line','//','/*','*','*/'))][:3])
records=[]
for path in sorted(paths):
 if not contexts[path] or failed[path]:continue
 f=next(x for x in q['files'] if x['path']==path);p=pathlib.Path(path);op=pathlib.Path(f['original']);assert h(p.read_bytes())==f.get('working_sha256',f['current_sha256']) and h(op.read_bytes())==f['original_sha256'];s=p.read_bytes().decode('latin1');o=op.read_bytes().decode('latin1');src=s.split('\n');org=o.split('\n');sc=prep(s);oc=prep(o);pre=collections.defaultdict(list);post=collections.defaultdict(list);precur=collections.Counter();postcur=collections.Counter()
 for g in idx[('original',f['original'])]:
  a=g['arms'][0];m=a.get('expression')
  if a['kind']=='ifdef' and m in macros:pre[(m,before(org,g['line']))].append(g);post[(m,after(org,end(oc,g['line'])))].append(g)
 for g in idx[('current',path)]:
  a=g['arms'][0];m=a.get('expression')
  if a['kind']=='ifdef' and m in macros:precur[(m,before(src,g['line']))]+=1;postcur[(m,after(src,end(sc,g['line'])))]+=1
 used=set()
 for g in idx[('current',path)]:
  a=g['arms'][0];m=a.get('expression')
  if not(a['kind']=='ifdef' and m in macros and a['status']=='pending'):continue
  n=g['line'];ce=end(sc,n);bk=(m,before(src,n));ak=(m,after(src,ce));m1=pre.get(bk,[]);m2=post.get(ak,[]);hits={t[0]['line'] for t,c in ((m1,precur[bk]),(m2,postcur[ak])) if len(t)==1 and c==1};j=n+1
  if n>=len(src) or not re.match(r'^\s*#\s*ifdef\s+'+re.escape(m)+r'\b',src[n-1]) or not src[n].strip().startswith('#error'):continue
  while j<len(src) and not src[j].strip():j+=1
  if len(hits)!=1 or not re.match(r'^\s*#\s*(else|elif|endif)\b',src[j]):continue
  hit=next(iter(hits));og=next(x for x in idx[('original',f['original'])] if x['line']==hit)
  if [x['kind'] for x in g['arms']]!=[x['kind'] for x in og['arms']] or (m,hit) in used:continue
  used.add((m,hit));a['status']='already-excluded';a['evidence']='Pinned original outer group uniquely anchored; sole #error; same-hash actual compiler/include contexts and project macro graph audit: s13-bfs-depth1-macro-broad-cohort.json';a.pop('pending_reason',None);records.append({'path':path,'macro':m,'current_sha256':h(p.read_bytes()),'original':str(op),'original_sha256':h(op.read_bytes()),'local_line':n,'local_end':ce,'original_line':hit,'preceding_anchor':before(src,n) if len(m1)==1 and precur[bk]==1 else None,'following_anchor':after(src,ce) if len(m2)==1 and postcur[ak]==1 else None,'guard':src[n].strip(),'blank_lines_after_guard':j-n-1})
assert records;qp.write_text(json.dumps(q,indent=2,ensure_ascii=False)+'\n',encoding='utf8');artifact={'scope':'same-hash first-depth guarded source in observed successful product/test include contexts; all compiled graphs and project macro definitions inventoried','macros':sorted(macros),'generated_graph_inventory':graph,'project_definition_scan':'No exact macro definitions or undefinitions in src, tests or tools C/C++/headers/build scripts; legacy original makefile flags are not active generated graphs.','instrumentation_input_hashes':input_hashes,'per_file_successful_contexts':{p:contexts[p] for p in sorted({r['path'] for r in records})},'existing_exclusions':records,'limitations':'No inference for unobserved files, changed snapshots, failed contexts, unsupported original builds, or non-sole-error bodies; no source modified.'};(root/'artifacts/mvdm-audit/s13-bfs-depth1-macro-broad-cohort.json').write_text(json.dumps(artifact,indent=2)+'\n',encoding='utf8');print('classified',len(records),'by macro',dict(collections.Counter(r['macro'] for r in records)),'files',len(set(r['path'] for r in records)),'root',dict(collections.Counter(a['status'] for g in q['groups'] if g.get('role')=='current' and g.get('depth')==1 for a in g['arms'])))
