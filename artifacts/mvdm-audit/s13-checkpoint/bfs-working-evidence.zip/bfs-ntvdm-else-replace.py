import pathlib,json,hashlib,re,collections
root=pathlib.Path('.');qp=root/'build/t473-s13/bfs/baseline-and-queue.json';q=json.loads(qp.read_text(encoding='utf8'));specs={'src/mvdm-host/softpc.new/base/keymouse/keyba.c':[(1950,2077,2148,2184,2149),(2599,2625,2691,2848,2692)],'src/mvdm-host/softpc.new/base/support/time_day.c':[(148,159,185,152,186)],'src/mvdm-host/softpc.new/base/system/ica.c':[(192,267,294,201,291)],'src/mvdm-host/softpc.new/base/system/timer.c':[(1924,2025,2126,2245,2238)]};h=lambda b:hashlib.sha256(b).hexdigest();records=[];prepared={};pruned=collections.Counter();remaps={}
def prep(s):return re.sub(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()) if m.group().startswith('/') else m.group(),s).split('\n')
def end(lines,start):
 d=1
 for i in range(start,len(lines)):
  m=re.match(r'^\s*#\s*(if|ifdef|ifndef|endif)\b',lines[i]);
  if not m:continue
  if m.group(1) in ('if','ifdef','ifndef'):d+=1
  else:
   d-=1
   if not d:return i+1
 raise ValueError('unbalanced')
for path,items in specs.items():
 p=root/path;f=next(x for x in q['files'] if x['path']==path);old=p.read_bytes();o=pathlib.Path(f['original']).read_bytes();assert h(old)==f.get('working_sha256',f['current_sha256']) and h(o)==f['original_sha256'];ls=old.split(b'\n');ol=o.replace(b'\r\n',b'\n').split(b'\n');oc=prep(o.decode('latin1'));(root/('build/t473-s13/bfs-ntvdm-before/'+p.stem+'-else-before.c')).write_bytes(old)
 for group,els,e,orig,logical in items:
  assert re.match(rb'^\s*#\s*ifdef\s+NTVDM\b',ls[group-1]) and re.match(rb'^\s*#\s*else\b',ls[els-1]) and re.match(rb'^\s*#\s*endif\b',ls[e-1]);og=next(g for g in q['groups'] if g.get('role')=='original' and g['path']==f['original'] and g['depth']==1 and g['line']==orig);assert og['arms'][0]['kind']=='ifdef' and og['arms'][0]['expression']=='NTVDM';oa=next(a for a in og['arms'] if a['kind']=='else');oe=end(oc,orig);body=b'\n'.join(x.rstrip(b'\r') for x in ls[els:e-1]);obody=b'\n'.join(ol[oa['line']:oe-1]);records.append({'path':path,'before_sha256':h(old),'original':f['original'],'original_sha256':h(o),'local_group_before':group,'local_else_before':els,'local_end_before':e,'original_group':orig,'original_else':oa['line'],'original_end':oe,'removed_body_sha256':h(body),'original_body_sha256':h(obody),'removed_body_lines':e-els-1,'subsumed_markers':dict(collections.Counter(re.findall(r'MVDM-HOST-DIV-\d+',body.decode('latin1')))),'following_line':logical,'status':'unverified','registration':'MVDM-HOST-DIV-574'})
 new=ls[:]
 for group,els,e,orig,logical in sorted(items,key=lambda z:z[1],reverse=True):
  cr=b'\r' if ls[els-1].endswith(b'\r') else b'';new[els:e-1]=[b'#error Excluded unsupported non-NTVDM alternative'+cr];newend=(e-1)-(e-els-2);new.insert(newend+1,('#line '+str(logical)).encode()+cr)
 out=b'\n'.join(new);prepared[path]=out;f['working_sha256']=h(out)
 def move(n,entries=tuple(items)):
  delta=0
  for _,els,e,_,_ in entries:
   if n>=e:delta+=2-(e-els)
   if n>e:delta+=1
  return n+delta
 remaps[path]=move;groups=[]
 for g in q['groups']:
  if g.get('role')!='current' or g['path']!=path:groups.append(g);continue
  n=g['line']
  if any(els<n<e for _,els,e,_,_ in items):
   assert g['depth']>1 and all(a['status']=='unreviewed' for a in g['arms']);pruned[path]+=1;continue
  for _,els,_,_,_ in items:
   for a in g['arms']:
    if a['line']==els:
     assert g['depth']==1 and a['kind']=='else' and a['status']=='pending';a['status']='newly-excluded';a['evidence']='DIV-574; s13-bfs-depth1-ntvdm-else-new.json';a.pop('pending_reason',None)
  g['line']=move(n)
  if isinstance(g.get('parent'),int):g['parent']=move(g['parent'])
  for a in g['arms']:a['line']=move(a['line'])
  groups.append(g)
 q['groups']=groups
 for r in records:
  if r['path']==path:r['current_group_line']=move(r['local_group_before']);r['current_else_line']=move(r['local_else_before']);r['after_sha256']=h(out)
rp=root/'artifacts/mvdm-audit/s13-rejected-legacy-branches.json';ledger=json.loads(rp.read_text(encoding='utf8'))
for x in ledger:
 path=x.get('path');items=specs.get(path)
 if not items:continue
 n=x.get('line')
 if isinstance(n,int) and any(els<n<e for _,els,e,_,_ in items):x['disposition']='subsumed-depth1-NTVDM-else';x['subsumed_before_line']=n
 else:
  for k in ['line','body_end']:
   if isinstance(x.get(k),int):x[k]=remaps[path](x[k])
 x['final_sha256']=h(prepared[path])
artifacts={}
for filename in ['s13-bfs-depth1-ntvdm-arms.json','s13-bfs-depth1-ntvdm-batch3.json']:
 p=root/'artifacts/mvdm-audit'/filename;rows=json.loads(p.read_text(encoding='utf8'))
 for r in rows:
  if r['path'] in remaps:r['current_start_line']=remaps[r['path']](r['current_start_line'])
 artifacts[p]=rows
for path,out in prepared.items():(root/path).write_bytes(out)
qp.write_text(json.dumps(q,indent=2,ensure_ascii=False)+'\n',encoding='utf8');rp.write_text(json.dumps(ledger,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
for p,rows in artifacts.items():p.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
(root/'artifacts/mvdm-audit/s13-bfs-depth1-ntvdm-else-new.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8');print('replaced',len(records),'removed branch lines',sum(x['removed_body_lines'] for x in records),'pruned groups',dict(pruned),'counts',dict(collections.Counter(a['status'] for g in q['groups'] if g.get('role')=='current' and g.get('depth')==1 for a in g['arms'])))
