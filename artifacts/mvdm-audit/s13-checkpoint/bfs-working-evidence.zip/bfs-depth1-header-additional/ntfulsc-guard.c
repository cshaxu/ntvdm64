#ifdef X86GFX
#error DIVERGENCE MVDM-HOST-DIV-584: hardware X86GFX declarations are not selected
#endif
int selected;
