import pathlib,json,hashlib,re,collections
root=pathlib.Path('.');path='src/mvdm-host/wow32/wkman.c';p=root/path;qp=root/'build/t473-s13/bfs/baseline-and-queue.json';q=json.loads(qp.read_text(encoding='utf8'));f=next(x for x in q['files'] if x['path']==path);old=p.read_bytes();o=pathlib.Path(f['original']).read_bytes();h=lambda b:hashlib.sha256(b).hexdigest();assert h(old)==f.get('working_sha256',f['current_sha256']) and h(o)==f['original_sha256'];ls=old.split(b'\n');ol=o.replace(b'\r\n',b'\n').split(b'\n');logical={x['after_physical_line']:x['logical_next_line'] for x in json.load(open('build/t473-s13/bfs-debug-wkman-lines/baseline-lines.json'))};items=[(178,220,222,158),(607,621,621,581),(1192,1203,1203,1160),(1229,1231,1235,1197),(1451,1453,1457,1422),(2487,2507,2509,2451),(4469,4537,4537,4410)]
def prep(s):return re.sub(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()) if m.group().startswith('/') else m.group(),s).split('\n')
def bound(lines,start):
 d=1;cut=None
 for i in range(start,len(lines)):
  m=re.match(r'^\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b',lines[i]);
  if not m:continue
  k=m.group(1)
  if k in ('if','ifdef','ifndef'):d+=1
  elif k=='endif':
   d-=1
   if not d:return (cut if cut else i+1),i+1
  elif d==1 and cut is None:cut=i+1
 raise ValueError('unbalanced')
sc=prep(old.decode('latin1'));oc=prep(o.decode('latin1'));records=[]
for start,cut,e,orig in items:
 assert re.match(rb'^\s*#\s*ifdef\s+DEBUG\b',ls[start-1]) and bound(sc,start)==(cut,e) and oc[orig-1].strip()=='#ifdef DEBUG';origcut,orige=bound(oc,orig);body=b'\n'.join(x.rstrip(b'\r') for x in ls[start:cut-1]);obody=b'\n'.join(ol[orig:origcut-1]);assert cut in logical and e in logical;records.append({'path':path,'before_sha256':h(old),'original':f['original'],'original_sha256':h(o),'local_group_before':start,'local_cut_before':cut,'local_end_before':e,'original_group':orig,'original_cut':origcut,'original_end':orige,'removed_body_sha256':h(body),'original_body_sha256':h(obody),'removed_body_lines':cut-start-1,'subsumed_markers':dict(collections.Counter(re.findall(r'MVDM-HOST-DIV-\d+',body.decode('latin1')))),'selected_alternative_line':logical[cut] if cut!=e else None,'following_line':logical[e],'status':'unverified','registration':'MVDM-HOST-DIV-575'})
(root/'build/t473-s13/bfs-ntvdm-before/wkman-debug-before.c').write_bytes(old);new=ls[:]
for start,cut,e,orig in sorted(items,reverse=True):
 cr=b'\r' if ls[start-1].endswith(b'\r') else b'';new[start:cut-1]=[b'#error Excluded unsupported DEBUG WOW profile'+cr];removed=(cut-start-1)-1;newcut=(cut-1)-removed
 if cut!=e:new.insert(newcut+1,('#line '+str(logical[cut])).encode()+cr)
 newend=(e-1)-removed+(1 if cut!=e else 0);new.insert(newend+1,('#line '+str(logical[e])).encode()+cr)
out=b'\n'.join(new)
def move(n):
 delta=0
 for start,cut,e,_ in items:
  if n>=cut:delta+=2-(cut-start)
  if cut!=e and n>cut:delta+=1
  if n>e:delta+=1
 return n+delta
removed=[];groups=[]
for g in q['groups']:
 if g.get('role')!='current' or g['path']!=path:groups.append(g);continue
 n=g['line']
 if any(start<n<cut for start,cut,_,_ in items):
  assert g['depth']>1 and all(a['status']=='unreviewed' for a in g['arms']);removed.append(g);continue
 if any(n==start for start,_,_,_ in items):
  assert g['depth']==1 and g['arms'][0]['status']=='pending';g['arms'][0]['status']='newly-excluded';g['arms'][0]['evidence']='DIV-575; s13-bfs-depth1-debug-wkman.json';g['arms'][0].pop('pending_reason',None)
 g['line']=move(n)
 if isinstance(g.get('parent'),int):g['parent']=move(g['parent'])
 for a in g['arms']:a['line']=move(a['line'])
 groups.append(g)
q['groups']=groups;f['working_sha256']=h(out)
for r in records:r['current_start_line']=move(r['local_group_before']);r['after_sha256']=h(out)
p.write_bytes(out);qp.write_text(json.dumps(q,indent=2,ensure_ascii=False)+'\n',encoding='utf8');(root/'artifacts/mvdm-audit/s13-bfs-depth1-debug-wkman.json').write_text(json.dumps(records,indent=2)+'\n');print('replaced',len(records),'removed body lines',sum(x['removed_body_lines'] for x in records),'pruned unreviewed groups',len(removed),'root',dict(collections.Counter(a['status'] for g in q['groups'] if g.get('role')=='current' and g.get('depth')==1 for a in g['arms'])))
