import json,csv,pathlib,re,hashlib,collections
root=pathlib.Path('.');qp=root/'build/t473-s13/bfs/baseline-and-queue.json';q=json.loads(qp.read_text(encoding='utf8'));macros={'MONITOR','X86GFX'};contexts=json.load(open('build/t473-s13/bfs-depth1-header-contexts.json'))['headers'];flagged=json.load(open('build/t473-s13/bfs-depth1-header-flagged/include-trace.json'));h=lambda b:hashlib.sha256(b).hexdigest();paths=set(contexts);failed=collections.Counter()
for r in flagged:
 assert r['exit']==0 and r['macro_flags']
 for p in paths:
  assert not any(x.lower().replace('\\','/').endswith('/'+pathlib.Path(p).name.lower()) for x in r['include_paths'])
idx=collections.defaultdict(list)
for g in q['groups']:
 if g.get('depth')==1:idx[(g.get('role'),g['path'])].append(g)
def prep(s):return re.sub(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()) if m.group().startswith('/') else m.group(),s).split('\n')
def end(lines,start):
 d=1
 for i in range(start,len(lines)):
  m=re.match(r'^\s*#\s*(if|ifdef|ifndef|endif)\b',lines[i]);
  if not m:continue
  if m.group(1) in ('if','ifdef','ifndef'):d+=1
  else:
   d-=1
   if not d:return i+1
 raise ValueError('unbalanced')
def after(lines,n):return tuple([t for t in (x.strip() for x in lines[n:]) if t and not t.startswith(('#line','//','/*','*','*/'))][:3])
def before(lines,n):return tuple([t for i in range(n-2,-1,-1) if (t:=lines[i].strip()) and not t.startswith(('#line','//','/*','*','*/'))][:3])
records=[]
for path in sorted(paths):
 if not contexts[path] or failed[path]:continue
 f=next(x for x in q['files'] if x['path']==path);p=pathlib.Path(path);op=pathlib.Path(f['original']);assert h(p.read_bytes())==f.get('working_sha256',f['current_sha256']) and h(op.read_bytes())==f['original_sha256'];s=p.read_bytes().decode('latin1');o=op.read_bytes().decode('latin1');src=s.split('\n');org=o.split('\n');sc=prep(s);oc=prep(o);pre=collections.defaultdict(list);post=collections.defaultdict(list);precur=collections.Counter();postcur=collections.Counter()
 for g in idx[('original',f['original'])]:
  a=g['arms'][0];m=a.get('expression')
  if a['kind']=='ifdef' and m in macros:pre[(m,before(org,g['line']))].append(g);post[(m,after(org,end(oc,g['line'])))].append(g)
 for g in idx[('current',path)]:
  a=g['arms'][0];m=a.get('expression')
  if a['kind']=='ifdef' and m in macros:precur[(m,before(src,g['line']))]+=1;postcur[(m,after(src,end(sc,g['line'])))]+=1
 used=set()
 for g in idx[('current',path)]:
  a=g['arms'][0];m=a.get('expression')
  if not(a['kind']=='ifdef' and m in macros and a['status']=='pending'):continue
  n=g['line'];ce=end(sc,n);bk=(m,before(src,n));ak=(m,after(src,ce));m1=pre.get(bk,[]);m2=post.get(ak,[]);hits={t[0]['line'] for t,c in ((m1,precur[bk]),(m2,postcur[ak])) if len(t)==1 and c==1};j=n+1
  if n>=len(src) or not re.match(r'^\s*#\s*ifdef\s+'+re.escape(m)+r'\b',src[n-1]) or not src[n].strip().startswith('#error'):continue
  while j<len(src) and not src[j].strip():j+=1
  if len(hits)!=1 or not re.match(r'^\s*#\s*(else|elif|endif)\b',src[j]):continue
  hit=next(iter(hits));og=next(x for x in idx[('original',f['original'])] if x['line']==hit)
  if [x['kind'] for x in g['arms']]!=[x['kind'] for x in og['arms']] or (m,hit) in used:continue
  used.add((m,hit));a['status']='already-excluded';a['evidence']='Pinned original outer group uniquely anchored; sole #error; actual header include context and flagged-TU audit: s13-bfs-depth1-host-header-contexts.json';a.pop('pending_reason',None);records.append({'path':path,'macro':m,'current_sha256':h(p.read_bytes()),'original':str(op),'original_sha256':h(op.read_bytes()),'local_line':n,'local_end':ce,'original_line':hit,'preceding_anchor':before(src,n) if len(m1)==1 and precur[bk]==1 else None,'following_anchor':after(src,ce) if len(m2)==1 and postcur[ak]==1 else None,'guard':src[n].strip(),'blank_lines_after_guard':j-n-1})
assert records;qp.write_text(json.dumps(q,indent=2,ensure_ascii=False)+'\n',encoding='utf8');artifact={'scope':'first-depth host headers; full historical include contexts revalidated with current compilers, and all explicitly MONITOR/X86GFX-flagged TUs checked for header inclusion','macros':sorted(macros),'header_contexts':contexts,'flagged_translation_units':flagged,'existing_exclusions':records,'limitations':'only unique pinned-original boundaries and sole existing #error bodies classified; audit is not a full release build'};(root/'artifacts/mvdm-audit/s13-bfs-depth1-host-header-contexts.json').write_text(json.dumps(artifact,indent=2)+'\n',encoding='utf8');print('classified',len(records),'by macro',dict(collections.Counter(r['macro'] for r in records)),'files',len(set(r['path'] for r in records)),'root',dict(collections.Counter(a['status'] for g in q['groups'] if g.get('role')=='current' and g.get('depth')==1 for a in g['arms'])))
