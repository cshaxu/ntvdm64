import json,csv,pathlib,re,collections
p=pathlib.Path('build/t473-s13/bfs/baseline-and-queue.json');x=json.loads(p.read_text());cs=json.load(open('build/t473-s13/bfs-live/contexts.json'));inds=json.load(open('build/t473-s13/bfs-live/product-context-indices.json'))['indices'];rows=list(csv.DictReader(open('build/t473-s13/bfs-live/branches.csv',encoding='utf8')));lookup={(r['path'],int(r['line'])):(i,r) for i,r in enumerate(rows)};sha={r['path']:r['current_sha256'].lower() for r in x['files']};marks=collections.defaultdict(set)
for i in inds:
 if cs[i]['exit']==0:
  for m in cs[i]['marks']:marks[m].add(cs[i]['arch'])
parents={(g['path'],g['line']):g for g in x['groups'] if g['role']=='current' and g['depth']==1};todo=[]
for g in x['groups']:
 if g['role']!='current' or g['depth']!=2:continue
 par=parents.get((g['path'],g['parent']));arms=[a for a in par['arms'] if a['line']<g['line']] if par else []
 if arms and arms[-1]['status']!='already-excluded':todo.append(g)
for g in todo:
 for j,a in enumerate(g['arms']):
  pair=lookup.get((g['path'],a['line']))
  if pair and pair[0] in marks and pair[1]['sha256'].lower()==sha[g['path']]:a.update(status='retained-observed',evidence='successful preprocessing in product dependency context',observed_architectures=sorted(marks[pair[0]]));continue
  if j==0 and a['kind']=='if' and a['expression'] in ('0','(0)'):
   lines=pathlib.Path(g['path']).read_text(encoding='latin1').split('\n');body=[];depth=0
   for s in lines[g['line']:]:
    m=re.match(r'^\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b',s)
    if m:
     op=m.group(1)
     if depth==0 and op in ('else','elif','endif'):break
     if op in ('if','ifdef','ifndef'):depth+=1
     if op=='endif':depth-=1
    body.append(s)
   t=[s.strip() for s in body if s.strip()]
   if len(t)==1 and re.match(r'#\s*error\b',t[0]):a.update(status='already-excluded',evidence='literal #if 0 with sole #error; original mapping and diagnostic lines pending');continue
  a.update(status='pending',evidence='not positively witnessed in product dependency contexts; semantic, inclusion and original-boundary review pending')
parents2={(g['path'],g['line']):g for g in todo};possible=confirmed=0
for g in x['groups']:
 if g['role']!='current' or g['depth']!=3:continue
 par=parents2.get((g['path'],g['parent']));arms=[a for a in par['arms'] if a['line']<g['line']] if par else []
 if arms and arms[-1]['status']!='already-excluded':possible+=1
 if arms and arms[-1]['status']=='retained-observed':confirmed+=1
counts=collections.Counter(a['status'] for g in todo for a in g['arms']);print('depth2 groups',len(todo),'arms',sum(counts.values()),'states',dict(counts),'depth3 confirmed',confirmed,'potential',possible);x['depth2_triage']={'groups':len(todo),'counts':dict(counts),'depth3_from_retained':confirmed,'depth3_potential':possible};p.write_text(json.dumps(x,indent=2),encoding='utf8')
