import pathlib,subprocess,json,re,collections
root=pathlib.Path.cwd();ninja=pathlib.Path(r'C:\Users\neko\AppData\Local\Microsoft\WinGet\Packages\BrechtSanders.WinLibs.POSIX.MSVCRT_Microsoft.Winget.Source_8wekyb3d8bbwe\mingw64\bin\ninja.exe'); contexts=json.load(open('build/t473-s13/bfs-live/contexts.json'));jobs=[]
for arch in ('x86','x64'):
 for build in (root/f'build/.ninja/msvc-{arch}-release').rglob('build.ninja'):
  folder=build.parent;p=subprocess.run([str(ninja),'-C',str(folder),'-t','compdb'],capture_output=True,text=True)
  if p.returncode:continue
  for e in json.loads(p.stdout):
   if not re.search(r'(?i)\bcl(?:\.exe)?\s',e.get('command','')):continue
   s=e.get('file','')
   if not s.lower().endswith(('.c','.cpp')) or '/mvdm-guest/' in s.lower().replace('\\','/') or not s.lower().replace('\\','/').startswith(str(root).lower().replace('\\','/')+'/src/') or not pathlib.Path(s).is_file():continue
   jobs.append((arch,str(folder),e))
assert len(jobs)==len(contexts),(len(jobs),len(contexts))
targets={('x86','worker'):['ntvdm.exe','VDMREDIR.dll','nthook32.dll'],('x86','wow32'):['wow32.dll'],('x64','worker'):['ntvwm.exe'],('x64','frontend'):['ntcon.exe'],('x64','monitor'):['ntmon.exe'],('x64','launcher'):['run16.exe'],('x64','service'):['ntsrv.exe'],('x64','hook'):['nthook64.dll']}
cmds={};errors=[]
for (arch,sub),ts in targets.items():
 folder=root/f'build/.ninja/msvc-{arch}-release'/sub
 for target in ts:
  p=subprocess.run([str(ninja),'-C',str(folder),'-t','commands',target],capture_output=True,text=True)
  if p.returncode:errors.append((str(folder),target,p.stderr[-300:]));continue
  cmds.setdefault((arch,str(folder)),set()).update(p.stdout.splitlines())
hits=[]
for i,((arch,folder,e),c) in enumerate(zip(jobs,contexts)):
 if (arch,folder) in cmds and e['command'] in cmds[(arch,folder)]:hits.append(i)
print('jobs',len(jobs),'product_dependency_contexts',len(hits),'failures',sum(contexts[i]['exit']!=0 for i in hits),'target_errors',errors)
pathlib.Path('build/t473-s13/bfs-live/product-context-indices.json').write_text(json.dumps({'indices':hits,'target_errors':errors},indent=2))
