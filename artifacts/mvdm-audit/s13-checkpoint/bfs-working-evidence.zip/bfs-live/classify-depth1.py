import json,pathlib,re,csv,collections
p=pathlib.Path('build/t473-s13/bfs/baseline-and-queue.json');x=json.loads(p.read_text());sha={a['path']:a['current_sha256'].lower() for a in x['files']};cs=json.load(open('build/t473-s13/bfs-live/contexts.json'));inds=json.load(open('build/t473-s13/bfs-live/product-context-indices.json'))['indices'];rows=list(csv.DictReader(open('build/t473-s13/bfs-live/branches.csv',encoding='utf8')));marks=collections.defaultdict(set)
for i in inds:
 c=cs[i]
 if c['exit']==0:
  for m in c['marks']:marks[m].add(c['arch'])
lookup={(r['path'],int(r['line'])):(i,r) for i,r in enumerate(rows)}
for g in x['groups']:
 if g['role']!='current' or g['depth']!=1:continue
 a=g['arms'][0]
 if a['kind']=='if' and a['expression'] in ('0','(0)'):
  lines=pathlib.Path(g['path']).read_text(encoding='latin1').split('\n');body=[];depth=0
  for s in lines[g['line']:]:
   m=re.match(r'^\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b',s)
   if m:
    op=m.group(1)
    if depth==0 and op in ('else','elif','endif'):break
    if op in ('if','ifdef','ifndef'):depth+=1
    if op=='endif':depth-=1
   body.append(s)
  t=[s.strip() for s in body if s.strip()]
  if len(t)==1 and re.match(r'#\s*error\b',t[0]):a.update(status='already-excluded',evidence='literal #if 0 with sole #error; original mapping and line controls pending')
 for a in g['arms']:
  pair=lookup.get((g['path'],a['line']))
  if not pair:continue
  i,r=pair
  if i not in marks or r['sha256'].lower()!=sha[g['path']]:continue
  if a['status']=='already-excluded':raise SystemExit('literal false unexpectedly observed')
  a.update(status='retained-observed',evidence='successful preprocessing in product dependency context',observed_architectures=sorted(marks[i]))
parents={(g['path'],g['line']):g for g in x['groups'] if g['role']=='current' and g['depth']==1};n=0; potential=0
for g in x['groups']:
 if g['role']!='current' or g['depth']!=2:continue
 parent=parents.get((g['path'],g['parent']))
 if not parent:continue
 a=[a for a in parent['arms'] if a['line']<g['line']]
 if a and a[-1]['status']=='retained-observed':n+=1
 if a and a[-1]['status']!='already-excluded':potential+=1
counts=collections.Counter(a['status'] for g in parents.values() for a in g['arms']);print('depth1',dict(counts),'retained_children',n,'potential_children_including_unreviewed',potential);x['depth1_product_observation']={'contexts':len(inds),'successful':sum(cs[i]['exit']==0 for i in inds),'next_depth_groups_from_retained':n,'potential_next_depth_groups':potential};p.write_text(json.dumps(x,indent=2),encoding='utf8')
