#ifdef _USERK_
#error DIVERGENCE OPENNT-HOST-145: kernel USER profile is not selected
#else
SELECTED_PATH
#endif
