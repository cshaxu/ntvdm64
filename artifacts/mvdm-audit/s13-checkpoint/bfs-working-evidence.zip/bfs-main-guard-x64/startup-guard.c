#ifndef CPU_40_STYLE
#error Excluded unsupported non-CPU40 host startup profile
#else
#line 61
int selected_line = __LINE__;
#endif
#line 62
int following_line = __LINE__;
