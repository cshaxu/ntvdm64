#if !defined(X86GFX) && !defined(CCPU)
#error DIVERGENCE MVDM-HOST-DIV-580: non-CCPU non-X86GFX display branch is not selected
#endif
int selected;
