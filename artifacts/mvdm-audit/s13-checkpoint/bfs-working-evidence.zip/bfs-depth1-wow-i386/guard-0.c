#ifdef i386
#error DIVERGENCE MVDM-HOST-DIV-589: historical i386 WOW branch is not selected
#endif
int selected;
