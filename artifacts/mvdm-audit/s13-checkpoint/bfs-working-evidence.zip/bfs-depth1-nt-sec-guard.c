#ifdef X86GFX
#error DIVERGENCE MVDM-HOST-DIV-593: X86GFX branch is not selected
#endif //X86GFX
