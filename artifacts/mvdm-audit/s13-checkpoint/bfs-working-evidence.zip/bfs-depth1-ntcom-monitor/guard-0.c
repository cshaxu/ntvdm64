#ifdef MONITOR
#error DIVERGENCE MVDM-HOST-DIV-579: hardware monitor IRET hooks are not selected
#endif
int selected;
