#if defined(ALLOC_PRAGMA)
#error DIVERGENCE OPENNT-HOST-144: kernel allocation pragma profile is not selected
#endif
