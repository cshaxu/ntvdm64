import pathlib,json,subprocess,importlib.util,re,shutil,hashlib
root=pathlib.Path.cwd();spec=importlib.util.spec_from_file_location('a','build/t473-s13/bfs-live/audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);folder=root/'build/.ninja/msvc-x64-release/worker-reference-x86';entries=json.loads(subprocess.check_output([str(a.NINJA),'-C',str(folder),'-t','compdb'],text=True));path='tests/observation/nt_event_observed.c';e=next(e for e in entries if e.get('file','').replace('\\','/').lower().endswith('/'+path));cmd=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1];cmd=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',cmd);cmd=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',cmd);env=a.env_for('x86');cl=shutil.which('cl.exe',path=env.get('PATH',env.get('Path','')));r=subprocess.run('"'+cl+'" /Zs /showIncludes '+cmd,cwd=folder,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=r.stdout+r.stderr;out=root/'build/t473-s13/bfs-depth1-prod-special';out.mkdir(exist_ok=True);(out/'nt_event_observed_reference.log').write_bytes(raw);incs=[]
for line in raw.decode('mbcs',errors='replace').splitlines():
 m=re.search(r'(?i)including file:\s*(.*)$',line)
 if m and pathlib.Path(m.group(1).strip()).is_file():incs.append(pathlib.Path(m.group(1).strip()))
undefs=[]
for f in [root/path]+incs:
 for n,line in enumerate(f.read_bytes().decode('latin1').split('\n'),1):
  if re.match(r'^\s*#\s*undef\s+PROD\b',line):undefs.append([str(f),n])
rec={'fixture':path,'fixture_sha256':hashlib.sha256((root/path).read_bytes()).hexdigest(),'exit':r.returncode,'included_count':len(incs),'host_def':[str(f) for f in incs if f.name.lower()=='host_def.h'],'source':[str(f) for f in incs if f.name.lower()=='nt_event.c'],'undef_prod':undefs,'flags_include_prod':bool(re.search(r'(?i)(?:/D|-D)PROD(?:\s|=|$)',cmd))};(out/'nt-event-observed-reference-include.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2));assert not r.returncode and rec['host_def'] and rec['source'] and not undefs and rec['flags_include_prod']

