import pathlib,re,json,subprocess,shutil,importlib.util,hashlib,concurrent.futures,functools,collections
root=pathlib.Path.cwd();out=root/'build/t473-s13/bfs-depth1-unresolved-contexts';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('a',root/'build/t473-s13/bfs-live/audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
envs={arch:a.env_for(arch) for arch in ('x86','x64')};cls={arch:shutil.which('cl.exe',path=envs[arch].get('PATH',envs[arch].get('Path',''))) for arch in envs}
names=json.load(open(root/'build/t473-s13/bfs-depth1-unresolved-macros.json'));name_set=set(names);pat=re.compile(r'^\s*#\s*(?:define|undef)\s+('+ '|'.join(map(re.escape,sorted(names,key=len,reverse=True)))+r')\b')
targets=json.load(open(root/'build/t473-s13/bfs-depth1-unresolved-context-targets.json'));bygraph=collections.defaultdict(dict)
for g in sorted(set(x['graph'] for x in targets)):
 p=root/g
 if not (p/'build.ninja').exists():continue
 q=subprocess.run([str(a.NINJA),'-C',str(p),'-t','compdb'],capture_output=True,text=True)
 if q.returncode:continue
 for e in json.loads(q.stdout):
  f=e.get('file','').replace(chr(92),'/');i=f.lower().find('/src/')
  if i>=0:bygraph[g.lower()][f[i+1:].lower()]=e
@functools.lru_cache(maxsize=6000)
def definitions(name):
 try:
  return [[name,n,s.strip()] for n,s in enumerate(pathlib.Path(name).read_bytes().decode('latin1').split('\n'),1) if pat.match(s)]
 except OSError:return [[name,'unreadable','']]
def run(t):
 path=t['path'];g=t['graph'];arch='x86' if 'worker-reference-x86' in g.lower() or 'wow32' in g.lower() else t['arch'];e=bygraph.get(g.lower(),{}).get(path.lower());rec={'path':path,'graph':g,'arch':arch}
 if not e:return dict(rec,exit=None,error='current compdb entry unavailable')
 cmd=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1];cmd=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',cmd);cmd=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',cmd)
 flags=[m.group(0) for m in re.finditer(r'(?<!\S)[/-][dDuU]([A-Za-z_]\w*)(?:=(?:"[^"]*"|\S+))?',cmd) if m.group(1) in name_set]
 r=subprocess.run('"'+cls[arch]+'" /EP /showIncludes '+cmd,cwd=root/g,env=envs[arch],stdout=subprocess.PIPE,stderr=subprocess.PIPE);txt=(r.stdout+r.stderr).decode('mbcs',errors='replace');incs=[]
 for line in txt.splitlines():
  m=re.search(r'(?i)including file:\s*(.*)$',line)
  if m and pathlib.Path(m.group(1).strip()).is_file():incs.append(pathlib.Path(m.group(1).strip()))
 defs=[]
 for f in [root/path]+incs:defs.extend(definitions(str(f)))
 rec.update(exit=r.returncode,source_sha256=hashlib.sha256((root/path).read_bytes()).hexdigest(),include_count=len(incs),macro_definitions=defs,exact_macro_flags=flags,error=txt[-250:] if r.returncode else '')
 return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:records=list(pool.map(run,targets))
(out/'include-trace.json').write_text(json.dumps(records,indent=2)+'\n');bad=[x for x in records if x.get('exit')!=0]
print('unresolved product contexts',len(records),'succeeded',len(records)-len(bad),'failed or missing',len(bad),flush=True)
for x in bad[:10]:print(json.dumps(x),flush=True)
