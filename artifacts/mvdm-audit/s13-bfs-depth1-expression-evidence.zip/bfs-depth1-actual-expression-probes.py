import pathlib,json,re,subprocess,shutil,importlib.util,hashlib,concurrent.futures,collections
root=pathlib.Path.cwd();out=root/'build/t473-s13/bfs-depth1-expression-probes';out.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('a',root/'build/t473-s13/bfs-live/audit.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a);envs={arch:a.env_for(arch) for arch in ('x86','x64')};cls={arch:shutil.which('cl.exe',path=envs[arch].get('PATH',envs[arch].get('Path',''))) for arch in envs}
items=[x for x in json.load(open('artifacts/mvdm-audit/s13-bfs-depth1-unresolved-observed-arms.json'))['records'] if x['path'].endswith('.c') and (x.get('product_macro_classification')=='unknown' or x.get('product_expression_classification')=='unknown')]
targets=json.load(open('build/t473-s13/bfs-depth1-unresolved-context-targets.json'));by_path=collections.defaultdict(list)
for x in targets:by_path[x['path'].lower()].append(x)
graphs={}
for g in set(t['graph'] for x in items for t in by_path[x['path'].lower()]):
 p=root/g
 if (p/'build.ninja').exists():graphs[g]=json.loads(subprocess.check_output([str(a.NINJA),'-C',str(p),'-t','compdb'],text=True))
cases=[(x,t) for x in items for t in by_path[x['path'].lower()]]
def run(job):
 x,t=job;path=x['path'];g=t['graph'];arch='x86' if 'worker-reference-x86' in g.lower() or 'wow32' in g.lower() else t['arch'];n=x['group_start'];src=root/path;data=src.read_bytes().split(b'\n');i=n-1;directive=[data[i]]
 while directive[-1].rstrip(b'\r \t').endswith(b'\\'):
  i+=1;directive.append(data[i])
 key=hashlib.sha256((path+':'+str(n)).encode()).hexdigest()[:16].upper();marker='T473_COND_'+key
 block=b'\n'.join(directive)+b'\n#pragma message("'+marker.encode()+b'_T")\n#else\n#pragma message("'+marker.encode()+b'_F")\n#endif\n'
 data.insert(n-1,block.rstrip(b'\n'));scratch=out/(key+'-'+hashlib.sha256(g.encode()).hexdigest()[:12]+'.c');scratch.write_bytes(b'\n'.join(data))
 e=next((v for v in graphs.get(g,[]) if v.get('file','').replace(chr(92),'/').lower().endswith('/'+path.lower())),None);r={'path':path,'arm_line':x['start'],'group_line':n,'graph':g,'arch':arch,'expression':x['group_arms'][0]['expression']}
 if not e:return dict(r,exit=None,error='missing compdb command')
 source=e['file'].replace(chr(92),'/');cmd=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1];cmd=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',cmd);cmd=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',cmd);cmd=re.sub(re.escape(source),lambda m:str(scratch).replace(chr(92),'/'),cmd,flags=re.I);cmd='/I "'+str(src.parent)+'" '+cmd
 v=subprocess.run('"'+cls[arch]+'" /EP '+cmd,cwd=root/g,env=envs[arch],stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=v.stdout.decode('mbcs',errors='replace');yes=marker+'_T' in raw;no=marker+'_F' in raw
 r.update(exit=v.returncode,primary_condition=(True if yes and not no else False if no and not yes else None),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),error=v.stderr.decode('mbcs',errors='replace')[-200:] if v.returncode else '')
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:records=list(pool.map(run,cases))
bad=[x for x in records if x.get('exit')!=0 or x.get('primary_condition') is None]
p=root/'artifacts/mvdm-audit/s13-bfs-depth1-actual-expression-probes.json';p.write_text(json.dumps({'scope':'scratch source probes of exact original outer directives in real product contexts; no source mutation','records':records,'limitations':['a source macro whose expansion depends on __LINE__ can be affected by the inserted probe','does not establish standalone test profiles or original selected-code mapping']},indent=2)+'\n')
print('unknown source arms',len(items),'product context probes',len(records),'successful',len(records)-len(bad),'failed',len(bad),flush=True)
for x in bad[:10]:print(json.dumps(x),flush=True)


