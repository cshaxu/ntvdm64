import pathlib,re,json,subprocess,shutil,importlib.util,hashlib,concurrent.futures,functools
root=pathlib.Path.cwd();out=root/'build/t473-s13/bfs-depth1-current-x86-full-includes';out.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('a',root/'build/t473-s13/bfs-live/audit.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a);env=a.env_for('x86');cl=shutil.which('cl.exe',path=env.get('PATH',env.get('Path','')))
graphs=['build/.ninja/msvc-x86-release/worker','build/.ninja/msvc-x86-release/wow32','build/.ninja/msvc-x64-release/worker-reference-x86'];jobs=[]
for g in graphs:
 entries=json.loads(subprocess.check_output([str(a.NINJA),'-C',str(root/g),'-t','compdb'],text=True))
 for e in entries:
  f=e.get('file','').replace(chr(92),'/');low=f.lower();i=low.find('/src/');j=low.find('/tests/');k=i if i>=0 else j
  if k<0 or not low.endswith(('.c','.cpp')):continue
  path=f[k+1:]
  if (root/path).is_file():jobs.append((g,path,e))
targets=['src/mvdm-host/softpc.new/host/inc/host_def.h','src/mvdm-host/softpc.new/host/inc/host_cpu.h','src/mvdm-host/softpc.new/host/inc/nt_graph.h','src/mvdm-host/softpc.new/base/inc/gvi.h','src/mvdm-host/softpc.new/base/inc/ica.h','src/mvdm-host/softpc.new/base/inc/ios.h','src/mvdm-host/softpc.new/base/inc/mouse_io.h','src/mvdm-host/softpc.new/base/inc/video.h']
@functools.lru_cache(maxsize=8000)
def changes(name):
 try:return [[name,n,s.strip()] for n,s in enumerate(pathlib.Path(name).read_bytes().decode('latin1').split('\n'),1) if re.match(r'^\s*#\s*(?:define|undef)\s+(?:EGG|VGG|NTVDM|LITTLEND|MONITOR|BIGWIN)\b',s)]
 except OSError:return [[name,'unreadable','']]
def run(job):
 g,path,e=job;cmd=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1];cmd=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',cmd);cmd=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',cmd)
 t=subprocess.run('"'+cl+'" /EP /showIncludes '+cmd,cwd=root/g,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=(t.stdout+t.stderr).decode('mbcs',errors='replace');incs=[]
 for line in raw.splitlines():
  m=re.search(r'(?i)including file:\s*(.*)$',line)
  if m and pathlib.Path(m.group(1).strip()).is_file():incs.append(m.group(1).strip())
 selected=[]
 for i,n in enumerate(incs):
  v=n.replace(chr(92),'/').lower()
  for target in targets:
   if v.endswith('/'+target.lower()):selected.append({'target':target,'include_order':i})
 defs=[]
 if selected:
  for n in [str(root/path)]+incs:defs.extend(changes(n))
 flags=[m.group(0) for m in re.finditer(r'(?<!\S)[/-][dDuU]([A-Za-z_]\w*)(?:=(?:"[^"]*"|\S+))?',cmd) if m.group(1) in ('EGG','VGG','NTVDM','LITTLEND','MONITOR','BIGWIN')]
 return {'path':path,'graph':g,'output':e.get('output',''),'exit':t.returncode,'source_sha256':hashlib.sha256((root/path).read_bytes()).hexdigest(),'selected_target_includes':selected,'relevant_macro_directives':defs,'relevant_flags':flags,'error':raw[-250:] if t.returncode else ''}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:records=list(pool.map(run,jobs))
p=out/'include-summary.json';p.write_text(json.dumps(records,indent=2)+'\n');bad=[x for x in records if x['exit']!=0]
print('current x86 compiler contexts',len(records),'succeeded',len(records)-len(bad),'failed',len(bad),'contexts with target headers',sum(bool(x['selected_target_includes']) for x in records),flush=True)
for x in bad[:12]:print(json.dumps(x),flush=True)
