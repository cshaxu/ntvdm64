from pathlib import Path
import json,csv,re,collections,hashlib
R=Path.cwd();O=R/'build/t483-s6-usage-scan';plan=json.loads((O/'plan.json').read_text(encoding='utf-8'))
contexts=[json.loads(x) for x in (O/'contexts.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(contexts)==len(plan['jobs']) and all(x['exit']==0 for x in contexts)
hits=collections.defaultdict(set);functions=collections.defaultdict(set);seen=collections.Counter();consumers=collections.defaultdict(set)
for c in contexts:
 for p in c['seen']:seen[p]+=1
 for p,ls in c['hits'].items():hits[p].update(ls)
 for p,fs in c['functions'].items():functions[p].update((x['name'],x['start'],x['end']) for x in fs)
 for p in plan['jobs'][c['index']]['interest']:consumers[p].add(c['index'])
def lines(data):
 v=data.decode('latin1').replace('\r\n','\n').split('\n')
 if v[-1]=='':v.pop()
 return v
rows=[];details={}
for x in plan['files']:
 p=x['path'];oldraw=Path(x['original']).read_bytes();raw=(R/p).read_bytes();assert hashlib.sha256(oldraw).hexdigest()==x['original_sha256'];assert hashlib.sha256(raw).hexdigest()==x['current_sha256']
 old=lines(oldraw);cur=lines(raw);total=len(old);logical=1;retained=set();macro_rows=set();macro=False;logical_rows={};mismatch=[]
 for phys,s in enumerate(cur,1):
  m=re.match(r'^\s*#\s*line\s+(\d+)\b',s)
  if m:logical=int(m[1]);continue
  logical_rows.setdefault(logical,[]).append(phys)
  if re.match(r'^\s*#\s*define\b',s):macro=True
  if macro:macro_rows.add(logical)
  if not s.rstrip().endswith('\\'):macro=False
  if 1<=logical<=total and s.strip()==old[logical-1].strip():
   if not s.lstrip().startswith('#'):retained.add(logical)
  elif s.strip() and not s.lstrip().startswith('#'):mismatch.append(logical)
  logical+=1
 selected={n for n in hits[p] if 1<=n<=total};out_of_range=sorted(n for n in hits[p] if not 1<=n<=total)
 scope=set();units=[]
 for name,start,end in sorted(functions[p],key=lambda z:(z[1],z[2],z[0])):
  if end<start or start<1 or start>total:continue
  rng=set(range(start,min(end,total)+1));scope.update(rng)
  units.append({'name':name,'original_logical_start':start,'original_logical_end':end,'retained_original_lines':len(rng & retained)})
 fnrows=scope & retained
 # Count retained original function bodies with internal comments/blank lines,
 # plus compiler-emitted original declarations/data outside those bodies.
 proved=fnrows | ((selected-scope)&retained)
 macro_candidates=macro_rows & set(range(1,total+1))
 suffix=Path(p).suffix
 category='C implementation' if suffix=='.c' else 'header declarations' if suffix=='.h' else 'build/export description'
 valid=bool(seen[p]);metric='retained original function units plus emitted declarations/data' if suffix=='.c' else 'emitted original declaration rows; macros not attributed' if suffix=='.h' else 'not comparable to C preprocessing'
 value=len(proved) if valid else None
 row={'path':p,'category':category,'integration_lines':value,'original_total_lines':total,'integration_percent':round(100*value/total,6) if value is not None else None,'compiled_function_count':len(units),'compiled_function_original_lines':len(fnrows) if valid else None,'compiler_emitted_logical_lines':len(selected) if valid else None,'compiler_emitted_percent':round(100*len(selected)/total,6) if valid else None,'retained_original_nondirective_lines':len(retained),'retained_macro_definition_rows':len(macro_candidates),'non_error_diff_points':x['filtered']['blocks'],'diff_added_lines':x['filtered']['added'],'diff_deleted_lines':x['filtered']['deleted'],'diff_lines':x['filtered']['added']+x['filtered']['deleted'],'preprocessing_contexts':seen[p],'metric':metric,'evidence_status':'observed product compilation; no runtime/link-liveness claim' if valid else 'not a C preprocessing input; no zero-use claim','line_mapping_review_cases':len(x['issues']),'out_of_original_range_emitted_rows':len(out_of_range),'source_sha256':x['current_sha256'],'original_sha256':x['original_sha256'],'original_path':x['original']}
 rows.append(row);details[p]={'functions':units,'retained_function_line_numbers':sorted(fnrows),'counted_original_line_numbers':sorted(proved),'compiler_emitted_line_numbers':sorted(selected),'outside_original_bounds':out_of_range,'retained_macro_definition_rows':sorted(macro_candidates),'contexts':sorted(consumers[p])}
rows.sort(key=lambda x:(x['integration_percent'] is None,x['integration_percent'] if x['integration_percent'] is not None else 0,x['path']))
for i,row in enumerate(rows,1):row['rank']=i
fields=['rank']+[k for k in rows[0] if k!='rank']
def csvwrite(path,items):
 with path.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(items)
csvwrite(O/'all-diff-files-by-usage.csv',rows)
crows=[x for x in rows if x['category']=='C implementation'];csvwrite(O/'c-files-by-usage.csv',crows)
csvwrite(O/'headers-by-usage.csv',[x for x in rows if x['category']=='header declarations'])
(O/'line-evidence.json').write_text(json.dumps(details,indent=2)+'\n',encoding='utf-8')
summary={'head':plan['head'],'files':len(rows),'categories':dict(collections.Counter(x['category'] for x in rows)),'contexts':len(contexts),'passed_contexts':sum(x['exit']==0 for x in contexts),'unbalanced_contexts':[x['index'] for x in contexts if x.get('final_brace_depth')],'diff_points':sum(x['non_error_diff_points'] for x in rows),'diff_lines':sum(x['diff_lines'] for x in rows),'C_below_1_percent':sum(x['integration_percent'] is not None and x['integration_percent']<1 for x in crows),'C_below_5_percent':sum(x['integration_percent'] is not None and x['integration_percent']<5 for x in crows),'C_below_10_percent':sum(x['integration_percent'] is not None and x['integration_percent']<10 for x in crows),'line_unit':'physical LF lines, drop terminal empty row; never current file total as denominator','limitations':['Integration numerator counts retained original function scope rows (comments and blanks included), plus emitted matching original declaration/data rows outside functions. Excludes #error/#line/framework and new adaptation rows.','This is evidenced source footprint, NOT exact executable runtime coverage or a complete dependency slice. Macro definitions outside those scopes are listed separately, not silently counted as used or unused.','Headers are declaration lower bounds; macro expansion does not attribute body rows to definition headers in normal MSVC /E output. Their ratios are not directly comparable to complete C function ranges.','Conditional #line ambiguity is reported from the existing conservative census; affected entries need local source review before an extraction decision.','Product compile/link-input closure includes archive members, not proof every compiled function survives linker garbage collection. No inference of safety to delete.','Two sources files and wow32.def have no C numerator; they are included with N/A, never zero.']}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
md=['# 镜像有差异文件：原版接入占比扫描','',f'基线 `{plan["head"]}`。254个文件；806个当前产品编译上下文全部预处理成功。无产品源码、guest或发布包修改。','', '## 口径','', '分母是固定原版文件的物理LF总行数。分子是可证实保留的原版函数范围行（含函数内注释、空行），加函数外已输出的原版声明／数据行；不计本地新增适配行、条件骨架、#error/#line。宏定义另列，不把未归因宏误报为无用。因此这是可证实接入规模，下限性质；不是精确运行覆盖率，也不是自动删除依据。','', 'C实现和头文件分组排列；头文件的声明行是下限，不能与完整函数行数直接比较。另有3个构建／导出描述文件不适用C预处理占比。所有逐行及函数范围见 line-evidence.json，所有上下文见 contexts.jsonl。','']
for category in ['C implementation','header declarations','build/export description']:
 md+=['## '+category,'','| 文件 | 接入行 | 原版总行 | 占比 | 函数数 | 非-error点 | +行 | −行 | diff行 |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
 for x in rows:
  if x['category']!=category:continue
  ratio='N/A' if x['integration_percent'] is None else f'{x["integration_percent"]:.3f}%';num='N/A' if x['integration_lines'] is None else str(x['integration_lines'])
  md.append(f'| `{x["path"]}` | {num} | {x["original_total_lines"]} | {ratio} | {x["compiled_function_count"]} | {x["non_error_diff_points"]} | {x["diff_added_lines"]} | {x["diff_deleted_lines"]} | {x["diff_lines"]} |')
md+=['','## 边界','']+['- '+x for x in summary['limitations']]
(O/'REPORT.md').write_text('\n'.join(md)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary,ensure_ascii=False));print('LOWEST C:',json.dumps(crows[:20],ensure_ascii=False))
