from pathlib import Path
import json,hashlib,subprocess,re,collections
R=Path.cwd();O=R/'build/t483-s6-usage-scan'
c=json.loads((R/'build/t483-s6-p19/census.json').read_text(encoding='utf-8'))
files=[x for x in c['files'] if x['filtered']['blocks']]
for x in files:
 assert hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['current_sha256']
 assert hashlib.sha256(Path(x['original']).read_bytes()).hexdigest()==x['original_sha256']
lookup={str((R/x['path']).resolve()).replace('\\','/').lower():x['path'] for x in files}
targets={'msvc-x86-release/worker':['ntvdm.exe','VCDEX.DLL','VDMREDIR.dll','nthook32.dll'],'msvc-x86-release/wow32':['wow32.dll'],'msvc-x64-release/worker':['ntvwm.exe'],'msvc-x64-release/frontend':['ntcon.exe'],'msvc-x64-release/monitor':['ntmon.exe'],'msvc-x64-release/launcher':['run16.exe'],'msvc-x64-release/service':['ntsrv.exe'],'msvc-x64-release/hook':['nthook64.dll']}
norm=lambda p:str(p).replace('\\','/').lower()
jobs=[];graphs=[]
for rel,ts in targets.items():
 g=R/'build/.ninja'/rel
 run=lambda *args:subprocess.check_output(['ninja','-C',str(g),'-t',*args],text=True,errors='replace')
 commands=set(run('commands',*ts).splitlines());db=json.loads(run('compdb'));deps={};key=None
 for line in run('deps').splitlines():
  if not line.startswith(' '):
   m=re.match(r'^(.*?):\s+#deps\s+\d+.*\((VALID|STALE)\)',line);key=norm(m[1]) if m else None
   if m:deps[key]={'state':m[2],'paths':[]}
  elif key:deps[key]['paths'].append(norm((g/line.strip()).resolve()))
 for e in db:
  if e['command'] not in commands or not re.search(r'(?i)\bcl(?:\.exe)?\s',e['command']):continue
  dep=deps.get(norm(e['output']),{});src=norm((g/e['file']).resolve());interest=sorted({lookup[p] for p in set(dep.get('paths',[])+[src]) if p in lookup})
  if not interest:continue
  jobs.append({**e,'graph':rel,'arch':'x64' if 'x64' in rel else 'x86','interest':interest,'dep_state':dep.get('state'),'object_sha256':hashlib.sha256((g/e['output']).read_bytes()).hexdigest()})
 graphs.append({'graph':rel,'targets':ts,'ninja_sha256':hashlib.sha256((g/'build.ninja').read_bytes()).hexdigest()})
plan={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':files,'graphs':graphs,'jobs':jobs}
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print('files',len(files),'jobs',len(jobs),'selected files',len(set(p for j in jobs for p in j['interest'])),'deps',collections.Counter(j['dep_state'] for j in jobs))
print('unobserved',[x['path'] for x in files if x['path'] not in set(p for j in jobs for p in j['interest'])])
