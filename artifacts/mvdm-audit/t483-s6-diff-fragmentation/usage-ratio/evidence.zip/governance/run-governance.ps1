$ErrorActionPreference='Stop'
$exe='C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe'
$p=Start-Process $exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"$PSScriptRoot/final-docs.ps1") -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/final-docs.log" -RedirectStandardError "$PSScriptRoot/final-docs.stderr"
$p.Id|Set-Content "$PSScriptRoot/final-docs.pid"
if(!$p.WaitForExit(300000)){taskkill /PID $p.Id /T /F;exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/governance-supervisor.exit"
exit $p.ExitCode
