from pathlib import Path
import subprocess,json,os,re,shutil,hashlib,concurrent.futures,collections,time
R=Path.cwd();O=R/'build/t483-s6-usage-scan';plan=json.loads((O/'plan.json').read_text(encoding='utf-8'));lookup={str((R/x['path']).resolve()).replace('\\','/').lower():x['path'] for x in plan['files']}
DEV=r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat'
envs={};compilers={}
for arch in ['x86','x64']:
 p=subprocess.run(f'"{DEV}" -arch={arch} -host_arch=x64 >nul && set',shell=True,capture_output=True,check=True,timeout=60)
 envs[arch]=dict(x.split('=',1) for x in p.stdout.decode('mbcs',errors='replace').splitlines() if '=' in x and not x.startswith('='));compilers[arch]=shutil.which('cl.exe',path=envs[arch].get('Path',envs[arch].get('PATH','')))
def observe(raw):
 hits=collections.defaultdict(set);funcs=collections.defaultdict(list);seen=set();current='';number=0;depth=0;prefix='';anchor=None;active=None;start=None
 for line in raw.decode('mbcs',errors='replace').split('\n'):
  m=re.match(r'^\s*#(?:line)?\s+(\d+)\s+"([^"]+)"',line)
  if m:
   number=int(m[1]);current=lookup.get(os.path.normpath(m[2].replace(chr(92)+chr(92),chr(92))).replace(chr(92),'/').lower(),'');
   if current:seen.add(current)
   continue
  if line.lstrip().startswith('#'):continue
  loc=(current,number);number+=1
  if line.strip() and current:hits[current].add(loc[1])
  # Preprocessor strips comments. Blank string literals to keep their braces inert.
  clean=re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:'_'*len(m[0]),line)
  parts=re.split(r'([{};])',clean)
  for part in parts:
   if part=='{':
    if depth==0:
     s=prefix.strip();name=None
     if s.endswith(')'):
      level=0;op=None
      for k in range(len(s)-1,-1,-1):
       if s[k]==')':level+=1
       elif s[k]=='(':
        level-=1
        if level==0:op=k;break
      if op is not None:
       nm=re.search(r'(\w+)\s*$',s[:op]);name=nm[1] if nm else None
     active=name;start=anchor
    depth+=1
   elif part=='}':
    depth-=1
    if depth==0:
     if active and start and start[0] and start[0]==current and loc[1]>=start[1]:funcs[current].append({'name':active,'start':start[1],'end':loc[1]})
     active=None;prefix='';anchor=None
   elif part==';' and depth==0:prefix='';anchor=None
   elif depth==0:
    if part.strip():
     if anchor is None:anchor=loc
     prefix+=part+' '
 return {'hits':{k:sorted(v) for k,v in hits.items()},'functions':dict(funcs),'seen':sorted(seen),'final_brace_depth':depth}
def run(pair):
 i,e=pair;t=time.time();arch=e['arch'];args=re.split(r'(?i)\bcl(?:\.exe)?\s+',e['command'],maxsplit=1)[1]
 args=re.sub(r'(?i)(?<!\S)/Fo(?:"[^"]*"|\S+)','',args);args=re.sub(r'(?i)(?<!\S)/(?:c|showIncludes)(?=\s|$)','',args)
 cmd='"'+compilers[arch]+'" /E '+args
 try:
  p=subprocess.run(cmd,cwd=e['directory'],env=envs[arch],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
  result={'index':i,'source':e['file'],'graph':e['graph'],'exit':p.returncode,'seconds':round(time.time()-t,3),'command':cmd,'output_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':p.stderr.decode('mbcs',errors='replace')[-2500:] if p.returncode else ''}
  if p.returncode==0:result.update(observe(p.stdout))
  return result
 except Exception as exc:return {'index':i,'exit':-1,'error':str(exc)}
done=[json.loads(x) for x in (O/'contexts.jsonl').read_text(encoding='utf-8').splitlines()] if (O/'contexts.jsonl').exists() else []
assert all(x['index']==i and x['exit']==0 for i,x in enumerate(done))
with (O/'contexts.jsonl').open('a',encoding='utf-8') as f,concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 bad=0
 for n,x in enumerate(pool.map(run,enumerate(plan['jobs'][len(done):],len(done))),len(done)+1):
  f.write(json.dumps(x)+'\n');f.flush();bad+=x['exit']!=0
  if n%40==0 or n==len(plan['jobs']):print(f'{n}/{len(plan["jobs"])} contexts; failures={bad}',flush=True)
print('DONE',flush=True)
