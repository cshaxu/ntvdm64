$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process python -ArgumentList 'build/t483-s6-usage-scan/capture.py' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/capture.log" -RedirectStandardError "$PSScriptRoot/capture.stderr"
$p.Id|Set-Content "$PSScriptRoot/child.pid"
if(!$p.WaitForExit(1800000)){taskkill /pid $p.Id /t /f;124|Set-Content "$PSScriptRoot/capture.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/capture.exit"
exit $p.ExitCode
