#define RIPMSG0(flags, szFmt)
typedef int (__stdcall *GENERICPROC)();
