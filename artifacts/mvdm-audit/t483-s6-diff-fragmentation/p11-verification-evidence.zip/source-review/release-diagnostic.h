#define RIPMSG0(flags, szFmt)
