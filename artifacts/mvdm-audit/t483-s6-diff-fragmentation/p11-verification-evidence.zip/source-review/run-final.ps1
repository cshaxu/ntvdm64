$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process -FilePath $env:ComSpec -ArgumentList '/d /c build\t483-s6-clmsg-review\final.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/final.log" -RedirectStandardError "$PSScriptRoot/final.stderr"
$p.Id|Set-Content "$PSScriptRoot/final-child.pid"
if(!$p.WaitForExit(180000)){taskkill /pid $p.Id /t /f; 124|Set-Content "$PSScriptRoot/final.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/final.exit"
exit $p.ExitCode
