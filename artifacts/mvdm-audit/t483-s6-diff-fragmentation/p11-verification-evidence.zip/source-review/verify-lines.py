from pathlib import Path
import re,json,sys
p=Path('build/t483-s6-clmsg-review');o=Path('O:/repos.external/OpenNT/windows/core/ntuser/client/clmsg.c').read_text().splitlines();names=list(dict.fromkeys(m[1] for m in re.finditer(r'^\w[^\r\n]*?\b(\w+)\(\r?\n',Path('src/non-mvdm/windows/core/ntuser/client/clmsg.c').read_text(),re.M)));expected={n:next(i+1 for i,l in enumerate(o) if re.search(r'\b'+n+r'\($',l)) for n in names};out={}
for ctx in ['default','cpd']:
 current='';logical=1;found={}
 for line in (p/f'final-{ctx}.i').read_text(encoding='latin1').splitlines():
  m=re.match(r'^#(?:line)?\s+(\d+)\s+"([^"]+)"',line)
  if m:logical=int(m[1]);current=m[2].replace('\\','/');continue
  m=re.match(r'^#(?:line)?\s+(\d+)\s*$',line)
  if m:logical=int(m[1]);continue
  if current.endswith('/final.c'):
   for name in names:
    if re.search(r'\b'+('wow_original_default_window_proc' if name=='DefWindowProcWorker' else name)+r'\(\s*$',line):found.setdefault(name,[]).append(logical)
  logical+=1
 out[ctx]={'function_anchors':found,'mismatches':{n:v for n,v in found.items() if v!=[expected[n]]}}
missing=sorted(set(names)-set().union(*(set(x['function_anchors']) for x in out.values())))
r={'expected':expected,'contexts':out,'missing':missing};(p/sys.argv[1]).write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r));sys.exit(1 if missing or any(x['mismatches'] for x in out.values()) else 0)
