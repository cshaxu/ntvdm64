$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process -FilePath $env:ComSpec -ArgumentList '/d /c build\t483-s6-clmsg-review\callback.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/callback.log" -RedirectStandardError "$PSScriptRoot/callback.stderr"
$p.Id|Set-Content "$PSScriptRoot/callback-child.pid"
if(!$p.WaitForExit(180000)){taskkill /pid $p.Id /t /f; 124|Set-Content "$PSScriptRoot/callback.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/callback.exit"
exit $p.ExitCode
