$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process -FilePath $env:ComSpec -ArgumentList '/d /c build\t483-s6-clmsg-review\diagnostic.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/diagnostic.log" -RedirectStandardError "$PSScriptRoot/diagnostic.stderr"
$p.Id|Set-Content "$PSScriptRoot/diagnostic-child.pid"
if(!$p.WaitForExit(180000)){taskkill /pid $p.Id /t /f; 124|Set-Content "$PSScriptRoot/diagnostic.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/diagnostic.exit"
exit $p.ExitCode
