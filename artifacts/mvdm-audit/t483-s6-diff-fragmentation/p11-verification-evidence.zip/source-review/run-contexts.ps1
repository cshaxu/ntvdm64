$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process -FilePath $env:ComSpec -ArgumentList '/d /c build\t483-s6-clmsg-review\contexts.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/contexts.log" -RedirectStandardError "$PSScriptRoot/contexts.stderr"
$p.Id|Set-Content "$PSScriptRoot/contexts-child.pid"
if(!$p.WaitForExit(180000)){taskkill /pid $p.Id /t /f; 124|Set-Content "$PSScriptRoot/contexts.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/contexts.exit"
exit $p.ExitCode
