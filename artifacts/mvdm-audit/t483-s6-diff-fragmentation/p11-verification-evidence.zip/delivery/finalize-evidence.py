from pathlib import Path
import json,csv,hashlib,zipfile
r=Path.cwd();b=r/'build/t483-s6-p11';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation';j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
for n in ['cached','publish','bitmap-final','message-final','dde','focused','full-isolated','review-check','verification','pipeline','delivery-supervisor']:assert (b/(n+'.exit')).read_text().strip()=='0',n
full=j(b/'full-isolated/timings.json');assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json');pub=j(b/'runtime-publication/result.json')
for x in c['files']:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256']
assert hashlib.sha256((r/'assets/winnt.zip').read_bytes()).hexdigest().upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
rows=j(b/'candidate-final/product-system32-manifest.json');assert len(rows)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in rows:assert hashlib.sha256((dest/x['Name']).read_bytes()).hexdigest().upper()==x['Sha256'].upper()
d={'packet':'M0 T483 S6 P11','status':'Verified and published;Git delivery accompanies receipt','source_checkpoint':c,'reduction':{'blocks':0,'lines':63},'publication':pub,'full':full,'compiler_lines':j(r/'build/t483-s6-clmsg-review/complete-final-lines.json'),'global':{'files':1062,'strict_equal':510,'filtered_zero':807,'nonzero_files':255,'blocks':2312,'lines':53752,'reviewed_files':21,'remaining_files':234,'cumulative_reduction_blocks':21,'cumulative_reduction_lines':771},'winnt_zip_unchanged':True}
(a/'batch-p11-checkpoint.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=a/'clmsg-whole-file-review.json';v=j(p);v['status']='Whole-file reviewed,implemented,verified and published;Git delivery accompanies receipt';v['verification']='P11 cached full,publish11x2,bitmap/message/DDE,control/task-order,Full20,shared boundary and governance passed;final source identity matches checkpoint';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv']:
 with p.open(encoding='utf-8',newline='') as f:q=csv.DictReader(f);fields=q.fieldnames;rs=list(q)
 for x in rs:
  if x['path']!=v['file']:continue
  if 'status' in fields:x['status']='reviewed-verified-p11-residuals-pending-owner'
  else:x.update(verification=v['verification'],delivery='P11;Git delivery accompanies receipt')
 with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rs)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8').replace('20/255 initial difference files reviewed;235 remain. Fifteen changed files','21/255 initial difference files reviewed;234 remain. Sixteen changed files').replace('verified across P2-P10','verified across P2-P11').replace('2312 blocks/53815 lines','2312 blocks/53752 lines').replace('708 lines. Mouse','771 lines. Mouse')
start=s.index('Current:ntuser/client/clmsg.c');end=s.index('\n\n## Current Technical Baseline',start);s=s[:start]+'Next:ntuser/kernel/userk.h,27 non-error blocks.'+s[end:]
pos=s.index('\n\n\nThe canonical pending');s=s[:pos]+'\n| client/clmsg.c |27->27|1042->979|P11 two complete original functions and five macros restored;Full20 passed|'+s[pos:]
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
body='## Current Technical Baseline\n\nP11 cached x86/x64 full builds passed. Package'+pub['package']+' contains11\nimages,published and hash-verified to assets/release and O:/winnt/system32.\nBitmap/message/DDE,controls/task-order,Full20 including real DOS4GW/NESticle,\nshared-boundary and governance passed. Final source identity matches the\nbuilt/published/tested checkpoint. Four original function compiler anchors\nmatch;16 error bodies remain unchanged. No guest or winnt.zip changes.\n\n[P11 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p11-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p11-verification-evidence.zip)\nbind source,package and tests. [Whole-file review](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/clmsg-whole-file-review.json)\nrecords original units restored and residual owner decisions. Earlier receipts\nremain indexed in the worklist. Git delivery accompanies this receipt.\n\n'
s=s[:start]+body+s[end:];p.write_text(s,encoding='utf-8',newline='\n');assert p.stat().st_size<16384
with (a/'README.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n[P11 receipt](batch-p11-checkpoint.json) and [evidence](p11-verification-evidence.zip):clmsg27->27 blocks,1042->979 lines;cached full,publish11x2,focused and Full20 passed. Residual owner decisions remain pending.\n')
with zipfile.ZipFile(a/'p11-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for root,label in [(b,'delivery'),(r/'build/t483-s6-clmsg-review','source-review')]:
  for p in root.rglob('*'):
   if p.is_file() and p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.h','.c'] and not any(part in ['cache-final','candidate-final','runtime-publication'] for part in p.relative_to(root).parts):z.write(p,label+'/'+p.relative_to(root).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print('P11 final receipt and documentation prepared')
