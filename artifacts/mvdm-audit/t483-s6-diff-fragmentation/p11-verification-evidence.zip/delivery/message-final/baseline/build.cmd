@echo off
call "O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32/msvc-x86.cmd" cl.exe /nologo /TC /O2 /MT /W4 /WX /wd4700 /wd4701 /wd4706 /wd4127 /wd4213 /DBASELINE_IMAGE /DTRANSACTION_GROUP /I"O:\repos.hobby\ntvdm64\build\t483-s6-p11\message-final/baseline" "O:\repos.hobby\ntvdm64\test\observation/wow_message_construction_fixture.c" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-p11\message-final/baseline/unit.obj" /Fe"O:\repos.hobby\ntvdm64\build\t483-s6-p11\message-final/baseline/unit.exe"
exit /b %errorlevel%
