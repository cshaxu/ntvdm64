$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 & 'O:/repos.hobby/ntvdm64/build/t483-s6-clmsg-review/run-final.ps1'
 $checks=Get-ChildItem build/t483-s6-clmsg-review -Filter 'final-*.exit'
 if($checks.Count -ne 4){throw 'Missing context results'}
 foreach($f in $checks){if((Get-Content $f.FullName).Trim() -ne '0'){throw "Context failed: $($f.Name)"}}
 python build/t483-s6-clmsg-review/verify-lines.py complete-final-lines.json
 if($LASTEXITCODE){throw 'Final line mismatch'}
 $checkpoint=Get-Content "$PSScriptRoot/source-checkpoint.json" -Raw|ConvertFrom-Json
 foreach($f in $checkpoint.files){if((Get-FileHash $f.path).Hash -ine $f.sha256){throw 'Source hash changed'}}
 $checkpoint|ConvertTo-Json -Depth 8|Set-Content "$PSScriptRoot/line-proof.json"
 $buildPid=[int](Get-Content "$PSScriptRoot/cached-owner.pid")
 $build=Get-Process -Id $buildPid -ErrorAction SilentlyContinue
 if($build -and !$build.WaitForExit(1800000)){throw 'Build still live at handoff deadline;not restarted'}
 if(!(Test-Path "$PSScriptRoot/cached.exit") -or (Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build failure'}
 & "$PSScriptRoot/run-pipeline.ps1"
 if($LASTEXITCODE){throw 'Pipeline failed'}
 '0'|Set-Content "$PSScriptRoot/delivery-supervisor.exit"
}catch{$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/delivery-supervisor.exit";exit 1}
