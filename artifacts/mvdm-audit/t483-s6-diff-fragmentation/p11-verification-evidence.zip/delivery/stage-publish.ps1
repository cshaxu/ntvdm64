$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Staging failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publication failed'}
 0|Set-Content "$PSScriptRoot/stage-publish.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/stage-publish.exit";exit 1}
