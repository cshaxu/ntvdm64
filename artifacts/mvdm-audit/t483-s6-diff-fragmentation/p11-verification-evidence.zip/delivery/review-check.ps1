$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 & tools/audit/verify-wow-shared-boundary.ps1 -WowBuildRoot build/.ninja/msvc-x86-release/wow32
 if($LASTEXITCODE){throw 'Boundary failed'}
 & tools/governance/Verify-DocumentationGovernance.ps1
 if($LASTEXITCODE){throw 'Governance failed'}
 & tools/governance/Test-DocumentationRelativeLinks.ps1
 if($LASTEXITCODE){throw 'Links failed'}
 git diff --check
 if($LASTEXITCODE){throw 'Diff check failed'}
 0|Set-Content "$PSScriptRoot/review-check.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/review-check.exit";exit 1}
