@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cl /nologo /W3 /I"O:\repos.hobby\ntvdm64/src" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-p11\full-isolated\console-font-restore/fixed.obj" /Fe"O:\repos.hobby\ntvdm64\build\t483-s6-p11\full-isolated\console-font-restore/fixed.exe" "O:\repos.hobby\ntvdm64\build\t483-s6-p11\full-isolated\console-font-restore/fixed.c"
exit /b %errorlevel%
