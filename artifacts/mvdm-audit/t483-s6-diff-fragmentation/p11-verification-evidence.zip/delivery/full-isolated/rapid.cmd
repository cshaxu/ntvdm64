@echo off
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-1
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-2
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-3
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-4
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-5
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-6
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-7
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-8
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-9
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-10
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-11
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-12
if errorlevel 1 exit /b 81
"O:\tmp\nff2\system32\run16.exe" command /c mem
if errorlevel 1 exit /b 82
"O:\tmp\nff2\system32\run16.exe" cmd /d /c echo S10-NATIVE-FINAL
if errorlevel 1 exit /b 83
echo S10-RAPID-COMPLETE
exit /b 19
