$ErrorActionPreference='Stop'
$r='O:\repos.hobby\ntvdm64'
$root="$r\build\t483-s6-p30\candidate-final";$stage="$r\build\t483-s6-p30\runtime-publication"
$destinations=@('O:\winnt\system32',"$r\assets\release")
try {
 $lineRows=Get-Content "$r/build/t483-s6-p30/line-proof.json" -Raw|ConvertFrom-Json
 foreach($item in $lineRows.files){if((Get-FileHash "$r/$($item.path)").Hash -ine $item.sha256){throw "Line proof/source mismatch: $($item.path)"}}
 if((Get-Content "$r/build/t483-s6-p30/cached.exit").Trim() -ne '0'){throw 'Cached build incomplete'}
 $checkpoint=Get-Content "$r/build/t483-s6-p30/source-checkpoint.json" -Raw|ConvertFrom-Json
 foreach($source in $checkpoint.files){if((Get-FileHash "$r/$($source.path)").Hash -ine $source.sha256){throw "Source changed after checkpoint: $($source.path)"}}


 foreach($deleted in $checkpoint.deleted){if(Test-Path "$r/$deleted"){throw "Retired source reappeared: $deleted"}}
 if($checkpoint.source_files -ne @($checkpoint.files).Count){throw 'Source checkpoint incomplete'}
 $rows=@(Get-Content "$root\product-system32-manifest.json" -Raw|ConvertFrom-Json)
 if($rows.Count -ne 11){throw 'Incomplete manifest'}
 foreach($row in $rows){if((Get-FileHash "$root\system32\$($row.Name)").Hash -ne $row.Sha256){throw 'Candidate hash mismatch'}}
 if(Test-Path $stage){throw 'Publication stage already exists'}
 New-Item -ItemType Directory "$stage\prior-system","$stage\prior-assets"|Out-Null
 foreach($d in $destinations){$prior=if($d -ieq $destinations[0]){"$stage\prior-system"}else{"$stage\prior-assets"};foreach($row in $rows){Copy-Item "$d\$($row.Name)" "$prior\$($row.Name)"};Copy-Item "$d\release-manifest.json" "$prior\release-manifest.json"}
 $procs=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -match '^O:\\winnt\\system32\\(?:ntsrv|ntvdm|ntvwm|ntcon|run16|ntmon)\.exe$'})
 $procs | Select-Object ProcessId,ExecutablePath,CommandLine | ConvertTo-Json | Set-Content "$stage/terminated-processes.json"
 foreach($p in $procs){Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue}
 try {
  foreach($d in $destinations){foreach($row in $rows){Copy-Item "$root\system32\$($row.Name)" "$d\$($row.Name)" -Force};Copy-Item "$root\product-system32-manifest.json" "$d\release-manifest.json" -Force;foreach($row in $rows){if((Get-FileHash "$d\$($row.Name)").Hash -ne $row.Sha256){throw "Destination mismatch: $d $($row.Name)"}}}
 } catch {
  $failure=$_;foreach($d in $destinations){$prior=if($d -ieq $destinations[0]){"$stage\prior-system"}else{"$stage\prior-assets"};foreach($row in $rows){Copy-Item "$prior\$($row.Name)" "$d\$($row.Name)" -Force};Copy-Item "$prior\release-manifest.json" "$d\release-manifest.json" -Force};throw $failure
 }
 [ordered]@{status='published';package=$rows[0].PackageId;images=11;destinations=$destinations;hashVerified=$true}|ConvertTo-Json|Set-Content "$stage\result.json"
 '0'|Set-Content "$r\build\t483-s6-p30\publish.exit"
 'PASS 11 images published and hash-verified at both destinations'
} catch {$_|Out-String|Write-Error -ErrorAction Continue;'1'|Set-Content "$r\build\t483-s6-p30\publish.exit";exit 1}
