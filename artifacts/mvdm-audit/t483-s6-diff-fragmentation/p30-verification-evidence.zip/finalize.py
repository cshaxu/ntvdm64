from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p30';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','retirement','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log and 'WOW_PROCESS_RETIREMENT errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=215,retired_reviewed_files=11,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=233,extraction_blocks=227,unused_removal_blocks=6,owner_retired_lines=23798,extraction_lines=22582,unused_removal_lines=1216,total_census_reduction_blocks=273,total_census_reduction_lines=24992)
assert (counts['files'],counts['blocks'],counts['lines'])==(1052,2060,29531)
for name,count in [('review-register.csv',2613),('pending-decisions.csv',1571)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'handles-compat-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'handles-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P30',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved full USER handle extraction, not original restoration','All retained mirrors and original guest unchanged','Original GetFullUserHandle name restored with the existing metadata accessor','No next-file admission'])
wr(a/'batch-p30-checkpoint.json',json.dumps(receipt,indent=2)+'\n')

p=r/'docs/states/CURRENT.md';t=p.read_text(encoding='utf-8')
for x,y in [('39/255 initial difference files reviewed;216 remain. P19,P21-P29 retire ten','40/255 initial difference files reviewed;215 remain. P19,P21-P30 retire eleven'),('29 reviewed/245,216 remain','29 reviewed/244,215 remain'),('census:1053 files','census:1052 files'),('(1044 host','(1043 host'),('and245 nonzero','and244 nonzero'),('total2065 blocks/29810 lines','total2060 blocks/29531 lines'),('backlog has1576 rows after retiring ten','backlog has1571 rows after retiring eleven')]:
 assert x in t,x
 t=t.replace(x,y,1)
i=t.index('| kernel/inctlpan.c')
t=t[:i]+'| client/handles.c |5->retired|279->retired|P30 GetFullUserHandle extraction; targeted WOW validation passed|\n'+t[i:]
i=t.index('## Remaining Scope')
t=t[:i]+t[i:].replace('## Remaining Scope\n\n','## Remaining Scope\n\nOwner reviewed queue.c for extraction and elected to retain the mirror.\n\n',1)
i=t.index('## Current Technical Baseline'); k=t.index('## Remaining Scope',i)
t=t[:i]+f'''## Current Technical Baseline

P30 cached x86/x64 build, link provider and import checks, WOW formal graph,
process retirement and WOW lifecycle passed. Package {pub['package']} contains
11 images published and hash verified in assets/release and O:/winnt/system32.
[Receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p30-checkpoint.json).
Full was outside the owner-approved targeted scope.

'''+t[k:]
wr(p,t)
p=a/'README.md';wr(p,p.read_text(encoding='utf-8')+'\n[P30 full USER handle extraction](handles-compat-extraction.json), [receipt](batch-p30-checkpoint.json) and [verification evidence](p30-verification-evidence.zip). The live census is 1052 files, 244 nonzero, 2060 blocks and 29531 lines.\n')
with zipfile.ZipFile(a/'p30-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  rel=p.relative_to(b)
  if p.is_file() and not set(rel.parts)&{'cache-final','candidate-final','runtime-publication'} and p.suffix in {'.json','.log','.txt','.exit','.py','.ps1','.cmd','.c'}:z.write(p,rel.as_posix())
print(counts)
