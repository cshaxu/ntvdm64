$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-ccpu-monitor-boundary.ps1 -WorkerBuild build/.ninja/msvc-x86-release/worker
 if($LASTEXITCODE){throw 'CPU boundary failed'}
 0|Set-Content "$PSScriptRoot/cpu-boundary.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-ccpu-debug-context.ps1 -WorkerBuild build/.ninja/msvc-x86-release/worker
 if($LASTEXITCODE){throw 'CPU debug/reset failed'}
 0|Set-Content "$PSScriptRoot/cpu-debug.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-ccpu-notification.ps1 -BuildRoot build/t483-s6-p7/notification
 if($LASTEXITCODE){throw 'CPU notification failed'}
 0|Set-Content "$PSScriptRoot/cpu-notification.exit"
 foreach($step in @('full-isolated','review-check')) {
  & $exe -NoProfile -ExecutionPolicy Bypass -File "$PSScriptRoot/$step.ps1"
  if($LASTEXITCODE){throw "$step failed"}
 }
 0|Set-Content "$PSScriptRoot/verification.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/verification.exit";exit 1}
