from pathlib import Path
import json,csv,hashlib,zipfile
r=Path.cwd();b=r/'build/t483-s6-p16';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cached','publish','full-isolated','pipeline-supervisor']:
 assert (b/(name+'.exit')).read_text().strip()=='0',name
full=j(b/'full-isolated/timings.json');assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
assert any(x['Gate']=='dos4gw-nesticle' and x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256']
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
files=j(b/'census.json')['files'];path='src/non-mvdm/base/win32/client/vdm.c';row=next(x for x in files if x['path']==path)
assert row['filtered']==dict(blocks=20,added=38,deleted=594) and not row['issues'] and len(row['excluded'])==2
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_files=30,remaining_files=225,cumulative_reduction_blocks=34,cumulative_reduction_lines=1119)
assert counts['blocks']==2299 and counts['lines']==53404 and counts['files']==1063
pub=j(b/'runtime-publication/result.json');review=j(a/'client-vdm-whole-file-review.json');assert not review['line_proof']['mismatches']
review['delivery']='P16 cached full,publish11x2,Full20 passed;governance and Git accompany receipt';review['full']=full
(a/'client-vdm-whole-file-review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
receipt=dict(packet='M0 T483 S6 P16',status='Build publication Full verified;governance and Git follow',source_checkpoint=c,publication=pub,full=full,global_counts=counts,reduction=dict(blocks=3,lines=164),autonomous_changes='Two declaration/binding lines,not transferred implementation',limits=['Four original functions restored;residual decisions remain pending owner','No guest/winnt.zip changes','Historical cast negative evidence reused,not newly rerun'])
(a/'batch-p16-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv']:
 with p.open(encoding='utf-8-sig',newline='') as f:rd=csv.DictReader(f);fields=rd.fieldnames;rows=list(rd)
 for x in rows:
  if x['path']!=path:continue
  if 'remaining_blocks' in fields:x['status']='reviewed-verified-p16-residuals-pending-owner'
  elif x['review_id']!='T483-R1977':x['verification']='P16 actual six-context compile0,cached full,publish11x2,Full20 and logical-line proof passed';x['delivery']='P16;Git accompanies receipt'
 with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8');s=s[:s.index('\nP16 client/vdm.c whole-file')]
s=s.replace('29/255 initial difference files reviewed;226 remain. Twenty-two changed files','30/255 initial difference files reviewed;225 remain. Twenty-three changed files').replace('verified across P2-P15','verified across P2-P16').replace('2302 blocks/53568 lines','2299 blocks/53404 lines').replace('reduction31 blocks/\n955 lines','reduction34 blocks/\n1119 lines')
pos=s.index('\n\n\nThe canonical pending');s=s[:pos]+'\n| client/vdm.c |23->20|796->632|P16 four original functions restored;six compile contexts and Full20 passed|'+s[pos:]
rows=list(csv.DictReader((a/'file-worklist.csv').open(encoding='utf-8')));n=next(x for x in rows if x['rank']=='31');s=s.replace('Next file is '+path+'.','Next file is '+n['path']+'.')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP16 cached x86/x64 full,six actual object contexts and Full20 passed.\nPackage '+pub['package']+' contains11 images,published and\nhash-verified to assets/release and O:/winnt/system32. Full includes actual\nDOS4GW/NESticle. No guest or winnt.zip changes. Four original client functions\nrestored;1868 matched nonblank lines retain original logical numbering.\nGovernance and Git delivery accompany the receipt. Residual decisions are pending.\n\n[P16 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p16-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p16-verification-evidence.zip).\n\n'+s[end:]
p.write_text(s.rstrip()+'\n',encoding='utf-8',newline='\n');assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('23->20 blocks,796->632 lines;delivery pending.','23->20 blocks,796->632 lines;cached build,publish11x2,Full20 passed;Git accompanies receipt.');s+='\n[P16 receipt](batch-p16-checkpoint.json) and [evidence](p16-verification-evidence.zip).\n';p.write_text(s,encoding='utf-8')
with zipfile.ZipFile(a/'p16-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for root,prefix in [(b,''),(r/'build/t483-s6-vdm-review','source-review/')]:
  for p in root.rglob('*'):
   if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(root).parts):continue
   if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.rsp','.txt','.csv'] or (p.suffix=='.png' and 'dos4gw-nesticle' in p.parts):z.write(p,prefix+p.relative_to(root).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print('P16 receipt ready',counts)
