$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 $owned=Get-Process -Id 33288 -ErrorAction SilentlyContinue
 if($owned -and !$owned.WaitForExit(1800000)){throw 'Cached build still live; no restart'}
 if(!(Test-Path "$PSScriptRoot/cached.exit") -or (Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build failed or incomplete'}
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 & "$PSScriptRoot/full-isolated.ps1"
 if($LASTEXITCODE){throw 'Full failed'}
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
 exit 0
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
