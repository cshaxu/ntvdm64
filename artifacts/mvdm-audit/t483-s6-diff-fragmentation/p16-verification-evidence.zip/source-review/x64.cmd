@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
pushd "O:\repos.hobby\ntvdm64\build\.ninja\msvc-x64-release\launcher"
cl "@O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x64-launcher-client\compile.rsp" > "O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x64-launcher-client\compile.log" 2>&1
if errorlevel 1 exit /b %errorlevel%
popd
pushd "O:\repos.hobby\ntvdm64\build\.ninja\msvc-x64-release\launcher"
cl "@O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x64-launcher-classifier\compile.rsp" > "O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x64-launcher-classifier\compile.log" 2>&1
if errorlevel 1 exit /b %errorlevel%
popd
pushd "O:\repos.hobby\ntvdm64\build\.ninja\msvc-x64-release\hook"
cl "@O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x64-hook-unit17\compile.rsp" > "O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x64-hook-unit17\compile.log" 2>&1
if errorlevel 1 exit /b %errorlevel%
popd
exit /b 0
