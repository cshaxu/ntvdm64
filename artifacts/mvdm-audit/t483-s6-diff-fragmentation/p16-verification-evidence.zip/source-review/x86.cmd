@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
pushd "O:\repos.hobby\ntvdm64\build\.ninja\msvc-x86-release\worker"
cl "@O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x86-worker-vdm\compile.rsp" > "O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x86-worker-vdm\compile.log" 2>&1
if errorlevel 1 exit /b %errorlevel%
popd
pushd "O:\repos.hobby\ntvdm64\build\.ninja\msvc-x86-release\worker"
cl "@O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x86-worker-client\compile.rsp" > "O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x86-worker-client\compile.log" 2>&1
if errorlevel 1 exit /b %errorlevel%
popd
pushd "O:\repos.hobby\ntvdm64\build\.ninja\msvc-x86-release\worker"
cl "@O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x86-worker-classifier\compile.rsp" > "O:\repos.hobby\ntvdm64\build\t483-s6-vdm-review\x86-worker-classifier\compile.log" 2>&1
if errorlevel 1 exit /b %errorlevel%
popd
exit /b 0
