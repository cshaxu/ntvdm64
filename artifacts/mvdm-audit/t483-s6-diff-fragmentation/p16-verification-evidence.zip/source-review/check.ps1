$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try{foreach($a in @('x86','x64')){& "$PSScriptRoot/$a.cmd" *> "$PSScriptRoot/$a.log";if($LASTEXITCODE){throw "$a failed $LASTEXITCODE"}};0|Set-Content "$PSScriptRoot/check.exit"}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/check.exit";exit 1}
