$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path "$PSScriptRoot/../..").Path
$logs = Join-Path $PSScriptRoot 'targeted'
$candidate = Join-Path $PSScriptRoot 'candidate-final'
$observer = "$repo/build/.ninja/msvc-x64-release/message-probes/console-startup-observer.exe"
$windowObserver = "$repo/build/t483-s5-p79-final/observers-x64/worker-window-snapshot.exe"
$guestFixture = "$repo/build/M0-T420/S44/p79-fixture/G7.COM"
. "$repo/test/observation/isolated_package_cleanup.ps1"
New-Item -ItemType Directory -Path $logs | Out-Null
$runtime = New-PhysicalRuntimeStage $candidate
try {
    $binary = Get-PackageBinaryRoot $runtime
    $manifest = Get-Content "$candidate/product-system32-manifest.json" -Raw | ConvertFrom-Json
    if (@($manifest).Count -ne 11) { throw 'Expected 11 components' }
    foreach ($row in $manifest) {
        foreach ($path in @("$binary/$($row.Name)", "O:/winnt/system32/$($row.Name)", "$repo/assets/release/$($row.Name)")) {
            if ((Get-IsolatedFileSha256 $path) -ne $row.Sha256) { throw "Published identity mismatch $path" }
        }
    }
    & python "$repo/test/observation/verify-ntvdm-export-ordinals.py" "$binary/ntvdm.exe" "$repo/src/ntvdm-exe/ntvdm-export-ordinals.csv" *> "$logs/ntvdm-export-ordinals.txt"
    if ($LASTEXITCODE) { throw 'NTVDM export ordinal contract failed' }
    $env:PATH = $binary + ';' + (Join-Path $env:SystemRoot 'System32')
    $env:MVDM_OBSERVER_PRIVATE_DESKTOP = '1'
    Remove-Item Env:MVDM_OBSERVER_MILESTONE_INPUT,Env:MVDM_OBSERVER_WINDOW_INPUT -ErrorAction SilentlyContinue
    $env:MVDM_OBSERVER_SHORT_HISTORY = '1'
    & "$repo/test/observation/observe-wow-frontiers.ps1" -Observer $observer -WindowObserver $windowObserver -Prefix wow-p4 -PackageRoot $runtime -ProcessPackageRoot $runtime -LogRoot $logs -WaitTarget -Guests @('WINMINE.EXE')
    $last = ((Get-Content "$logs/wow-p4-winmine-windows.txt" -Raw) -split 'sample-ms=')[-1]
    if ($last -notmatch 'visible=1 class=(?:00C900A800C000D7 text=00C900A800C000D7|004D0069006E00650073007700650065007000650072 text=004D0069006E00650073007700650065007000650072)' -or !$last.Contains('alive=1')) {
        throw 'Required WOW Minesweeper frontier absent'
    }
    Write-Output 'PASS isolated WOW Minesweeper window'
    Remove-Item Env:MVDM_OBSERVER_SHORT_HISTORY
    $env:MVDM_OBSERVER_MILESTONE_INPUT = '1'
    & "$repo/tools/audit/Verify-CommandExitStatus.ps1" -Observer $observer -PackageRoot $runtime -ProcessPackageRoot $runtime -LogRoot $logs -LogPrefix 'console-p4' -GuestFixturePath $guestFixture -OrdinaryFrontend -Cases @('mem-repeat','guest-seven')
    $manifest | ConvertTo-Json | Set-Content "$logs/runtime-manifest.json"
} finally {
    Remove-PhysicalRuntimeStage $runtime
}
'0' | Set-Content "$PSScriptRoot/targeted.exit"
