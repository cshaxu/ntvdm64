from pathlib import Path
import struct,json,hashlib
r=Path.cwd();b=r/'build/t483-s6-p27'
def imports(p):
 d=p.read_bytes();pe=struct.unpack_from('<I',d,60)[0];n=struct.unpack_from('<H',d,pe+6)[0];sz=struct.unpack_from('<H',d,pe+20)[0];o=pe+24;is64=struct.unpack_from('<H',d,o)[0]==0x20b;dirs=o+(112 if is64 else 96);irva=struct.unpack_from('<I',d,dirs+8)[0];secs=[]
 for i in range(n):
  at=o+sz+i*40;vsize,va,rawsize,raw=struct.unpack_from('<IIII',d,at+8);secs.append((va,max(vsize,rawsize),raw))
 def off(va):
  for v,l,p in secs:
   if v<=va<v+l:return p+va-v
  raise ValueError(('Unmapped RVA',p,va))
 def cstr(at):return d[at:d.index(b'\0',at)].decode('ascii')
 result=[]
 if irva:
  at=off(irva)
  while any(struct.unpack_from('<IIIII',d,at)):
   oft,_,_,name,ft=struct.unpack_from('<IIIII',d,at);dll=cstr(off(name));t=off(oft or ft);size=8 if is64 else 4;fmt='<Q' if is64 else '<I'
   while (v:=struct.unpack_from(fmt,d,t)[0]):
    result.append(dll.lower()+'!'+('#'+str(v&65535) if v>>(size*8-1) else cstr(off(v)+2)));t+=size
   at+=20
 return sorted(result)
manifest=json.loads((b/'candidate-final/product-system32-manifest.json').read_text(encoding='utf-8-sig'));report=[]
for row in manifest:
 name=row['Name'];prior=r/'build/t483-s6-p26/candidate-final/system32'/name;current=b/'candidate-final/system32'/name
 a=imports(prior);z=imports(current);assert a==z,('Import provider changed',name,set(a)^set(z))
 report.append(dict(image=name,imports_identical=True,rtl_1970_imports=[x for x in z if 'RtlSecondsSince1970ToTime' in x]))

m=(r/'build/.ninja/msvc-x86-release/wow32/wow32.dll.map').read_text(errors='replace')
owner=[x for x in m.splitlines() if '_CopyInflateRect@16 ' in x]
assert len(owner)==1 and 'wow-control-rect.obj' in owner[0],owner
assert '_CopyOffsetRect@16' not in m
(b/'link-provider-proof.json').write_text(json.dumps(dict(imports=report,owner=owner),indent=2))
