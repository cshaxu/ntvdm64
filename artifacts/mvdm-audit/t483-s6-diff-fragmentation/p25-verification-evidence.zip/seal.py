from pathlib import Path
import json,zipfile
r=Path.cwd();b=r/'build/t483-s6-p25';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
assert (b/'final-docs.exit').read_text().strip()=='0'
p=a/'batch-p25-checkpoint.json';j=json.loads(p.read_text(encoding='utf-8'));j['governance']={'documentation':'passed','relative_links':'passed','diff_check':'passed'};j['status']='Cached build,targeted tests,publication and governance passed;Git delivery accompanies receipt';p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(a/'p25-verification-evidence.zip','a',zipfile.ZIP_DEFLATED) as z:
 for name in ['final-docs.exit','final-docs.log','final-docs.stderr']:z.write(b/name,'governance/'+name)
print('Evidence sealed; Full not run by owner instruction')

