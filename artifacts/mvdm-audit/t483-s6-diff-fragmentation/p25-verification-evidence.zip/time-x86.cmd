@echo off
cd /d O:\repos.hobby\ntvdm64
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cl /nologo /W3 /O2 /Fe:build\t483-s6-p25\native-time-x86.exe /Fo:build\t483-s6-p25\native-time-x86.obj build\t483-s6-p25\native-time.c
if errorlevel 1 exit /b 1
build\t483-s6-p25\native-time-x86.exe
if errorlevel 1 exit /b 1
lib /nologo /list build/.ninja/msvc-x86-release/worker/original-opennt-rtl-x86.lib > build/t483-s6-p25/members-x86-0.txt
if errorlevel 1 exit /b 1
exit /b 0
