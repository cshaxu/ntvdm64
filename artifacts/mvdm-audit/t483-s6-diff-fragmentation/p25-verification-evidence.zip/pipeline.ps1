$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached incomplete'}
 foreach($arch in @('x86','x64')) {
  & $env:ComSpec /d /c "build\t483-s6-p25\time-$arch.cmd"
  if($LASTEXITCODE){throw "Native time/archive check failed: $arch"}
 }
 foreach($p in Get-ChildItem "$PSScriptRoot/members-*.txt") {
  $members=Get-Content $p -Raw
  if(!$members -or $members -match '(?im)(?:^|[/\\])time\.obj\s*$'){throw "Retired time member remains: $p"}
 }
 '0'|Set-Content "$PSScriptRoot/time-provider.exit"
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 python "$PSScriptRoot/verify-provider.py"
 if($LASTEXITCODE){throw "Product provider changed"}
 '0'|Set-Content "$PSScriptRoot/provider-proof.exit"
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p25/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'WOW lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
}catch{$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
