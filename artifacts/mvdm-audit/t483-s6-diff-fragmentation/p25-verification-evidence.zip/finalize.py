from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p25';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','time-provider','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=220,retired_reviewed_files=6,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=214,extraction_blocks=208,unused_removal_blocks=6,owner_retired_lines=21733,extraction_lines=20517,unused_removal_lines=1216,total_census_reduction_blocks=254,total_census_reduction_lines=22927)
assert (counts['files'],counts['blocks'],counts['lines'])==(1057,2079,31596)
for name,count in [('review-register.csv',2648),('pending-decisions.csv',1596)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'rtl-time-retirement.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'rtl-time-retirement.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P25',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved unused archive-member removal, no compat replacement','All retained mirrors and original guest unchanged','Native NTDLL seven calendar vectors passed on x86 and x64; no product caller newly redirected','No next-file admission'])
wr(a/'batch-p25-checkpoint.json',json.dumps(receipt,indent=2)+'\n')
# Confirm the generated live graph and archive-member evidence actually exclude time.c.
for p in (r/'build/.ninja').rglob('build.ninja'):
 if any(x in p.as_posix() for x in ['msvc-x86-release/worker','msvc-x64-release/worker','msvc-x64-release/launcher','msvc-x64-release/service']):
  assert 'obj/opennt-rtl/time.obj' not in p.read_text(encoding='utf-8'),str(p)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8')
s=s.replace('34/255 initial difference files reviewed;221 remain. P19,P21-P24 retire five','35/255 initial difference files reviewed;220 remain. P19,P21-P25 retire six').replace('live population is29 reviewed/250,221 remain.','live population is29 reviewed/249,220 remain.').replace('Current census:1058 files','Current census:1057 files').replace('(1049 host','(1048 host').replace('and250 nonzero files','and249 nonzero files').replace('Current delivered total2085 blocks/32812 lines.','Current delivered total2079 blocks/31596 lines.')
s=s.replace('The canonical pending backlog has1601 rows after retiring five owner-approved mirror files,','The canonical pending backlog has1596 rows after retiring six owner-approved mirror files,')
s=s.replace('| client/client.c |8->retired|3564->retired|P24 five compat units;original bodies and targeted lifecycle passed|','| client/client.c |8->retired|3564->retired|P24 five compat units;original bodies and targeted lifecycle passed|\n| rtl/time.c |6->removed|1216->removed|P25 unused archive member removed;no compat replacement|')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP25 cached x86/x64 build and targeted verification passed:RTL archive member\nchecks,native NTDLL seven calendar cases on both architectures,and actual WOW\nlifecycle. Full was not run,per owner-selected targeted scope. Package '+pub['package']+'\ncontains11 images,published and hash-verified to assets/release and O:/winnt/system32.\nRetained mirrors,guest and winnt.zip are unchanged.\n[P25 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p25-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p25-verification-evidence.zip).\n\n'+s[end:]
s=s.replace('## P25 In Progress','## P25 Delivery');s+='\nP25 removes6 blocks/1216 lines without replacement. Cumulative original\nrestoration40 blocks/1194 lines,compat extractions208 blocks/20517 lines,\nunused removal6 blocks/1216 lines:total254 blocks/22927 lines.\nMain register2648 rows;pending1596 rows. Build,publish11x2,targeted tests\npassed;governance and Git accompany receipt. No next-file admission.\n';wr(p,s);assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('Unused member removal;final build,publication and targeted checks pending.','Unused member removal;cached build,archive verification,publish11x2 and targeted tests passed.');s+='\n[P25 receipt](batch-p25-checkpoint.json) and [verification evidence](p25-verification-evidence.zip).\nCurrent census:1057 files,249 nonzero,2079 blocks/31596 lines.\nP20 usage ratios predate the now-removed RTL time.c.\n';wr(p,s)
with zipfile.ZipFile(a/'p25-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):continue
  if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv','.c']:z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print(counts)
