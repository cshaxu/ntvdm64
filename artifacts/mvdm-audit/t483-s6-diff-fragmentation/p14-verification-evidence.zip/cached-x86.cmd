@echo off
cd /d O:\repos.hobby\ntvdm64
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
cmake --preset msvc-x86-release-ccache -DNTVDM_POWERSHELL:FILEPATH="C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe"
if errorlevel 1 exit /b 1
cmake --build --preset msvc-x86-release-ccache
if errorlevel 1 exit /b %errorlevel%
ninja -C build\.ninja\msvc-x86-release\worker ntvdm.exe VCDEX.DLL VDMREDIR.dll nthook32.dll ntvdm-command-capture-test.exe ntvdm-command-launch-test.exe ccpu-monitor-boundary-test.exe debug-register-binding-test.exe ccpu-halt-reset-test.exe
if errorlevel 1 exit /b %errorlevel%
cmake --build --preset msvc-x86-release-ccache --target wow32
if errorlevel 1 exit /b 1
exit /b 0
