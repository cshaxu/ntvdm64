from pathlib import Path
import csv, hashlib, json, zipfile

r=Path.cwd(); b=r/'build/t483-s6-p14'
a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cached','publish','command-tests','full-isolated','pipeline','pipeline-supervisor','delivery-supervisor']:
    assert (b/(name+'.exit')).read_text().strip()=='0',name
full=j(b/'full-isolated/timings.json')
assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
assert any(x['Gate']=='dos4gw-nesticle' and x['Passed'] for x in full['Gates'])
checkpoint=j(b/'source-checkpoint.json'); newline=j(b/'newline-identity.json')
for x in checkpoint['files']:
    actual=sha(r/x['path'])
    if x['path'].endswith('/cmdexec.c'):
        assert x['sha256']==newline['compiled_source_sha256']
        assert actual==newline['final_source_sha256'] and newline['normalized_bytes_identical']
        assert actual==j(a/'cmdexec-whole-file-review.json')['after_sha256']
    else: assert actual==x['sha256']
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
manifest=j(b/'candidate-final/product-system32-manifest.json');assert len(manifest)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
    for x in manifest:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
files=j(b/'census.json')['files']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_files=28,remaining_files=227,cumulative_reduction_blocks=31,cumulative_reduction_lines=939)
assert counts['blocks']==2302 and counts['lines']==53584 and counts['files']==1063,counts
pub=j(b/'runtime-publication/result.json')
receipt=dict(packet='M0 T483 S6 P14',status='Built, published, focused and Full verified; governance and Git delivery tracked separately',source_checkpoint=checkpoint,final_newline_identity=newline,reduction=dict(blocks=7,lines=42),publication=pub,full=full,global_counts=counts,line_proof=j(b/'original-line-proof.json'),winnt_zip_unchanged=True,limits=['No runtime semantic change claimed from restored unused declaration.','Source-level line proof is not a separate preprocessor run.','sevid001 remains unchanged; existing source/controls reviewed, no new device test claim.','Residual owner decisions remain pending.'])
(a/'batch-p14-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
paths={'src/mvdm-host/dos/command/cmdexec.c','src/mvdm-host/wow32/wkman.c'}
for name in ['cmdexec','wkman']:
    p=a/(name+'-whole-file-review.json');d=j(p)
    d['delivery']='P14 cached full, publish11x2, COMMAND fixtures and Full20 passed; governance/Git delivery follows receipt'
    d['validation']='Final cmdexec physical newline correction is normalized-byte-identical to compiled source; no other postbuild source edits'
    p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv']:
    with p.open(encoding='utf-8-sig',newline='') as f:reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
    for x in rows:
        if x['path'] not in paths:continue
        if 'remaining_blocks' in fields:x['status']='reviewed-verified-p14-residuals-pending-owner'
        elif x['review_status']=='pending-decision':
            x['verification']='P14 cached full, published11x2, COMMAND fixtures and Full20 passed; source line proof and final newline identity archived'
            x['delivery']='P14; Git delivery accompanies receipt'
    with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8')
s=s.replace('Nineteen changed files\nverified across P2-P13;seven reviewed unchanged;two files locally restored.','Twenty-one changed files\nverified across P2-P14;seven reviewed unchanged.')
s=s.replace('cumulative delivered reduction24 blocks/\n897 lines;additional7 blocks/42 lines restored locally,not delivered.','cumulative verified reduction31 blocks/\n939 lines;P14 Git delivery pending.')
s=s.replace('No residual omission is silently approved. Next file is wkman.c.','No residual omission is silently approved. Next audit follows P14 Git delivery.')
pos=s.index('\n\n\nThe canonical pending')
s=s[:pos]+'\n| wow32/wkman.c |25->25|46->45|P14 extra blank removed;Full20 passed|\n| command/cmdexec.c |24->17|123->82|P14 declaration/format restored;Full20 passed|'+s[pos:]
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'''## Current Technical Baseline

P14 cached x86/x64 full, COMMAND capture/launch fixtures and Full20 passed.
Package'''+pub['package']+''' contains11 images, published and
hash-verified to assets/release and O:/winnt/system32. Full includes the real
DOS4GW/NESticle gate. No guest or winnt.zip changes. Final physical newline
correction is normalized-byte-identical to compiled source; preserved existing
three CRLF lines. Governance and Git delivery follow the evidence receipt.

[P14 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p14-checkpoint.json)
and [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p14-verification-evidence.zip)
bind sources, package and tests. Pending decisions are not approved by test success.

'''+s[end:]
if '\nS6 wkman review:' in s:s=s[:s.index('\nS6 wkman review:')]
p.write_text(s.rstrip()+'\n',encoding='utf-8',newline='\n');assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('P14 build/delivery pending.','P14 build/publication/Full passed; governance/Git follow receipt.')
s+='\n[P14 receipt](batch-p14-checkpoint.json) and [evidence](p14-verification-evidence.zip):combined7 blocks/42 lines restored;Full20 passed.\n'
p.write_text(s,encoding='utf-8',newline='\n')
with zipfile.ZipFile(a/'p14-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in b.rglob('*'):
        if p.is_file() and p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv'] and not any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):z.write(p,p.relative_to(b).as_posix())
        elif p.is_file() and p.suffix=='.png' and 'dos4gw-nesticle' in p.parts:z.write(p,p.relative_to(b).as_posix())
    z.write(b/'runtime-publication/result.json','publication/result.json')
print('P14 verified receipt ready',counts)
