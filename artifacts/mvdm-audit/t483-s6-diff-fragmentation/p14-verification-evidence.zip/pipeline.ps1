$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 foreach($name in @('ntvdm-command-capture-test.exe','ntvdm-command-launch-test.exe')){
  & "build/.ninja/msvc-x86-release/worker/$name"
  if($LASTEXITCODE){throw "$name failed"}
 }
 '0'|Set-Content "$PSScriptRoot/command-tests.exit"
 & "$PSScriptRoot/full-isolated.ps1"
 if($LASTEXITCODE){throw 'Full failed'}
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
 exit 0
} catch {$_|Out-String|Write-Output; '1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
