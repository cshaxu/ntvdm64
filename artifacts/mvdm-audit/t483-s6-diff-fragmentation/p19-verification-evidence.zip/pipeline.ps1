$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 if(!(Test-Path "$PSScriptRoot/cached.exit") -or (Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build failed or incomplete'}
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 & 'C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe' -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-control-boundaries.ps1 -EvidenceRoot build/t483-s6-p19/focused-final
 if($LASTEXITCODE){throw 'WOW boundaries failed'}
 '0'|Set-Content "$PSScriptRoot/focused.exit"
 & 'C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe' -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p19/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'Cleanup exception/lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 & "$PSScriptRoot/full-isolated.ps1"
 if($LASTEXITCODE){throw 'Full failed'}
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
 exit 0
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
