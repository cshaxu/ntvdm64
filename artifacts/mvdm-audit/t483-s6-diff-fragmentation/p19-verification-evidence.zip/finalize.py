from pathlib import Path
import json,csv,hashlib,zipfile,re
r=Path.cwd();b=r/'build/t483-s6-p19';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cached','publish','focused','lifecycle','full-isolated','pipeline-supervisor']:
 assert (b/(name+'.exit')).read_text().strip()=='0',name
log=(b/'pipeline.log').read_text(encoding='utf-8-sig')
passed=re.findall(r'^wow_[^ ]+ exit=0 elapsed_seconds=',log,re.M);assert len(passed)==38,len(passed)
assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
assert 'WOW_CONTROL_FNID errors=0' in (b/'focused-final/wow_control_fnid_fixture.stdout.log').read_text()
full=j(b/'full-isolated/timings.json');assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
assert any(x['Gate']=='dos4gw-nesticle' and x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256']
for x in c['deleted']:assert not (r/x).exists()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=32,remaining_files=222,retired_reviewed_files=1,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=130,owner_retired_lines=9237,total_census_reduction_blocks=170,total_census_reduction_lines=10431)
assert counts['blocks']==2163 and counts['lines']==44092 and counts['files']==1062
pub=j(b/'runtime-publication/result.json');review=j(a/'ntstubs-compat-extraction.json');review['status']='P19 cached full,publish11x2,focused38,lifecycle and Full20 passed;governance and Git accompany receipt'
(a/'ntstubs-compat-extraction.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
receipt=dict(packet='M0 T483 S6 P19',status='Build publication tests verified;governance and Git accompany receipt',source_checkpoint=c,publication=pub,full=full,focused={'count':38,'passed':38,'fnid':'12 contract assertions, errors=0; controlled HWND boundary, real production operation'},lifecycle='errors=0',global_counts=counts,retirement=dict(file=c['deleted'][0],blocks=130,lines=9237,classification='Owner-approved compat extraction, not original restoration'),limits=['No new guest changes or winnt.zip changes','Other mirrors unchanged by hash','No automatic next-file admission'])
(a/'batch-p19-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8').replace('Current candidate total2163','Current delivered total2163').replace('P19 owner-approved compat extraction;delivery pending','P19 compat extraction;focused38 and Full20 passed').replace('## P19 In Progress','## P19 Delivery').replace('Cached build/publication/Full verification and Git delivery pending.','Cached build,publish11x2,focused38,lifecycle and Full20 passed;Git accompanies receipt.')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP19 cached full,WOW focused38,actual lifecycle and Full20 passed.\nPackage '+pub['package']+' contains11 images,published and\nhash-verified to assets/release and O:/winnt/system32. Full includes actual\nDOS4GW/NESticle. The owner-approved FNID extraction retires kernel/ntstubs.c;\nits existing semantics now reside in compat. No guest or winnt.zip changes.\n\n[P19 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p19-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p19-verification-evidence.zip).\n\n'+s[end:]
p.write_text(s,encoding='utf-8',newline='\n');assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('Build/publication/test delivery pending.','Cached full,publish11x2,focused38,lifecycle and Full20 passed;Git accompanies receipt.');s+='\n[P19 receipt](batch-p19-checkpoint.json) and [evidence](p19-verification-evidence.zip).\n';p.write_text(s,encoding='utf-8',newline='\n')
with zipfile.ZipFile(a/'p19-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):continue
  if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.rsp','.txt','.csv','.c'] or (p.suffix=='.png' and 'dos4gw-nesticle' in p.parts):z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print('P19 receipt ready',counts)
