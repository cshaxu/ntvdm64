from pathlib import Path
import json,csv,hashlib,zipfile,re
r=Path.cwd();b=r/'build/t483-s6-p18';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cached','publish','focused','lifecycle','full-isolated','pipeline-supervisor']:
 assert (b/(name+'.exit')).read_text().strip()=='0',name
log=(b/'pipeline.log').read_text(encoding='utf-8-sig')
passed=re.findall(r'^wow_[^ ]+ exit=0 elapsed_seconds=',log,re.M);assert len(passed)==37,len(passed)
assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log and 'WOW_FIXTURE_OK case=task-lifecycle' in log
full=j(b/'full-isolated/timings.json');assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
assert any(x['Gate']=='dos4gw-nesticle' and x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256']
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
files=j(b/'census.json')['files'];path='src/non-mvdm/windows/core/ntuser/kernel/cleanup.c';row=next(x for x in files if x['path']==path)
assert row['filtered']==dict(blocks=20,added=24,deleted=20) and not row['issues'] and len(row['excluded'])==1
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_files=33,remaining_files=222,cumulative_reduction_blocks=40,cumulative_reduction_lines=1194)
assert counts['blocks']==2293 and counts['lines']==53329 and counts['files']==1063
pub=j(b/'runtime-publication/result.json');review=j(a/'cleanup-whole-file-review.json');assert not review['line_proof']['mismatches']
review['status']='P18 cached full,publish11x2,focused37,lifecycle and Full20 passed;governance and Git accompany receipt'
review['test']='Final active lifecycle fixture passed:ClientDied exception status,zero parameters,noncontinuable flag and unwind checked;WOW_USER_TASK_LIFECYCLE errors=0'
(a/'cleanup-whole-file-review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
receipt=dict(packet='M0 T483 S6 P18',status='Build publication Full verified;governance and Git follow',source_checkpoint=c,publication=pub,full=full,focused={'count':37,'passed':37},lifecycle='errors=0;restored ClientDied contract included',global_counts=counts,reduction=dict(blocks=1,lines=22),autonomous_changes='Five binding-header lines:comment,declaration,existing RTL alias and original status constant;no new function or state',limits=['ClientDied restored;no new production caller','client/wow.c reviewed unchanged;historical controls not rerun','Residual owner decisions remain pending;no guest/winnt.zip changes'])
(a/'batch-p18-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv']:
 with p.open(encoding='utf-8-sig',newline='') as f:rd=csv.DictReader(f);fields=rd.fieldnames;rows=list(rd)
 for x in rows:
  if x['path']!=path:continue
  if 'remaining_blocks' in fields:x['status']='reviewed-verified-p18-residuals-pending-owner'
  else:
   x['mirror_diff_delta']=x['mirror_diff_delta'].replace('P18 final delivery pending','P18 verified;Git accompanies receipt')
   x['verification']='P18 cached full,publish11x2,focused37,actual lifecycle and Full20 passed;254 original logical matches'
   x['delivery']='P18;Git accompanies receipt'
   if x['review_id']=='T483-R2500':x['change_plan']='ClientDied restored and verified;historical aggregate includes remaining header boundary,pending owner.'
 with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8');s=s[:s.index('\nS6 rank32 client/wow.c reviewed')]
s=s.replace('32/255 initial difference files reviewed;223 remain. Twenty-four changed files','33/255 initial difference files reviewed;222 remain. Twenty-five changed files').replace('verified across P2-P17','verified across P2-P18').replace('2294 blocks/53351 lines','2293 blocks/53329 lines').replace('reduction39 blocks/\n1172 lines','reduction40 blocks/\n1194 lines')
pos=s.index('\n\n\nThe canonical pending');s=s[:pos]+'\n| client/wow.c |21->21|832->832|No source change;94 original logical rows match;residual decisions pending|\n| kernel/cleanup.c |21->20|66->44|P18 original ClientDied restored;focused37,lifecycle and Full20 passed|'+s[pos:]
s=s.replace('Next file is '+path+'.','Next file is src/mvdm-host/softpc.new/host/src/nt_graph.c.')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP18 cached x86/x64 full,WOW focused37,actual lifecycle and Full20 passed.\nPackage '+pub['package']+' contains11 images,published and\nhash-verified to assets/release and O:/winnt/system32. Full includes actual\nDOS4GW/NESticle. No guest or winnt.zip changes. Original ClientDied restored\nthrough existing native RTL exception provider;254 meaningful original logical\nlines match. Residual decisions remain pending;governance and Git accompany receipt.\n\n[P18 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p18-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p18-verification-evidence.zip).\n\n'+s[end:]
p.write_text(s.rstrip()+'\n',encoding='utf-8',newline='\n');assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('Final delivery pending.','P18 cached full,publish11x2,focused37,lifecycle and Full20 passed;Git accompanies receipt.');s+='\n[P18 receipt](batch-p18-checkpoint.json) and [evidence](p18-verification-evidence.zip).\n';p.write_text(s,encoding='utf-8',newline='\n')
with zipfile.ZipFile(a/'p18-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for root,prefix in [(b,''),(r/'build/t483-s6-cleanup-review','source-review/')]:
  for p in root.rglob('*'):
   if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(root).parts):continue
   if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.rsp','.txt','.csv','.c'] or (p.suffix=='.png' and 'dos4gw-nesticle' in p.parts):z.write(p,prefix+p.relative_to(root).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print('P18 receipt ready',counts)
