@echo off
cd /d O:\repos.hobby\ntvdm64
call build\t483-s6-p18\cached-x86.cmd
if errorlevel 1 exit /b %errorlevel%
call build\t483-s6-p18\cached-x64.cmd
exit /b %errorlevel%

