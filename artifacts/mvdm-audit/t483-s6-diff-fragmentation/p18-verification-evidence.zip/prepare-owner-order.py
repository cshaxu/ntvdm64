from pathlib import Path
import json,csv,hashlib
r=Path.cwd();a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation';b=r/'build/t483-s6-p18'
c=json.loads((b/'census.json').read_text(encoding='utf-8'));prior={x['path']:x for x in csv.DictReader((a/'file-worklist.csv').open(encoding='utf-8',newline=''))}
for x in c['files']:
 assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['current_sha256'],x['path']
items=sorted((x for x in c['files'] if x['filtered']['blocks']),key=lambda x:(-x['filtered']['blocks'],x['path']))
fields=['rank','path','non_error_blocks','added','deleted','difference_lines','paired_error_bodies','mask_review_cases','prior_worklist_rank','review_status','source_sha256']
with (a/'owner-review-order.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader()
 for n,x in enumerate(items,1):
  q=x['filtered'];p=prior.get(x['path'],{});w.writerow(dict(rank=n,path=x['path'],non_error_blocks=q['blocks'],added=q['added'],deleted=q['deleted'],difference_lines=q['added']+q['deleted'],paired_error_bodies=len(x['excluded']),mask_review_cases=len(x['issues']),prior_worklist_rank=p.get('rank',''),review_status=p.get('status','not-previously-listed'),source_sha256=x['current_sha256']))
summary={'scope':'All current nonzero normalized/error-masked mirror files,including reviewed/pending files;not only unaudited files','sort':'non_error_blocks descending,path ascending for ties','files':len(items),'blocks':sum(x['filtered']['blocks'] for x in items),'lines':sum(x['filtered']['added']+x['filtered']['deleted'] for x in items),'mask_uncertainty_files':sum(bool(x['issues']) for x in items),'note':'Only proven paired error bodies masked. Ambiguous or added conditions remain counted;do not mislabel these as proved semantic differences. Source hashes checked against fresh census.','execution':'Owner manual review;no automatic next-file admission after P18'}
(a/'owner-review-order.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
p=a/'README.md';s=p.read_text(encoding='utf-8');s+='\n## Owner manual review order after P18\n\n[Current descending file list](owner-review-order.csv) and [counting summary](owner-review-order.json) cover every remaining nonzero mirror,including already reviewed files. Sort by non-error blocks descending,then path ascending. Prior worklist ranks remain as history. Ambiguous exclusion matches remain counted and explicitly flagged. The owner selects the next file;automatic progression stops after P18 delivery.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8');s=s.replace('No residual omission is silently approved. Next file is src/mvdm-host/softpc.new/host/src/nt_graph.c.','No residual omission is silently approved. Owner superseding direction:after P18,\nstop automatic progression and hand over every remaining nonzero file ordered by\nnon-error blocks descending,path ascending for ties. Await owner file selection.\n[Manual review order](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/owner-review-order.csv).');p.write_text(s,encoding='utf-8',newline='\n');assert p.stat().st_size<16384
print(summary)
