$ErrorActionPreference='Stop'
$p=Start-Process cmd.exe -ArgumentList @('/d','/c',"`"$PSScriptRoot/controls.cmd`"") -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/controls.log" -RedirectStandardError "$PSScriptRoot/controls.stderr.log"
$null=$p.Handle
@{pid=$p.Id;started=[DateTime]::UtcNow.ToString('o');deadlineSeconds=180}|ConvertTo-Json|Set-Content "$PSScriptRoot/controls-process.json"
if(!$p.WaitForExit(180000)){& taskkill.exe /PID $p.Id /T /F;throw 'Owned controls deadline exceeded'}
$p.ExitCode|Set-Content "$PSScriptRoot/controls-run.exit"
exit $p.ExitCode
