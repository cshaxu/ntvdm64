$ErrorActionPreference='Stop'
$p=Start-Process cmd.exe -ArgumentList @('/d','/c',"`"$PSScriptRoot/native.cmd`"") -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/native.log" -RedirectStandardError "$PSScriptRoot/native.stderr.log"
$null=$p.Handle
@{pid=$p.Id;started=[DateTime]::UtcNow.ToString('o');deadlineSeconds=180}|ConvertTo-Json|Set-Content "$PSScriptRoot/native-process.json"
if(!$p.WaitForExit(180000)){& taskkill.exe /PID $p.Id /T /F;throw 'Owned native deadline exceeded'}
$p.ExitCode|Set-Content "$PSScriptRoot/native-run.exit"
exit $p.ExitCode
