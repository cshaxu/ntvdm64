$ErrorActionPreference='Stop'
$p=Start-Process cmd.exe -ArgumentList @('/d','/c',"`"$PSScriptRoot/retry.cmd`"") -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/retry.log" -RedirectStandardError "$PSScriptRoot/retry.stderr.log"
$null=$p.Handle
@{pid=$p.Id;started=[DateTime]::UtcNow.ToString('o');deadlineSeconds=180}|ConvertTo-Json|Set-Content "$PSScriptRoot/retry-process.json"
if(!$p.WaitForExit(180000)){& taskkill.exe /PID $p.Id /T /F;throw 'Owned retry deadline exceeded'}
$p.ExitCode|Set-Content "$PSScriptRoot/retry-run.exit"
exit $p.ExitCode
