$ErrorActionPreference='Stop'
$p=Start-Process cmd.exe -ArgumentList @('/d','/c',"`"$PSScriptRoot/declared.cmd`"") -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/declared.log" -RedirectStandardError "$PSScriptRoot/declared.stderr.log"
$null=$p.Handle
@{pid=$p.Id;started=[DateTime]::UtcNow.ToString('o');deadlineSeconds=180}|ConvertTo-Json|Set-Content "$PSScriptRoot/declared-process.json"
if(!$p.WaitForExit(180000)){& taskkill.exe /PID $p.Id /T /F;throw 'Owned declared deadline exceeded'}
$p.ExitCode|Set-Content "$PSScriptRoot/declared-run.exit"
exit $p.ExitCode
