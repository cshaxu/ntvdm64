from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p32';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','targeted','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'assertions=16 failures=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=213,retired_reviewed_files=13,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=243,extraction_blocks=233,unused_removal_blocks=10,owner_retired_lines=24333,extraction_lines=22943,unused_removal_lines=1390,total_census_reduction_blocks=283,total_census_reduction_lines=25527)
assert (counts['files'],counts['blocks'],counts['lines'])==(1050,2050,28996)
for name,count in [('review-register.csv',2603),('pending-decisions.csv',1564)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'apibuff-retirement.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'apibuff-retirement.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P32',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved unused archive removal','All retained mirrors and original guest unchanged','exitwin.c retains its explicit pre-task registration owner','No next-file admission'])
wr(a/'batch-p32-checkpoint.json',json.dumps(receipt,indent=2)+'\n')

p=r/'docs/states/CURRENT.md';t=p.read_text(encoding='utf-8')
for x,y in [('41/255 initial difference files reviewed;214 remain. P19,P21-P31 retire twelve','42/255 initial difference files reviewed;213 remain. P19,P21-P32 retire thirteen'),('29 reviewed/243,214 remain','29 reviewed/242,213 remain'),('census:1051 files','census:1050 files'),('(1042 host','(1041 host'),('and243 nonzero','and242 nonzero'),('total2054 blocks/29170 lines','total2050 blocks/28996 lines'),('backlog has1566 rows after retiring twelve','backlog has1564 rows after retiring thirteen')]:
 assert x in t,x
 t=t.replace(x,y,1)
i=t.index('| kernel/random.c')
t=t[:i]+'| api/apibuff.c |4->removed|174->removed|P32 unused Redirector archive removed|\n'+t[i:]
i=t.index('## Remaining Scope')
t=t[:i]+t[i:].replace('## Remaining Scope\n\n','## Remaining Scope\n\nP32 retains exitwin.c after checking pre-task registration and its explicit process owner.\n\n',1)
i=t.index('## Current Technical Baseline'); k=t.index('## Remaining Scope',i)
t=t[:i]+f'''## Current Technical Baseline

P32 cached x86/x64 build, link and import checks, Redirector OEM capacity
and server enumeration fixtures passed. Package {pub['package']} contains
11 images published and hash verified in assets/release and O:/winnt/system32.
[Receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p32-checkpoint.json).
Full was outside the owner-approved targeted scope.

'''+t[k:]
wr(p,t)
p=a/'README.md';wr(p,p.read_text(encoding='utf-8')+'\n[P32 unused NetAPI archive retirement](apibuff-retirement.json), [receipt](batch-p32-checkpoint.json) and [verification evidence](p32-verification-evidence.zip). The live census is 1050 files, 242 nonzero, 2050 blocks and 28996 lines.\n')
with zipfile.ZipFile(a/'p32-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  rel=p.relative_to(b)
  if p.is_file() and not set(rel.parts)&{'cache-final','candidate-final','runtime-publication'} and p.suffix in {'.json','.log','.txt','.exit','.py','.ps1','.cmd','.c'}:z.write(p,rel.as_posix())
print(counts)
