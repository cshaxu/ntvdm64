$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached incomplete'}
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw "Stage failed"}
 python "$PSScriptRoot/verify-provider.py"
 if($LASTEXITCODE){throw 'Provider proof failed'}
 '0'|Set-Content "$PSScriptRoot/provider-proof.exit"
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 & "$PSScriptRoot/targeted.ps1"
 if($LASTEXITCODE){throw 'Redirector targeted tests failed'}
 '0'|Set-Content "$PSScriptRoot/targeted.exit"
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
}catch{$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
