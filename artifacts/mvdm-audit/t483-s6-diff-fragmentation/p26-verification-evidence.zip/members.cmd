@echo off
cd /d O:\repos.hobby\ntvdm64
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
lib /nologo /list build/.ninja/msvc-x86-release/worker/original-softpc-support.lib > build/t483-s6-p26/support-members.txt
if errorlevel 1 exit /b 1
dumpbin /symbols build/.ninja/msvc-x86-release/worker/obj/adapter-softpc/mvdm_softpc_execution.obj > build/t483-s6-p26/worker-symbols.txt
if errorlevel 1 exit /b 1
exit /b 0
