from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();b=r/'build/t483-s6-p26'
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
p=r/'src/ntvdm-exe/softpc/mvdm_standalone_worker.c';s=p.read_text(encoding='utf-8').replace('/* Original SoftPC support/xt.c storage; main.c retains initialization. */\nint verbose;\n','');wr(p,s)
p=r/'src/ntvdm-exe/softpc/mvdm_softpc_execution.c';s=p.read_text(encoding='utf-8');s=s.replace('/* Original SoftPC host spelling;', '/* Original support/xt.c process storage, shared by product and execution\n * fixtures. Original main.c retains initialization. */\nint verbose;\n\n/* Original SoftPC host spelling;');wr(p,s)
for rel in ['src/ntvdm-exe/softpc/README.md','docs/etc/operations/policy/source-policy.md','docs/states/CURRENT.md']:
 p=r/rel;s=p.read_text(encoding='utf-8').replace('standalone-worker process storage','shared SoftPC execution storage').replace('existing standalone-worker process compatibility storage','existing shared SoftPC execution compatibility storage').replace('existing\nstandalone-worker process storage','existing\nshared SoftPC execution storage').replace('int verbose in existing standalone-worker process compatibility storage','int verbose in existing shared SoftPC execution storage');wr(p,s)
for rel in ['build/t483-s6-p26/source-review.json','artifacts/mvdm-audit/t483-s6-diff-fragmentation/xt-storage-extraction.json']:
 p=r/rel;j=json.loads(p.read_text(encoding='utf-8'));j['target']='src/ntvdm-exe/softpc/mvdm_softpc_execution.c';j['placement_correction']='First full build proved standalone worker is excluded from CCPU fixtures; common execution unit supplies one definition to both closures.';wr(p,json.dumps(j,indent=2)+'\n')
for name in ['members.cmd','verify-provider.py']:
 p=b/name;s=p.read_text(encoding='utf-8').replace('mvdm_standalone_worker.obj','mvdm_softpc_execution.obj');wr(p,s)
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();files=[dict(path=x,sha256=hashlib.sha256((r/x).read_bytes()).hexdigest()) for x in paths if (r/x).is_file() and x.startswith(('src/','test/','tools/'))]
wr(b/'source-checkpoint.json',json.dumps(dict(files=files,deleted=['src/mvdm-host/softpc.new/base/support/xt.c'],source_files=len(files)),indent=2)+'\n')
for n in ['cached.log','cached.stderr','cached.exit']:
 p=b/n
 if p.exists():wr(b/('first-'+n),p.read_text(encoding='utf-8-sig'))
