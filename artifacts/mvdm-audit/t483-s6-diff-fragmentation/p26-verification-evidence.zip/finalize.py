from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p26';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','ccpu','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=219,retired_reviewed_files=7,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=218,extraction_blocks=212,unused_removal_blocks=6,owner_retired_lines=22072,extraction_lines=20856,unused_removal_lines=1216,total_census_reduction_blocks=258,total_census_reduction_lines=23266)
assert (counts['files'],counts['blocks'],counts['lines'])==(1056,2075,31257)
for name,count in [('review-register.csv',2644),('pending-decisions.csv',1594)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'xt-storage-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'xt-storage-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P26',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved one-global extraction, not original restoration','All retained mirrors and original guest unchanged','Original CPU interrupt/parity providers unchanged; verbose storage relocated only','No next-file admission'])
wr(a/'batch-p26-checkpoint.json',json.dumps(receipt,indent=2)+'\n')
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8')
s=s.replace('35/255 initial difference files reviewed;220 remain. P19,P21-P25 retire six','36/255 initial difference files reviewed;219 remain. P19,P21-P26 retire seven').replace('live population is29 reviewed/249,220 remain.','live population is29 reviewed/248,219 remain.').replace('Current census:1057 files','Current census:1056 files').replace('(1048 host','(1047 host').replace('and249 nonzero files','and248 nonzero files').replace('Current delivered total2079 blocks/31596 lines.','Current delivered total2075 blocks/31257 lines.')
s=s.replace('The canonical pending backlog has1596 rows after retiring six owner-approved mirror files,','The canonical pending backlog has1594 rows after retiring seven owner-approved mirror files,')
s=s.replace('| rtl/time.c |6->removed|1216->removed|P25 unused archive member removed;no compat replacement|','| rtl/time.c |6->removed|1216->removed|P25 unused archive member removed;no compat replacement|\n| support/xt.c |4->retired|339->retired|P26 verbose storage extraction;historical mask ambiguity retained in evidence|')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP26 cached x86/x64 build and targeted verification passed:archive/symbol and\n11-image import proof,CCPU boundary/halt/reset/debug tests,and actual WOW\nlifecycle. Full was not run,per owner-selected targeted scope. Package '+pub['package']+'\ncontains11 images,published and hash-verified to assets/release and O:/winnt/system32.\nRetained mirrors,guest and winnt.zip are unchanged.\n[P26 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p26-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p26-verification-evidence.zip).\n\n'+s[end:]
s=s.replace('## P26 In Progress','## P26 Delivery');s+='\nP26 retires4 recorded blocks/339 lines,including two historical mask ambiguities.\nCumulative original restoration40 blocks/1194 lines,extractions212 blocks/20856\nlines,unused removal6 blocks/1216 lines:total258 blocks/23266 lines.\nMain register2644 rows;pending1594 rows. Build,publish11x2,targeted tests passed;\ngovernance and Git accompany receipt. No next-file admission.\n';wr(p,s);assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('lines;includes two historical ambiguous-arm masks. Final verification pending.','lines;includes two historical ambiguous-arm masks. Cached build,archive/symbol\nproof,publish11x2 and targeted CCPU/WOW verification passed.');s+='\n[P26 receipt](batch-p26-checkpoint.json) and [verification evidence](p26-verification-evidence.zip).\nCurrent census:1056 files,248 nonzero,2075 blocks/31257 lines.\nP20 usage ratios predate the now-retired support/xt.c.\n';wr(p,s)
with zipfile.ZipFile(a/'p26-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):continue
  if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv','.c']:z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print(counts)
