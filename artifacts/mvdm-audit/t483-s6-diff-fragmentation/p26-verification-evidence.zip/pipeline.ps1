$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached incomplete'}
 & $env:ComSpec /d /c build\t483-s6-p26\members.cmd
 if($LASTEXITCODE){throw 'Archive/symbol inspection failed'}
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 python "$PSScriptRoot/verify-provider.py"
 if($LASTEXITCODE){throw 'Provider proof failed'}
 '0'|Set-Content "$PSScriptRoot/provider-proof.exit"
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-ccpu-monitor-boundary.ps1 -WorkerBuild build/.ninja/msvc-x86-release/worker
 if($LASTEXITCODE){throw 'CCPU boundary tests failed'}
 & build/.ninja/msvc-x86-release/worker/ccpu-halt-reset-test.exe
 if($LASTEXITCODE){throw 'CCPU halt/reset failed'}
 & build/.ninja/msvc-x86-release/worker/debug-register-binding-test.exe
 if($LASTEXITCODE){throw 'Debug register binding failed'}
 '0'|Set-Content "$PSScriptRoot/ccpu.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p26/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'WOW lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
}catch{$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
