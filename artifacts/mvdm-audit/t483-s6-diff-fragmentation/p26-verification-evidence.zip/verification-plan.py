from pathlib import Path
b=Path('build/t483-s6-p26')
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
wr(b/'members.cmd','''@echo off
cd /d O:\\repos.hobby\\ntvdm64
call "C:\\Program Files (x86)\\Microsoft Visual Studio\\2022\\BuildTools\\Common7\\Tools\\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
lib /nologo /list build/.ninja/msvc-x86-release/worker/original-softpc-support.lib > build/t483-s6-p26/support-members.txt
if errorlevel 1 exit /b 1
dumpbin /symbols build/.ninja/msvc-x86-release/worker/obj/adapter-softpc/mvdm_standalone_worker.obj > build/t483-s6-p26/worker-symbols.txt
if errorlevel 1 exit /b 1
exit /b 0
''')
s=Path('build/t483-s6-p25/verify-provider.py').read_text(encoding='utf-8-sig').replace('t483-s6-p25','t483-s6-p26').replace('t483-s6-p24','t483-s6-p25');s=s[:s.index('for path in [r/')]+'''graph=r/'build/.ninja/msvc-x86-release/worker/build.ninja'
assert 'obj/support/xt.obj' not in graph.read_text(encoding='utf-8')
members=(b/'support-members.txt').read_text(encoding='utf-8-sig');assert members.strip() and not any(x.replace('\\\\','/').strip().endswith('/xt.obj') for x in members.splitlines())
symbols=(b/'worker-symbols.txt').read_text(encoding='utf-8-sig');assert '| _verbose' in symbols
m=(r/'build/.ninja/msvc-x86-release/worker/ntvdm.exe.map').read_text(encoding='utf-8',errors='replace');assert '_verbose ' in m and '_CsIsBig ' not in m
assert 'original-ccpu386:c_main.obj' in next(x for x in m.splitlines() if '_cpu_interrupt_map ' in x)
assert 'original-softpc-host-roots:stubs.obj' in next(x for x in m.splitlines() if '_trap_delay_count ' in x)
(b/'link-provider-proof.json').write_text(json.dumps(dict(imports=report,support_members=members.splitlines(),verbose_in_worker=True,ccpu_and_trap_owners_unchanged=True),indent=2)+'\\n',encoding='utf-8')
print('PASS 11 import tables unchanged; xt archive member removed; worker verbose and original CPU providers verified')
''';wr(b/'verify-provider.py',s)
wr(b/'pipeline.ps1','''$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached incomplete'}
 & $env:ComSpec /d /c build\\t483-s6-p26\\members.cmd
 if($LASTEXITCODE){throw 'Archive/symbol inspection failed'}
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 python "$PSScriptRoot/verify-provider.py"
 if($LASTEXITCODE){throw 'Provider proof failed'}
 '0'|Set-Content "$PSScriptRoot/provider-proof.exit"
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-ccpu-monitor-boundary.ps1 -WorkerBuild build/.ninja/msvc-x86-release/worker
 if($LASTEXITCODE){throw 'CCPU boundary tests failed'}
 & build/.ninja/msvc-x86-release/worker/ccpu-halt-reset-test.exe
 if($LASTEXITCODE){throw 'CCPU halt/reset failed'}
 & build/.ninja/msvc-x86-release/worker/debug-register-binding-test.exe
 if($LASTEXITCODE){throw 'Debug register binding failed'}
 '0'|Set-Content "$PSScriptRoot/ccpu.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p26/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'WOW lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
}catch{$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
''')
