$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 $owned=Get-Process -Id 14920 -ErrorAction SilentlyContinue
 if($owned -and !$owned.WaitForExit(2400000)){throw 'Delivery still live; no restart'}
 if(!(Test-Path "$PSScriptRoot/pipeline-supervisor.exit") -or (Get-Content "$PSScriptRoot/pipeline-supervisor.exit").Trim() -ne '0'){throw 'Delivery failed or missing exit'}
 python "$PSScriptRoot/finalize.py"
 if($LASTEXITCODE){throw 'Evidence finalization failed'}
 & "$PSScriptRoot/final-docs.ps1"
 if($LASTEXITCODE){throw 'Governance failed'}
 '0'|Set-Content "$PSScriptRoot/finish.exit"
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/finish.exit";exit 1}
