$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process -FilePath $env:ComSpec -ArgumentList '/d /c build\t483-s6-p17\cached.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/cached.log" -RedirectStandardError "$PSScriptRoot/cached.stderr"
$p.Id|Set-Content "$PSScriptRoot/cached-child.pid"
if(!$p.WaitForExit(1800000)){taskkill /pid $p.Id /t /f; 124|Set-Content "$PSScriptRoot/cached.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/cached.exit"
exit $p.ExitCode
