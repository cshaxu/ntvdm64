from pathlib import Path
import json,csv,hashlib,zipfile
r=Path.cwd();b=r/'build/t483-s6-p17';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cached','publish','focused','full-isolated','pipeline-supervisor']:
 assert (b/(name+'.exit')).read_text().strip()=='0',name
focused=j(b/'focused-result.json');assert focused['count']==37 and focused['passed']==37 and focused['exit']=='0'
full=j(b/'full-isolated/timings.json');assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
assert any(x['Gate']=='dos4gw-nesticle' and x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256']
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
files=j(b/'census.json')['files'];path='src/non-mvdm/windows/core/ntuser/client/dlgmgr.c';row=next(x for x in files if x['path']==path)
assert row['filtered']==dict(blocks=17,added=37,deleted=205) and len(row['issues'])==4 and len(row['excluded'])==1
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_files=31,remaining_files=224,cumulative_reduction_blocks=39,cumulative_reduction_lines=1172)
assert counts['blocks']==2294 and counts['lines']==53351 and counts['files']==1063
pub=j(b/'runtime-publication/result.json');review=j(a/'client-dlgmgr-whole-file-review.json');assert not review['line_proof']['mismatches']
review['delivery']='P17 cached full,publish11x2,Full20 passed;governance and Git accompany receipt';review['full']=full
(a/'client-dlgmgr-whole-file-review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
receipt=dict(packet='M0 T483 S6 P17',status='Build publication Full verified;governance and Git follow',source_checkpoint=c,publication=pub,full=full,focused=focused,global_counts=counts,reduction=dict(blocks=5,lines=53),autonomous_changes='None;all restored content remains in original mirror owner',limits=['Original CvtDec,declarations/comments restored;residual decisions remain pending owner','No guest/winnt.zip changes','Historical native dialog and retirement controls reused,not newly rerun'])
(a/'batch-p17-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv']:
 with p.open(encoding='utf-8-sig',newline='') as f:rd=csv.DictReader(f);fields=rd.fieldnames;rows=list(rd)
 for x in rows:
  if x['path']!=path:continue
  if 'remaining_blocks' in fields:x['status']='reviewed-verified-p17-residuals-pending-owner'
  elif 'pending' in x['review_status']:x['verification']='P17 actual WOW focused37,cached full,publish11x2,Full20 and logical-line proof passed';x['delivery']='P17;Git accompanies receipt'
 with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8');s=s[:s.index('\nP17 client/dlgmgr.c whole-file')]
s=s.replace('30/255 initial difference files reviewed;225 remain. Twenty-three changed files','31/255 initial difference files reviewed;224 remain. Twenty-four changed files').replace('verified across P2-P16','verified across P2-P17').replace('2299 blocks/53404 lines','2294 blocks/53351 lines').replace('reduction34 blocks/\n1119 lines','reduction39 blocks/\n1172 lines')
pos=s.index('\n\n\nThe canonical pending');s=s[:pos]+'\n| client/dlgmgr.c |22->17|295->242|P17 original declarations/CvtDec/comments restored;focused37 and Full20 passed|'+s[pos:]
rows=list(csv.DictReader((a/'file-worklist.csv').open(encoding='utf-8')));n=next(x for x in rows if x['rank']=='32');s=s.replace('Next file is '+path+'.','Next file is '+n['path']+'.')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP17 cached x86/x64 full,WOW focused37 and Full20 passed.\nPackage '+pub['package']+' contains11 images,published and\nhash-verified to assets/release and O:/winnt/system32. Full includes actual\nDOS4GW/NESticle. No guest or winnt.zip changes. Original CvtDec,declarations/comments\nrestored;789 nontrivial matched lines retain original logical numbering.\nGovernance and Git delivery accompany the receipt. Residual decisions are pending.\n\n[P17 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p17-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p17-verification-evidence.zip).\n\n'+s[end:]
p.write_text(s.rstrip()+'\n',encoding='utf-8',newline='\n');assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8',newline='\n').replace('22->17 blocks,295->242 lines;delivery pending.','22->17 blocks,295->242 lines;cached build,publish11x2,Full20 passed;Git accompanies receipt.');s+='\n[P17 receipt](batch-p17-checkpoint.json) and [evidence](p17-verification-evidence.zip).\n';p.write_text(s,encoding='utf-8',newline='\n')
with zipfile.ZipFile(a/'p17-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for root,prefix in [(b,''),(r/'build/t483-s6-dlgmgr-review','source-review/')]:
  for p in root.rglob('*'):
   if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(root).parts):continue
   if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.rsp','.txt','.csv'] or (p.suffix=='.png' and 'dos4gw-nesticle' in p.parts):z.write(p,prefix+p.relative_to(root).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print('P17 receipt ready',counts)
