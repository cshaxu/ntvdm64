from pathlib import Path
import subprocess,json,hashlib
r=Path.cwd();b=r/'build/t483-s6-p23'
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['src/compat/wow_object_ownership.c']
files=[dict(path=x,sha256=hashlib.sha256((r/x).read_bytes()).hexdigest()) for x in paths if (r/x).is_file() and x.startswith(('src/','test/','tools/'))]
wr(b/'source-checkpoint.json',json.dumps(dict(files=files,deleted=['src/non-mvdm/windows/core/ntuser/kernel/handtabl.c'],source_files=len(files)),indent=2)+'\n')
wr(b/'line-proof.json',json.dumps(dict(files=[],reason='All1059 retained mirror files match P22 by SHA256; no retained #error or #line is modified. Selected non-IME table matches pinned original.'))+'\n')
wr(b/'pipeline.ps1','''$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build incomplete'}
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publication failed'}
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-cleanup-bounds.ps1
 if($LASTEXITCODE){throw 'Original ownership/cleanup source proof failed'}
 '0'|Set-Content "$PSScriptRoot/ownership.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-control-boundaries.ps1 -EvidenceRoot build/t483-s6-p23/control-evidence
 if($LASTEXITCODE){throw 'Focused controls failed'}
 '0'|Set-Content "$PSScriptRoot/controls.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow32-s1-formal-graph.ps1 -BuildRoot build/.ninja/msvc-x86-release/wow32
 if($LASTEXITCODE){throw 'Formal graph failed'}
 '0'|Set-Content "$PSScriptRoot/formal-graph.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p23/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'WOW lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
''')
