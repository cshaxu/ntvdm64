from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p23';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','ownership','controls','formal-graph','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=222,retired_reviewed_files=4,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=200,owner_retired_lines=16953,total_census_reduction_blocks=240,total_census_reduction_lines=18147)
assert (counts['files'],counts['blocks'],counts['lines'])==(1059,2093,36376)
for name,count in [('review-register.csv',2664),('pending-decisions.csv',1608)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'handtabl-compat-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'handtabl-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P23',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved extraction, not original restoration','All retained mirrors and original guest unchanged','Original ownership table values/types/flags unchanged','No next-file admission'])
wr(a/'batch-p23-checkpoint.json',json.dumps(receipt,indent=2)+'\n')
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8').replace('P19,P21 and P22 retire three already','P19,P21,P22 and P23 retire four already').replace('live population is30 reviewed/252','live population is29 reviewed/251').replace('1060 files\n(1051 host','1059 files\n(1050 host').replace('and252 nonzero files','and251 nonzero files').replace('Current delivered total2117 blocks/37757 lines.','Current delivered total2093 blocks/36376 lines.').replace('The canonical pending backlog has1617 rows after retiring kernel/ntstubs,client/wow and kernel/input records,','The canonical pending backlog has1608 rows after retiring kernel/ntstubs,client/wow,kernel/input and kernel/handtabl records,')
import re
s=re.sub(r'^\| kernel/handtabl.c .*$', '| kernel/handtabl.c |24->retired|1381->retired|P23 compat extraction;original ownership and targeted lifecycle passed|',s,flags=re.M)
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP23 cached build and owner-selected targeted verification passed:original\nownership/cleanup source proof,focused controls,formal graph and actual WOW\nlifecycle. Full was not run,per owner approval. Package '+pub['package']+'\ncontains11 images,published and hash-verified to assets/release and O:/winnt/system32.\nOther mirrors,guest and winnt.zip are unchanged.\n[P23 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p23-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p23-verification-evidence.zip).\n\n'+s[end:]
s=s.replace('## P23 In Progress','## P23 Delivery');s+='\nP23 retires24 blocks/1381 lines;combined extractions retire200 blocks/16953 lines.\nWith original restoration40 blocks/1194 lines,the census is down240 blocks/18147 lines.\nMain register2664 rows;pending1608 rows. Cached build,targeted verification\nand publish11x2 passed;governance and Git accompany receipt. No next-file admission.\n';wr(p,s);assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('Local implementation;\ncached build,targeted tests,publish11x2 and Git pending. Full waived by owner.','Cached build,targeted tests and publish11x2 passed;Git accompanies receipt.\nFull waived by owner.');s+='\n[P23 receipt](batch-p23-checkpoint.json) and [verification evidence](p23-verification-evidence.zip).\nCurrent census:1059 files,251 nonzero,2093 blocks/36376 lines.\nThe P20 ratio snapshot also predates the now-retired kernel/handtabl.c.\n';wr(p,s)
with zipfile.ZipFile(a/'p23-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):continue
  if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv']:z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print(counts)
