$ErrorActionPreference = 'Stop'
$repo = (Get-Location).Path
$build = Join-Path $repo 'build/.ninja/msvc-x86-release/call-boundaries'
$vs = 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/VsDevCmd.bat'
$cases = @('wow_control_brush_fixture','wow_button_resources_fixture','wow_control_draw_state_fixture','wow_button_lifetime_fixture')
function Run-Owned([string]$name, [string]$file, [string[]]$arguments, [int]$seconds) {
    $p = @{FilePath=$file; WorkingDirectory=$build; WindowStyle='Hidden'; PassThru=$true
        RedirectStandardOutput="$PSScriptRoot/$name.stdout.log"; RedirectStandardError="$PSScriptRoot/$name.stderr.log"}
    if ($arguments.Count) { $p.ArgumentList = $arguments }
    $child = Start-Process @p
    if (!$child.WaitForExit($seconds * 1000)) {
        & taskkill.exe /PID $child.Id /T /F | Out-Host
        throw "$name exceeded its deadline"
    }
    Get-Content "$PSScriptRoot/$name.stdout.log"
    if ($child.ExitCode -ne 0) { throw "$name failed with exit code $($child.ExitCode)" }
    Write-Output "PASS $name"
}
try {
    & "$repo/tools/build/New-T447S3CallBoundaryNinja.ps1" -RepositoryRoot $repo -BuildRoot $build -VsDevCmd $vs
    $targets = @($cases | ForEach-Object { "bin/$_.exe" })
    Run-Owned 'targeted-build' (Get-Command ninja.exe).Source (@('-j','4') + $targets) 300
    foreach ($name in $cases) { Run-Owned $name "$build/bin/$name.exe" @() 30 }
} catch { $_ | Out-String | Write-Output; exit 1 }
exit 0
