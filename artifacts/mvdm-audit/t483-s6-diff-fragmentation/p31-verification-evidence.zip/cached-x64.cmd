@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cmake --preset msvc-x64-release-ccache -DNTVDM_POWERSHELL:FILEPATH="C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe"
if errorlevel 1 exit /b 1
cmake --build --preset msvc-x64-release-ccache
if errorlevel 1 exit /b 1
for %%d in (worker frontend monitor launcher service hook) do (
 ninja -C build\.ninja\msvc-x64-release\%%d
 if errorlevel 1 exit /b 1
)
exit /b 0
