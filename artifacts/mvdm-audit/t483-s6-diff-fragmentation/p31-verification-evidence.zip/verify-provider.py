from pathlib import Path
import struct,json,hashlib
r=Path.cwd();b=r/'build/t483-s6-p31'
def imports(p):
 d=p.read_bytes();pe=struct.unpack_from('<I',d,60)[0];n=struct.unpack_from('<H',d,pe+6)[0];sz=struct.unpack_from('<H',d,pe+20)[0];o=pe+24;is64=struct.unpack_from('<H',d,o)[0]==0x20b;dirs=o+(112 if is64 else 96);irva=struct.unpack_from('<I',d,dirs+8)[0];secs=[]
 for i in range(n):
  at=o+sz+i*40;vsize,va,rawsize,raw=struct.unpack_from('<IIII',d,at+8);secs.append((va,max(vsize,rawsize),raw))
 def off(va):
  for v,l,p in secs:
   if v<=va<v+l:return p+va-v
  raise ValueError(('Unmapped RVA',p,va))
 def cstr(at):return d[at:d.index(b'\0',at)].decode('ascii')
 result=[]
 if irva:
  at=off(irva)
  while any(struct.unpack_from('<IIIII',d,at)):
   oft,_,_,name,ft=struct.unpack_from('<IIIII',d,at);dll=cstr(off(name));t=off(oft or ft);size=8 if is64 else 4;fmt='<Q' if is64 else '<I'
   while (v:=struct.unpack_from(fmt,d,t)[0]):
    result.append(dll.lower()+'!'+('#'+str(v&65535) if v>>(size*8-1) else cstr(off(v)+2)));t+=size
   at+=20
 return sorted(result)
manifest=json.loads((b/'candidate-final/product-system32-manifest.json').read_text(encoding='utf-8-sig'));report=[]
for row in manifest:
 name=row['Name'];prior=r/'build/t483-s6-p30/candidate-final/system32'/name;current=b/'candidate-final/system32'/name
 a=imports(prior);z=imports(current);assert a==z,('Import provider changed',name,set(a)^set(z))
 report.append(dict(image=name,imports_identical=True,rtl_1970_imports=[x for x in z if 'RtlSecondsSince1970ToTime' in x]))


m=(r/'build/.ninja/msvc-x86-release/wow32/wow32.dll.map').read_text(errors='replace')
brush=[x for x in m.splitlines() if '_xxxGetControlBrush@12 ' in x]
assert len(brush)==1 and 'wow-control-brush.obj' in brush[0],brush
assert '_CheckPwndFilter' not in m
owner=[x for x in m.splitlines() if '_sysBmpStyles ' in x]
assert len(owner)==1 and 'wow_button_resources.obj' in owner[0],owner
def table_bytes(image, va, size):
 d=image.read_bytes()
 pe=struct.unpack_from('<I',d,60)[0]; o=pe+24
 image_base=struct.unpack_from('<I',d,o+28)[0]
 rva=va-image_base; sec=o+struct.unpack_from('<H',d,pe+20)[0]
 for i in range(struct.unpack_from('<H',d,pe+6)[0]):
  _,addr,rawsize,raw=struct.unpack_from('<IIII',d,sec+40*i+8)
  if addr<=rva and rva+size<=addr+rawsize:
   start=raw+rva-addr
   return d[start:start+size]
 raise ValueError((image,va))

before=table_bytes(r/'build/t483-s6-p30/candidate-final/system32/wow32.dll',0x10091518,272)
after=table_bytes(b/'candidate-final/system32/wow32.dll',int(owner[0].split()[2],16),64)
assert before[-64:]==after
(b/'link-provider-proof.json').write_text(json.dumps(dict(imports=report,brush=brush,table=owner,table_entries=16,retained_table_sha256=hashlib.sha256(after).hexdigest(),retained_entries_match_prior=True),indent=2))
