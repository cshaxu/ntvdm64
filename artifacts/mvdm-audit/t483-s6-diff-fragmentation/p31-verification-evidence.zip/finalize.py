from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p31';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','targeted','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'control_brush_failures=0' in log and 'button_resource_failures=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=214,retired_reviewed_files=12,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=239,extraction_blocks=233,unused_removal_blocks=6,owner_retired_lines=24159,extraction_lines=22943,unused_removal_lines=1216,total_census_reduction_blocks=279,total_census_reduction_lines=25353)
assert (counts['files'],counts['blocks'],counts['lines'])==(1051,2054,29170)
for name,count in [('review-register.csv',2606),('pending-decisions.csv',1566)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'random-compat-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'random-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P31',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved control brush extraction, not original restoration','All retained mirrors and original guest unchanged','Original xxxGetControlBrush preserved and button table reduced to 16 production entries','No next-file admission'])
wr(a/'batch-p31-checkpoint.json',json.dumps(receipt,indent=2)+'\n')

p=r/'docs/states/CURRENT.md';t=p.read_text(encoding='utf-8')
for x,y in [('40/255 initial difference files reviewed;215 remain. P19,P21-P30 retire eleven','41/255 initial difference files reviewed;214 remain. P19,P21-P31 retire twelve'),('29 reviewed/244,215 remain','29 reviewed/243,214 remain'),('census:1052 files','census:1051 files'),('(1043 host','(1042 host'),('and244 nonzero','and243 nonzero'),('total2060 blocks/29531 lines','total2054 blocks/29170 lines'),('backlog has1571 rows after retiring eleven','backlog has1566 rows after retiring twelve')]:
 assert x in t,x
 t=t.replace(x,y,1)
i=t.index('| client/handles.c')
t=t[:i]+'| kernel/random.c |6->retired|361->retired|P31 xxxGetControlBrush extraction and 16-row button table|\n'+t[i:]
i=t.index('## Current Technical Baseline'); k=t.index('## Remaining Scope',i)
t=t[:i]+f'''## Current Technical Baseline

P31 cached x86/x64 build, link provider and import checks, WOW formal graph,
brush, button resource, drawing and lifetime fixtures passed. Package {pub['package']} contains
11 images published and hash verified in assets/release and O:/winnt/system32.
[Receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p31-checkpoint.json).
Full was outside the owner-approved targeted scope.

'''+t[k:]
wr(p,t)
p=a/'README.md';wr(p,p.read_text(encoding='utf-8')+'\n[P31 control brush extraction](random-compat-extraction.json), [receipt](batch-p31-checkpoint.json) and [verification evidence](p31-verification-evidence.zip). The live census is 1051 files, 243 nonzero, 2054 blocks and 29170 lines.\n')
with zipfile.ZipFile(a/'p31-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  rel=p.relative_to(b)
  if p.is_file() and not set(rel.parts)&{'cache-final','candidate-final','runtime-publication'} and p.suffix in {'.json','.log','.txt','.exit','.py','.ps1','.cmd','.c'}:z.write(p,rel.as_posix())
print(counts)
