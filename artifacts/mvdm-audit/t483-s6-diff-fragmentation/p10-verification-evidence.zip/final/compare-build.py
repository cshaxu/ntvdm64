from pathlib import Path
import hashlib,json,struct
p=Path('build/t483-s6-p10-line-final');records=json.loads((p/'before-build.json').read_text(encoding='utf-8'));out=[]
def normalize(b):
 a=bytearray(b);assert a[:2]==b'MZ';pe=struct.unpack_from('<I',a,0x3c)[0];assert a[pe:pe+4]==bytes([80,69,0,0]);a[pe+8:pe+12]=bytes(4)
 opt=pe+24;ns=struct.unpack_from('<H',a,pe+6)[0];sz=struct.unpack_from('<H',a,pe+20)[0];dd=opt+(96 if struct.unpack_from('<H',a,opt)[0]==0x10b else 112)
 dr,ds=struct.unpack_from('<II',a,dd+48)
 if dr:
  q=None
  for i in range(ns):
   o=opt+sz+40*i;vsize,va,rawsize,raw=struct.unpack_from('<IIII',a,o+8)
   if va<=dr<va+max(vsize,rawsize):q=raw+dr-va;break
  assert q is not None and ds%28==0
  for k in range(ds//28):a[q+28*k+4:q+28*k+8]=bytes(4)
 return bytes(a)
for r in records:
 a=(p/'before-build'/r['name']).read_bytes();b=Path(r['build_path']).read_bytes()
 kind='identical' if a==b else ('coff-and-debug-directory-timestamps-only' if normalize(a)==normalize(b) else 'other')
 out.append({'name':r['name'],'before_sha256':hashlib.sha256(a).hexdigest(),'after_sha256':hashlib.sha256(b).hexdigest(),'classification':kind,'before_size':len(a),'after_size':len(b),'different_bytes':sum(x!=y for x,y in zip(a,b))+abs(len(a)-len(b))})
(p/'build-comparison.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out))
