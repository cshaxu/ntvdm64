from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p28';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','controls','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=217,retired_reviewed_files=9,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=224,extraction_blocks=218,unused_removal_blocks=6,owner_retired_lines=22638,extraction_lines=21422,unused_removal_lines=1216,total_census_reduction_blocks=264,total_census_reduction_lines=23832)
assert (counts['files'],counts['blocks'],counts['lines'])==(1054,2069,30691)
for name,count in [('review-register.csv',2635),('pending-decisions.csv',1588)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'miscutil-compat-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'miscutil-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P28',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved dialog pointer extraction, not original restoration','All retained mirrors and original guest unchanged','SetDialogPointer body preserved and linked from compat','No next-file admission'])
wr(a/'batch-p28-checkpoint.json',json.dumps(receipt,indent=2)+'\n')

p=r/'docs/states/CURRENT.md';t=p.read_text(encoding='utf-8')
for x,y in [('37/255 initial difference files reviewed;218 remain. P19,P21-P27 retire eight','38/255 initial difference files reviewed;217 remain. P19,P21-P28 retire nine'),('29 reviewed/247,218 remain','29 reviewed/246,217 remain'),('census:1055 files','census:1054 files'),('(1046 host','(1045 host'),('and247 nonzero','and246 nonzero'),('total2072 blocks/30889 lines','total2069 blocks/30691 lines'),('backlog has1592 rows after retiring eight','backlog has1588 rows after retiring nine')]:
 assert x in t,x
 t=t.replace(x,y,1)
i=t.index('| rtl/rect.c')
t=t[:i]+'| kernel/miscutil.c |3->retired|198->retired|P28 SetDialogPointer extraction; targeted WOW validation passed|\n'+t[i:]
i=t.index('## Current Technical Baseline'); k=t.index('## Remaining Scope',i)
t=t[:i]+f'''## Current Technical Baseline

P28 cached x86/x64 build, link provider and import checks, WOW formal graph,
control fixtures and WOW lifecycle passed. Package {pub['package']} contains
11 images published and hash verified in assets/release and O:/winnt/system32.
[Receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p28-checkpoint.json).
Full was outside the owner-approved targeted scope.

'''+t[k:]
wr(p,t)
p=a/'README.md';wr(p,p.read_text(encoding='utf-8')+'\n[P28 dialog pointer extraction](miscutil-compat-extraction.json), [receipt](batch-p28-checkpoint.json) and [verification evidence](p28-verification-evidence.zip). The live census is 1054 files, 246 nonzero, 2069 blocks and 30691 lines.\n')
p=a/'README.md';wr(p,p.read_text(encoding='utf-8')+'\n[Original function paths, signatures and line ranges](extracted-function-provenance.md).\n')
with zipfile.ZipFile(a/'p28-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  rel=p.relative_to(b)
  if p.is_file() and not set(rel.parts)&{'cache-final','candidate-final','runtime-publication'} and p.suffix in {'.json','.log','.txt','.exit','.py','.ps1','.cmd','.c'}:z.write(p,rel.as_posix())
print(counts)
