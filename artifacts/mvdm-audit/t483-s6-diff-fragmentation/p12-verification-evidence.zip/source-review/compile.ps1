$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process $env:ComSpec -ArgumentList '/d /c build\t483-s6-handtabl-review\compile.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/compile.stdout" -RedirectStandardError "$PSScriptRoot/compile.stderr"
$p.Id|Set-Content "$PSScriptRoot/compile-child.pid"
if(!$p.WaitForExit(120000)){taskkill /pid $p.Id /t /f;124|Set-Content "$PSScriptRoot/compile.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/compile.exit"
exit $p.ExitCode
