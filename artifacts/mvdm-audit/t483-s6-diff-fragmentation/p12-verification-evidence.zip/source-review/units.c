/****************************** Module Header ******************************\
* Module Name: handtabl.c
*
* Copyright (c) 1985-95, Microsoft Corporation
*
* Implements the USER handle table.
*
* 01-13-92 ScottLu      Created.
\***************************************************************************/

#include <windows.h>
#include "compat/include/opennt_user_multipass.h"
#define WOW_USER_OBJECT_FLAGS_ONLY
#include "userk.h"
#line 12
#pragma hdrstop

/*
 * Turning this variable on results in lock tracking, for debugging
 * purposes. This is FALSE by default.
 */
#ifdef DEBUG_LOCKS
#error
#else
BOOL gfTrackLocks = FALSE;
#endif

/*
 * Handle table allocation globals.  The purpose of keeping per-page free
 * lists is to keep the table as small as is practical and to minimize
 * the number of pages touched while performing handle table operations.
 */
#define CPAGEENTRIESINIT    4

typedef struct _HANDLEPAGE {
    DWORD iheLimit; /* first handle index past the end of the page */
    DWORD iheFree;  /* first free handle in the page */
} HANDLEPAGE, *PHANDLEPAGE;

DWORD gcHandlePages;
PHANDLEPAGE gpHandlePages;

CONST BYTE gabObjectCreateFlags[TYPE_CTYPES] = {
    0,                                                  /* free */
    OCF_THREADOWNED | OCF_MARKTHREAD | OCF_USEQUOTA,    /* window */
    OCF_PROCESSOWNED,                                   /* menu */
    OCF_PROCESSOWNED | OCF_USEQUOTA,                    /* cursor/icon */
    OCF_THREADOWNED | OCF_USEQUOTA,                     /* hswpi (SetWindowPos Information) */
    OCF_THREADOWNED | OCF_MARKTHREAD,                   /* hook */
    OCF_THREADOWNED | OCF_USEQUOTA,                     /* thread info object (internal) */
    0,                                                  /* clipboard data (internal) */
    OCF_THREADOWNED,                                    /* CALLPROCDATA */
    OCF_PROCESSOWNED | OCF_USEQUOTA,                    /* accel table */
    OCF_THREADOWNED | OCF_USEQUOTA,                     /* dde access */
    OCF_THREADOWNED | OCF_MARKTHREAD | OCF_USEQUOTA,    /* dde conversation */
    OCF_THREADOWNED | OCF_MARKTHREAD | OCF_USEQUOTA,    /* ddex */
    OCF_PROCESSOWNED,                                   /* zombie */
    OCF_PROCESSOWNED,                                   /* keyboard layout */
    OCF_PROCESSOWNED,                                   /* keyboard file */
#ifdef FE_IME
#error
#endif
};

/*
 * Tag array for objects allocated from pool
 */
CONST DWORD gdwAllocTag[TYPE_CTYPES] = {
    0,              /* free */
    0,              /* window */
    0,              /* menu */
    TAG_CURSOR,     /* cursor/icon */
    TAG_SWP,        /* hswpi (SetWindowPos Information) */
    0,              /* hook */
    TAG_THREADINFO, /* thread info object (internal) */
    TAG_CLIPBOARD,  /* clipboard data (internal) */
    0,              /* CALLPROCDATA */
    TAG_ACCEL,      /* accel table */
    TAG_DDE9,       /* dde access */
    TAG_DDEa,       /* dde conversation */
    TAG_DDEb,       /* ddex */
    0,              /* zombie */
    TAG_KBDLAYOUT,  /* keyboard layout */
    TAG_KBDFILE,    /* keyboard file */
#ifdef FE_IME
#error
#endif
};

#ifdef DEBUG
#error
#line 98
#endif

void HMDestroyUnlockedObject(PHE phe);
void HMRecordLock(PVOID ppobj, PVOID pobj, DWORD cLockObj, PVOID pfn);
BOOL HMUnrecordLock(PVOID ppobj, PVOID pobj);
VOID ShowLocks(PHE);
BOOL HMRelocateLockRecord(PVOID ppobjNew, int cbDelta);

/***************************************************************************\
* HMInitHandleTable
*
* Initialize the handle table. Unused entries are linked together.
*
* 01-13-92 ScottLu      Created.
\***************************************************************************/

#define CHANDLEENTRIESINIT 200
#define CLOCKENTRIESINIT   100

#line 134
#ifdef DEBUG
#error
#line 137
#endif
#line 286
#if (DBG || TRACE_OBJECT_ALLOCS)
#error
#line 302
#endif // TRACE_OBJECT_ALLOCS
#line 456
#ifdef FE_IME
#error
#endif
#line 544
#if 0
#error
#line 563
#endif
#line 585
#ifdef DEBUG
#error
#endif
#line 594
#ifndef DEBUG
#line 600
#ifdef FE_IME
#error
#endif
#line 622
#else // DEBUG
#error
#line 712
#endif
#line 764
#ifdef DEBUG
#error
#line 776
#endif
#line 797
#ifdef DEBUG
#error
#line 803
#endif
#line 852
#ifdef DEBUG
#error
#line 952
#endif // DEBUG
#line 963
#ifdef DEBUG
#error
#line 994
#endif // DEBUG
#line 1030
}


/***************************************************************************\
* HMAssignmentLock
*
* This api is used for structure and global variable assignment.
* Returns pobjOld if the object was *not* destroyed. Means the object is
* still valid.
*
* 02-24-92 ScottLu      Created.
\***************************************************************************/

PVOID FASTCALL HMAssignmentLock(
    PVOID *ppobj,
    PVOID pobj)
{
    PVOID pobjOld;

    pobjOld = *ppobj;
    *ppobj = pobj;

    /*
     * Unlocks the old, locks the new.
     */
    if (pobjOld != NULL) {
#ifdef DEBUG
#error
#line 1069
#endif

        /*
         * if we are locking in the same object that is there then
         * it is a no-op but we don't want to do the Unlock and the Lock
         * because the unlock could free object and the lock would lock
         * in a freed pointer; 6410.
         */
        if (pobjOld == pobj) {
            return pobjOld;
        }
    }


    if (pobj != NULL) {
#ifdef DEBUG
#error
#line 1098
#endif
        HMLockObject(pobj);
    }

/*
 * This unlock has been moved from up above, so that we implement a
 * "lock before unlock" strategy.  Just in case pobjOld was the
 * only object referencing pobj, pobj won't go away when we unlock
 * pobjNew -- it will have been locked above.
 */

    if (pobjOld) {
        pobjOld = HMUnlockObject(pobjOld);
    }

    return pobjOld;
}


/***************************************************************************\
* HMAssignmentLock
*
* This api is used for structure and global variable assignment.
* Returns pobjOld if the object was *not* destroyed. Means the object is
* still valid.
*
* 02-24-92 ScottLu      Created.
\***************************************************************************/

PVOID FASTCALL HMAssignmentUnlock(
    PVOID *ppobj)
{
    PVOID pobjOld;

    pobjOld = *ppobj;
    *ppobj = NULL;

    /*
     * Unlocks the old, locks the new.
     */
    if (pobjOld != NULL) {
#ifdef DEBUG
#error
#line 1152
#endif
        pobjOld = HMUnlockObject(pobjOld);
    }

    return pobjOld;
}


/***************************************************************************\
#line 1169
#ifdef DEBUG
#error
#line 1188
#endif
#line 1198
#ifdef DEBUG
#error
#line 1239
#endif
#line 1250
#ifdef DEBUG
#error
#line 1301
#endif
#line 1321
#ifdef DEBUG
#error
#line 1325
#else
#line 1329
#endif
#line 1353
#ifdef DEBUG
#error
#line 1361
#endif
#line 1394
#ifdef DEBUG
#error
#line 1423
#endif
#line 1519
#ifdef FE_IME
#error
#line 1523
#endif
#line 1691
#ifdef DEBUG
#error
#line 1712
#endif
#line 1714
#ifdef DEBUG
#error
#line 1794
#endif
#line 1886
#ifdef DEBUG
#error
#line 1911
#endif // DEBUG
#line 1933
#ifdef DEBUG
#error
#line 2013
#endif // DEBUG
#line 2137
/***************************************************************************\
* KernelPtoH
*
* This function is called from the client to convert pool-based object
* pointers, such as a cursor pointer, to a handle.
*
* HISTORY:
* 11/22/95       BradG            Created
\***************************************************************************/
HANDLE KernelPtoH( PVOID pObj ) {
    HANDLE h;

    UserAssert( pObj != NULL );

    try {
        h = PtoHq( pObj );
    } except (EXCEPTION_EXECUTE_HANDLER) {
        h = NULL;
    }
    return h;
}
