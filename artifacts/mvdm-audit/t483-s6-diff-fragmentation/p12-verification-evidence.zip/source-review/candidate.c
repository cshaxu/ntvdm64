/****************************** Module Header ******************************\
* Module Name: handtabl.c
*
* Copyright (c) 1985-95, Microsoft Corporation
*
* Implements the USER handle table.
*
* 01-13-92 ScottLu      Created.
\***************************************************************************/

#include <windows.h>
#include "compat/include/opennt_user_multipass.h"
#define WOW_USER_OBJECT_FLAGS_ONLY
#include "userk.h"
#line 12
#pragma hdrstop
#line 14
/*
 * Turning this variable on results in lock tracking, for debugging
 * purposes. This is FALSE by default.
 */
#ifdef DEBUG_LOCKS
#error
#else
BOOL gfTrackLocks = FALSE;
#endif

/*
 * Handle table allocation globals.  The purpose of keeping per-page free
 * lists is to keep the table as small as is practical and to minimize
 * the number of pages touched while performing handle table operations.
 */
#define CPAGEENTRIESINIT    4

typedef struct _HANDLEPAGE {
    DWORD iheLimit; /* first handle index past the end of the page */
    DWORD iheFree;  /* first free handle in the page */
} HANDLEPAGE, *PHANDLEPAGE;

DWORD gcHandlePages;
PHANDLEPAGE gpHandlePages;

CONST BYTE gabObjectCreateFlags[TYPE_CTYPES] = {
    0,                                                  /* free */
    OCF_THREADOWNED | OCF_MARKTHREAD | OCF_USEQUOTA,    /* window */
    OCF_PROCESSOWNED,                                   /* menu */
    OCF_PROCESSOWNED | OCF_USEQUOTA,                    /* cursor/icon */
    OCF_THREADOWNED | OCF_USEQUOTA,                     /* hswpi (SetWindowPos Information) */
    OCF_THREADOWNED | OCF_MARKTHREAD,                   /* hook */
    OCF_THREADOWNED | OCF_USEQUOTA,                     /* thread info object (internal) */
    0,                                                  /* clipboard data (internal) */
    OCF_THREADOWNED,                                    /* CALLPROCDATA */
    OCF_PROCESSOWNED | OCF_USEQUOTA,                    /* accel table */
    OCF_THREADOWNED | OCF_USEQUOTA,                     /* dde access */
    OCF_THREADOWNED | OCF_MARKTHREAD | OCF_USEQUOTA,    /* dde conversation */
    OCF_THREADOWNED | OCF_MARKTHREAD | OCF_USEQUOTA,    /* ddex */
    OCF_PROCESSOWNED,                                   /* zombie */
    OCF_PROCESSOWNED,                                   /* keyboard layout */
    OCF_PROCESSOWNED,                                   /* keyboard file */
#ifdef FE_IME
#error
#endif
};
#line 81
#ifdef FE_IME
#error
#endif
#line 86
#ifdef DEBUG
#error
#line 98
#endif
#line 134
#ifdef DEBUG
#error
#line 137
#endif
#line 286
#if (DBG || TRACE_OBJECT_ALLOCS)
#error
#line 302
#endif // TRACE_OBJECT_ALLOCS
#line 456
#ifdef FE_IME
#error
#endif
#line 544
#if 0
#error
#line 563
#endif
#line 585
#ifdef DEBUG
#error
#endif
#line 594
#ifndef DEBUG
#line 600
#ifdef FE_IME
#error
#endif
#line 622
#else // DEBUG
#error
#line 712
#endif
#line 764
#ifdef DEBUG
#error
#line 776
#endif
#line 797
#ifdef DEBUG
#error
#line 803
#endif
#line 852
#ifdef DEBUG
#error
#line 952
#endif // DEBUG
#line 963
#ifdef DEBUG
#error
#line 994
#endif // DEBUG
#line 1056
#ifdef DEBUG
#error
#line 1069
#endif
#line 1084
#ifdef DEBUG
#error
#line 1098
#endif
#line 1139
#ifdef DEBUG
#error
#line 1152
#endif
#line 1169
#ifdef DEBUG
#error
#line 1188
#endif
#line 1198
#ifdef DEBUG
#error
#line 1239
#endif
#line 1250
#ifdef DEBUG
#error
#line 1301
#endif
#line 1321
#ifdef DEBUG
#error
#line 1325
#else
#line 1329
#endif
#line 1353
#ifdef DEBUG
#error
#line 1361
#endif
#line 1394
#ifdef DEBUG
#error
#line 1423
#endif
#line 1519
#ifdef FE_IME
#error
#line 1523
#endif
#line 1691
#ifdef DEBUG
#error
#line 1712
#endif
#line 1714
#ifdef DEBUG
#error
#line 1794
#endif
#line 1886
#ifdef DEBUG
#error
#line 1911
#endif // DEBUG
#line 1933
#ifdef DEBUG
#error
#line 2013
#endif // DEBUG
