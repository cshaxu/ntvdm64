from pathlib import Path
import json,re,hashlib
b=Path('build/t483-s6-p12')
checkpoint=json.loads((b/'source-checkpoint.json').read_text(encoding='utf-8'))
for item in checkpoint['files']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item
expected={'BOOL gfTrackLocks':21,'DWORD gcHandlePages':36,'PHANDLEPAGE gpHandlePages':37,'gabObjectCreateFlags[':39,'gdwAllocTag[':64,'KernelPtoH( PVOID':2146}
found={};line=1;file=''
for text in (b/'handtabl.i').read_text(encoding='latin1').splitlines():
    m=re.match(r'^#(?:line)?\s+(\d+)(?:\s+"([^"]+)")?',text)
    if m:
        line=int(m[1]);file=m[2] or file;continue
    if file.replace('\\','/').lower().endswith('/kernel/handtabl.c'):
        for token in expected:
            if token in text:found[token]=line
    line+=1
assert found==expected,(found,expected)
checkpoint['compiler_anchors']=found
checkpoint['preprocessed_sha256']=hashlib.sha256((b/'handtabl.i').read_bytes()).hexdigest()
(b/'line-proof.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
print('PASS original logical lines',found)
