$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 $buildPid=[int](Get-Content "$PSScriptRoot/runner.pid")
 $build=Get-Process -Id $buildPid -ErrorAction SilentlyContinue
 if($build -and !$build.WaitForExit(1800000)){throw 'Owned cached build still running at supervision deadline'}
 if(!(Test-Path "$PSScriptRoot/cached.exit") -or (Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached full failed'}
 & $env:ComSpec /d /c "$PSScriptRoot/preprocess.cmd"
 if($LASTEXITCODE){throw 'Preprocessing failed'}
 & python "$PSScriptRoot/check-lines.py"
 if($LASTEXITCODE){throw 'Original line proof failed'}
 & "$PSScriptRoot/run-pipeline.ps1"
 if($LASTEXITCODE){throw 'Delivery pipeline failed'}
 0|Set-Content "$PSScriptRoot/delivery-supervisor.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/delivery-supervisor.exit";exit 1}
