#include <windows.h>
#include <stdio.h>
#include "common/protocol/console_io.h"
static BOOL StreamIoSwitchOn, presentation_only, window_mode;
static DWORD begin_error, query_error;
static int query_result=1, queries;
static DWORD ntvdm_console_client_begin(void *owner) {
    (void)owner; return begin_error;
}
static int ntvdm_console_window_query(DWORD mode,LONG values[4]) {
    ++queries;
    if(mode==CONSOLE_WINDOW_PRESENTATION_ONLY)values[0]=presentation_only;
    else if(mode==CONSOLE_WINDOW_TEXT_FRAME_REQUIRED)values[0]=presentation_only || window_mode;
    else return -1;
    SetLastError(query_error);return query_result;
}
static DWORD begin_character_io(void *owner,HANDLE stop)
{
    LONG presentation[4]={0};
    DWORD error;
    int available;
    (void)stop;
    error=ntvdm_console_client_begin(owner);
    if(error)return error;
    /* Resolve the authenticated frontend requirement before original startup
     * can enable stream I/O. A short DOS task can finish before the first
     * video tick; deferring this choice loses writes on frame-only frontends.
     * A native Console shown in a Window still owns stream/restore state.
     * Only presentation-only frontends must disable the startup option. */
    available=ntvdm_console_window_query(CONSOLE_WINDOW_PRESENTATION_ONLY,presentation);
    if(available<=0)return available<0 ? ERROR_INVALID_STATE : GetLastError();
    if(presentation[0])StreamIoSwitchOn=FALSE;
    return ERROR_SUCCESS;
}
#define CHECK(x) do {if(!(x)){fprintf(stderr,"failed line %d: %s\n",__LINE__,#x);return 1;}}while(0)
int main(void) {
    /* Window selection must preserve native Console exit/restore semantics. */
    for(int window=0;window!=2;++window) {
        window_mode=window;presentation_only=FALSE;StreamIoSwitchOn=TRUE;
        CHECK(begin_character_io(NULL,NULL)==0);CHECK(StreamIoSwitchOn);
    }
    /* A frame-only VM needs stream disabled before the first video tick. */
    presentation_only=TRUE;StreamIoSwitchOn=TRUE;
    CHECK(begin_character_io(NULL,NULL)==0);CHECK(!StreamIoSwitchOn);
    /* Never re-enable an option disabled by another owner. */
    presentation_only=FALSE;
    CHECK(begin_character_io(NULL,NULL)==0);CHECK(!StreamIoSwitchOn);
    StreamIoSwitchOn=TRUE;query_result=0;query_error=ERROR_NOT_READY;
    CHECK(begin_character_io(NULL,NULL)==ERROR_NOT_READY);CHECK(StreamIoSwitchOn);
    query_result=-1;
    CHECK(begin_character_io(NULL,NULL)==ERROR_INVALID_STATE);CHECK(StreamIoSwitchOn);
    queries=0;begin_error=ERROR_ACCESS_DENIED;
    CHECK(begin_character_io(NULL,NULL)==ERROR_ACCESS_DENIED);CHECK(queries==0);
    puts("PASS native Window, frame-only VM, disabled option and startup errors");
    return 0;
}