@echo off
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-1
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-1-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-2
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-2-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-3
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-3-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-4
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-4-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-5
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-5-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-6
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-6-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-7
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-7-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-8
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-8-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-9
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-9-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-10
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-10-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-11
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-11-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /k echo S10-INTERACTIVE-12
if errorlevel 1 (echo S10-INTERACTIVE-FAILURE-12-code-%errorlevel% & exit /b 81)
"O:\tmp\nc42\system32\run16.exe" cmd /d /c echo S10-INTERACTIVE-FINAL
if errorlevel 1 exit /b 82
echo S10-INTERACTIVE-COMPLETE
exit /b 19
