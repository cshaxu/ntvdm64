#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#define GLOBAL
#define IFN2(t,a,u,b) (t a,u b)
typedef unsigned char half_word;
typedef unsigned long sys_addr;
#define VGA_HEIGHT_0 22
#define VGA_HEIGHT_1 25
#define VGA_HEIGHT_2 28
#define VGA_HEIGHT_3 43
#define VGA_HEIGHT_4 50
#define MID_VAL(x,y) (x+((y)-(x))/2)
#define EGA_CGDDOT 8
#define EGA_CGMN 14
#define EGA_HIFONT 16
#define EGA_IPSTAT1_REG 0
#define EGA_AC_INDEX_DATA 0
#define EGA_PALETTE_ENABLE 0
#define VID_LEN 0
#define VID_COLS 1
static struct {HANDLE OutputHandle;} sc;
static CONSOLE_SCREEN_BUFFER_INFO ConsBufferInfo;
static int blocked_in_gfx_mode,cell_height,font_height,loads,scanlines;
static BYTE font[32];
static BOOL WINAPI console_info(HANDLE h,PCONSOLE_SCREEN_BUFFER_INFO b){(void)h;(void)b;return TRUE;}
#define GetConsoleScreenBufferInfo console_info
#define ErrorExit() abort()
static int get_char_height(void){return cell_height;}
static void low_set_mode(int mode){(void)mode;}
static void inb(int port,half_word *v){(void)port;*v=0;}
static void outb(int port,int v){(void)port;(void)v;}
static void display_mode(void){}
static void (*choose_display_mode)(void)=display_mode;
static void set_screen_height_recal(int n){scanlines=n;}
static void recalc_text(int n){cell_height=n;}
static void sas_storew_no_check(int a,int b){(void)a;(void)b;}
void load_font(sys_addr table,int count,int first,int bank,int n){
    if(count!=256 || first || bank || table!=(sys_addr)n)abort();
    ++loads;font_height=n;
    for(int i=0;i<n;++i)font[i]=(BYTE)n;
    /* Original loader changes registers; dimensions must follow. */
    scanlines=-1;cell_height=16;
}
GLOBAL VOID calcScreenParams IFN2( USHORT *, pCharHeight, USHORT *, pVgaHeight )
{
    USHORT   consoleWidth,
	     consoleHeight,
	     vgaHeight,
	     charHeight,
	     scanLines;
    half_word temp;

    /* Get console information. */
    if (!GetConsoleScreenBufferInfo(sc.OutputHandle, &ConsBufferInfo))
	ErrorExit();

    /* Now sync the SoftPC screen to the console. */
#ifdef X86GFX
#line 535
#error Unsupported excluded original configuration
#endif
#line 536
    {
	consoleWidth = ConsBufferInfo.srWindow.Right -
		       ConsBufferInfo.srWindow.Left + 1;
	consoleHeight = ConsBufferInfo.srWindow.Bottom -
			ConsBufferInfo.srWindow.Top + 1;
    }
#ifdef X86GFX
#line 543
#error DIVERGENCE MVDM-HOST-DIV-510: X86GFX branch is not selected for this source; see mirror register.
#endif
#line 553

    /*
     * Set the display to the nearest VGA text mode size, which is one of
     * 80x22, 80x25, 80x28, 80x43 or 80x50.
     */
    if (consoleHeight <= MID_VAL(VGA_HEIGHT_0, VGA_HEIGHT_1))
    {
	/* 22 lines */
	vgaHeight = VGA_HEIGHT_0;
	scanLines = 351;
	charHeight = 16;
    }
    else if (consoleHeight <= MID_VAL(VGA_HEIGHT_1, VGA_HEIGHT_2))
    {
	/* 25 lines */
	vgaHeight = VGA_HEIGHT_1;
	scanLines = 399;
	charHeight = 16;
    }
    else if (consoleHeight <= MID_VAL(VGA_HEIGHT_2, VGA_HEIGHT_3))
    {
	/* 28 lines */
	vgaHeight = VGA_HEIGHT_2;
	scanLines = 391;
	charHeight = 14;
    }
    else if (consoleHeight <= MID_VAL(VGA_HEIGHT_3, VGA_HEIGHT_4))
    {
	/* 43 lines */
	vgaHeight = VGA_HEIGHT_3;
	scanLines = 349;
	charHeight = 8;
    }
    else
    {
	/* 50 lines */
	vgaHeight = VGA_HEIGHT_4;
	scanLines = 399;
	charHeight = 8;
    }

#ifdef X86GFX
#line 594
#error Unsupported excluded original configuration
#endif
#line 595
    {
        /* The app may have shutdown in a gfx mode - force text mode back */
        if (blocked_in_gfx_mode)
        {
            low_set_mode(3);
            inb(EGA_IPSTAT1_REG,&temp);
            outb(EGA_AC_INDEX_DATA, EGA_PALETTE_ENABLE);   /* re-enable video */
            (*choose_display_mode)();
            blocked_in_gfx_mode = FALSE;
        }
	/*
	 * Set screen height appropriately for current window size.
	 * Now call video routine to set the character height, updating the
	 * BIOS RAM as it does so.
	 */	
	if (charHeight != get_char_height())
	{
	    extern void load_font(sys_addr, int, int, int, int);
	    load_font(charHeight == 8 ? EGA_CGDDOT :
	              charHeight == 14 ? EGA_CGMN : EGA_HIFONT,
	              256, 0, 0, charHeight);
	}
#line 610
	set_screen_height_recal( scanLines ); /* Tim Oct 92 */
	recalc_text(charHeight);

        /* badly written apps assume 25 line mode page len is 4096 */
        if (vgaHeight == 25)
            sas_storew_no_check(VID_LEN, 0x1000);
#ifdef X86GFX
#line 617
#error DIVERGENCE MVDM-HOST-DIV-510: X86GFX branch is not selected for this source; see mirror register.
#endif	/* X86GFX */
#line 619

    }
#ifdef X86GFX
#line 622
#error DIVERGENCE MVDM-HOST-DIV-510: X86GFX branch is not selected for this source; see mirror register.
#endif /* X86GFX */
#line 647
    sas_storew_no_check(VID_COLS, 80);   // fixup from 40 char shutdown
    *pCharHeight = charHeight;
    *pVgaHeight  = vgaHeight;

}
#define CHECK(x) do {if(!(x)){fprintf(stderr,"failed line %d: %s\n",__LINE__,#x);return 1;}}while(0)
int main(void){
    const int rows[]={22,25,28,43,50}, heights[]={16,16,14,8,8};
    USHORT height,lines;
    for(int i=0;i<5;++i){
        ConsBufferInfo.srWindow.Bottom=(SHORT)(rows[i]-1);
        ConsBufferInfo.srWindow.Right=79;
        /* Eight new scanlines over stale taller glyphs after Windows. */
        cell_height=font_height=8;loads=0;
        for(int j=0;j<32;++j)font[j]=(BYTE)(j<8?8:99);
        calcScreenParams(&height,&lines);
        CHECK(height==heights[i] && lines==rows[i]);
        CHECK(cell_height==heights[i] && font_height==heights[i]);
        CHECK(scanlines>0);
        for(int j=0;j<height;++j)CHECK(font[j]==height);
        CHECK(loads==(height!=8));
        font[0]=123;loads=0;
        calcScreenParams(&height,&lines);
        CHECK(!loads && font[0]==123);
    }
    puts("PASS font restoration and same-height downloaded glyph preservation");
    return 0;
}