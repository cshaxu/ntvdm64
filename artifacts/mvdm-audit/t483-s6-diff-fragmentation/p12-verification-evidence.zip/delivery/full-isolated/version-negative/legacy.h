

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Mon Jan 18 19:14:07 2038
 */
/* Compiler settings for legacy.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */


#ifndef __legacy_h__
#define __legacy_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef DECLSPEC_XFGVIRT
#if defined(_CONTROL_FLOW_GUARD_XFG)
#define DECLSPEC_XFGVIRT(base, func) __declspec(xfg_virtual(base, func))
#else
#define DECLSPEC_XFGVIRT(base, func)
#endif
#endif

/* Forward Declarations */ 

/* header files for imported files */
#include "wtypes.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __vdm_service_INTERFACE_DEFINED__
#define __vdm_service_INTERFACE_DEFINED__

/* interface vdm_service */
/* [unique][version][uuid] */ 

typedef /* [context_handle] */ void *VDM_CONNECTION;

/* client prototype */
error_status_t Client_RequestParticipantExit( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long scope);
/* server prototype */
error_status_t Server_RequestParticipantExit( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long scope);

/* client prototype */
error_status_t Client_WorkerIoCheckpoint( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long reason,
    /* [in] */ unsigned long request,
    /* [out] */ unsigned long *decision);
/* server prototype */
error_status_t Server_WorkerIoCheckpoint( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long reason,
    /* [in] */ unsigned long request,
    /* [out] */ unsigned long *decision);

/* client prototype */
error_status_t Client_WorkerIoTransition( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long action);
/* server prototype */
error_status_t Server_WorkerIoTransition( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long action);

/* client prototype */
error_status_t Client_FrontendIoDisconnected( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);
/* server prototype */
error_status_t Server_FrontendIoDisconnected( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);

/* client prototype */
error_status_t Client_SubmitNativeRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long operation,
    /* [system_handle][in] */ HANDLE frontend,
    /* [range][in] */ unsigned long bytes,
    /* [size_is][unique][in] */ byte *payload,
    /* [system_handle][out] */ HANDLE *target,
    /* [system_handle][out] */ HANDLE *receipt,
    /* [out] */ unsigned long *request);
/* server prototype */
error_status_t Server_SubmitNativeRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long operation,
    /* [system_handle][in] */ HANDLE frontend,
    /* [range][in] */ unsigned long bytes,
    /* [size_is][unique][in] */ byte *payload,
    /* [system_handle][out] */ HANDLE *target,
    /* [system_handle][out] */ HANDLE *receipt,
    /* [out] */ unsigned long *request);

/* client prototype */
error_status_t Client_FinishNativeRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [out] */ unsigned long *exit_code,
    /* [out] */ unsigned long *target_completed);
/* server prototype */
error_status_t Server_FinishNativeRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [out] */ unsigned long *exit_code,
    /* [out] */ unsigned long *target_completed);

/* client prototype */
error_status_t Client_StartVdmWorker( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long environment_chars,
    /* [size_is][in] */ wchar_t *environment,
    /* [in] */ unsigned long show_window,
    /* [system_handle][in] */ HANDLE frontend,
    /* [system_handle][out] */ HANDLE *worker,
    /* [system_handle][out] */ HANDLE *parent,
    /* [out] */ unsigned long *parent_receipt);
/* server prototype */
error_status_t Server_StartVdmWorker( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long environment_chars,
    /* [size_is][in] */ wchar_t *environment,
    /* [in] */ unsigned long show_window,
    /* [system_handle][in] */ HANDLE frontend,
    /* [system_handle][out] */ HANDLE *worker,
    /* [system_handle][out] */ HANDLE *parent,
    /* [out] */ unsigned long *parent_receipt);

/* client prototype */
error_status_t Client_StartNativeWorker( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long native_type,
    /* [system_handle][out] */ HANDLE *worker);
/* server prototype */
error_status_t Server_StartNativeWorker( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long native_type,
    /* [system_handle][out] */ HANDLE *worker);

/* client prototype */
error_status_t Client_StartFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper console_window,
    /* [in] */ unsigned long borrowed,
    /* [system_handle][out] */ HANDLE *root,
    /* [system_handle][out] */ HANDLE *capability,
    /* [system_handle][out] */ HANDLE *restored);
/* server prototype */
error_status_t Server_StartFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper console_window,
    /* [in] */ unsigned long borrowed,
    /* [system_handle][out] */ HANDLE *root,
    /* [system_handle][out] */ HANDLE *capability,
    /* [system_handle][out] */ HANDLE *restored);

/* client prototype */
error_status_t Client_FrontendStartupResult( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [in] */ unsigned long status);
/* server prototype */
error_status_t Server_FrontendStartupResult( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [in] */ unsigned long status);

/* client prototype */
error_status_t Client_FrontendConsoleRestored( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);
/* server prototype */
error_status_t Server_FrontendConsoleRestored( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);

/* client prototype */
error_status_t Client_FrontendCloseQuiesced( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);
/* server prototype */
error_status_t Server_FrontendCloseQuiesced( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);

/* client prototype */
error_status_t Client_WaitFrontendConsoleRestored( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation);
/* server prototype */
error_status_t Server_WaitFrontendConsoleRestored( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation);

/* client prototype */
error_status_t Client_WorkerIoReleaseEvent( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *release);
/* server prototype */
error_status_t Server_WorkerIoReleaseEvent( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *release);

/* client prototype */
error_status_t Client_CompleteWorkerChannel( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [in] */ unsigned long exit_code,
    /* [in] */ unsigned long io_error,
    /* [in] */ unsigned long io_flags);
/* server prototype */
error_status_t Server_CompleteWorkerChannel( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [in] */ unsigned long exit_code,
    /* [in] */ unsigned long io_error,
    /* [in] */ unsigned long io_flags);

/* client prototype */
error_status_t Client_GetNextNativeCommand( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long capacity,
    /* [length_is][size_is][out] */ byte *payload,
    /* [out] */ unsigned long *bytes,
    /* [system_handle][out] */ HANDLE *caller_process,
    /* [system_handle][out] */ HANDLE *execution,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *request,
    /* [out] */ unsigned long *caller_generation);
/* server prototype */
error_status_t Server_GetNextNativeCommand( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long capacity,
    /* [length_is][size_is][out] */ byte *payload,
    /* [out] */ unsigned long *bytes,
    /* [system_handle][out] */ HANDLE *caller_process,
    /* [system_handle][out] */ HANDLE *execution,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *request,
    /* [out] */ unsigned long *caller_generation);

/* client prototype */
error_status_t Client_NativeStartupResult( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long caller_generation,
    /* [in] */ unsigned long request,
    /* [in] */ unsigned long status,
    /* [system_handle][in] */ HANDLE target,
    /* [system_handle][in] */ HANDLE receipt);
/* server prototype */
error_status_t Server_NativeStartupResult( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long caller_generation,
    /* [in] */ unsigned long request,
    /* [in] */ unsigned long status,
    /* [system_handle][in] */ HANDLE target,
    /* [system_handle][in] */ HANDLE receipt);

/* client prototype */
error_status_t Client_RegisterNativeBackend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE frontend);
/* server prototype */
error_status_t Server_RegisterNativeBackend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE frontend);

/* client prototype */
error_status_t Client_BindNativeTarget( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [system_handle][in] */ HANDLE target,
    /* [system_handle][in] */ HANDLE receipt);
/* server prototype */
error_status_t Server_BindNativeTarget( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [system_handle][in] */ HANDLE target,
    /* [system_handle][in] */ HANDLE receipt);

/* client prototype */
error_status_t Client_AcquireConsoleContext( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE frontend,
    /* [system_handle][out] */ HANDLE *capability);
/* server prototype */
error_status_t Server_AcquireConsoleContext( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE frontend,
    /* [system_handle][out] */ HANDLE *capability);

/* client prototype */
error_status_t Client_BindConsoleContext( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability);
/* server prototype */
error_status_t Server_BindConsoleContext( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability);

/* client prototype */
error_status_t Client_WorkerFrontendCapability( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *capability);
/* server prototype */
error_status_t Server_WorkerFrontendCapability( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *capability);

/* client prototype */
error_status_t Client_RegisterFrontendRoot( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [out] */ hyper *frontend_instance,
    /* [out] */ unsigned long *frontend_generation);
/* server prototype */
error_status_t Server_RegisterFrontendRoot( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [out] */ hyper *frontend_instance,
    /* [out] */ unsigned long *frontend_generation);

/* client prototype */
error_status_t Client_RegisterFrontendLease( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ hyper console_window,
    /* [in] */ unsigned long creator_pid,
    /* [in] */ unsigned long borrowed,
    /* [system_handle][in] */ HANDLE retire,
    /* [system_handle][in] */ HANDLE restored);
/* server prototype */
error_status_t Server_RegisterFrontendLease( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ hyper console_window,
    /* [in] */ unsigned long creator_pid,
    /* [in] */ unsigned long borrowed,
    /* [system_handle][in] */ HANDLE retire,
    /* [system_handle][in] */ HANDLE restored);

/* client prototype */
error_status_t Client_FrontendJoinCandidate( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *nonce,
    /* [out] */ unsigned long *candidate_pid);
/* server prototype */
error_status_t Server_FrontendJoinCandidate( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *nonce,
    /* [out] */ unsigned long *candidate_pid);

/* client prototype */
error_status_t Client_FrontendJoinDecision( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ unsigned long nonce,
    /* [in] */ unsigned long same_console);
/* server prototype */
error_status_t Server_FrontendJoinDecision( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ unsigned long nonce,
    /* [in] */ unsigned long same_console);

/* client prototype */
error_status_t Client_FrontendLeaseReady( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);
/* server prototype */
error_status_t Server_FrontendLeaseReady( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);

/* client prototype */
error_status_t Client_RetainFrontendRoot( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [system_handle][out] */ HANDLE *root,
    /* [out] */ unsigned long *root_generation);
/* server prototype */
error_status_t Server_RetainFrontendRoot( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [system_handle][out] */ HANDLE *root,
    /* [out] */ unsigned long *root_generation);

/* client prototype */
error_status_t Client_RequestFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability);
/* server prototype */
error_status_t Server_RequestFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability);

/* client prototype */
error_status_t Client_FrontendRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *request,
    /* [system_handle][out] */ HANDLE *worker);
/* server prototype */
error_status_t Server_FrontendRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *request,
    /* [system_handle][out] */ HANDLE *worker);

/* client prototype */
error_status_t Client_AttachFrontendRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ unsigned long request,
    /* [system_handle][in] */ HANDLE channel,
    /* [system_handle][in] */ HANDLE ready);
/* server prototype */
error_status_t Server_AttachFrontendRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ unsigned long request,
    /* [system_handle][in] */ HANDLE channel,
    /* [system_handle][in] */ HANDLE ready);

/* client prototype */
error_status_t Client_TakeFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *channel,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *ready);
/* server prototype */
error_status_t Server_TakeFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *channel,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *ready);

/* client prototype */
error_status_t Client_WaitFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *channel,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *ready);
/* server prototype */
error_status_t Server_WaitFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *channel,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *ready);

typedef struct _DTASKMGR_KEY
    {
    hyper instance;
    unsigned long category;
    unsigned long generation;
    hyper object;
    } 	DTASKMGR_KEY;

typedef struct _DTASKMGR_WORKER
    {
    DTASKMGR_KEY key;
    DTASKMGR_KEY parent;
    unsigned long depth;
    unsigned long display_state;
    unsigned long actions;
    unsigned long process_id;
    unsigned long kind;
    unsigned long state;
    hyper started_filetime;
    unsigned long task;
    unsigned long stack_depth;
    wchar_t image[ 260 ];
    hyper frontend_vm;
    } 	DTASKMGR_WORKER;

typedef struct _WORKER_TRACE_NODE
    {
    hyper node;
    hyper parent;
    unsigned long relation;
    unsigned long source;
    unsigned long kind;
    unsigned long state;
    unsigned long process_id;
    unsigned long task;
    unsigned long flags;
    unsigned long reserved;
    unsigned long dos_psp;
    unsigned long reserved2;
    hyper entered_order;
    hyper created_filetime;
    wchar_t image[ 260 ];
    } 	WORKER_TRACE_NODE;

typedef struct _DOS_OBSERVATION_FACT
    {
    hyper event_filetime;
    hyper occurrence;
    hyper parent;
    hyper direct;
    unsigned long event;
    unsigned long psp;
    unsigned long parent_psp;
    unsigned long flags;
    wchar_t image[ 260 ];
    } 	DOS_OBSERVATION_FACT;

/* client prototype */
error_status_t Client_Connect( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [out] */ unsigned long *server_protocol,
    /* [out] */ byte server_version[ 32 ],
    /* [out] */ VDM_CONNECTION *connection,
    /* [out] */ unsigned long *generation,
    /* [system_handle][out] */ HANDLE *server,
    /* [system_handle][out] */ HANDLE *shutdown,
    /* [system_handle][out] */ HANDLE *console_close,
    /* [system_handle][out] */ HANDLE *wow_task_close);
/* server prototype */
error_status_t Server_Connect( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [out] */ unsigned long *server_protocol,
    /* [out] */ byte server_version[ 32 ],
    /* [out] */ VDM_CONNECTION *connection,
    /* [out] */ unsigned long *generation,
    /* [system_handle][out] */ HANDLE *server,
    /* [system_handle][out] */ HANDLE *shutdown,
    /* [system_handle][out] */ HANDLE *console_close,
    /* [system_handle][out] */ HANDLE *wow_task_close);

/* client prototype */
error_status_t Client_BindWowTask( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long task,
    /* [range][in] */ unsigned short htask,
    /* [out] */ hyper *identity);
/* server prototype */
error_status_t Server_BindWowTask( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long task,
    /* [range][in] */ unsigned short htask,
    /* [out] */ hyper *identity);

/* client prototype */
error_status_t Client_RetireWowTask( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper identity);
/* server prototype */
error_status_t Server_RetireWowTask( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper identity);

/* client prototype */
error_status_t Client_TakeWowTaskClose( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out] */ hyper *identity);
/* server prototype */
error_status_t Server_TakeWowTaskClose( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out] */ hyper *identity);

/* client prototype */
error_status_t Client_FailWowTaskClose( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper identity);
/* server prototype */
error_status_t Server_FailWowTaskClose( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper identity);

/* client prototype */
error_status_t Client_ReportConsoleMembers( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long member_count,
    /* [size_is][in] */ unsigned long member_ids[  ]);
/* server prototype */
error_status_t Server_ReportConsoleMembers( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long member_count,
    /* [size_is][in] */ unsigned long member_ids[  ]);

/* client prototype */
error_status_t Client_First( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out] */ unsigned long *first);
/* server prototype */
error_status_t Server_First( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out] */ unsigned long *first);

/* client prototype */
error_status_t Client_Check( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *parent_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **parent_events,
    /* [out] */ unsigned long *parent_receipt,
    /* [out] */ unsigned long *reply_bytes,
    /* [out] */ byte reply[ 40 ]);
/* server prototype */
error_status_t Server_Check( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *parent_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **parent_events,
    /* [out] */ unsigned long *parent_receipt,
    /* [out] */ unsigned long *reply_bytes,
    /* [out] */ byte reply[ 40 ]);

/* client prototype */
error_status_t Client_Get( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *wait_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **wait_events,
    /* [out] */ unsigned long *pipe_stream_mask,
    /* [out] */ unsigned long *pipe_stream_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **pipe_streams,
    /* [out] */ unsigned long *file_stream_mask,
    /* [out] */ unsigned long *file_stream_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **file_streams,
    /* [out] */ unsigned long *reply_bytes,
    /* [size_is][size_is][out] */ byte **reply);
/* server prototype */
error_status_t Server_Get( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *wait_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **wait_events,
    /* [out] */ unsigned long *pipe_stream_mask,
    /* [out] */ unsigned long *pipe_stream_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **pipe_streams,
    /* [out] */ unsigned long *file_stream_mask,
    /* [out] */ unsigned long *file_stream_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **file_streams,
    /* [out] */ unsigned long *reply_bytes,
    /* [size_is][size_is][out] */ byte **reply);

/* client prototype */
error_status_t Client_Exit( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long is_wow,
    /* [in] */ unsigned long wow_task,
    /* [out] */ unsigned long *close_worker_wait);
/* server prototype */
error_status_t Server_Exit( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long is_wow,
    /* [in] */ unsigned long wow_task,
    /* [out] */ unsigned long *close_worker_wait);

/* client prototype */
error_status_t Client_Update( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *parent_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **parent_events,
    /* [out] */ unsigned long *parent_receipt,
    /* [out] */ unsigned long *reply_bytes,
    /* [out] */ byte reply[ 32 ]);
/* server prototype */
error_status_t Server_Update( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *parent_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **parent_events,
    /* [out] */ unsigned long *parent_receipt,
    /* [out] */ unsigned long *reply_bytes,
    /* [out] */ byte reply[ 32 ]);

/* client prototype */
error_status_t Client_ExitCode( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long parent_receipt,
    /* [out] */ unsigned long *exit_code);
/* server prototype */
error_status_t Server_ExitCode( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long parent_receipt,
    /* [out] */ unsigned long *exit_code);

/* client prototype */
error_status_t Client_Reenter( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long increment);
/* server prototype */
error_status_t Server_Reenter( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long increment);

/* client prototype */
error_status_t Client_Disconnect( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out][in] */ VDM_CONNECTION *connection);
/* server prototype */
error_status_t Server_Disconnect( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out][in] */ VDM_CONNECTION *connection);

/* client prototype */
error_status_t Client_AttachFile( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long role,
    /* [system_handle][in] */ HANDLE stream,
    /* [out] */ unsigned long *receipt);
/* server prototype */
error_status_t Server_AttachFile( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long role,
    /* [system_handle][in] */ HANDLE stream,
    /* [out] */ unsigned long *receipt);

/* client prototype */
error_status_t Client_AttachPipe( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long role,
    /* [system_handle][in] */ HANDLE stream,
    /* [out] */ unsigned long *receipt);
/* server prototype */
error_status_t Server_AttachPipe( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long role,
    /* [system_handle][in] */ HANDLE stream,
    /* [out] */ unsigned long *receipt);

/* client prototype */
error_status_t Client_RevokeStream( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long receipt);
/* server prototype */
error_status_t Server_RevokeStream( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long receipt);

/* client prototype */
error_status_t Client_TaskSnapshot( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [out] */ unsigned long *count,
    /* [size_is][size_is][out] */ DTASKMGR_WORKER **entries);
/* server prototype */
error_status_t Server_TaskSnapshot( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [out] */ unsigned long *count,
    /* [size_is][size_is][out] */ DTASKMGR_WORKER **entries);

/* client prototype */
error_status_t Client_CloseManagementNode( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DTASKMGR_KEY *key);
/* server prototype */
error_status_t Server_CloseManagementNode( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DTASKMGR_KEY *key);

/* client prototype */
error_status_t Client_WorkerTaskTrace( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DTASKMGR_KEY *key,
    /* [out] */ unsigned long *coverage,
    /* [out] */ unsigned long *count,
    /* [size_is][size_is][out] */ WORKER_TRACE_NODE **entries);
/* server prototype */
error_status_t Server_WorkerTaskTrace( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DTASKMGR_KEY *key,
    /* [out] */ unsigned long *coverage,
    /* [out] */ unsigned long *count,
    /* [size_is][size_is][out] */ WORKER_TRACE_NODE **entries);

/* client prototype */
error_status_t Client_ObserveNativeCreationAsync( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE reporter,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [system_handle][in] */ HANDLE child,
    /* [in] */ unsigned long creation_flags,
    /* [out] */ hyper *node);
/* server prototype */
error_status_t Server_ObserveNativeCreationAsync( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE reporter,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [system_handle][in] */ HANDLE child,
    /* [in] */ unsigned long creation_flags,
    /* [out] */ hyper *node);

/* client prototype */
error_status_t Client_ObserveDosEventAsync( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DOS_OBSERVATION_FACT *fact,
    /* [in] */ unsigned long gap);
/* server prototype */
error_status_t Server_ObserveDosEventAsync( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DOS_OBSERVATION_FACT *fact,
    /* [in] */ unsigned long gap);

/* client prototype */
error_status_t Client_RegisterWowExec( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long window);
/* server prototype */
error_status_t Server_RegisterWowExec( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long window);

/* client prototype */
error_status_t Client_RetireWorkerlessFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *retired);
/* server prototype */
error_status_t Server_RetireWorkerlessFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *retired);

/* client prototype */
error_status_t Client_FrontendStateChanged( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [system_handle][out] */ HANDLE *state_changed);
/* server prototype */
error_status_t Server_FrontendStateChanged( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [system_handle][out] */ HANDLE *state_changed);

/* client prototype */
error_status_t Client_WowStarted( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long task);
/* server prototype */
error_status_t Server_WowStarted( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long task);

/* client prototype */
error_status_t Client_WowStartup( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long parent_receipt,
    /* [system_handle][out] */ HANDLE *event,
    /* [out] */ unsigned long *started);
/* server prototype */
error_status_t Server_WowStartup( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long parent_receipt,
    /* [system_handle][out] */ HANDLE *event,
    /* [out] */ unsigned long *started);

/* client prototype */
error_status_t Client_RegisterEmbeddedFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper payload,
    /* [in] */ hyper vm,
    /* [in] */ hyper incarnation,
    /* [out] */ hyper *frontend_instance,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *notification,
    /* [system_handle][out] */ HANDLE *retire);
/* server prototype */
error_status_t Server_RegisterEmbeddedFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper payload,
    /* [in] */ hyper vm,
    /* [in] */ hyper incarnation,
    /* [out] */ hyper *frontend_instance,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *notification,
    /* [system_handle][out] */ HANDLE *retire);

/* client prototype */
error_status_t Client_CloseFrontendInstance( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);
/* server prototype */
error_status_t Server_CloseFrontendInstance( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);

/* client prototype */
error_status_t Client_UnregisterFrontendInstance( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);
/* server prototype */
error_status_t Server_UnregisterFrontendInstance( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation);



extern RPC_IF_HANDLE Client_vdm_service_v1_0_c_ifspec;
extern RPC_IF_HANDLE vdm_service_v1_0_c_ifspec;
extern RPC_IF_HANDLE Server_vdm_service_v1_0_s_ifspec;
#endif /* __vdm_service_INTERFACE_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

void __RPC_USER VDM_CONNECTION_rundown( VDM_CONNECTION );

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


