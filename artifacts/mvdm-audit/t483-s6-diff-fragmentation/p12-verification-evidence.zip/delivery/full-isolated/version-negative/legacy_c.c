

/* this ALWAYS GENERATED file contains the RPC client stubs */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Mon Jan 18 19:14:07 2038
 */
/* Compiler settings for legacy.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#if defined(_M_AMD64)


#if _MSC_VER >= 1200
#pragma warning(push)
#endif

#pragma warning( disable: 4211 )  /* redefine extern to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#pragma warning( disable: 4024 )  /* array to pointer mapping*/

#include <string.h>

#include "legacy.h"

#define TYPE_FORMAT_STRING_SIZE   645                               
#define PROC_FORMAT_STRING_SIZE   4579                              
#define EXPR_FORMAT_STRING_SIZE   1                                 
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   0            

typedef struct _legacy_MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } legacy_MIDL_TYPE_FORMAT_STRING;

typedef struct _legacy_MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } legacy_MIDL_PROC_FORMAT_STRING;

typedef struct _legacy_MIDL_EXPR_FORMAT_STRING
    {
    long          Pad;
    unsigned char  Format[ EXPR_FORMAT_STRING_SIZE ];
    } legacy_MIDL_EXPR_FORMAT_STRING;


static const RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax_2_0 = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};

static const RPC_SYNTAX_IDENTIFIER  _NDR64_RpcTransferSyntax_1_0 = 
{{0x71710533,0xbeba,0x4937,{0x83,0x19,0xb5,0xdb,0xef,0x9c,0xcc,0x36}},{1,0}};

#if defined(_CONTROL_FLOW_GUARD_XFG)
#define XFG_TRAMPOLINES(ObjectType)\
NDR_SHAREABLE unsigned long ObjectType ## _UserSize_XFG(unsigned long * pFlags, unsigned long Offset, void * pObject)\
{\
return  ObjectType ## _UserSize(pFlags, Offset, (ObjectType *)pObject);\
}\
NDR_SHAREABLE unsigned char * ObjectType ## _UserMarshal_XFG(unsigned long * pFlags, unsigned char * pBuffer, void * pObject)\
{\
return ObjectType ## _UserMarshal(pFlags, pBuffer, (ObjectType *)pObject);\
}\
NDR_SHAREABLE unsigned char * ObjectType ## _UserUnmarshal_XFG(unsigned long * pFlags, unsigned char * pBuffer, void * pObject)\
{\
return ObjectType ## _UserUnmarshal(pFlags, pBuffer, (ObjectType *)pObject);\
}\
NDR_SHAREABLE void ObjectType ## _UserFree_XFG(unsigned long * pFlags, void * pObject)\
{\
ObjectType ## _UserFree(pFlags, (ObjectType *)pObject);\
}
#define XFG_TRAMPOLINES64(ObjectType)\
NDR_SHAREABLE unsigned long ObjectType ## _UserSize64_XFG(unsigned long * pFlags, unsigned long Offset, void * pObject)\
{\
return  ObjectType ## _UserSize64(pFlags, Offset, (ObjectType *)pObject);\
}\
NDR_SHAREABLE unsigned char * ObjectType ## _UserMarshal64_XFG(unsigned long * pFlags, unsigned char * pBuffer, void * pObject)\
{\
return ObjectType ## _UserMarshal64(pFlags, pBuffer, (ObjectType *)pObject);\
}\
NDR_SHAREABLE unsigned char * ObjectType ## _UserUnmarshal64_XFG(unsigned long * pFlags, unsigned char * pBuffer, void * pObject)\
{\
return ObjectType ## _UserUnmarshal64(pFlags, pBuffer, (ObjectType *)pObject);\
}\
NDR_SHAREABLE void ObjectType ## _UserFree64_XFG(unsigned long * pFlags, void * pObject)\
{\
ObjectType ## _UserFree64(pFlags, (ObjectType *)pObject);\
}
#define XFG_BIND_TRAMPOLINES(HandleType, ObjectType)\
static void* ObjectType ## _bind_XFG(HandleType pObject)\
{\
return ObjectType ## _bind((ObjectType) pObject);\
}\
static void ObjectType ## _unbind_XFG(HandleType pObject, handle_t ServerHandle)\
{\
ObjectType ## _unbind((ObjectType) pObject, ServerHandle);\
}
#define XFG_TRAMPOLINE_FPTR(Function) Function ## _XFG
#define XFG_TRAMPOLINE_FPTR_DEPENDENT_SYMBOL(Symbol) Symbol ## _XFG
#else
#define XFG_TRAMPOLINES(ObjectType)
#define XFG_TRAMPOLINES64(ObjectType)
#define XFG_BIND_TRAMPOLINES(HandleType, ObjectType)
#define XFG_TRAMPOLINE_FPTR(Function) Function
#define XFG_TRAMPOLINE_FPTR_DEPENDENT_SYMBOL(Symbol) Symbol
#endif



extern const legacy_MIDL_TYPE_FORMAT_STRING legacy__MIDL_TypeFormatString;
extern const legacy_MIDL_PROC_FORMAT_STRING legacy__MIDL_ProcFormatString;
extern const legacy_MIDL_EXPR_FORMAT_STRING legacy__MIDL_ExprFormatString;

#define GENERIC_BINDING_TABLE_SIZE   0            


/* Standard interface: vdm_service, ver. 1.0,
   GUID={0x7d3e78bd,0x0472,0x4736,{0x87,0x97,0xe6,0x4e,0x96,0x6d,0x69,0x2e}} */

 extern const MIDL_STUBLESS_PROXY_INFO vdm_service_ProxyInfo;


static const RPC_CLIENT_INTERFACE vdm_service___RpcClientInterface =
    {
    sizeof(RPC_CLIENT_INTERFACE),
    {{0x7d3e78bd,0x0472,0x4736,{0x87,0x97,0xe6,0x4e,0x96,0x6d,0x69,0x2e}},{1,0}},
    {{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}},
    0,
    0,
    0,
    0,
    &vdm_service_ProxyInfo,
    0x02000000
    };
RPC_IF_HANDLE Client_vdm_service_v1_0_c_ifspec = (RPC_IF_HANDLE)& vdm_service___RpcClientInterface;
#ifdef __cplusplus
namespace {
#endif

extern const MIDL_STUB_DESC vdm_service_StubDesc;
#ifdef __cplusplus
}
#endif

static RPC_BINDING_HANDLE vdm_service__MIDL_AutoBindHandle;


error_status_t Client_RequestParticipantExit( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long scope)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  0,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  scope);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WorkerIoCheckpoint( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long reason,
    /* [in] */ unsigned long request,
    /* [out] */ unsigned long *decision)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  1,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  reason,
                  request,
                  decision);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WorkerIoTransition( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long action)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  2,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  action);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendIoDisconnected( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  3,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_SubmitNativeRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long operation,
    /* [system_handle][in] */ HANDLE frontend,
    /* [range][in] */ unsigned long bytes,
    /* [size_is][unique][in] */ byte *payload,
    /* [system_handle][out] */ HANDLE *target,
    /* [system_handle][out] */ HANDLE *receipt,
    /* [out] */ unsigned long *request)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  4,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  operation,
                  frontend,
                  bytes,
                  payload,
                  target,
                  receipt,
                  request);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FinishNativeRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [out] */ unsigned long *exit_code,
    /* [out] */ unsigned long *target_completed)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  5,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  request,
                  exit_code,
                  target_completed);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_StartVdmWorker( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long environment_chars,
    /* [size_is][in] */ wchar_t *environment,
    /* [in] */ unsigned long show_window,
    /* [system_handle][in] */ HANDLE frontend,
    /* [system_handle][out] */ HANDLE *worker,
    /* [system_handle][out] */ HANDLE *parent,
    /* [out] */ unsigned long *parent_receipt)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  6,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  environment_chars,
                  environment,
                  show_window,
                  frontend,
                  worker,
                  parent,
                  parent_receipt);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_StartNativeWorker( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long native_type,
    /* [system_handle][out] */ HANDLE *worker)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  7,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  native_type,
                  worker);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_StartFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper console_window,
    /* [in] */ unsigned long borrowed,
    /* [system_handle][out] */ HANDLE *root,
    /* [system_handle][out] */ HANDLE *capability,
    /* [system_handle][out] */ HANDLE *restored)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  8,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  console_window,
                  borrowed,
                  root,
                  capability,
                  restored);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendStartupResult( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [in] */ unsigned long status)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  9,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  capability,
                  status);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendConsoleRestored( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  10,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendCloseQuiesced( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  11,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WaitFrontendConsoleRestored( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  12,
                  0,
                  binding,
                  connection,
                  process,
                  generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WorkerIoReleaseEvent( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *release)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  13,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  release);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_CompleteWorkerChannel( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [in] */ unsigned long exit_code,
    /* [in] */ unsigned long io_error,
    /* [in] */ unsigned long io_flags)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  14,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  request,
                  exit_code,
                  io_error,
                  io_flags);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_GetNextNativeCommand( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [range][in] */ unsigned long capacity,
    /* [length_is][size_is][out] */ byte *payload,
    /* [out] */ unsigned long *bytes,
    /* [system_handle][out] */ HANDLE *caller_process,
    /* [system_handle][out] */ HANDLE *execution,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *request,
    /* [out] */ unsigned long *caller_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  15,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  capacity,
                  payload,
                  bytes,
                  caller_process,
                  execution,
                  frontend,
                  request,
                  caller_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_NativeStartupResult( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long caller_generation,
    /* [in] */ unsigned long request,
    /* [in] */ unsigned long status,
    /* [system_handle][in] */ HANDLE target,
    /* [system_handle][in] */ HANDLE receipt)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  16,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  caller_generation,
                  request,
                  status,
                  target,
                  receipt);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RegisterNativeBackend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE frontend)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  17,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_BindNativeTarget( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request,
    /* [system_handle][in] */ HANDLE target,
    /* [system_handle][in] */ HANDLE receipt)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  18,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  request,
                  target,
                  receipt);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_AcquireConsoleContext( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE frontend,
    /* [system_handle][out] */ HANDLE *capability)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  19,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend,
                  capability);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_BindConsoleContext( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  20,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  capability);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WorkerFrontendCapability( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *capability)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  21,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  capability);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RegisterFrontendRoot( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [out] */ hyper *frontend_instance,
    /* [out] */ unsigned long *frontend_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  22,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  capability,
                  frontend_instance,
                  frontend_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RegisterFrontendLease( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ hyper console_window,
    /* [in] */ unsigned long creator_pid,
    /* [in] */ unsigned long borrowed,
    /* [system_handle][in] */ HANDLE retire,
    /* [system_handle][in] */ HANDLE restored)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  23,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation,
                  console_window,
                  creator_pid,
                  borrowed,
                  retire,
                  restored);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendJoinCandidate( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *nonce,
    /* [out] */ unsigned long *candidate_pid)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  24,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation,
                  nonce,
                  candidate_pid);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendJoinDecision( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ unsigned long nonce,
    /* [in] */ unsigned long same_console)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  25,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation,
                  nonce,
                  same_console);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendLeaseReady( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  26,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RetainFrontendRoot( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability,
    /* [system_handle][out] */ HANDLE *root,
    /* [out] */ unsigned long *root_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  27,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  capability,
                  root,
                  root_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RequestFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][in] */ HANDLE capability)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  28,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  capability);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *request,
    /* [system_handle][out] */ HANDLE *worker)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  29,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation,
                  request,
                  worker);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_AttachFrontendRequest( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [in] */ unsigned long request,
    /* [system_handle][in] */ HANDLE channel,
    /* [system_handle][in] */ HANDLE ready)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  30,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation,
                  request,
                  channel,
                  ready);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_TakeFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *channel,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *ready)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  31,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  channel,
                  frontend,
                  frontend_generation,
                  ready);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WaitFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [system_handle][out] */ HANDLE *channel,
    /* [system_handle][out] */ HANDLE *frontend,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *ready)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  32,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  channel,
                  frontend,
                  frontend_generation,
                  ready);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_Connect( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [out] */ unsigned long *server_protocol,
    /* [out] */ byte server_version[ 32 ],
    /* [out] */ VDM_CONNECTION *connection,
    /* [out] */ unsigned long *generation,
    /* [system_handle][out] */ HANDLE *server,
    /* [system_handle][out] */ HANDLE *shutdown,
    /* [system_handle][out] */ HANDLE *console_close,
    /* [system_handle][out] */ HANDLE *wow_task_close)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  33,
                  0,
                  binding,
                  process,
                  protocol,
                  application_version,
                  server_protocol,
                  server_version,
                  connection,
                  generation,
                  server,
                  shutdown,
                  console_close,
                  wow_task_close);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_BindWowTask( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long task,
    /* [range][in] */ unsigned short htask,
    /* [out] */ hyper *identity)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  34,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  task,
                  htask,
                  identity);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RetireWowTask( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper identity)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  35,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  identity);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_TakeWowTaskClose( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out] */ hyper *identity)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  36,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  identity);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FailWowTaskClose( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper identity)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  37,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  identity);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_ReportConsoleMembers( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long member_count,
    /* [size_is][in] */ unsigned long member_ids[  ])
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  38,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  member_count,
                  member_ids);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_First( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out] */ unsigned long *first)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  39,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  first);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_Check( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *parent_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **parent_events,
    /* [out] */ unsigned long *parent_receipt,
    /* [out] */ unsigned long *reply_bytes,
    /* [out] */ byte reply[ 40 ])
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  40,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  request_bytes,
                  request,
                  parent_event_count,
                  parent_events,
                  parent_receipt,
                  reply_bytes,
                  reply);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_Get( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *wait_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **wait_events,
    /* [out] */ unsigned long *pipe_stream_mask,
    /* [out] */ unsigned long *pipe_stream_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **pipe_streams,
    /* [out] */ unsigned long *file_stream_mask,
    /* [out] */ unsigned long *file_stream_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **file_streams,
    /* [out] */ unsigned long *reply_bytes,
    /* [size_is][size_is][out] */ byte **reply)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  41,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  request_bytes,
                  request,
                  wait_event_count,
                  wait_events,
                  pipe_stream_mask,
                  pipe_stream_count,
                  pipe_streams,
                  file_stream_mask,
                  file_stream_count,
                  file_streams,
                  reply_bytes,
                  reply);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_Exit( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long is_wow,
    /* [in] */ unsigned long wow_task,
    /* [out] */ unsigned long *close_worker_wait)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  42,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  is_wow,
                  wow_task,
                  close_worker_wait);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_Update( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long request_bytes,
    /* [size_is][in] */ byte *request,
    /* [out] */ unsigned long *parent_event_count,
    /* [size_is][size_is][system_handle][out] */ HANDLE **parent_events,
    /* [out] */ unsigned long *parent_receipt,
    /* [out] */ unsigned long *reply_bytes,
    /* [out] */ byte reply[ 32 ])
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  43,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  request_bytes,
                  request,
                  parent_event_count,
                  parent_events,
                  parent_receipt,
                  reply_bytes,
                  reply);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_ExitCode( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long parent_receipt,
    /* [out] */ unsigned long *exit_code)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  44,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  parent_receipt,
                  exit_code);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_Reenter( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long increment)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  45,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  increment);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_Disconnect( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [out][in] */ VDM_CONNECTION *connection)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  46,
                  0,
                  binding,
                  process,
                  generation,
                  connection);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_AttachFile( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long role,
    /* [system_handle][in] */ HANDLE stream,
    /* [out] */ unsigned long *receipt)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  47,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  role,
                  stream,
                  receipt);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_AttachPipe( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long role,
    /* [system_handle][in] */ HANDLE stream,
    /* [out] */ unsigned long *receipt)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  48,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  role,
                  stream,
                  receipt);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RevokeStream( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long receipt)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  49,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  receipt);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_TaskSnapshot( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [out] */ unsigned long *count,
    /* [size_is][size_is][out] */ DTASKMGR_WORKER **entries)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  50,
                  0,
                  binding,
                  process,
                  protocol,
                  application_version,
                  count,
                  entries);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_CloseManagementNode( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DTASKMGR_KEY *key)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  51,
                  0,
                  binding,
                  process,
                  protocol,
                  application_version,
                  key);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WorkerTaskTrace( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DTASKMGR_KEY *key,
    /* [out] */ unsigned long *coverage,
    /* [out] */ unsigned long *count,
    /* [size_is][size_is][out] */ WORKER_TRACE_NODE **entries)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  52,
                  0,
                  binding,
                  process,
                  protocol,
                  application_version,
                  key,
                  coverage,
                  count,
                  entries);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_ObserveNativeCreationAsync( 
    /* [in] */ handle_t binding,
    /* [system_handle][in] */ HANDLE reporter,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [system_handle][in] */ HANDLE child,
    /* [in] */ unsigned long creation_flags,
    /* [out] */ hyper *node)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  53,
                  0,
                  binding,
                  reporter,
                  protocol,
                  application_version,
                  child,
                  creation_flags,
                  node);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_ObserveDosEventAsync( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long protocol,
    /* [in] */ byte application_version[ 32 ],
    /* [in] */ DOS_OBSERVATION_FACT *fact,
    /* [in] */ unsigned long gap)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  54,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  protocol,
                  application_version,
                  fact,
                  gap);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RegisterWowExec( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long window)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  55,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  window);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RetireWorkerlessFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [out] */ unsigned long *retired)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  56,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation,
                  retired);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_FrontendStateChanged( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation,
    /* [system_handle][out] */ HANDLE *state_changed)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  57,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation,
                  state_changed);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WowStarted( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long task)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  58,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  task);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_WowStartup( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ unsigned long parent_receipt,
    /* [system_handle][out] */ HANDLE *event,
    /* [out] */ unsigned long *started)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  59,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  parent_receipt,
                  event,
                  started);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_RegisterEmbeddedFrontend( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper payload,
    /* [in] */ hyper vm,
    /* [in] */ hyper incarnation,
    /* [out] */ hyper *frontend_instance,
    /* [out] */ unsigned long *frontend_generation,
    /* [system_handle][out] */ HANDLE *notification,
    /* [system_handle][out] */ HANDLE *retire)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  60,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  payload,
                  vm,
                  incarnation,
                  frontend_instance,
                  frontend_generation,
                  notification,
                  retire);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_CloseFrontendInstance( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  61,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


error_status_t Client_UnregisterFrontendInstance( 
    /* [in] */ handle_t binding,
    /* [in] */ VDM_CONNECTION connection,
    /* [system_handle][in] */ HANDLE process,
    /* [in] */ unsigned long generation,
    /* [in] */ hyper frontend_instance,
    /* [in] */ unsigned long frontend_generation)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall3(
                  ( PMIDL_STUBLESS_PROXY_INFO  )&vdm_service_ProxyInfo,
                  62,
                  0,
                  binding,
                  connection,
                  process,
                  generation,
                  frontend_instance,
                  frontend_generation);
    return ( error_status_t  )_RetVal.Simple;
    
}


#if !defined(__RPC_WIN64__)
#error  Invalid build platform for this stub.
#endif

static const legacy_MIDL_PROC_FORMAT_STRING legacy__MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure RequestParticipantExit */

			0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x0 ),	/* 0 */
/*  8 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 10 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 12 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 14 */	NdrFcShort( 0x34 ),	/* 52 */
/* 16 */	NdrFcShort( 0x8 ),	/* 8 */
/* 18 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 20 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 22 */	NdrFcShort( 0x0 ),	/* 0 */
/* 24 */	NdrFcShort( 0x0 ),	/* 0 */
/* 26 */	NdrFcShort( 0x0 ),	/* 0 */
/* 28 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 30 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 32 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 34 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 36 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 38 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 40 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 42 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 44 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 46 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter scope */

/* 48 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 50 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 52 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 54 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 56 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 58 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WorkerIoCheckpoint */

/* 60 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 62 */	NdrFcLong( 0x0 ),	/* 0 */
/* 66 */	NdrFcShort( 0x1 ),	/* 1 */
/* 68 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 70 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 72 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 74 */	NdrFcShort( 0x3c ),	/* 60 */
/* 76 */	NdrFcShort( 0x24 ),	/* 36 */
/* 78 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 80 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 82 */	NdrFcShort( 0x0 ),	/* 0 */
/* 84 */	NdrFcShort( 0x0 ),	/* 0 */
/* 86 */	NdrFcShort( 0x0 ),	/* 0 */
/* 88 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 90 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 92 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 94 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 96 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 98 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 100 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 102 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 104 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 106 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter reason */

/* 108 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 110 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 112 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 114 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 116 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 118 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter decision */

/* 120 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 122 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 124 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 126 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 128 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 130 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WorkerIoTransition */

/* 132 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 134 */	NdrFcLong( 0x0 ),	/* 0 */
/* 138 */	NdrFcShort( 0x2 ),	/* 2 */
/* 140 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 142 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 144 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 146 */	NdrFcShort( 0x34 ),	/* 52 */
/* 148 */	NdrFcShort( 0x8 ),	/* 8 */
/* 150 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 152 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 154 */	NdrFcShort( 0x0 ),	/* 0 */
/* 156 */	NdrFcShort( 0x0 ),	/* 0 */
/* 158 */	NdrFcShort( 0x0 ),	/* 0 */
/* 160 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 162 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 164 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 166 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 168 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 170 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 172 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 174 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 176 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 178 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter action */

/* 180 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 182 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 184 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 186 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 188 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 190 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendIoDisconnected */

/* 192 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 194 */	NdrFcLong( 0x0 ),	/* 0 */
/* 198 */	NdrFcShort( 0x3 ),	/* 3 */
/* 200 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 202 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 204 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 206 */	NdrFcShort( 0x44 ),	/* 68 */
/* 208 */	NdrFcShort( 0x8 ),	/* 8 */
/* 210 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 212 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 214 */	NdrFcShort( 0x0 ),	/* 0 */
/* 216 */	NdrFcShort( 0x0 ),	/* 0 */
/* 218 */	NdrFcShort( 0x0 ),	/* 0 */
/* 220 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 222 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 224 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 226 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 228 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 230 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 232 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 234 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 236 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 238 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 240 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 242 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 244 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 246 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 248 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 250 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 252 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 254 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 256 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure SubmitNativeRequest */

/* 258 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 260 */	NdrFcLong( 0x0 ),	/* 0 */
/* 264 */	NdrFcShort( 0x4 ),	/* 4 */
/* 266 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 268 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 270 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 272 */	NdrFcShort( 0x3c ),	/* 60 */
/* 274 */	NdrFcShort( 0x24 ),	/* 36 */
/* 276 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0xb,		/* 11 */
/* 278 */	0xa,		/* 10 */
			0x45,		/* Ext Flags:  new corr desc, srv corr check, has range on conformance */
/* 280 */	NdrFcShort( 0x0 ),	/* 0 */
/* 282 */	NdrFcShort( 0x1 ),	/* 1 */
/* 284 */	NdrFcShort( 0x0 ),	/* 0 */
/* 286 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 288 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 290 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 292 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 294 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 296 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 298 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 300 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 302 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 304 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter operation */

/* 306 */	NdrFcShort( 0x88 ),	/* Flags:  in, by val, */
/* 308 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 310 */	NdrFcShort( 0x10 ),	/* 16 */

	/* Parameter frontend */

/* 312 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 314 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 316 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter bytes */

/* 318 */	NdrFcShort( 0x88 ),	/* Flags:  in, by val, */
/* 320 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 322 */	NdrFcShort( 0x20 ),	/* 32 */

	/* Parameter payload */

/* 324 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 326 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 328 */	NdrFcShort( 0x2a ),	/* Type Offset=42 */

	/* Parameter target */

/* 330 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 332 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 334 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter receipt */

/* 336 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 338 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 340 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter request */

/* 342 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 344 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 346 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 348 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 350 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 352 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FinishNativeRequest */

/* 354 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 356 */	NdrFcLong( 0x0 ),	/* 0 */
/* 360 */	NdrFcShort( 0x5 ),	/* 5 */
/* 362 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 364 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 366 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 368 */	NdrFcShort( 0x34 ),	/* 52 */
/* 370 */	NdrFcShort( 0x40 ),	/* 64 */
/* 372 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 374 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 376 */	NdrFcShort( 0x0 ),	/* 0 */
/* 378 */	NdrFcShort( 0x0 ),	/* 0 */
/* 380 */	NdrFcShort( 0x0 ),	/* 0 */
/* 382 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 384 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 386 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 388 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 390 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 392 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 394 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 396 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 398 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 400 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 402 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 404 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 406 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter exit_code */

/* 408 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 410 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 412 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter target_completed */

/* 414 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 416 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 418 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 420 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 422 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 424 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure StartVdmWorker */

/* 426 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 428 */	NdrFcLong( 0x0 ),	/* 0 */
/* 432 */	NdrFcShort( 0x6 ),	/* 6 */
/* 434 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 436 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 438 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 440 */	NdrFcShort( 0x3c ),	/* 60 */
/* 442 */	NdrFcShort( 0x24 ),	/* 36 */
/* 444 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0xb,		/* 11 */
/* 446 */	0xa,		/* 10 */
			0x45,		/* Ext Flags:  new corr desc, srv corr check, has range on conformance */
/* 448 */	NdrFcShort( 0x0 ),	/* 0 */
/* 450 */	NdrFcShort( 0x1 ),	/* 1 */
/* 452 */	NdrFcShort( 0x0 ),	/* 0 */
/* 454 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 456 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 458 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 460 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 462 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 464 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 466 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 468 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 470 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 472 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter environment_chars */

/* 474 */	NdrFcShort( 0x88 ),	/* Flags:  in, by val, */
/* 476 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 478 */	NdrFcShort( 0x4c ),	/* 76 */

	/* Parameter environment */

/* 480 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 482 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 484 */	NdrFcShort( 0x5a ),	/* Type Offset=90 */

	/* Parameter show_window */

/* 486 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 488 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 490 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend */

/* 492 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 494 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 496 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter worker */

/* 498 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 500 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 502 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter parent */

/* 504 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 506 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 508 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter parent_receipt */

/* 510 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 512 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 514 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 516 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 518 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 520 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure StartNativeWorker */

/* 522 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 524 */	NdrFcLong( 0x0 ),	/* 0 */
/* 528 */	NdrFcShort( 0x7 ),	/* 7 */
/* 530 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 532 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 534 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 536 */	NdrFcShort( 0x34 ),	/* 52 */
/* 538 */	NdrFcShort( 0x8 ),	/* 8 */
/* 540 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 542 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 544 */	NdrFcShort( 0x0 ),	/* 0 */
/* 546 */	NdrFcShort( 0x0 ),	/* 0 */
/* 548 */	NdrFcShort( 0x0 ),	/* 0 */
/* 550 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 552 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 554 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 556 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 558 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 560 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 562 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 564 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 566 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 568 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter native_type */

/* 570 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 572 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 574 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter worker */

/* 576 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 578 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 580 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Return value */

/* 582 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 584 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 586 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure StartFrontend */

/* 588 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 590 */	NdrFcLong( 0x0 ),	/* 0 */
/* 594 */	NdrFcShort( 0x8 ),	/* 8 */
/* 596 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 598 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 600 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 602 */	NdrFcShort( 0x44 ),	/* 68 */
/* 604 */	NdrFcShort( 0x8 ),	/* 8 */
/* 606 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x9,		/* 9 */
/* 608 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 610 */	NdrFcShort( 0x0 ),	/* 0 */
/* 612 */	NdrFcShort( 0x0 ),	/* 0 */
/* 614 */	NdrFcShort( 0x0 ),	/* 0 */
/* 616 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 618 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 620 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 622 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 624 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 626 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 628 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 630 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 632 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 634 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter console_window */

/* 636 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 638 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 640 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter borrowed */

/* 642 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 644 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 646 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter root */

/* 648 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 650 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 652 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter capability */

/* 654 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 656 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 658 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter restored */

/* 660 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 662 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 664 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 666 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 668 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 670 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendStartupResult */

/* 672 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 674 */	NdrFcLong( 0x0 ),	/* 0 */
/* 678 */	NdrFcShort( 0x9 ),	/* 9 */
/* 680 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 682 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 684 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 686 */	NdrFcShort( 0x34 ),	/* 52 */
/* 688 */	NdrFcShort( 0x8 ),	/* 8 */
/* 690 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 692 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 694 */	NdrFcShort( 0x0 ),	/* 0 */
/* 696 */	NdrFcShort( 0x0 ),	/* 0 */
/* 698 */	NdrFcShort( 0x0 ),	/* 0 */
/* 700 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 702 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 704 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 706 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 708 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 710 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 712 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 714 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 716 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 718 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter capability */

/* 720 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 722 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 724 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter status */

/* 726 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 728 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 730 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 732 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 734 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 736 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendConsoleRestored */

/* 738 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 740 */	NdrFcLong( 0x0 ),	/* 0 */
/* 744 */	NdrFcShort( 0xa ),	/* 10 */
/* 746 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 748 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 750 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 752 */	NdrFcShort( 0x44 ),	/* 68 */
/* 754 */	NdrFcShort( 0x8 ),	/* 8 */
/* 756 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 758 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 760 */	NdrFcShort( 0x0 ),	/* 0 */
/* 762 */	NdrFcShort( 0x0 ),	/* 0 */
/* 764 */	NdrFcShort( 0x0 ),	/* 0 */
/* 766 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 768 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 770 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 772 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 774 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 776 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 778 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 780 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 782 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 784 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 786 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 788 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 790 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 792 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 794 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 796 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 798 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 800 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 802 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendCloseQuiesced */

/* 804 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 806 */	NdrFcLong( 0x0 ),	/* 0 */
/* 810 */	NdrFcShort( 0xb ),	/* 11 */
/* 812 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 814 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 816 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 818 */	NdrFcShort( 0x44 ),	/* 68 */
/* 820 */	NdrFcShort( 0x8 ),	/* 8 */
/* 822 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 824 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 826 */	NdrFcShort( 0x0 ),	/* 0 */
/* 828 */	NdrFcShort( 0x0 ),	/* 0 */
/* 830 */	NdrFcShort( 0x0 ),	/* 0 */
/* 832 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 834 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 836 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 838 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 840 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 842 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 844 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 846 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 848 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 850 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 852 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 854 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 856 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 858 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 860 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 862 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 864 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 866 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 868 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WaitFrontendConsoleRestored */

/* 870 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 872 */	NdrFcLong( 0x0 ),	/* 0 */
/* 876 */	NdrFcShort( 0xc ),	/* 12 */
/* 878 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 880 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 882 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 884 */	NdrFcShort( 0x2c ),	/* 44 */
/* 886 */	NdrFcShort( 0x8 ),	/* 8 */
/* 888 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x4,		/* 4 */
/* 890 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 892 */	NdrFcShort( 0x0 ),	/* 0 */
/* 894 */	NdrFcShort( 0x0 ),	/* 0 */
/* 896 */	NdrFcShort( 0x0 ),	/* 0 */
/* 898 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 900 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 902 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 904 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 906 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 908 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 910 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 912 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 914 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 916 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 918 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 920 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 922 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WorkerIoReleaseEvent */

/* 924 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 926 */	NdrFcLong( 0x0 ),	/* 0 */
/* 930 */	NdrFcShort( 0xd ),	/* 13 */
/* 932 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 934 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 936 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 938 */	NdrFcShort( 0x2c ),	/* 44 */
/* 940 */	NdrFcShort( 0x8 ),	/* 8 */
/* 942 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 944 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 946 */	NdrFcShort( 0x0 ),	/* 0 */
/* 948 */	NdrFcShort( 0x0 ),	/* 0 */
/* 950 */	NdrFcShort( 0x0 ),	/* 0 */
/* 952 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 954 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 956 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 958 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 960 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 962 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 964 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 966 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 968 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 970 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter release */

/* 972 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 974 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 976 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 978 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 980 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 982 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure CompleteWorkerChannel */

/* 984 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 986 */	NdrFcLong( 0x0 ),	/* 0 */
/* 990 */	NdrFcShort( 0xe ),	/* 14 */
/* 992 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 994 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 996 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 998 */	NdrFcShort( 0x4c ),	/* 76 */
/* 1000 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1002 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 1004 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1006 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1008 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1010 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1012 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1014 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1016 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1018 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1020 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1022 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1024 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1026 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1028 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1030 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 1032 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1034 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1036 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter exit_code */

/* 1038 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1040 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1042 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter io_error */

/* 1044 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1046 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1048 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter io_flags */

/* 1050 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1052 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1054 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1056 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1058 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1060 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure GetNextNativeCommand */

/* 1062 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1064 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1068 */	NdrFcShort( 0xf ),	/* 15 */
/* 1070 */	NdrFcShort( 0x68 ),	/* X64 Stack size/offset = 104 */
/* 1072 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1074 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1076 */	NdrFcShort( 0x34 ),	/* 52 */
/* 1078 */	NdrFcShort( 0x5c ),	/* 92 */
/* 1080 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0xc,		/* 12 */
/* 1082 */	0xa,		/* 10 */
			0x43,		/* Ext Flags:  new corr desc, clt corr check, has range on conformance */
/* 1084 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1086 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1088 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1090 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1092 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1094 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1096 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1098 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1100 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1102 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1104 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1106 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1108 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter capacity */

/* 1110 */	NdrFcShort( 0x88 ),	/* Flags:  in, by val, */
/* 1112 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1114 */	NdrFcShort( 0x70 ),	/* 112 */

	/* Parameter payload */

/* 1116 */	NdrFcShort( 0x113 ),	/* Flags:  must size, must free, out, simple ref, */
/* 1118 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1120 */	NdrFcShort( 0x7e ),	/* Type Offset=126 */

	/* Parameter bytes */

/* 1122 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1124 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1126 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter caller_process */

/* 1128 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1130 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1132 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter execution */

/* 1134 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1136 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1138 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter frontend */

/* 1140 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1142 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 1144 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter request */

/* 1146 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1148 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 1150 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter caller_generation */

/* 1152 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1154 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 1156 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1158 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1160 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 1162 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure NativeStartupResult */

/* 1164 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1166 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1170 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1172 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 1174 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1176 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1178 */	NdrFcShort( 0x44 ),	/* 68 */
/* 1180 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1182 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x9,		/* 9 */
/* 1184 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1186 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1188 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1190 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1192 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1194 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1196 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1198 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1200 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1202 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1204 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1206 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1208 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1210 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter caller_generation */

/* 1212 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1214 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1216 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 1218 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1220 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1222 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter status */

/* 1224 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1226 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1228 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter target */

/* 1230 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1232 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1234 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter receipt */

/* 1236 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1238 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1240 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 1242 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1244 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 1246 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RegisterNativeBackend */

/* 1248 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1250 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1254 */	NdrFcShort( 0x11 ),	/* 17 */
/* 1256 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1258 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1260 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1262 */	NdrFcShort( 0x2c ),	/* 44 */
/* 1264 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1266 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 1268 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1270 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1272 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1274 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1276 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1278 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1280 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1282 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1284 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1286 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1288 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1290 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1292 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1294 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend */

/* 1296 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1298 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1300 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 1302 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1304 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1306 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure BindNativeTarget */

/* 1308 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1310 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1314 */	NdrFcShort( 0x12 ),	/* 18 */
/* 1316 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1318 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1320 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1322 */	NdrFcShort( 0x34 ),	/* 52 */
/* 1324 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1326 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 1328 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1330 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1332 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1334 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1336 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1338 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1340 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1342 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1344 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1346 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1348 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1350 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1352 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1354 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 1356 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1358 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1360 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter target */

/* 1362 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1364 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1366 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter receipt */

/* 1368 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1370 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1372 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 1374 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1376 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1378 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure AcquireConsoleContext */

/* 1380 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1386 */	NdrFcShort( 0x13 ),	/* 19 */
/* 1388 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1390 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1392 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1394 */	NdrFcShort( 0x2c ),	/* 44 */
/* 1396 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1398 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 1400 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1402 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1404 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1406 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1408 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1410 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1412 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1414 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1416 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1418 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1420 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1422 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1424 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1426 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend */

/* 1428 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1430 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1432 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter capability */

/* 1434 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1436 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1438 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 1440 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1442 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1444 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure BindConsoleContext */

/* 1446 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1448 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1452 */	NdrFcShort( 0x14 ),	/* 20 */
/* 1454 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1456 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1458 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1460 */	NdrFcShort( 0x2c ),	/* 44 */
/* 1462 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1464 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 1466 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1468 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1470 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1472 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1474 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1476 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1478 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1480 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1482 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1484 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1486 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1488 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1490 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1492 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter capability */

/* 1494 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1496 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1498 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 1500 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1502 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1504 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WorkerFrontendCapability */

/* 1506 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1508 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1512 */	NdrFcShort( 0x15 ),	/* 21 */
/* 1514 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1516 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1518 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1520 */	NdrFcShort( 0x2c ),	/* 44 */
/* 1522 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1524 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 1526 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1528 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1530 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1532 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1534 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1536 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1538 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1540 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1542 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1544 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1546 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1548 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1550 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1552 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter capability */

/* 1554 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1556 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1558 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 1560 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1562 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1564 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RegisterFrontendRoot */

/* 1566 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1568 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1572 */	NdrFcShort( 0x16 ),	/* 22 */
/* 1574 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1576 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1578 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1580 */	NdrFcShort( 0x2c ),	/* 44 */
/* 1582 */	NdrFcShort( 0x48 ),	/* 72 */
/* 1584 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 1586 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1588 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1590 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1592 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1594 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1596 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1598 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1600 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1602 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1604 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1606 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1608 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1610 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1612 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter capability */

/* 1614 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1616 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1618 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter frontend_instance */

/* 1620 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1622 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1624 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 1626 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1628 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1630 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1632 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1634 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1636 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RegisterFrontendLease */

/* 1638 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1640 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1644 */	NdrFcShort( 0x17 ),	/* 23 */
/* 1646 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 1648 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1650 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1652 */	NdrFcShort( 0x64 ),	/* 100 */
/* 1654 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1656 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0xb,		/* 11 */
/* 1658 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1660 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1662 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1664 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1666 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1668 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1670 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1672 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1674 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1676 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1678 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1680 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1682 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1684 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 1686 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1688 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1690 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 1692 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1694 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1696 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter console_window */

/* 1698 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1700 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1702 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter creator_pid */

/* 1704 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1706 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1708 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter borrowed */

/* 1710 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1712 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1714 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter retire */

/* 1716 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1718 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 1720 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter restored */

/* 1722 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1724 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 1726 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 1728 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1730 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 1732 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendJoinCandidate */

/* 1734 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1736 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1740 */	NdrFcShort( 0x18 ),	/* 24 */
/* 1742 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 1744 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1746 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1748 */	NdrFcShort( 0x44 ),	/* 68 */
/* 1750 */	NdrFcShort( 0x40 ),	/* 64 */
/* 1752 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 1754 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1756 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1758 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1760 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1762 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1764 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1766 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1768 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1770 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1772 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1774 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1776 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1778 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1780 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 1782 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1784 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1786 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 1788 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1790 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1792 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter nonce */

/* 1794 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1796 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1798 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter candidate_pid */

/* 1800 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1802 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1804 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1806 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1808 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1810 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendJoinDecision */

/* 1812 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1814 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1818 */	NdrFcShort( 0x19 ),	/* 25 */
/* 1820 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 1822 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1824 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1826 */	NdrFcShort( 0x54 ),	/* 84 */
/* 1828 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1830 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 1832 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1834 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1836 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1838 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1840 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1842 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1844 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1846 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1848 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1850 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1852 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1854 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1856 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1858 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 1860 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1862 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1864 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 1866 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1868 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1870 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter nonce */

/* 1872 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1874 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1876 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter same_console */

/* 1878 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1880 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1882 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1884 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1886 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1888 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendLeaseReady */

/* 1890 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1892 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1896 */	NdrFcShort( 0x1a ),	/* 26 */
/* 1898 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 1900 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1902 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1904 */	NdrFcShort( 0x44 ),	/* 68 */
/* 1906 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1908 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 1910 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1912 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1914 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1916 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1918 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1920 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1922 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1924 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1926 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1928 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1930 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1932 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1934 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 1936 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 1938 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1940 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 1942 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 1944 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1946 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 1948 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1950 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1952 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 1954 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RetainFrontendRoot */

/* 1956 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 1958 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1962 */	NdrFcShort( 0x1b ),	/* 27 */
/* 1964 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 1966 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 1968 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 1970 */	NdrFcShort( 0x2c ),	/* 44 */
/* 1972 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1974 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 1976 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 1978 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1980 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1982 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1984 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 1986 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 1988 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 1990 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 1992 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1994 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 1996 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 1998 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2000 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2002 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter capability */

/* 2004 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2006 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2008 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter root */

/* 2010 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2012 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2014 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter root_generation */

/* 2016 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2018 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2020 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2022 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2024 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2026 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RequestFrontend */

/* 2028 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2030 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2034 */	NdrFcShort( 0x1c ),	/* 28 */
/* 2036 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2038 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2040 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2042 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2044 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2046 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 2048 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2050 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2052 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2054 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2056 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2058 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2060 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2062 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2064 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2066 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2068 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2070 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2072 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2074 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter capability */

/* 2076 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2078 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2080 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 2082 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2084 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2086 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendRequest */

/* 2088 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2090 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2094 */	NdrFcShort( 0x1d ),	/* 29 */
/* 2096 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 2098 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2100 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2102 */	NdrFcShort( 0x44 ),	/* 68 */
/* 2104 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2106 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 2108 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2110 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2112 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2114 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2116 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2118 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2120 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2122 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2124 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2126 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2128 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2130 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2132 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2134 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 2136 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2138 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2140 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 2142 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2144 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2146 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 2148 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2150 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2152 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter worker */

/* 2154 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2156 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2158 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Return value */

/* 2160 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2162 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 2164 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure AttachFrontendRequest */

/* 2166 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2168 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2172 */	NdrFcShort( 0x1e ),	/* 30 */
/* 2174 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 2176 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2178 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2180 */	NdrFcShort( 0x4c ),	/* 76 */
/* 2182 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2184 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x9,		/* 9 */
/* 2186 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2188 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2190 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2192 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2194 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2196 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2198 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2200 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2202 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2204 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2206 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2208 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2210 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2212 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 2214 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2216 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2218 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 2220 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2222 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2224 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 2226 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2228 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2230 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter channel */

/* 2232 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2234 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2236 */	NdrFcShort( 0xa8 ),	/* Type Offset=168 */

	/* Parameter ready */

/* 2238 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2240 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 2242 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 2244 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2246 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 2248 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure TakeFrontend */

/* 2250 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2252 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2256 */	NdrFcShort( 0x1f ),	/* 31 */
/* 2258 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 2260 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2262 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2264 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2266 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2268 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 2270 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2272 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2274 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2276 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2278 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2280 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2282 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2284 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2286 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2288 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2290 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2292 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2294 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2296 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter channel */

/* 2298 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2300 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2302 */	NdrFcShort( 0xa8 ),	/* Type Offset=168 */

	/* Parameter frontend */

/* 2304 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2306 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2308 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter frontend_generation */

/* 2310 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2312 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2314 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter ready */

/* 2316 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2318 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2320 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 2322 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2324 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 2326 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WaitFrontend */

/* 2328 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2330 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2334 */	NdrFcShort( 0x20 ),	/* 32 */
/* 2336 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 2338 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2340 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2342 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2344 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2346 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 2348 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2350 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2352 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2354 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2356 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2358 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2360 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2362 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2364 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2366 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2368 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2370 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2372 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2374 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter channel */

/* 2376 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2378 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2380 */	NdrFcShort( 0xa8 ),	/* Type Offset=168 */

	/* Parameter frontend */

/* 2382 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2384 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2386 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter frontend_generation */

/* 2388 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2390 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2392 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter ready */

/* 2394 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2396 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2398 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 2400 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2402 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 2404 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure Connect */

/* 2406 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2408 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2412 */	NdrFcShort( 0x21 ),	/* 33 */
/* 2414 */	NdrFcShort( 0x68 ),	/* X64 Stack size/offset = 104 */
/* 2416 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2418 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2420 */	NdrFcShort( 0x38 ),	/* 56 */
/* 2422 */	NdrFcShort( 0xa8 ),	/* 168 */
/* 2424 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0xc,		/* 12 */
/* 2426 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2428 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2430 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2432 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2434 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter process */

/* 2436 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2438 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2440 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter protocol */

/* 2442 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2444 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2446 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter application_version */

/* 2448 */	NdrFcShort( 0xa ),	/* Flags:  must free, in, */
/* 2450 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2452 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Parameter server_protocol */

/* 2454 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2456 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2458 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter server_version */

/* 2460 */	NdrFcShort( 0x12 ),	/* Flags:  must free, out, */
/* 2462 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2464 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Parameter connection */

/* 2466 */	NdrFcShort( 0x110 ),	/* Flags:  out, simple ref, */
/* 2468 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2470 */	NdrFcShort( 0xbc ),	/* Type Offset=188 */

	/* Parameter generation */

/* 2472 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2474 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2476 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter server */

/* 2478 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2480 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 2482 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter shutdown */

/* 2484 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2486 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 2488 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter console_close */

/* 2490 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2492 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 2494 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter wow_task_close */

/* 2496 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2498 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 2500 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 2502 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2504 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 2506 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure BindWowTask */

/* 2508 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2510 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2514 */	NdrFcShort( 0x22 ),	/* 34 */
/* 2516 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 2518 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2520 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2522 */	NdrFcShort( 0x3a ),	/* 58 */
/* 2524 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2526 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 2528 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2530 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2532 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2534 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2536 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2538 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2540 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2542 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2544 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2546 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2548 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2550 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2552 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2554 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter task */

/* 2556 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2558 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2560 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter htask */

/* 2562 */	NdrFcShort( 0x88 ),	/* Flags:  in, by val, */
/* 2564 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2566 */	NdrFcShort( 0xc0 ),	/* 192 */

	/* Parameter identity */

/* 2568 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2570 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2572 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Return value */

/* 2574 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2576 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2578 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RetireWowTask */

/* 2580 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2582 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2586 */	NdrFcShort( 0x23 ),	/* 35 */
/* 2588 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2590 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2592 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2594 */	NdrFcShort( 0x3c ),	/* 60 */
/* 2596 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2598 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 2600 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2602 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2604 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2606 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2608 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2610 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2612 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2614 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2616 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2618 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2620 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2622 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2624 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2626 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter identity */

/* 2628 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2630 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2632 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Return value */

/* 2634 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2636 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2638 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure TakeWowTaskClose */

/* 2640 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2642 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2646 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2648 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2650 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2652 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2654 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2656 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2658 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 2660 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2662 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2664 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2666 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2668 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2670 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2672 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2674 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2676 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2678 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2680 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2682 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2684 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2686 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter identity */

/* 2688 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2690 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2692 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Return value */

/* 2694 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2696 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2698 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FailWowTaskClose */

/* 2700 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2702 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2706 */	NdrFcShort( 0x25 ),	/* 37 */
/* 2708 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2710 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2712 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2714 */	NdrFcShort( 0x3c ),	/* 60 */
/* 2716 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2718 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 2720 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2722 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2724 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2726 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2728 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2730 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2732 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2734 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2736 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2738 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2740 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2742 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2744 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2746 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter identity */

/* 2748 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2750 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2752 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Return value */

/* 2754 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2756 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2758 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure ReportConsoleMembers */

/* 2760 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2762 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2766 */	NdrFcShort( 0x26 ),	/* 38 */
/* 2768 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2770 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2772 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2774 */	NdrFcShort( 0x34 ),	/* 52 */
/* 2776 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2778 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 2780 */	0xa,		/* 10 */
			0x45,		/* Ext Flags:  new corr desc, srv corr check, has range on conformance */
/* 2782 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2784 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2786 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2788 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2790 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2792 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2794 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2796 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2798 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2800 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2802 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2804 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2806 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter member_count */

/* 2808 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2810 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2812 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter member_ids */

/* 2814 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 2816 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2818 */	NdrFcShort( 0xca ),	/* Type Offset=202 */

	/* Return value */

/* 2820 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2822 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2824 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure First */

/* 2826 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2828 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2832 */	NdrFcShort( 0x27 ),	/* 39 */
/* 2834 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2836 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2838 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2840 */	NdrFcShort( 0x2c ),	/* 44 */
/* 2842 */	NdrFcShort( 0x24 ),	/* 36 */
/* 2844 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 2846 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 2848 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2850 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2852 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2854 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2856 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2858 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2860 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2862 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2864 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2866 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2868 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2870 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2872 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter first */

/* 2874 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2876 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2878 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2880 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2882 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2884 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure Check */

/* 2886 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2888 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2892 */	NdrFcShort( 0x28 ),	/* 40 */
/* 2894 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 2896 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2898 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2900 */	NdrFcShort( 0x34 ),	/* 52 */
/* 2902 */	NdrFcShort( 0x94 ),	/* 148 */
/* 2904 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0xb,		/* 11 */
/* 2906 */	0xa,		/* 10 */
			0x47,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, has range on conformance */
/* 2908 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2910 */	NdrFcShort( 0x1 ),	/* 1 */
/* 2912 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2914 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 2916 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 2918 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 2920 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 2922 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2924 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 2926 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 2928 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2930 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 2932 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request_bytes */

/* 2934 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 2936 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 2938 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 2940 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 2942 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 2944 */	NdrFcShort( 0xe4 ),	/* Type Offset=228 */

	/* Parameter parent_event_count */

/* 2946 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2948 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 2950 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter parent_events */

/* 2952 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 2954 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 2956 */	NdrFcShort( 0xfa ),	/* Type Offset=250 */

	/* Parameter parent_receipt */

/* 2958 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2960 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 2962 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter reply_bytes */

/* 2964 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 2966 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 2968 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter reply */

/* 2970 */	NdrFcShort( 0x12 ),	/* Flags:  must free, out, */
/* 2972 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 2974 */	NdrFcShort( 0x12c ),	/* Type Offset=300 */

	/* Return value */

/* 2976 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2978 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 2980 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure Get */

/* 2982 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 2984 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2988 */	NdrFcShort( 0x29 ),	/* 41 */
/* 2990 */	NdrFcShort( 0x88 ),	/* X64 Stack size/offset = 136 */
/* 2992 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 2994 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 2996 */	NdrFcShort( 0x34 ),	/* 52 */
/* 2998 */	NdrFcShort( 0xb0 ),	/* 176 */
/* 3000 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x10,		/* 16 */
/* 3002 */	0xa,		/* 10 */
			0x47,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, has range on conformance */
/* 3004 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3006 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3008 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3010 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3012 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3014 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3016 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3018 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3020 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3022 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3024 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3026 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3028 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request_bytes */

/* 3030 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3032 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3034 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 3036 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 3038 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3040 */	NdrFcShort( 0xe4 ),	/* Type Offset=228 */

	/* Parameter wait_event_count */

/* 3042 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3044 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3046 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter wait_events */

/* 3048 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 3050 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3052 */	NdrFcShort( 0xfa ),	/* Type Offset=250 */

	/* Parameter pipe_stream_mask */

/* 3054 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3056 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 3058 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pipe_stream_count */

/* 3060 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3062 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 3064 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pipe_streams */

/* 3066 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 3068 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 3070 */	NdrFcShort( 0x132 ),	/* Type Offset=306 */

	/* Parameter file_stream_mask */

/* 3072 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3074 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 3076 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter file_stream_count */

/* 3078 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3080 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 3082 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter file_streams */

/* 3084 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 3086 */	NdrFcShort( 0x68 ),	/* X64 Stack size/offset = 104 */
/* 3088 */	NdrFcShort( 0x164 ),	/* Type Offset=356 */

	/* Parameter reply_bytes */

/* 3090 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3092 */	NdrFcShort( 0x70 ),	/* X64 Stack size/offset = 112 */
/* 3094 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter reply */

/* 3096 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 3098 */	NdrFcShort( 0x78 ),	/* X64 Stack size/offset = 120 */
/* 3100 */	NdrFcShort( 0x19c ),	/* Type Offset=412 */

	/* Return value */

/* 3102 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3104 */	NdrFcShort( 0x80 ),	/* X64 Stack size/offset = 128 */
/* 3106 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure Exit */

/* 3108 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3110 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3114 */	NdrFcShort( 0x2a ),	/* 42 */
/* 3116 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 3118 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3120 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3122 */	NdrFcShort( 0x3c ),	/* 60 */
/* 3124 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3126 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 3128 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3130 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3132 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3136 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3138 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3140 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3142 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3144 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3146 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3148 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3150 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3152 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3154 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter is_wow */

/* 3156 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3158 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3160 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter wow_task */

/* 3162 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3164 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3166 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter close_worker_wait */

/* 3168 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3170 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3172 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3174 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3176 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3178 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure Update */

/* 3180 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3182 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3186 */	NdrFcShort( 0x2b ),	/* 43 */
/* 3188 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 3190 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3192 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3194 */	NdrFcShort( 0x34 ),	/* 52 */
/* 3196 */	NdrFcShort( 0x8c ),	/* 140 */
/* 3198 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0xb,		/* 11 */
/* 3200 */	0xa,		/* 10 */
			0x47,		/* Ext Flags:  new corr desc, clt corr check, srv corr check, has range on conformance */
/* 3202 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3204 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3206 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3208 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3210 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3212 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3214 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3216 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3218 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3220 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3222 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3224 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3226 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request_bytes */

/* 3228 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3230 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3232 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter request */

/* 3234 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 3236 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3238 */	NdrFcShort( 0xe4 ),	/* Type Offset=228 */

	/* Parameter parent_event_count */

/* 3240 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3242 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3244 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter parent_events */

/* 3246 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 3248 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3250 */	NdrFcShort( 0xfa ),	/* Type Offset=250 */

	/* Parameter parent_receipt */

/* 3252 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3254 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 3256 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter reply_bytes */

/* 3258 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3260 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 3262 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter reply */

/* 3264 */	NdrFcShort( 0x12 ),	/* Flags:  must free, out, */
/* 3266 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 3268 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Return value */

/* 3270 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3272 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 3274 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure ExitCode */

/* 3276 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3278 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3282 */	NdrFcShort( 0x2c ),	/* 44 */
/* 3284 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3286 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3288 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3290 */	NdrFcShort( 0x34 ),	/* 52 */
/* 3292 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3294 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 3296 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3298 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3300 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3302 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3304 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3306 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3308 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3310 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3312 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3314 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3316 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3318 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3320 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3322 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter parent_receipt */

/* 3324 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3326 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3328 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter exit_code */

/* 3330 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3332 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3334 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3336 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3338 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3340 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure Reenter */

/* 3342 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3344 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3348 */	NdrFcShort( 0x2d ),	/* 45 */
/* 3350 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3352 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3354 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3356 */	NdrFcShort( 0x34 ),	/* 52 */
/* 3358 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3360 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 3362 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3364 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3366 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3368 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3370 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3372 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3374 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3376 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3378 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3380 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3382 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3384 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3386 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3388 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter increment */

/* 3390 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3392 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3394 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3396 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3398 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3400 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure Disconnect */

/* 3402 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3404 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3408 */	NdrFcShort( 0x2e ),	/* 46 */
/* 3410 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3412 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3414 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3416 */	NdrFcShort( 0x40 ),	/* 64 */
/* 3418 */	NdrFcShort( 0x40 ),	/* 64 */
/* 3420 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x4,		/* 4 */
/* 3422 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3424 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3426 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3428 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3430 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter process */

/* 3432 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3434 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3436 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3438 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3440 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3442 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter connection */

/* 3444 */	NdrFcShort( 0x118 ),	/* Flags:  in, out, simple ref, */
/* 3446 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3448 */	NdrFcShort( 0x1be ),	/* Type Offset=446 */

	/* Return value */

/* 3450 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3452 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3454 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure AttachFile */

/* 3456 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3458 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3462 */	NdrFcShort( 0x2f ),	/* 47 */
/* 3464 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 3466 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3468 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3470 */	NdrFcShort( 0x34 ),	/* 52 */
/* 3472 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3474 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 3476 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3478 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3480 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3482 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3484 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3486 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3488 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3490 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3492 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3494 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3496 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3498 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3500 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3502 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter role */

/* 3504 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3506 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3508 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter stream */

/* 3510 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3512 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3514 */	NdrFcShort( 0x16c ),	/* Type Offset=364 */

	/* Parameter receipt */

/* 3516 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3518 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3520 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3522 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3524 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3526 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure AttachPipe */

/* 3528 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3530 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3534 */	NdrFcShort( 0x30 ),	/* 48 */
/* 3536 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 3538 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3540 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3542 */	NdrFcShort( 0x34 ),	/* 52 */
/* 3544 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3546 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 3548 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3550 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3552 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3554 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3556 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3558 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3560 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3562 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3564 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3566 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3568 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3570 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3572 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3574 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter role */

/* 3576 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3578 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3580 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter stream */

/* 3582 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3584 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3586 */	NdrFcShort( 0xa8 ),	/* Type Offset=168 */

	/* Parameter receipt */

/* 3588 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3590 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3592 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3594 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3596 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3598 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RevokeStream */

/* 3600 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3602 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3606 */	NdrFcShort( 0x31 ),	/* 49 */
/* 3608 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3610 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3612 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3614 */	NdrFcShort( 0x34 ),	/* 52 */
/* 3616 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3618 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 3620 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3622 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3624 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3626 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3628 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3630 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3632 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3634 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3636 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3638 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3640 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3642 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3644 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3646 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter receipt */

/* 3648 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3650 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3652 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 3654 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3656 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3658 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure TaskSnapshot */

/* 3660 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3662 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3666 */	NdrFcShort( 0x32 ),	/* 50 */
/* 3668 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3670 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3672 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3674 */	NdrFcShort( 0x38 ),	/* 56 */
/* 3676 */	NdrFcShort( 0x24 ),	/* 36 */
/* 3678 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 3680 */	0xa,		/* 10 */
			0x43,		/* Ext Flags:  new corr desc, clt corr check, has range on conformance */
/* 3682 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3684 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3686 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3688 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter process */

/* 3690 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3692 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3694 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter protocol */

/* 3696 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3698 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3700 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter application_version */

/* 3702 */	NdrFcShort( 0xa ),	/* Flags:  must free, in, */
/* 3704 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3706 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Parameter count */

/* 3708 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3710 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3712 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter entries */

/* 3714 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 3716 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3718 */	NdrFcShort( 0x1c2 ),	/* Type Offset=450 */

	/* Return value */

/* 3720 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3722 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3724 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure CloseManagementNode */

/* 3726 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3728 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3732 */	NdrFcShort( 0x33 ),	/* 51 */
/* 3734 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3736 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3738 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3740 */	NdrFcShort( 0x74 ),	/* 116 */
/* 3742 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3744 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 3746 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3748 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3750 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3752 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3754 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter process */

/* 3756 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3758 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3760 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter protocol */

/* 3762 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3764 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3766 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter application_version */

/* 3768 */	NdrFcShort( 0xa ),	/* Flags:  must free, in, */
/* 3770 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3772 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Parameter key */

/* 3774 */	NdrFcShort( 0x10a ),	/* Flags:  must free, in, simple ref, */
/* 3776 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3778 */	NdrFcShort( 0x1ca ),	/* Type Offset=458 */

	/* Return value */

/* 3780 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3782 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3784 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WorkerTaskTrace */

/* 3786 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3788 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3792 */	NdrFcShort( 0x34 ),	/* 52 */
/* 3794 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 3796 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3798 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3800 */	NdrFcShort( 0x74 ),	/* 116 */
/* 3802 */	NdrFcShort( 0x40 ),	/* 64 */
/* 3804 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 3806 */	0xa,		/* 10 */
			0x43,		/* Ext Flags:  new corr desc, clt corr check, has range on conformance */
/* 3808 */	NdrFcShort( 0x1 ),	/* 1 */
/* 3810 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3812 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3814 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter process */

/* 3816 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3818 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3820 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter protocol */

/* 3822 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3824 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3826 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter application_version */

/* 3828 */	NdrFcShort( 0xa ),	/* Flags:  must free, in, */
/* 3830 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3832 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Parameter key */

/* 3834 */	NdrFcShort( 0x10a ),	/* Flags:  must free, in, simple ref, */
/* 3836 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3838 */	NdrFcShort( 0x1ca ),	/* Type Offset=458 */

	/* Parameter coverage */

/* 3840 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3842 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3844 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter count */

/* 3846 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3848 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3850 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter entries */

/* 3852 */	NdrFcShort( 0x2013 ),	/* Flags:  must size, must free, out, srv alloc size=8 */
/* 3854 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3856 */	NdrFcShort( 0x224 ),	/* Type Offset=548 */

	/* Return value */

/* 3858 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3860 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 3862 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure ObserveNativeCreationAsync */

/* 3864 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3866 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3870 */	NdrFcShort( 0x35 ),	/* 53 */
/* 3872 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 3874 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3876 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3878 */	NdrFcShort( 0x40 ),	/* 64 */
/* 3880 */	NdrFcShort( 0x2c ),	/* 44 */
/* 3882 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 3884 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3886 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3888 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3890 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3892 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter reporter */

/* 3894 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3896 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3898 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter protocol */

/* 3900 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3902 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3904 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter application_version */

/* 3906 */	NdrFcShort( 0xa ),	/* Flags:  must free, in, */
/* 3908 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3910 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Parameter child */

/* 3912 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3914 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3916 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter creation_flags */

/* 3918 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3920 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3922 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter node */

/* 3924 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 3926 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 3928 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Return value */

/* 3930 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 3932 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 3934 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure ObserveDosEventAsync */

/* 3936 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 3938 */	NdrFcLong( 0x0 ),	/* 0 */
/* 3942 */	NdrFcShort( 0x36 ),	/* 54 */
/* 3944 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 3946 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 3948 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 3950 */	NdrFcShort( 0x2d8 ),	/* 728 */
/* 3952 */	NdrFcShort( 0x8 ),	/* 8 */
/* 3954 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 3956 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 3958 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3960 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3962 */	NdrFcShort( 0x0 ),	/* 0 */
/* 3964 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 3966 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 3968 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 3970 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 3972 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 3974 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 3976 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 3978 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3980 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 3982 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter protocol */

/* 3984 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 3986 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 3988 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter application_version */

/* 3990 */	NdrFcShort( 0xa ),	/* Flags:  must free, in, */
/* 3992 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 3994 */	NdrFcShort( 0xb2 ),	/* Type Offset=178 */

	/* Parameter fact */

/* 3996 */	NdrFcShort( 0x10a ),	/* Flags:  must free, in, simple ref, */
/* 3998 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4000 */	NdrFcShort( 0x272 ),	/* Type Offset=626 */

	/* Parameter gap */

/* 4002 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4004 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 4006 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4008 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4010 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 4012 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RegisterWowExec */

/* 4014 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4016 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4020 */	NdrFcShort( 0x37 ),	/* 55 */
/* 4022 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4024 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4026 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4028 */	NdrFcShort( 0x34 ),	/* 52 */
/* 4030 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4032 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 4034 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4036 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4038 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4040 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4042 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4044 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4046 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4048 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4050 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4052 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4054 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4056 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4058 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4060 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter window */

/* 4062 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4064 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4066 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4068 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4070 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4072 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RetireWorkerlessFrontend */

/* 4074 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4076 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4080 */	NdrFcShort( 0x38 ),	/* 56 */
/* 4082 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 4084 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4086 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4088 */	NdrFcShort( 0x44 ),	/* 68 */
/* 4090 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4092 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 4094 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4096 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4098 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4100 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4102 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4104 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4106 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4108 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4110 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4112 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4114 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4116 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4118 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4120 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 4122 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4124 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4126 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 4128 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4130 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4132 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter retired */

/* 4134 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4136 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4138 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4140 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4142 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 4144 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure FrontendStateChanged */

/* 4146 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4148 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4152 */	NdrFcShort( 0x39 ),	/* 57 */
/* 4154 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 4156 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4158 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4160 */	NdrFcShort( 0x44 ),	/* 68 */
/* 4162 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4164 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 4166 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4168 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4172 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4174 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4176 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4178 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4180 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4182 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4184 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4186 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4188 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4190 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4192 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 4194 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4196 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4198 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 4200 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4202 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4204 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter state_changed */

/* 4206 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4208 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4210 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 4212 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4214 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 4216 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WowStarted */

/* 4218 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4220 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4224 */	NdrFcShort( 0x3a ),	/* 58 */
/* 4226 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4228 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4230 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4232 */	NdrFcShort( 0x34 ),	/* 52 */
/* 4234 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4236 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x5,		/* 5 */
/* 4238 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4240 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4242 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4244 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4246 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4248 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4250 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4252 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4254 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4256 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4258 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4260 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4262 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4264 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter task */

/* 4266 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4268 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4270 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4272 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4274 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4276 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure WowStartup */

/* 4278 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4280 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4284 */	NdrFcShort( 0x3b ),	/* 59 */
/* 4286 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 4288 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4290 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4292 */	NdrFcShort( 0x34 ),	/* 52 */
/* 4294 */	NdrFcShort( 0x24 ),	/* 36 */
/* 4296 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0x7,		/* 7 */
/* 4298 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4300 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4302 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4304 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4306 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4308 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4310 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4312 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4314 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4316 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4318 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4320 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4322 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4324 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter parent_receipt */

/* 4326 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4328 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4330 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter event */

/* 4332 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4334 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4336 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter started */

/* 4338 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4340 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4342 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4344 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4346 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 4348 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure RegisterEmbeddedFrontend */

/* 4350 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4352 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4356 */	NdrFcShort( 0x3c ),	/* 60 */
/* 4358 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 4360 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4362 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4364 */	NdrFcShort( 0x5c ),	/* 92 */
/* 4366 */	NdrFcShort( 0x48 ),	/* 72 */
/* 4368 */	0x47,		/* Oi2 Flags:  srv must size, clt must size, has return, has ext, */
			0xb,		/* 11 */
/* 4370 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4372 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4374 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4376 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4378 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4380 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4382 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4384 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4386 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4388 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4390 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4392 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4394 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4396 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter payload */

/* 4398 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4400 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4402 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter vm */

/* 4404 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4406 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4408 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter incarnation */

/* 4410 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4412 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4414 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 4416 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4418 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 4420 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 4422 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 4424 */	NdrFcShort( 0x40 ),	/* X64 Stack size/offset = 64 */
/* 4426 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter notification */

/* 4428 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4430 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 4432 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Parameter retire */

/* 4434 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 4436 */	NdrFcShort( 0x50 ),	/* X64 Stack size/offset = 80 */
/* 4438 */	NdrFcShort( 0x1a ),	/* Type Offset=26 */

	/* Return value */

/* 4440 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4442 */	NdrFcShort( 0x58 ),	/* X64 Stack size/offset = 88 */
/* 4444 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure CloseFrontendInstance */

/* 4446 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4448 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4452 */	NdrFcShort( 0x3d ),	/* 61 */
/* 4454 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 4456 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4458 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4460 */	NdrFcShort( 0x44 ),	/* 68 */
/* 4462 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4464 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 4466 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4468 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4470 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4472 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4474 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4476 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4478 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4480 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4482 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4484 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4486 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4488 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4490 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4492 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 4494 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4496 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4498 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 4500 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4502 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4504 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4506 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4508 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4510 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

	/* Procedure UnregisterFrontendInstance */

/* 4512 */	0x0,		/* 0 */
			0x48,		/* Old Flags:  */
/* 4514 */	NdrFcLong( 0x0 ),	/* 0 */
/* 4518 */	NdrFcShort( 0x3e ),	/* 62 */
/* 4520 */	NdrFcShort( 0x38 ),	/* X64 Stack size/offset = 56 */
/* 4522 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x0,		/* 0 */
/* 4524 */	NdrFcShort( 0x0 ),	/* X64 Stack size/offset = 0 */
/* 4526 */	NdrFcShort( 0x44 ),	/* 68 */
/* 4528 */	NdrFcShort( 0x8 ),	/* 8 */
/* 4530 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x6,		/* 6 */
/* 4532 */	0xa,		/* 10 */
			0x41,		/* Ext Flags:  new corr desc, has range on conformance */
/* 4534 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4536 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4538 */	NdrFcShort( 0x0 ),	/* 0 */
/* 4540 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter connection */

/* 4542 */	NdrFcShort( 0x8 ),	/* Flags:  in, */
/* 4544 */	NdrFcShort( 0x8 ),	/* X64 Stack size/offset = 8 */
/* 4546 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter process */

/* 4548 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 4550 */	NdrFcShort( 0x10 ),	/* X64 Stack size/offset = 16 */
/* 4552 */	NdrFcShort( 0x6 ),	/* Type Offset=6 */

	/* Parameter generation */

/* 4554 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4556 */	NdrFcShort( 0x18 ),	/* X64 Stack size/offset = 24 */
/* 4558 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter frontend_instance */

/* 4560 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4562 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 4564 */	0xb,		/* FC_HYPER */
			0x0,		/* 0 */

	/* Parameter frontend_generation */

/* 4566 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 4568 */	NdrFcShort( 0x28 ),	/* X64 Stack size/offset = 40 */
/* 4570 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 4572 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 4574 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 4576 */	0x10,		/* FC_ERROR_STATUS_T */
			0x0,		/* 0 */

			0x0
        }
    };

static const legacy_MIDL_TYPE_FORMAT_STRING legacy__MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	0x30,		/* FC_BIND_CONTEXT */
			0x41,		/* Ctxt flags:  in, can't be null */
/*  4 */	0x0,		/* 0 */
			0x0,		/* 0 */
/*  6 */	0x3c,		/* FC_SYSTEM_HANDLE */
			0x4,		/* 4 */
/*  8 */	NdrFcLong( 0x0 ),	/* 0 */
/* 12 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 14 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 16 */	0xb7,		/* FC_RANGE */
			0x8,		/* 8 */
/* 18 */	NdrFcLong( 0x1 ),	/* 1 */
/* 22 */	NdrFcLong( 0x2 ),	/* 2 */
/* 26 */	0x3c,		/* FC_SYSTEM_HANDLE */
			0x2,		/* 2 */
/* 28 */	NdrFcLong( 0x0 ),	/* 0 */
/* 32 */	0xb7,		/* FC_RANGE */
			0x8,		/* 8 */
/* 34 */	NdrFcLong( 0x0 ),	/* 0 */
/* 38 */	NdrFcLong( 0x100000 ),	/* 1048576 */
/* 42 */	
			0x12, 0x20,	/* FC_UP [maybenull_sizeis] */
/* 44 */	NdrFcShort( 0x2 ),	/* Offset= 2 (46) */
/* 46 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 48 */	NdrFcShort( 0x1 ),	/* 1 */
/* 50 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x0,		/*  */
/* 52 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 54 */	NdrFcShort( 0x11 ),	/* Corr flags:  early, */
/* 56 */	0x1 , /* correlation range */
			0x0,		/* 0 */
/* 58 */	NdrFcLong( 0x0 ),	/* 0 */
/* 62 */	NdrFcLong( 0x100000 ),	/* 1048576 */
/* 66 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 68 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 70 */	NdrFcShort( 0xffc0 ),	/* Offset= -64 (6) */
/* 72 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 74 */	NdrFcShort( 0xffd0 ),	/* Offset= -48 (26) */
/* 76 */	0xb7,		/* FC_RANGE */
			0x8,		/* 8 */
/* 78 */	NdrFcLong( 0x2 ),	/* 2 */
/* 82 */	NdrFcLong( 0x10000 ),	/* 65536 */
/* 86 */	
			0x11, 0x0,	/* FC_RP */
/* 88 */	NdrFcShort( 0x2 ),	/* Offset= 2 (90) */
/* 90 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 92 */	NdrFcShort( 0x2 ),	/* 2 */
/* 94 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x0,		/*  */
/* 96 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 98 */	NdrFcShort( 0x11 ),	/* Corr flags:  early, */
/* 100 */	0x1 , /* correlation range */
			0x0,		/* 0 */
/* 102 */	NdrFcLong( 0x2 ),	/* 2 */
/* 106 */	NdrFcLong( 0x10000 ),	/* 65536 */
/* 110 */	0x5,		/* FC_WCHAR */
			0x5b,		/* FC_END */
/* 112 */	0xb7,		/* FC_RANGE */
			0x8,		/* 8 */
/* 114 */	NdrFcLong( 0x1 ),	/* 1 */
/* 118 */	NdrFcLong( 0x100000 ),	/* 1048576 */
/* 122 */	
			0x11, 0x0,	/* FC_RP */
/* 124 */	NdrFcShort( 0x2 ),	/* Offset= 2 (126) */
/* 126 */	
			0x1c,		/* FC_CVARRAY */
			0x0,		/* 0 */
/* 128 */	NdrFcShort( 0x1 ),	/* 1 */
/* 130 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x0,		/*  */
/* 132 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 134 */	NdrFcShort( 0x11 ),	/* Corr flags:  early, */
/* 136 */	0x1 , /* correlation range */
			0x0,		/* 0 */
/* 138 */	NdrFcLong( 0x1 ),	/* 1 */
/* 142 */	NdrFcLong( 0x100000 ),	/* 1048576 */
/* 146 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x54,		/* FC_DEREFERENCE */
/* 148 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 150 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 152 */	0x0 , 
			0x0,		/* 0 */
/* 154 */	NdrFcLong( 0x0 ),	/* 0 */
/* 158 */	NdrFcLong( 0x0 ),	/* 0 */
/* 162 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 164 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 166 */	0xb,		/* FC_HYPER */
			0x5c,		/* FC_PAD */
/* 168 */	0x3c,		/* FC_SYSTEM_HANDLE */
			0xc,		/* 12 */
/* 170 */	NdrFcLong( 0x0 ),	/* 0 */
/* 174 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 176 */	NdrFcShort( 0xfff8 ),	/* Offset= -8 (168) */
/* 178 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 180 */	NdrFcShort( 0x20 ),	/* 32 */
/* 182 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 184 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 186 */	NdrFcShort( 0x2 ),	/* Offset= 2 (188) */
/* 188 */	0x30,		/* FC_BIND_CONTEXT */
			0xa0,		/* Ctxt flags:  via ptr, out, */
/* 190 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 192 */	0xb7,		/* FC_RANGE */
			0x6,		/* 6 */
/* 194 */	NdrFcLong( 0x1 ),	/* 1 */
/* 198 */	NdrFcLong( 0xffff ),	/* 65535 */
/* 202 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 204 */	NdrFcShort( 0x4 ),	/* 4 */
/* 206 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x0,		/*  */
/* 208 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 210 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 212 */	0x0 , 
			0x0,		/* 0 */
/* 214 */	NdrFcLong( 0x0 ),	/* 0 */
/* 218 */	NdrFcLong( 0x0 ),	/* 0 */
/* 222 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 224 */	
			0x11, 0x0,	/* FC_RP */
/* 226 */	NdrFcShort( 0x2 ),	/* Offset= 2 (228) */
/* 228 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 230 */	NdrFcShort( 0x1 ),	/* 1 */
/* 232 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x0,		/*  */
/* 234 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 236 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 238 */	0x0 , 
			0x0,		/* 0 */
/* 240 */	NdrFcLong( 0x0 ),	/* 0 */
/* 244 */	NdrFcLong( 0x0 ),	/* 0 */
/* 248 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 250 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] [pointer_deref] */
/* 252 */	NdrFcShort( 0x2 ),	/* Offset= 2 (254) */
/* 254 */	
			0x12, 0x20,	/* FC_UP [maybenull_sizeis] */
/* 256 */	NdrFcShort( 0x2 ),	/* Offset= 2 (258) */
/* 258 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x0,		/* 0 */
/* 260 */	NdrFcShort( 0x0 ),	/* 0 */
/* 262 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x54,		/* FC_DEREFERENCE */
/* 264 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 266 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 268 */	0x0 , 
			0x0,		/* 0 */
/* 270 */	NdrFcLong( 0x0 ),	/* 0 */
/* 274 */	NdrFcLong( 0x0 ),	/* 0 */
/* 278 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 282 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 284 */	0x0 , 
			0x0,		/* 0 */
/* 286 */	NdrFcLong( 0x0 ),	/* 0 */
/* 290 */	NdrFcLong( 0x0 ),	/* 0 */
/* 294 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 296 */	NdrFcShort( 0xfef2 ),	/* Offset= -270 (26) */
/* 298 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 300 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 302 */	NdrFcShort( 0x28 ),	/* 40 */
/* 304 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 306 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] [pointer_deref] */
/* 308 */	NdrFcShort( 0x2 ),	/* Offset= 2 (310) */
/* 310 */	
			0x12, 0x20,	/* FC_UP [maybenull_sizeis] */
/* 312 */	NdrFcShort( 0x2 ),	/* Offset= 2 (314) */
/* 314 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x0,		/* 0 */
/* 316 */	NdrFcShort( 0x0 ),	/* 0 */
/* 318 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x54,		/* FC_DEREFERENCE */
/* 320 */	NdrFcShort( 0x48 ),	/* X64 Stack size/offset = 72 */
/* 322 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 324 */	0x0 , 
			0x0,		/* 0 */
/* 326 */	NdrFcLong( 0x0 ),	/* 0 */
/* 330 */	NdrFcLong( 0x0 ),	/* 0 */
/* 334 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 338 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 340 */	0x0 , 
			0x0,		/* 0 */
/* 342 */	NdrFcLong( 0x0 ),	/* 0 */
/* 346 */	NdrFcLong( 0x0 ),	/* 0 */
/* 350 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 352 */	NdrFcShort( 0xff48 ),	/* Offset= -184 (168) */
/* 354 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 356 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] [pointer_deref] */
/* 358 */	NdrFcShort( 0x2 ),	/* Offset= 2 (360) */
/* 360 */	
			0x12, 0x20,	/* FC_UP [maybenull_sizeis] */
/* 362 */	NdrFcShort( 0x8 ),	/* Offset= 8 (370) */
/* 364 */	0x3c,		/* FC_SYSTEM_HANDLE */
			0x0,		/* 0 */
/* 366 */	NdrFcLong( 0x0 ),	/* 0 */
/* 370 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x0,		/* 0 */
/* 372 */	NdrFcShort( 0x0 ),	/* 0 */
/* 374 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x54,		/* FC_DEREFERENCE */
/* 376 */	NdrFcShort( 0x60 ),	/* X64 Stack size/offset = 96 */
/* 378 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 380 */	0x0 , 
			0x0,		/* 0 */
/* 382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 386 */	NdrFcLong( 0x0 ),	/* 0 */
/* 390 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 394 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 396 */	0x0 , 
			0x0,		/* 0 */
/* 398 */	NdrFcLong( 0x0 ),	/* 0 */
/* 402 */	NdrFcLong( 0x0 ),	/* 0 */
/* 406 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 408 */	NdrFcShort( 0xffd4 ),	/* Offset= -44 (364) */
/* 410 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 412 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] [pointer_deref] */
/* 414 */	NdrFcShort( 0x2 ),	/* Offset= 2 (416) */
/* 416 */	
			0x12, 0x20,	/* FC_UP [maybenull_sizeis] */
/* 418 */	NdrFcShort( 0x2 ),	/* Offset= 2 (420) */
/* 420 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 422 */	NdrFcShort( 0x1 ),	/* 1 */
/* 424 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x54,		/* FC_DEREFERENCE */
/* 426 */	NdrFcShort( 0x70 ),	/* X64 Stack size/offset = 112 */
/* 428 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 430 */	0x0 , 
			0x0,		/* 0 */
/* 432 */	NdrFcLong( 0x0 ),	/* 0 */
/* 436 */	NdrFcLong( 0x0 ),	/* 0 */
/* 440 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 442 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 444 */	NdrFcShort( 0x2 ),	/* Offset= 2 (446) */
/* 446 */	0x30,		/* FC_BIND_CONTEXT */
			0xe0,		/* Ctxt flags:  via ptr, in, out, */
/* 448 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 450 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] [pointer_deref] */
/* 452 */	NdrFcShort( 0x2 ),	/* Offset= 2 (454) */
/* 454 */	
			0x12, 0x20,	/* FC_UP [maybenull_sizeis] */
/* 456 */	NdrFcShort( 0x2e ),	/* Offset= 46 (502) */
/* 458 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 460 */	NdrFcShort( 0x18 ),	/* 24 */
/* 462 */	0xb,		/* FC_HYPER */
			0x8,		/* FC_LONG */
/* 464 */	0x8,		/* FC_LONG */
			0xb,		/* FC_HYPER */
/* 466 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 468 */	
			0x1d,		/* FC_SMFARRAY */
			0x1,		/* 1 */
/* 470 */	NdrFcShort( 0x208 ),	/* 520 */
/* 472 */	0x5,		/* FC_WCHAR */
			0x5b,		/* FC_END */
/* 474 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 476 */	NdrFcShort( 0x268 ),	/* 616 */
/* 478 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 480 */	NdrFcShort( 0xffea ),	/* Offset= -22 (458) */
/* 482 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 484 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (458) */
/* 486 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 488 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 490 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 492 */	0xb,		/* FC_HYPER */
			0x8,		/* FC_LONG */
/* 494 */	0x8,		/* FC_LONG */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 496 */	0x0,		/* 0 */
			NdrFcShort( 0xffe3 ),	/* Offset= -29 (468) */
			0xb,		/* FC_HYPER */
/* 500 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 502 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x7,		/* 7 */
/* 504 */	NdrFcShort( 0x0 ),	/* 0 */
/* 506 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x54,		/* FC_DEREFERENCE */
/* 508 */	NdrFcShort( 0x20 ),	/* X64 Stack size/offset = 32 */
/* 510 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 512 */	0x0 , 
			0x0,		/* 0 */
/* 514 */	NdrFcLong( 0x0 ),	/* 0 */
/* 518 */	NdrFcLong( 0x0 ),	/* 0 */
/* 522 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 526 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 528 */	0x0 , 
			0x0,		/* 0 */
/* 530 */	NdrFcLong( 0x0 ),	/* 0 */
/* 534 */	NdrFcLong( 0x0 ),	/* 0 */
/* 538 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 540 */	NdrFcShort( 0xffbe ),	/* Offset= -66 (474) */
/* 542 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 544 */	
			0x11, 0x0,	/* FC_RP */
/* 546 */	NdrFcShort( 0xffa8 ),	/* Offset= -88 (458) */
/* 548 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] [pointer_deref] */
/* 550 */	NdrFcShort( 0x2 ),	/* Offset= 2 (552) */
/* 552 */	
			0x12, 0x20,	/* FC_UP [maybenull_sizeis] */
/* 554 */	NdrFcShort( 0x1a ),	/* Offset= 26 (580) */
/* 556 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 558 */	NdrFcShort( 0x250 ),	/* 592 */
/* 560 */	0xb,		/* FC_HYPER */
			0xb,		/* FC_HYPER */
/* 562 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 564 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 566 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 568 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 570 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 572 */	0xb,		/* FC_HYPER */
			0xb,		/* FC_HYPER */
/* 574 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 576 */	NdrFcShort( 0xff94 ),	/* Offset= -108 (468) */
/* 578 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 580 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x7,		/* 7 */
/* 582 */	NdrFcShort( 0x0 ),	/* 0 */
/* 584 */	0x29,		/* Corr desc:  parameter, FC_ULONG */
			0x54,		/* FC_DEREFERENCE */
/* 586 */	NdrFcShort( 0x30 ),	/* X64 Stack size/offset = 48 */
/* 588 */	NdrFcShort( 0x1 ),	/* Corr flags:  early, */
/* 590 */	0x0 , 
			0x0,		/* 0 */
/* 592 */	NdrFcLong( 0x0 ),	/* 0 */
/* 596 */	NdrFcLong( 0x0 ),	/* 0 */
/* 600 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 604 */	NdrFcShort( 0x0 ),	/* Corr flags:  */
/* 606 */	0x0 , 
			0x0,		/* 0 */
/* 608 */	NdrFcLong( 0x0 ),	/* 0 */
/* 612 */	NdrFcLong( 0x0 ),	/* 0 */
/* 616 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 618 */	NdrFcShort( 0xffc2 ),	/* Offset= -62 (556) */
/* 620 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 622 */	
			0x11, 0x0,	/* FC_RP */
/* 624 */	NdrFcShort( 0x2 ),	/* Offset= 2 (626) */
/* 626 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 628 */	NdrFcShort( 0x238 ),	/* 568 */
/* 630 */	0xb,		/* FC_HYPER */
			0xb,		/* FC_HYPER */
/* 632 */	0xb,		/* FC_HYPER */
			0xb,		/* FC_HYPER */
/* 634 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 636 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 638 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 640 */	NdrFcShort( 0xff54 ),	/* Offset= -172 (468) */
/* 642 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */

			0x0
        }
    };

static const unsigned short vdm_service_FormatStringOffsetTable[] =
    {
    0,
    60,
    132,
    192,
    258,
    354,
    426,
    522,
    588,
    672,
    738,
    804,
    870,
    924,
    984,
    1062,
    1164,
    1248,
    1308,
    1380,
    1446,
    1506,
    1566,
    1638,
    1734,
    1812,
    1890,
    1956,
    2028,
    2088,
    2166,
    2250,
    2328,
    2406,
    2508,
    2580,
    2640,
    2700,
    2760,
    2826,
    2886,
    2982,
    3108,
    3180,
    3276,
    3342,
    3402,
    3456,
    3528,
    3600,
    3660,
    3726,
    3786,
    3864,
    3936,
    4014,
    4074,
    4146,
    4218,
    4278,
    4350,
    4446,
    4512
    };



#endif /* defined(_M_AMD64)*/



/* this ALWAYS GENERATED file contains the RPC client stubs */


 /* File created by MIDL compiler version 8.01.0628 */
/* at Mon Jan 18 19:14:07 2038
 */
/* Compiler settings for legacy.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.01.0628 
    protocol : all , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#if defined(_M_AMD64)




#if !defined(__RPC_WIN64__)
#error  Invalid build platform for this stub.
#endif


#include "ndr64types.h"
#include "pshpack8.h"
#ifdef __cplusplus
namespace {
#endif


typedef 
NDR64_FORMAT_CHAR
__midl_frag644_t;
extern const __midl_frag644_t __midl_frag644;

typedef 
NDR64_FORMAT_CHAR
__midl_frag643_t;
extern const __midl_frag643_t __midl_frag643;

typedef 
NDR64_FORMAT_CHAR
__midl_frag642_t;
extern const __midl_frag642_t __midl_frag642;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag640_t;
extern const __midl_frag640_t __midl_frag640;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag639_t;
extern const __midl_frag639_t __midl_frag639;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag638_t;
extern const __midl_frag638_t __midl_frag638;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag629_t;
extern const __midl_frag629_t __midl_frag629;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag628_t;
extern const __midl_frag628_t __midl_frag628;

typedef 
NDR64_FORMAT_CHAR
__midl_frag625_t;
extern const __midl_frag625_t __midl_frag625;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag624_t;
extern const __midl_frag624_t __midl_frag624;

typedef 
NDR64_FORMAT_CHAR
__midl_frag623_t;
extern const __midl_frag623_t __midl_frag623;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag622_t;
extern const __midl_frag622_t __midl_frag622;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
}
__midl_frag615_t;
extern const __midl_frag615_t __midl_frag615;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag605_t;
extern const __midl_frag605_t __midl_frag605;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag599_t;
extern const __midl_frag599_t __midl_frag599;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag590_t;
extern const __midl_frag590_t __midl_frag590;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag581_t;
extern const __midl_frag581_t __midl_frag581;

typedef 
struct 
{
    struct _NDR64_STRUCTURE_HEADER_FORMAT frag1;
}
__midl_frag572_t;
extern const __midl_frag572_t __midl_frag572;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag571_t;
extern const __midl_frag571_t __midl_frag571;

typedef 
struct 
{
    struct _NDR64_FIX_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag570_t;
extern const __midl_frag570_t __midl_frag570;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag565_t;
extern const __midl_frag565_t __midl_frag565;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag556_t;
extern const __midl_frag556_t __midl_frag556;

typedef 
struct 
{
    struct _NDR64_STRUCTURE_HEADER_FORMAT frag1;
}
__midl_frag554_t;
extern const __midl_frag554_t __midl_frag554;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_OPERATOR frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag553_t;
extern const __midl_frag553_t __midl_frag553;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag552_t;
extern const __midl_frag552_t __midl_frag552;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag551_t;
extern const __midl_frag551_t __midl_frag551;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag550_t;
extern const __midl_frag550_t __midl_frag550;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag545_t;
extern const __midl_frag545_t __midl_frag545;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag541_t;
extern const __midl_frag541_t __midl_frag541;

typedef 
struct 
{
    struct _NDR64_STRUCTURE_HEADER_FORMAT frag1;
}
__midl_frag539_t;
extern const __midl_frag539_t __midl_frag539;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag534_t;
extern const __midl_frag534_t __midl_frag534;

typedef 
struct 
{
    struct _NDR64_STRUCTURE_HEADER_FORMAT frag1;
}
__midl_frag532_t;
extern const __midl_frag532_t __midl_frag532;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_OPERATOR frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag531_t;
extern const __midl_frag531_t __midl_frag531;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag530_t;
extern const __midl_frag530_t __midl_frag530;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag529_t;
extern const __midl_frag529_t __midl_frag529;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag528_t;
extern const __midl_frag528_t __midl_frag528;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag522_t;
extern const __midl_frag522_t __midl_frag522;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag512_t;
extern const __midl_frag512_t __midl_frag512;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag507_t;
extern const __midl_frag507_t __midl_frag507;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag503_t;
extern const __midl_frag503_t __midl_frag503;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag498_t;
extern const __midl_frag498_t __midl_frag498;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag496_t;
extern const __midl_frag496_t __midl_frag496;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag495_t;
extern const __midl_frag495_t __midl_frag495;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
}
__midl_frag492_t;
extern const __midl_frag492_t __midl_frag492;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag486_t;
extern const __midl_frag486_t __midl_frag486;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag483_t;
extern const __midl_frag483_t __midl_frag483;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag478_t;
extern const __midl_frag478_t __midl_frag478;

typedef 
struct 
{
    struct _NDR64_CONF_VAR_BOGUS_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag469_t;
extern const __midl_frag469_t __midl_frag469;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag468_t;
extern const __midl_frag468_t __midl_frag468;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag467_t;
extern const __midl_frag467_t __midl_frag467;

typedef 
NDR64_FORMAT_CHAR
__midl_frag464_t;
extern const __midl_frag464_t __midl_frag464;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_VAR frag2;
}
__midl_frag463_t;
extern const __midl_frag463_t __midl_frag463;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag462_t;
extern const __midl_frag462_t __midl_frag462;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag461_t;
extern const __midl_frag461_t __midl_frag461;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
}
__midl_frag456_t;
extern const __midl_frag456_t __midl_frag456;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag447_t;
extern const __midl_frag447_t __midl_frag447;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_OPERATOR frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag444_t;
extern const __midl_frag444_t __midl_frag444;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag443_t;
extern const __midl_frag443_t __midl_frag443;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag442_t;
extern const __midl_frag442_t __midl_frag442;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag441_t;
extern const __midl_frag441_t __midl_frag441;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag438_t;
extern const __midl_frag438_t __midl_frag438;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_OPERATOR frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag437_t;
extern const __midl_frag437_t __midl_frag437;

typedef 
struct 
{
    struct _NDR64_CONF_VAR_BOGUS_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag436_t;
extern const __midl_frag436_t __midl_frag436;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag435_t;
extern const __midl_frag435_t __midl_frag435;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag434_t;
extern const __midl_frag434_t __midl_frag434;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_OPERATOR frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag428_t;
extern const __midl_frag428_t __midl_frag428;

typedef 
struct 
{
    struct _NDR64_CONF_VAR_BOGUS_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag427_t;
extern const __midl_frag427_t __midl_frag427;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag426_t;
extern const __midl_frag426_t __midl_frag426;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag425_t;
extern const __midl_frag425_t __midl_frag425;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_OPERATOR frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag419_t;
extern const __midl_frag419_t __midl_frag419;

typedef 
struct 
{
    struct _NDR64_CONF_VAR_BOGUS_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag418_t;
extern const __midl_frag418_t __midl_frag418;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag417_t;
extern const __midl_frag417_t __midl_frag417;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag416_t;
extern const __midl_frag416_t __midl_frag416;

typedef 
NDR64_FORMAT_CHAR
__midl_frag413_t;
extern const __midl_frag413_t __midl_frag413;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_VAR frag2;
}
__midl_frag412_t;
extern const __midl_frag412_t __midl_frag412;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag411_t;
extern const __midl_frag411_t __midl_frag411;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag410_t;
extern const __midl_frag410_t __midl_frag410;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag407_t;
extern const __midl_frag407_t __midl_frag407;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag406_t;
extern const __midl_frag406_t __midl_frag406;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
    struct _NDR64_PARAM_FORMAT frag14;
    struct _NDR64_PARAM_FORMAT frag15;
    struct _NDR64_PARAM_FORMAT frag16;
    struct _NDR64_PARAM_FORMAT frag17;
    struct _NDR64_PARAM_FORMAT frag18;
}
__midl_frag405_t;
extern const __midl_frag405_t __midl_frag405;

typedef 
NDR64_FORMAT_CHAR
__midl_frag404_t;
extern const __midl_frag404_t __midl_frag404;

typedef 
struct 
{
    struct _NDR64_FIX_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag403_t;
extern const __midl_frag403_t __midl_frag403;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag398_t;
extern const __midl_frag398_t __midl_frag398;

typedef 
struct 
{
    struct _NDR64_CONF_VAR_BOGUS_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag396_t;
extern const __midl_frag396_t __midl_frag396;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag395_t;
extern const __midl_frag395_t __midl_frag395;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag394_t;
extern const __midl_frag394_t __midl_frag394;

typedef 
NDR64_FORMAT_CHAR
__midl_frag391_t;
extern const __midl_frag391_t __midl_frag391;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_VAR frag2;
}
__midl_frag390_t;
extern const __midl_frag390_t __midl_frag390;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag389_t;
extern const __midl_frag389_t __midl_frag389;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag388_t;
extern const __midl_frag388_t __midl_frag388;

typedef 
NDR64_FORMAT_CHAR
__midl_frag387_t;
extern const __midl_frag387_t __midl_frag387;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag385_t;
extern const __midl_frag385_t __midl_frag385;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag384_t;
extern const __midl_frag384_t __midl_frag384;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
}
__midl_frag383_t;
extern const __midl_frag383_t __midl_frag383;

typedef 
NDR64_FORMAT_CHAR
__midl_frag382_t;
extern const __midl_frag382_t __midl_frag382;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag380_t;
extern const __midl_frag380_t __midl_frag380;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag376_t;
extern const __midl_frag376_t __midl_frag376;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag372_t;
extern const __midl_frag372_t __midl_frag372;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag367_t;
extern const __midl_frag367_t __midl_frag367;

typedef 
NDR64_FORMAT_CHAR
__midl_frag365_t;
extern const __midl_frag365_t __midl_frag365;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag361_t;
extern const __midl_frag361_t __midl_frag361;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag358_t;
extern const __midl_frag358_t __midl_frag358;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag354_t;
extern const __midl_frag354_t __midl_frag354;

typedef 
struct _NDR64_RANGE_FORMAT
__midl_frag344_t;
extern const __midl_frag344_t __midl_frag344;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag339_t;
extern const __midl_frag339_t __midl_frag339;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag337_t;
extern const __midl_frag337_t __midl_frag337;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag336_t;
extern const __midl_frag336_t __midl_frag336;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag330_t;
extern const __midl_frag330_t __midl_frag330;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag327_t;
extern const __midl_frag327_t __midl_frag327;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag326_t;
extern const __midl_frag326_t __midl_frag326;

typedef 
struct 
{
    struct _NDR64_FIX_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag325_t;
extern const __midl_frag325_t __midl_frag325;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
    struct _NDR64_PARAM_FORMAT frag14;
}
__midl_frag319_t;
extern const __midl_frag319_t __midl_frag319;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag312_t;
extern const __midl_frag312_t __midl_frag312;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag311_t;
extern const __midl_frag311_t __midl_frag311;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag310_t;
extern const __midl_frag310_t __midl_frag310;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag306_t;
extern const __midl_frag306_t __midl_frag306;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag295_t;
extern const __midl_frag295_t __midl_frag295;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag294_t;
extern const __midl_frag294_t __midl_frag294;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag293_t;
extern const __midl_frag293_t __midl_frag293;

typedef 
NDR64_FORMAT_CHAR
__midl_frag292_t;
extern const __midl_frag292_t __midl_frag292;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
}
__midl_frag283_t;
extern const __midl_frag283_t __midl_frag283;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag280_t;
extern const __midl_frag280_t __midl_frag280;

typedef 
NDR64_FORMAT_CHAR
__midl_frag276_t;
extern const __midl_frag276_t __midl_frag276;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag272_t;
extern const __midl_frag272_t __midl_frag272;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag270_t;
extern const __midl_frag270_t __midl_frag270;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag266_t;
extern const __midl_frag266_t __midl_frag266;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag256_t;
extern const __midl_frag256_t __midl_frag256;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag249_t;
extern const __midl_frag249_t __midl_frag249;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag240_t;
extern const __midl_frag240_t __midl_frag240;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag229_t;
extern const __midl_frag229_t __midl_frag229;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
}
__midl_frag217_t;
extern const __midl_frag217_t __midl_frag217;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag212_t;
extern const __midl_frag212_t __midl_frag212;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag207_t;
extern const __midl_frag207_t __midl_frag207;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag200_t;
extern const __midl_frag200_t __midl_frag200;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag194_t;
extern const __midl_frag194_t __midl_frag194;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag191_t;
extern const __midl_frag191_t __midl_frag191;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag186_t;
extern const __midl_frag186_t __midl_frag186;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag178_t;
extern const __midl_frag178_t __midl_frag178;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
}
__midl_frag162_t;
extern const __midl_frag162_t __midl_frag162;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_NOOP frag2;
    struct _NDR64_EXPR_CONST64 frag3;
}
__midl_frag148_t;
extern const __midl_frag148_t __midl_frag148;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_EXPR_OPERATOR frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag147_t;
extern const __midl_frag147_t __midl_frag147;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_RANGE_FORMAT frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag146_t;
extern const __midl_frag146_t __midl_frag146;

typedef 
struct 
{
    struct _NDR64_CONF_VAR_ARRAY_HEADER_FORMAT frag1;
}
__midl_frag145_t;
extern const __midl_frag145_t __midl_frag145;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag144_t;
extern const __midl_frag144_t __midl_frag144;

typedef 
struct _NDR64_RANGE_FORMAT
__midl_frag143_t;
extern const __midl_frag143_t __midl_frag143;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
    struct _NDR64_PARAM_FORMAT frag14;
}
__midl_frag139_t;
extern const __midl_frag139_t __midl_frag139;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
}
__midl_frag130_t;
extern const __midl_frag130_t __midl_frag130;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag123_t;
extern const __midl_frag123_t __midl_frag123;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
}
__midl_frag118_t;
extern const __midl_frag118_t __midl_frag118;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag111_t;
extern const __midl_frag111_t __midl_frag111;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag97_t;
extern const __midl_frag97_t __midl_frag97;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag94_t;
extern const __midl_frag94_t __midl_frag94;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag90_t;
extern const __midl_frag90_t __midl_frag90;

typedef 
NDR64_FORMAT_CHAR
__midl_frag89_t;
extern const __midl_frag89_t __midl_frag89;

typedef 
NDR64_FORMAT_CHAR
__midl_frag88_t;
extern const __midl_frag88_t __midl_frag88;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag86_t;
extern const __midl_frag86_t __midl_frag86;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag85_t;
extern const __midl_frag85_t __midl_frag85;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
}
__midl_frag84_t;
extern const __midl_frag84_t __midl_frag84;

typedef 
NDR64_FORMAT_CHAR
__midl_frag83_t;
extern const __midl_frag83_t __midl_frag83;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag81_t;
extern const __midl_frag81_t __midl_frag81;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag76_t;
extern const __midl_frag76_t __midl_frag76;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag73_t;
extern const __midl_frag73_t __midl_frag73;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag72_t;
extern const __midl_frag72_t __midl_frag72;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag71_t;
extern const __midl_frag71_t __midl_frag71;

typedef 
NDR64_FORMAT_CHAR
__midl_frag66_t;
extern const __midl_frag66_t __midl_frag66;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_RANGE_FORMAT frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag65_t;
extern const __midl_frag65_t __midl_frag65;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag64_t;
extern const __midl_frag64_t __midl_frag64;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag63_t;
extern const __midl_frag63_t __midl_frag63;

typedef 
struct _NDR64_RANGE_FORMAT
__midl_frag62_t;
extern const __midl_frag62_t __midl_frag62;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
}
__midl_frag58_t;
extern const __midl_frag58_t __midl_frag58;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag48_t;
extern const __midl_frag48_t __midl_frag48;

typedef 
NDR64_FORMAT_CHAR
__midl_frag40_t;
extern const __midl_frag40_t __midl_frag40;

typedef 
struct 
{
    NDR64_FORMAT_UINT32 frag1;
    struct _NDR64_RANGE_FORMAT frag2;
    struct _NDR64_EXPR_VAR frag3;
}
__midl_frag39_t;
extern const __midl_frag39_t __midl_frag39;

typedef 
struct 
{
    struct _NDR64_CONF_ARRAY_HEADER_FORMAT frag1;
    struct _NDR64_ARRAY_ELEMENT_INFO frag2;
}
__midl_frag38_t;
extern const __midl_frag38_t __midl_frag38;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag37_t;
extern const __midl_frag37_t __midl_frag37;

typedef 
struct _NDR64_RANGE_FORMAT
__midl_frag36_t;
extern const __midl_frag36_t __midl_frag36;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag35_t;
extern const __midl_frag35_t __midl_frag35;

typedef 
struct _NDR64_RANGE_FORMAT
__midl_frag34_t;
extern const __midl_frag34_t __midl_frag34;

typedef 
NDR64_FORMAT_CHAR
__midl_frag33_t;
extern const __midl_frag33_t __midl_frag33;

typedef 
struct _NDR64_SYSTEM_HANDLE_FORMAT
__midl_frag32_t;
extern const __midl_frag32_t __midl_frag32;

typedef 
struct _NDR64_CONTEXT_HANDLE_FORMAT
__midl_frag31_t;
extern const __midl_frag31_t __midl_frag31;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
    struct _NDR64_PARAM_FORMAT frag10;
    struct _NDR64_PARAM_FORMAT frag11;
    struct _NDR64_PARAM_FORMAT frag12;
    struct _NDR64_PARAM_FORMAT frag13;
}
__midl_frag30_t;
extern const __midl_frag30_t __midl_frag30;

typedef 
NDR64_FORMAT_CHAR
__midl_frag29_t;
extern const __midl_frag29_t __midl_frag29;

typedef 
NDR64_FORMAT_CHAR
__midl_frag27_t;
extern const __midl_frag27_t __midl_frag27;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
}
__midl_frag23_t;
extern const __midl_frag23_t __midl_frag23;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
}
__midl_frag17_t;
extern const __midl_frag17_t __midl_frag17;

typedef 
struct _NDR64_POINTER_FORMAT
__midl_frag14_t;
extern const __midl_frag14_t __midl_frag14;

typedef 
struct 
{
    struct _NDR64_PROC_FORMAT frag1;
    struct _NDR64_BIND_AND_NOTIFY_EXTENSION frag2;
    struct _NDR64_PARAM_FORMAT frag3;
    struct _NDR64_PARAM_FORMAT frag4;
    struct _NDR64_PARAM_FORMAT frag5;
    struct _NDR64_PARAM_FORMAT frag6;
    struct _NDR64_PARAM_FORMAT frag7;
    struct _NDR64_PARAM_FORMAT frag8;
    struct _NDR64_PARAM_FORMAT frag9;
}
__midl_frag8_t;
extern const __midl_frag8_t __midl_frag8;

typedef 
NDR64_FORMAT_UINT32
__midl_frag1_t;
extern const __midl_frag1_t __midl_frag1;

static const __midl_frag644_t __midl_frag644 =
0x13    /* FC64_ERROR_STATUS_T */;

static const __midl_frag643_t __midl_frag643 =
0x5    /* FC64_INT32 */;

static const __midl_frag642_t __midl_frag642 =
0x7    /* FC64_INT64 */;

static const __midl_frag640_t __midl_frag640 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag639_t __midl_frag639 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 65 /* 0x41 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag638_t __midl_frag638 =
{ 
/* UnregisterFrontendInstance */
    { 
    /* UnregisterFrontendInstance */      /* procedure UnregisterFrontendInstance */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag643,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag642,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag643,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag629_t __midl_frag629 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 2 /* 0x2 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag628_t __midl_frag628 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag629
};

static const __midl_frag625_t __midl_frag625 =
0x5    /* FC64_INT32 */;

static const __midl_frag624_t __midl_frag624 =
{ 
/* *long */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag625
};

static const __midl_frag623_t __midl_frag623 =
0x7    /* FC64_INT64 */;

static const __midl_frag622_t __midl_frag622 =
{ 
/* *hyper */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag623
};

static const __midl_frag615_t __midl_frag615 =
{ 
/* RegisterEmbeddedFrontend */
    { 
    /* RegisterEmbeddedFrontend */      /* procedure RegisterEmbeddedFrontend */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 96 /* 0x60 */ ,  /* Stack size */
        (NDR64_UINT32) 92 /* 0x5c */,
        (NDR64_UINT32) 80 /* 0x50 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 11 /* 0xb */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* payload */      /* parameter payload */
        &__midl_frag623,
        { 
        /* payload */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* vm */      /* parameter vm */
        &__midl_frag623,
        { 
        /* vm */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* incarnation */      /* parameter incarnation */
        &__midl_frag623,
        { 
        /* incarnation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag623,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag625,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* notification */      /* parameter notification */
        &__midl_frag629,
        { 
        /* notification */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* retire */      /* parameter retire */
        &__midl_frag629,
        { 
        /* retire */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    }
};

static const __midl_frag605_t __midl_frag605 =
{ 
/* WowStartup */
    { 
    /* WowStartup */      /* procedure WowStartup */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* parent_receipt */      /* parameter parent_receipt */
        &__midl_frag625,
        { 
        /* parent_receipt */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* event */      /* parameter event */
        &__midl_frag629,
        { 
        /* event */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* started */      /* parameter started */
        &__midl_frag625,
        { 
        /* started */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag599_t __midl_frag599 =
{ 
/* WowStarted */
    { 
    /* WowStarted */      /* procedure WowStarted */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* task */      /* parameter task */
        &__midl_frag625,
        { 
        /* task */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag590_t __midl_frag590 =
{ 
/* FrontendStateChanged */
    { 
    /* FrontendStateChanged */      /* procedure FrontendStateChanged */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag623,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag625,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* state_changed */      /* parameter state_changed */
        &__midl_frag629,
        { 
        /* state_changed */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag581_t __midl_frag581 =
{ 
/* RetireWorkerlessFrontend */
    { 
    /* RetireWorkerlessFrontend */      /* procedure RetireWorkerlessFrontend */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag623,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag625,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* retired */      /* parameter retired */
        &__midl_frag625,
        { 
        /* retired */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag572_t __midl_frag572 =
{ 
/* DOS_OBSERVATION_FACT */
    { 
    /* DOS_OBSERVATION_FACT */
        0x30,    /* FC64_STRUCT */
        (NDR64_UINT8) 7 /* 0x7 */,
        { 
        /* DOS_OBSERVATION_FACT */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 568 /* 0x238 */
    }
};

static const __midl_frag571_t __midl_frag571 =
{ 
/* *DOS_OBSERVATION_FACT */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag572
};

static const __midl_frag570_t __midl_frag570 =
{ 
/*  */
    { 
    /* struct _NDR64_FIX_ARRAY_HEADER_FORMAT */
        0x40,    /* FC64_FIX_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* struct _NDR64_FIX_ARRAY_HEADER_FORMAT */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */
    }
};

static const __midl_frag565_t __midl_frag565 =
{ 
/* ObserveDosEventAsync */
    { 
    /* ObserveDosEventAsync */      /* procedure ObserveDosEventAsync */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 732 /* 0x2dc */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* protocol */      /* parameter protocol */
        &__midl_frag625,
        { 
        /* protocol */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* application_version */      /* parameter application_version */
        &__midl_frag570,
        { 
        /* application_version */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* fact */      /* parameter fact */
        &__midl_frag572,
        { 
        /* fact */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* gap */      /* parameter gap */
        &__midl_frag625,
        { 
        /* gap */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag556_t __midl_frag556 =
{ 
/* ObserveNativeCreationAsync */
    { 
    /* ObserveNativeCreationAsync */      /* procedure ObserveNativeCreationAsync */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 64 /* 0x40 */,
        (NDR64_UINT32) 48 /* 0x30 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* reporter */      /* parameter reporter */
        &__midl_frag640,
        { 
        /* reporter */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* protocol */      /* parameter protocol */
        &__midl_frag625,
        { 
        /* protocol */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* application_version */      /* parameter application_version */
        &__midl_frag570,
        { 
        /* application_version */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* child */      /* parameter child */
        &__midl_frag640,
        { 
        /* child */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* creation_flags */      /* parameter creation_flags */
        &__midl_frag625,
        { 
        /* creation_flags */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* node */      /* parameter node */
        &__midl_frag623,
        { 
        /* node */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag554_t __midl_frag554 =
{ 
/* WORKER_TRACE_NODE */
    { 
    /* WORKER_TRACE_NODE */
        0x30,    /* FC64_STRUCT */
        (NDR64_UINT8) 7 /* 0x7 */,
        { 
        /* WORKER_TRACE_NODE */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 592 /* 0x250 */
    }
};

static const __midl_frag553_t __midl_frag553 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_OPERATOR */
        0x4,    /* FC_EXPR_OPER */
        0x5,    /* OP_UNARY_INDIRECTION */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT8) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x8,    /* FC64_UINT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 48 /* 0x30 */  /* Offset */
    }
};

static const __midl_frag552_t __midl_frag552 =
{ 
/* *WORKER_TRACE_NODE */
    { 
    /* *WORKER_TRACE_NODE */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 7 /* 0x7 */,
        { 
        /* *WORKER_TRACE_NODE */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 592 /* 0x250 */,
        &__midl_frag553
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 592 /* 0x250 */,
        &__midl_frag554
    }
};

static const __midl_frag551_t __midl_frag551 =
{ 
/* *WORKER_TRACE_NODE */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag552
};

static const __midl_frag550_t __midl_frag550 =
{ 
/* **WORKER_TRACE_NODE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag551
};

static const __midl_frag545_t __midl_frag545 =
{ 
/* *DTASKMGR_KEY */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag539
};

static const __midl_frag541_t __midl_frag541 =
{ 
/* WorkerTaskTrace */
    { 
    /* WorkerTaskTrace */      /* procedure WorkerTaskTrace */
        (NDR64_UINT32) 21889088 /* 0x14e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ClientCorrelation, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 120 /* 0x78 */,
        (NDR64_UINT32) 72 /* 0x48 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* protocol */      /* parameter protocol */
        &__midl_frag625,
        { 
        /* protocol */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* application_version */      /* parameter application_version */
        &__midl_frag570,
        { 
        /* application_version */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* key */      /* parameter key */
        &__midl_frag539,
        { 
        /* key */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* coverage */      /* parameter coverage */
        &__midl_frag625,
        { 
        /* coverage */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* count */      /* parameter count */
        &__midl_frag625,
        { 
        /* count */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* entries */      /* parameter entries */
        &__midl_frag550,
        { 
        /* entries */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag539_t __midl_frag539 =
{ 
/* DTASKMGR_KEY */
    { 
    /* DTASKMGR_KEY */
        0x30,    /* FC64_STRUCT */
        (NDR64_UINT8) 7 /* 0x7 */,
        { 
        /* DTASKMGR_KEY */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 24 /* 0x18 */
    }
};

static const __midl_frag534_t __midl_frag534 =
{ 
/* CloseManagementNode */
    { 
    /* CloseManagementNode */      /* procedure CloseManagementNode */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 120 /* 0x78 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* protocol */      /* parameter protocol */
        &__midl_frag625,
        { 
        /* protocol */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* application_version */      /* parameter application_version */
        &__midl_frag570,
        { 
        /* application_version */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* key */      /* parameter key */
        &__midl_frag539,
        { 
        /* key */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag532_t __midl_frag532 =
{ 
/* DTASKMGR_WORKER */
    { 
    /* DTASKMGR_WORKER */
        0x30,    /* FC64_STRUCT */
        (NDR64_UINT8) 7 /* 0x7 */,
        { 
        /* DTASKMGR_WORKER */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 616 /* 0x268 */
    }
};

static const __midl_frag531_t __midl_frag531 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_OPERATOR */
        0x4,    /* FC_EXPR_OPER */
        0x5,    /* OP_UNARY_INDIRECTION */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT8) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x8,    /* FC64_UINT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */  /* Offset */
    }
};

static const __midl_frag530_t __midl_frag530 =
{ 
/* *DTASKMGR_WORKER */
    { 
    /* *DTASKMGR_WORKER */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 7 /* 0x7 */,
        { 
        /* *DTASKMGR_WORKER */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 616 /* 0x268 */,
        &__midl_frag531
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 616 /* 0x268 */,
        &__midl_frag532
    }
};

static const __midl_frag529_t __midl_frag529 =
{ 
/* *DTASKMGR_WORKER */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag530
};

static const __midl_frag528_t __midl_frag528 =
{ 
/* **DTASKMGR_WORKER */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag529
};

static const __midl_frag522_t __midl_frag522 =
{ 
/* TaskSnapshot */
    { 
    /* TaskSnapshot */      /* procedure TaskSnapshot */
        (NDR64_UINT32) 21889088 /* 0x14e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ClientCorrelation, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 56 /* 0x38 */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* protocol */      /* parameter protocol */
        &__midl_frag625,
        { 
        /* protocol */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* application_version */      /* parameter application_version */
        &__midl_frag570,
        { 
        /* application_version */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* count */      /* parameter count */
        &__midl_frag625,
        { 
        /* count */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* entries */      /* parameter entries */
        &__midl_frag528,
        { 
        /* entries */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag512_t __midl_frag512 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag507_t __midl_frag507 =
{ 
/* AttachPipe */
    { 
    /* AttachPipe */      /* procedure AttachPipe */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* role */      /* parameter role */
        &__midl_frag625,
        { 
        /* role */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* stream */      /* parameter stream */
        &__midl_frag512,
        { 
        /* stream */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* receipt */      /* parameter receipt */
        &__midl_frag625,
        { 
        /* receipt */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag503_t __midl_frag503 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag498_t __midl_frag498 =
{ 
/* AttachFile */
    { 
    /* AttachFile */      /* procedure AttachFile */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag643,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* role */      /* parameter role */
        &__midl_frag643,
        { 
        /* role */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* stream */      /* parameter stream */
        &__midl_frag503,
        { 
        /* stream */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* receipt */      /* parameter receipt */
        &__midl_frag625,
        { 
        /* receipt */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag496_t __midl_frag496 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 224 /* 0xe0 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag495_t __midl_frag495 =
{ 
/* *struct _NDR64_POINTER_FORMAT */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag496
};

static const __midl_frag492_t __midl_frag492 =
{ 
/* Disconnect */
    { 
    /* Disconnect */      /* procedure Disconnect */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 40 /* 0x28 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 4 /* 0x4 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag643,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag496,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], [out], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    }
};

static const __midl_frag486_t __midl_frag486 =
{ 
/* Reenter */
    { 
    /* Reenter */      /* procedure Reenter */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag643,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* increment */      /* parameter increment */
        &__midl_frag643,
        { 
        /* increment */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag483_t __midl_frag483 =
{ 
/* *long */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag643
};

static const __midl_frag478_t __midl_frag478 =
{ 
/* ExitCode */
    { 
    /* ExitCode */      /* procedure ExitCode */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag643,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* parent_receipt */      /* parameter parent_receipt */
        &__midl_frag643,
        { 
        /* parent_receipt */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* exit_code */      /* parameter exit_code */
        &__midl_frag643,
        { 
        /* exit_code */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag469_t __midl_frag469 =
{ 
/* *HANDLE */
    { 
    /* *HANDLE */
        { 
        /* *HANDLE */
            0x47,    /* FC64_BOGUS_ARRAY */
            (NDR64_UINT8) 0 /* 0x0 */,
            { 
            /* *HANDLE */
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0
            },
            (NDR64_UINT8) 1 /* 0x1 */,
            (NDR64_UINT32) 0 /* 0x0 */,
            &__midl_frag629
        },
        &__midl_frag553,
        0,
        0
    }
};

static const __midl_frag468_t __midl_frag468 =
{ 
/* *HANDLE */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag469
};

static const __midl_frag467_t __midl_frag467 =
{ 
/* **HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag468
};

static const __midl_frag464_t __midl_frag464 =
0x2    /* FC64_INT8 */;

static const __midl_frag463_t __midl_frag463 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */  /* Offset */
    }
};

static const __midl_frag462_t __midl_frag462 =
{ 
/* *byte */
    { 
    /* *byte */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* *byte */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag463
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag464
    }
};

static const __midl_frag461_t __midl_frag461 =
{ 
/* *byte */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag462
};

static const __midl_frag456_t __midl_frag456 =
{ 
/* Update */
    { 
    /* Update */      /* procedure Update */
        (NDR64_UINT32) 23986240 /* 0x16e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ServerCorrelation, ClientCorrelation, HasExtensions */
        (NDR64_UINT32) 96 /* 0x60 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 152 /* 0x98 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 11 /* 0xb */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* request_bytes */      /* parameter request_bytes */
        &__midl_frag625,
        { 
        /* request_bytes */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag462,
        { 
        /* request */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* parent_event_count */      /* parameter parent_event_count */
        &__midl_frag643,
        { 
        /* parent_event_count */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* parent_events */      /* parameter parent_events */
        &__midl_frag467,
        { 
        /* parent_events */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* parent_receipt */      /* parameter parent_receipt */
        &__midl_frag643,
        { 
        /* parent_receipt */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* reply_bytes */      /* parameter reply_bytes */
        &__midl_frag643,
        { 
        /* reply_bytes */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* reply */      /* parameter reply */
        &__midl_frag570,
        { 
        /* reply */
            0,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [out] */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    }
};

static const __midl_frag447_t __midl_frag447 =
{ 
/* Exit */
    { 
    /* Exit */      /* procedure Exit */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 60 /* 0x3c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag639,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag640,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* is_wow */      /* parameter is_wow */
        &__midl_frag625,
        { 
        /* is_wow */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* wow_task */      /* parameter wow_task */
        &__midl_frag625,
        { 
        /* wow_task */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* close_worker_wait */      /* parameter close_worker_wait */
        &__midl_frag625,
        { 
        /* close_worker_wait */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag444_t __midl_frag444 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_OPERATOR */
        0x4,    /* FC_EXPR_OPER */
        0x5,    /* OP_UNARY_INDIRECTION */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT8) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x8,    /* FC64_UINT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 112 /* 0x70 */  /* Offset */
    }
};

static const __midl_frag443_t __midl_frag443 =
{ 
/* *byte */
    { 
    /* *byte */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* *byte */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag444
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag464
    }
};

static const __midl_frag442_t __midl_frag442 =
{ 
/* *byte */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag443
};

static const __midl_frag441_t __midl_frag441 =
{ 
/* **byte */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag442
};

static const __midl_frag438_t __midl_frag438 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag437_t __midl_frag437 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_OPERATOR */
        0x4,    /* FC_EXPR_OPER */
        0x5,    /* OP_UNARY_INDIRECTION */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT8) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x8,    /* FC64_UINT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 96 /* 0x60 */  /* Offset */
    }
};

static const __midl_frag436_t __midl_frag436 =
{ 
/* *HANDLE */
    { 
    /* *HANDLE */
        { 
        /* *HANDLE */
            0x47,    /* FC64_BOGUS_ARRAY */
            (NDR64_UINT8) 0 /* 0x0 */,
            { 
            /* *HANDLE */
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0
            },
            (NDR64_UINT8) 1 /* 0x1 */,
            (NDR64_UINT32) 0 /* 0x0 */,
            &__midl_frag438
        },
        &__midl_frag437,
        0,
        0
    }
};

static const __midl_frag435_t __midl_frag435 =
{ 
/* *HANDLE */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag436
};

static const __midl_frag434_t __midl_frag434 =
{ 
/* **HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag435
};

static const __midl_frag428_t __midl_frag428 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_OPERATOR */
        0x4,    /* FC_EXPR_OPER */
        0x5,    /* OP_UNARY_INDIRECTION */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT8) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x8,    /* FC64_UINT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 72 /* 0x48 */  /* Offset */
    }
};

static const __midl_frag427_t __midl_frag427 =
{ 
/* *HANDLE */
    { 
    /* *HANDLE */
        { 
        /* *HANDLE */
            0x47,    /* FC64_BOGUS_ARRAY */
            (NDR64_UINT8) 0 /* 0x0 */,
            { 
            /* *HANDLE */
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0
            },
            (NDR64_UINT8) 1 /* 0x1 */,
            (NDR64_UINT32) 0 /* 0x0 */,
            &__midl_frag512
        },
        &__midl_frag428,
        0,
        0
    }
};

static const __midl_frag426_t __midl_frag426 =
{ 
/* *HANDLE */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag427
};

static const __midl_frag425_t __midl_frag425 =
{ 
/* **HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag426
};

static const __midl_frag419_t __midl_frag419 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_OPERATOR */
        0x4,    /* FC_EXPR_OPER */
        0x5,    /* OP_UNARY_INDIRECTION */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT8) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x8,    /* FC64_UINT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 48 /* 0x30 */  /* Offset */
    }
};

static const __midl_frag418_t __midl_frag418 =
{ 
/* *HANDLE */
    { 
    /* *HANDLE */
        { 
        /* *HANDLE */
            0x47,    /* FC64_BOGUS_ARRAY */
            (NDR64_UINT8) 0 /* 0x0 */,
            { 
            /* *HANDLE */
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0
            },
            (NDR64_UINT8) 1 /* 0x1 */,
            (NDR64_UINT32) 0 /* 0x0 */,
            &__midl_frag629
        },
        &__midl_frag419,
        0,
        0
    }
};

static const __midl_frag417_t __midl_frag417 =
{ 
/* *HANDLE */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag418
};

static const __midl_frag416_t __midl_frag416 =
{ 
/* **HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag417
};

static const __midl_frag413_t __midl_frag413 =
0x2    /* FC64_INT8 */;

static const __midl_frag412_t __midl_frag412 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */  /* Offset */
    }
};

static const __midl_frag411_t __midl_frag411 =
{ 
/* *byte */
    { 
    /* *byte */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* *byte */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag412
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag413
    }
};

static const __midl_frag410_t __midl_frag410 =
{ 
/* *byte */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag411
};

static const __midl_frag407_t __midl_frag407 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag406_t __midl_frag406 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 65 /* 0x41 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag405_t __midl_frag405 =
{ 
/* Get */
    { 
    /* Get */      /* procedure Get */
        (NDR64_UINT32) 23986240 /* 0x16e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ServerCorrelation, ClientCorrelation, HasExtensions */
        (NDR64_UINT32) 136 /* 0x88 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 200 /* 0xc8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 16 /* 0x10 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag406,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag407,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag625,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* request_bytes */      /* parameter request_bytes */
        &__midl_frag625,
        { 
        /* request_bytes */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag411,
        { 
        /* request */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* wait_event_count */      /* parameter wait_event_count */
        &__midl_frag625,
        { 
        /* wait_event_count */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* wait_events */      /* parameter wait_events */
        &__midl_frag416,
        { 
        /* wait_events */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* pipe_stream_mask */      /* parameter pipe_stream_mask */
        &__midl_frag625,
        { 
        /* pipe_stream_mask */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* pipe_stream_count */      /* parameter pipe_stream_count */
        &__midl_frag625,
        { 
        /* pipe_stream_count */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* pipe_streams */      /* parameter pipe_streams */
        &__midl_frag425,
        { 
        /* pipe_streams */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* file_stream_mask */      /* parameter file_stream_mask */
        &__midl_frag625,
        { 
        /* file_stream_mask */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    },
    { 
    /* file_stream_count */      /* parameter file_stream_count */
        &__midl_frag625,
        { 
        /* file_stream_count */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        96 /* 0x60 */,   /* Stack offset */
    },
    { 
    /* file_streams */      /* parameter file_streams */
        &__midl_frag434,
        { 
        /* file_streams */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        104 /* 0x68 */,   /* Stack offset */
    },
    { 
    /* reply_bytes */      /* parameter reply_bytes */
        &__midl_frag625,
        { 
        /* reply_bytes */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        112 /* 0x70 */,   /* Stack offset */
    },
    { 
    /* reply */      /* parameter reply */
        &__midl_frag441,
        { 
        /* reply */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        120 /* 0x78 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag644,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        128 /* 0x80 */,   /* Stack offset */
    }
};

static const __midl_frag404_t __midl_frag404 =
0x13    /* FC64_ERROR_STATUS_T */;

static const __midl_frag403_t __midl_frag403 =
{ 
/*  */
    { 
    /* struct _NDR64_FIX_ARRAY_HEADER_FORMAT */
        0x40,    /* FC64_FIX_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* struct _NDR64_FIX_ARRAY_HEADER_FORMAT */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 40 /* 0x28 */
    }
};

static const __midl_frag398_t __midl_frag398 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 2 /* 0x2 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag396_t __midl_frag396 =
{ 
/* *HANDLE */
    { 
    /* *HANDLE */
        { 
        /* *HANDLE */
            0x47,    /* FC64_BOGUS_ARRAY */
            (NDR64_UINT8) 0 /* 0x0 */,
            { 
            /* *HANDLE */
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0
            },
            (NDR64_UINT8) 1 /* 0x1 */,
            (NDR64_UINT32) 0 /* 0x0 */,
            &__midl_frag398
        },
        &__midl_frag553,
        0,
        0
    }
};

static const __midl_frag395_t __midl_frag395 =
{ 
/* *HANDLE */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag396
};

static const __midl_frag394_t __midl_frag394 =
{ 
/* **HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 20 /* 0x14 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag395
};

static const __midl_frag391_t __midl_frag391 =
0x2    /* FC64_INT8 */;

static const __midl_frag390_t __midl_frag390 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */  /* Offset */
    }
};

static const __midl_frag389_t __midl_frag389 =
{ 
/* *byte */
    { 
    /* *byte */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* *byte */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag390
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag391
    }
};

static const __midl_frag388_t __midl_frag388 =
{ 
/* *byte */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag389
};

static const __midl_frag387_t __midl_frag387 =
0x5    /* FC64_INT32 */;

static const __midl_frag385_t __midl_frag385 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag384_t __midl_frag384 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 65 /* 0x41 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag383_t __midl_frag383 =
{ 
/* Check */
    { 
    /* Check */      /* procedure Check */
        (NDR64_UINT32) 23986240 /* 0x16e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ServerCorrelation, ClientCorrelation, HasExtensions */
        (NDR64_UINT32) 96 /* 0x60 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 160 /* 0xa0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 11 /* 0xb */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* request_bytes */      /* parameter request_bytes */
        &__midl_frag387,
        { 
        /* request_bytes */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag389,
        { 
        /* request */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* parent_event_count */      /* parameter parent_event_count */
        &__midl_frag625,
        { 
        /* parent_event_count */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* parent_events */      /* parameter parent_events */
        &__midl_frag394,
        { 
        /* parent_events */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* parent_receipt */      /* parameter parent_receipt */
        &__midl_frag625,
        { 
        /* parent_receipt */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* reply_bytes */      /* parameter reply_bytes */
        &__midl_frag625,
        { 
        /* reply_bytes */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* reply */      /* parameter reply */
        &__midl_frag403,
        { 
        /* reply */
            0,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [out] */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag404,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    }
};

static const __midl_frag382_t __midl_frag382 =
0x13    /* FC64_ERROR_STATUS_T */;

static const __midl_frag380_t __midl_frag380 =
{ 
/* *long */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag387
};

static const __midl_frag376_t __midl_frag376 =
{ 
/* First */
    { 
    /* First */      /* procedure First */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* first */      /* parameter first */
        &__midl_frag387,
        { 
        /* first */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag372_t __midl_frag372 =
{ 
/*  */
    { 
    /* struct _NDR64_CONF_ARRAY_HEADER_FORMAT */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 3 /* 0x3 */,
        { 
        /* struct _NDR64_CONF_ARRAY_HEADER_FORMAT */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 4 /* 0x4 */,
        &__midl_frag390
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 4 /* 0x4 */,
        &__midl_frag387
    }
};

static const __midl_frag367_t __midl_frag367 =
{ 
/* ReportConsoleMembers */
    { 
    /* ReportConsoleMembers */      /* procedure ReportConsoleMembers */
        (NDR64_UINT32) 19660864 /* 0x12c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, ServerCorrelation, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* member_count */      /* parameter member_count */
        &__midl_frag387,
        { 
        /* member_count */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* member_ids */      /* parameter member_ids */
        &__midl_frag372,
        { 
        /* member_ids */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag365_t __midl_frag365 =
0x7    /* FC64_INT64 */;

static const __midl_frag361_t __midl_frag361 =
{ 
/* FailWowTaskClose */
    { 
    /* FailWowTaskClose */      /* procedure FailWowTaskClose */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 60 /* 0x3c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* identity */      /* parameter identity */
        &__midl_frag365,
        { 
        /* identity */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag358_t __midl_frag358 =
{ 
/* *hyper */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag365
};

static const __midl_frag354_t __midl_frag354 =
{ 
/* TakeWowTaskClose */
    { 
    /* TakeWowTaskClose */      /* procedure TakeWowTaskClose */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 48 /* 0x30 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* identity */      /* parameter identity */
        &__midl_frag365,
        { 
        /* identity */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag344_t __midl_frag344 =
{ 
/* short */
    0xa4,    /* FC64_RANGE */
    0x4,    /* FC64_INT16 */
    (NDR64_UINT16) 0 /* 0x0 */,
    (NDR64_INT64) 1 /* 0x1 */,
    (NDR64_INT64) 65535 /* 0xffff */
};

static const __midl_frag339_t __midl_frag339 =
{ 
/* BindWowTask */
    { 
    /* BindWowTask */      /* procedure BindWowTask */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 58 /* 0x3a */,
        (NDR64_UINT32) 48 /* 0x30 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* task */      /* parameter task */
        &__midl_frag387,
        { 
        /* task */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* htask */      /* parameter htask */
        &__midl_frag344,
        { 
        /* htask */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* identity */      /* parameter identity */
        &__midl_frag365,
        { 
        /* identity */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag337_t __midl_frag337 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 2 /* 0x2 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag336_t __midl_frag336 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag337
};

static const __midl_frag330_t __midl_frag330 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag385
};

static const __midl_frag327_t __midl_frag327 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 160 /* 0xa0 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag326_t __midl_frag326 =
{ 
/* *struct _NDR64_POINTER_FORMAT */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag327
};

static const __midl_frag325_t __midl_frag325 =
{ 
/*  */
    { 
    /* struct _NDR64_FIX_ARRAY_HEADER_FORMAT */
        0x40,    /* FC64_FIX_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* struct _NDR64_FIX_ARRAY_HEADER_FORMAT */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */
    }
};

static const __midl_frag319_t __midl_frag319 =
{ 
/* Connect */
    { 
    /* Connect */      /* procedure Connect */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 104 /* 0x68 */ ,  /* Stack size */
        (NDR64_UINT32) 56 /* 0x38 */,
        (NDR64_UINT32) 180 /* 0xb4 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 12 /* 0xc */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag407,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* protocol */      /* parameter protocol */
        &__midl_frag625,
        { 
        /* protocol */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* application_version */      /* parameter application_version */
        &__midl_frag325,
        { 
        /* application_version */
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* server_protocol */      /* parameter server_protocol */
        &__midl_frag387,
        { 
        /* server_protocol */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* server_version */      /* parameter server_version */
        &__midl_frag325,
        { 
        /* server_version */
            0,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustFree, [out] */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag327,
        { 
        /* connection */
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* server */      /* parameter server */
        &__midl_frag385,
        { 
        /* server */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* shutdown */      /* parameter shutdown */
        &__midl_frag337,
        { 
        /* shutdown */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* console_close */      /* parameter console_close */
        &__midl_frag337,
        { 
        /* console_close */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* wow_task_close */      /* parameter wow_task_close */
        &__midl_frag337,
        { 
        /* wow_task_close */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        96 /* 0x60 */,   /* Stack offset */
    }
};

static const __midl_frag312_t __midl_frag312 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag407
};

static const __midl_frag311_t __midl_frag311 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag310_t __midl_frag310 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag311
};

static const __midl_frag306_t __midl_frag306 =
{ 
/* WaitFrontend */
    { 
    /* WaitFrontend */      /* procedure WaitFrontend */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* channel */      /* parameter channel */
        &__midl_frag311,
        { 
        /* channel */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend */      /* parameter frontend */
        &__midl_frag407,
        { 
        /* frontend */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* ready */      /* parameter ready */
        &__midl_frag337,
        { 
        /* ready */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag404,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag295_t __midl_frag295 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag294_t __midl_frag294 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 65 /* 0x41 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag293_t __midl_frag293 =
{ 
/* TakeFrontend */
    { 
    /* TakeFrontend */      /* procedure TakeFrontend */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* channel */      /* parameter channel */
        &__midl_frag311,
        { 
        /* channel */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend */      /* parameter frontend */
        &__midl_frag385,
        { 
        /* frontend */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* ready */      /* parameter ready */
        &__midl_frag337,
        { 
        /* ready */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag292_t __midl_frag292 =
0x13    /* FC64_ERROR_STATUS_T */;

static const __midl_frag283_t __midl_frag283 =
{ 
/* AttachFrontendRequest */
    { 
    /* AttachFrontendRequest */      /* procedure AttachFrontendRequest */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 80 /* 0x50 */ ,  /* Stack size */
        (NDR64_UINT32) 76 /* 0x4c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 9 /* 0x9 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag365,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag387,
        { 
        /* request */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* channel */      /* parameter channel */
        &__midl_frag311,
        { 
        /* channel */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* ready */      /* parameter ready */
        &__midl_frag337,
        { 
        /* ready */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    }
};

static const __midl_frag280_t __midl_frag280 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag295
};

static const __midl_frag276_t __midl_frag276 =
0x7    /* FC64_INT64 */;

static const __midl_frag272_t __midl_frag272 =
{ 
/* FrontendRequest */
    { 
    /* FrontendRequest */      /* procedure FrontendRequest */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag276,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag387,
        { 
        /* request */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* worker */      /* parameter worker */
        &__midl_frag295,
        { 
        /* worker */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag270_t __midl_frag270 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 2 /* 0x2 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag266_t __midl_frag266 =
{ 
/* RequestFrontend */
    { 
    /* RequestFrontend */      /* procedure RequestFrontend */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag270,
        { 
        /* capability */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag256_t __midl_frag256 =
{ 
/* RetainFrontendRoot */
    { 
    /* RetainFrontendRoot */      /* procedure RetainFrontendRoot */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag337,
        { 
        /* capability */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* root */      /* parameter root */
        &__midl_frag295,
        { 
        /* root */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* root_generation */      /* parameter root_generation */
        &__midl_frag387,
        { 
        /* root_generation */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag249_t __midl_frag249 =
{ 
/* FrontendLeaseReady */
    { 
    /* FrontendLeaseReady */      /* procedure FrontendLeaseReady */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag365,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag240_t __midl_frag240 =
{ 
/* FrontendJoinDecision */
    { 
    /* FrontendJoinDecision */      /* procedure FrontendJoinDecision */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 84 /* 0x54 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag365,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* nonce */      /* parameter nonce */
        &__midl_frag387,
        { 
        /* nonce */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* same_console */      /* parameter same_console */
        &__midl_frag387,
        { 
        /* same_console */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag229_t __midl_frag229 =
{ 
/* FrontendJoinCandidate */
    { 
    /* FrontendJoinCandidate */      /* procedure FrontendJoinCandidate */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 72 /* 0x48 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag365,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* nonce */      /* parameter nonce */
        &__midl_frag387,
        { 
        /* nonce */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* candidate_pid */      /* parameter candidate_pid */
        &__midl_frag387,
        { 
        /* candidate_pid */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag217_t __midl_frag217 =
{ 
/* RegisterFrontendLease */
    { 
    /* RegisterFrontendLease */      /* procedure RegisterFrontendLease */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 96 /* 0x60 */ ,  /* Stack size */
        (NDR64_UINT32) 100 /* 0x64 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 11 /* 0xb */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag365,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* console_window */      /* parameter console_window */
        &__midl_frag365,
        { 
        /* console_window */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* creator_pid */      /* parameter creator_pid */
        &__midl_frag387,
        { 
        /* creator_pid */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* borrowed */      /* parameter borrowed */
        &__midl_frag387,
        { 
        /* borrowed */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* retire */      /* parameter retire */
        &__midl_frag337,
        { 
        /* retire */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* restored */      /* parameter restored */
        &__midl_frag337,
        { 
        /* restored */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    }
};

static const __midl_frag212_t __midl_frag212 =
{ 
/* *hyper */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag365
};

static const __midl_frag207_t __midl_frag207 =
{ 
/* RegisterFrontendRoot */
    { 
    /* RegisterFrontendRoot */      /* procedure RegisterFrontendRoot */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 80 /* 0x50 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag337,
        { 
        /* capability */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag365,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag200_t __midl_frag200 =
{ 
/* WorkerFrontendCapability */
    { 
    /* WorkerFrontendCapability */      /* procedure WorkerFrontendCapability */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag337,
        { 
        /* capability */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag194_t __midl_frag194 =
{ 
/* BindConsoleContext */
    { 
    /* BindConsoleContext */      /* procedure BindConsoleContext */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag337,
        { 
        /* capability */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag191_t __midl_frag191 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag337
};

static const __midl_frag186_t __midl_frag186 =
{ 
/* AcquireConsoleContext */
    { 
    /* AcquireConsoleContext */      /* procedure AcquireConsoleContext */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend */      /* parameter frontend */
        &__midl_frag337,
        { 
        /* frontend */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag337,
        { 
        /* capability */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag178_t __midl_frag178 =
{ 
/* BindNativeTarget */
    { 
    /* BindNativeTarget */      /* procedure BindNativeTarget */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag387,
        { 
        /* request */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* target */      /* parameter target */
        &__midl_frag295,
        { 
        /* target */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* receipt */      /* parameter receipt */
        &__midl_frag337,
        { 
        /* receipt */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag162_t __midl_frag162 =
{ 
/* NativeStartupResult */
    { 
    /* NativeStartupResult */      /* procedure NativeStartupResult */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 80 /* 0x50 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 9 /* 0x9 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* caller_generation */      /* parameter caller_generation */
        &__midl_frag387,
        { 
        /* caller_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag387,
        { 
        /* request */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* status */      /* parameter status */
        &__midl_frag387,
        { 
        /* status */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* target */      /* parameter target */
        &__midl_frag295,
        { 
        /* target */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* receipt */      /* parameter receipt */
        &__midl_frag337,
        { 
        /* receipt */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    }
};

static const __midl_frag148_t __midl_frag148 =
{ 
/*  */
    (NDR64_UINT32) 1 /* 0x1 */,
    { 
    /* struct _NDR64_EXPR_NOOP */
        0x5,    /* FC_EXPR_PAD */
        (NDR64_UINT8) 4 /* 0x4 */,
        (NDR64_UINT16) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_CONST64 */
        0x2,    /* FC_EXPR_CONST64 */
        0x7,    /* FC64_INT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT64) 0 /* 0x0 */
    }
};

static const __midl_frag147_t __midl_frag147 =
{ 
/*  */
    (NDR64_UINT32) 0 /* 0x0 */,
    { 
    /* struct _NDR64_EXPR_OPERATOR */
        0x4,    /* FC_EXPR_OPER */
        0x5,    /* OP_UNARY_INDIRECTION */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT8) 0 /* 0x0 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x8,    /* FC64_UINT64 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 48 /* 0x30 */  /* Offset */
    }
};

static const __midl_frag146_t __midl_frag146 =
{ 
/*  */
    (NDR64_UINT32) 5 /* 0x5 */,
    { 
    /* struct _NDR64_RANGE_FORMAT */
        0xa4,    /* FC64_RANGE */
        0x5,    /* FC64_INT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_INT64) 1 /* 0x1 */,
        (NDR64_INT64) 1048576 /* 0x100000 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */  /* Offset */
    }
};

static const __midl_frag145_t __midl_frag145 =
{ 
/* *byte */
    { 
    /* *byte */
        0x43,    /* FC64_CONFVAR_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* *byte */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag146,
        &__midl_frag147
    }
};

static const __midl_frag144_t __midl_frag144 =
{ 
/* *byte */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag145
};

static const __midl_frag143_t __midl_frag143 =
{ 
/* long */
    0xa4,    /* FC64_RANGE */
    0x5,    /* FC64_INT32 */
    (NDR64_UINT16) 0 /* 0x0 */,
    (NDR64_INT64) 1 /* 0x1 */,
    (NDR64_INT64) 1048576 /* 0x100000 */
};

static const __midl_frag139_t __midl_frag139 =
{ 
/* GetNextNativeCommand */
    { 
    /* GetNextNativeCommand */      /* procedure GetNextNativeCommand */
        (NDR64_UINT32) 21889088 /* 0x14e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ClientCorrelation, HasExtensions */
        (NDR64_UINT32) 104 /* 0x68 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 104 /* 0x68 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 12 /* 0xc */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* capacity */      /* parameter capacity */
        &__midl_frag143,
        { 
        /* capacity */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* payload */      /* parameter payload */
        &__midl_frag145,
        { 
        /* payload */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [out], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* bytes */      /* parameter bytes */
        &__midl_frag387,
        { 
        /* bytes */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* caller_process */      /* parameter caller_process */
        &__midl_frag385,
        { 
        /* caller_process */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* execution */      /* parameter execution */
        &__midl_frag337,
        { 
        /* execution */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* frontend */      /* parameter frontend */
        &__midl_frag337,
        { 
        /* frontend */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag387,
        { 
        /* request */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* caller_generation */      /* parameter caller_generation */
        &__midl_frag387,
        { 
        /* caller_generation */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        96 /* 0x60 */,   /* Stack offset */
    }
};

static const __midl_frag130_t __midl_frag130 =
{ 
/* CompleteWorkerChannel */
    { 
    /* CompleteWorkerChannel */      /* procedure CompleteWorkerChannel */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 72 /* 0x48 */ ,  /* Stack size */
        (NDR64_UINT32) 76 /* 0x4c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 8 /* 0x8 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag294,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag295,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag387,
        { 
        /* request */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* exit_code */      /* parameter exit_code */
        &__midl_frag387,
        { 
        /* exit_code */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* io_error */      /* parameter io_error */
        &__midl_frag387,
        { 
        /* io_error */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* io_flags */      /* parameter io_flags */
        &__midl_frag387,
        { 
        /* io_flags */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    }
};

static const __midl_frag123_t __midl_frag123 =
{ 
/* WorkerIoReleaseEvent */
    { 
    /* WorkerIoReleaseEvent */      /* procedure WorkerIoReleaseEvent */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* release */      /* parameter release */
        &__midl_frag337,
        { 
        /* release */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag292,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag118_t __midl_frag118 =
{ 
/* WaitFrontendConsoleRestored */
    { 
    /* WaitFrontendConsoleRestored */      /* procedure WaitFrontendConsoleRestored */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 40 /* 0x28 */ ,  /* Stack size */
        (NDR64_UINT32) 44 /* 0x2c */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 4 /* 0x4 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    }
};

static const __midl_frag111_t __midl_frag111 =
{ 
/* FrontendCloseQuiesced */
    { 
    /* FrontendCloseQuiesced */      /* procedure FrontendCloseQuiesced */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag276,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag387,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag97_t __midl_frag97 =
{ 
/* FrontendStartupResult */
    { 
    /* FrontendStartupResult */      /* procedure FrontendStartupResult */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag384,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag385,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag387,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag270,
        { 
        /* capability */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* status */      /* parameter status */
        &__midl_frag387,
        { 
        /* status */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag94_t __midl_frag94 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag270
};

static const __midl_frag90_t __midl_frag90 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag385
};

static const __midl_frag89_t __midl_frag89 =
0x5    /* FC64_INT32 */;

static const __midl_frag88_t __midl_frag88 =
0x7    /* FC64_INT64 */;

static const __midl_frag86_t __midl_frag86 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag85_t __midl_frag85 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 65 /* 0x41 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag84_t __midl_frag84 =
{ 
/* StartFrontend */
    { 
    /* StartFrontend */      /* procedure StartFrontend */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 80 /* 0x50 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 9 /* 0x9 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag85,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag86,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag89,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* console_window */      /* parameter console_window */
        &__midl_frag88,
        { 
        /* console_window */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* borrowed */      /* parameter borrowed */
        &__midl_frag89,
        { 
        /* borrowed */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* root */      /* parameter root */
        &__midl_frag385,
        { 
        /* root */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* capability */      /* parameter capability */
        &__midl_frag270,
        { 
        /* capability */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* restored */      /* parameter restored */
        &__midl_frag270,
        { 
        /* restored */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag382,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    }
};

static const __midl_frag83_t __midl_frag83 =
0x13    /* FC64_ERROR_STATUS_T */;

static const __midl_frag81_t __midl_frag81 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag86
};

static const __midl_frag76_t __midl_frag76 =
{ 
/* StartNativeWorker */
    { 
    /* StartNativeWorker */      /* procedure StartNativeWorker */
        (NDR64_UINT32) 17694784 /* 0x10e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag85,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag86,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag89,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* native_type */      /* parameter native_type */
        &__midl_frag89,
        { 
        /* native_type */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* worker */      /* parameter worker */
        &__midl_frag86,
        { 
        /* worker */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag83,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag73_t __midl_frag73 =
{ 
/* *long */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag89
};

static const __midl_frag72_t __midl_frag72 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 2 /* 0x2 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag71_t __midl_frag71 =
{ 
/* *HANDLE */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag72
};

static const __midl_frag66_t __midl_frag66 =
0x11    /* FC64_WCHAR */;

static const __midl_frag65_t __midl_frag65 =
{ 
/*  */
    (NDR64_UINT32) 5 /* 0x5 */,
    { 
    /* struct _NDR64_RANGE_FORMAT */
        0xa4,    /* FC64_RANGE */
        0x5,    /* FC64_INT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_INT64) 2 /* 0x2 */,
        (NDR64_INT64) 65536 /* 0x10000 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 32 /* 0x20 */  /* Offset */
    }
};

static const __midl_frag64_t __midl_frag64 =
{ 
/* *wchar_t */
    { 
    /* *wchar_t */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 1 /* 0x1 */,
        { 
        /* *wchar_t */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 2 /* 0x2 */,
        &__midl_frag65
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 2 /* 0x2 */,
        &__midl_frag66
    }
};

static const __midl_frag63_t __midl_frag63 =
{ 
/* *wchar_t */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag64
};

static const __midl_frag62_t __midl_frag62 =
{ 
/* long */
    0xa4,    /* FC64_RANGE */
    0x5,    /* FC64_INT32 */
    (NDR64_UINT16) 0 /* 0x0 */,
    (NDR64_INT64) 2 /* 0x2 */,
    (NDR64_INT64) 65536 /* 0x10000 */
};

static const __midl_frag58_t __midl_frag58 =
{ 
/* StartVdmWorker */
    { 
    /* StartVdmWorker */      /* procedure StartVdmWorker */
        (NDR64_UINT32) 19791936 /* 0x12e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ServerCorrelation, HasExtensions */
        (NDR64_UINT32) 96 /* 0x60 */ ,  /* Stack size */
        (NDR64_UINT32) 60 /* 0x3c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 11 /* 0xb */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag85,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag86,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag89,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* environment_chars */      /* parameter environment_chars */
        &__midl_frag62,
        { 
        /* environment_chars */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* environment */      /* parameter environment */
        &__midl_frag64,
        { 
        /* environment */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], SimpleRef */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* show_window */      /* parameter show_window */
        &__midl_frag89,
        { 
        /* show_window */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* frontend */      /* parameter frontend */
        &__midl_frag72,
        { 
        /* frontend */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* worker */      /* parameter worker */
        &__midl_frag86,
        { 
        /* worker */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* parent */      /* parameter parent */
        &__midl_frag72,
        { 
        /* parent */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* parent_receipt */      /* parameter parent_receipt */
        &__midl_frag89,
        { 
        /* parent_receipt */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag83,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    }
};

static const __midl_frag48_t __midl_frag48 =
{ 
/* FinishNativeRequest */
    { 
    /* FinishNativeRequest */      /* procedure FinishNativeRequest */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 72 /* 0x48 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag85,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag86,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag89,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag89,
        { 
        /* request */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* exit_code */      /* parameter exit_code */
        &__midl_frag89,
        { 
        /* exit_code */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* target_completed */      /* parameter target_completed */
        &__midl_frag89,
        { 
        /* target_completed */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag83,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag40_t __midl_frag40 =
0x2    /* FC64_INT8 */;

static const __midl_frag39_t __midl_frag39 =
{ 
/*  */
    (NDR64_UINT32) 5 /* 0x5 */,
    { 
    /* struct _NDR64_RANGE_FORMAT */
        0xa4,    /* FC64_RANGE */
        0x5,    /* FC64_INT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_INT64) 0 /* 0x0 */,
        (NDR64_INT64) 1048576 /* 0x100000 */
    },
    { 
    /* struct _NDR64_EXPR_VAR */
        0x3,    /* FC_EXPR_VAR */
        0x6,    /* FC64_UINT32 */
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT32) 48 /* 0x30 */  /* Offset */
    }
};

static const __midl_frag38_t __midl_frag38 =
{ 
/* *byte */
    { 
    /* *byte */
        0x41,    /* FC64_CONF_ARRAY */
        (NDR64_UINT8) 0 /* 0x0 */,
        { 
        /* *byte */
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        },
        (NDR64_UINT8) 0 /* 0x0 */,
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag39
    },
    { 
    /* struct _NDR64_ARRAY_ELEMENT_INFO */
        (NDR64_UINT32) 1 /* 0x1 */,
        &__midl_frag40
    }
};

static const __midl_frag37_t __midl_frag37 =
{ 
/* *byte */
    0x21,    /* FC64_UP */
    (NDR64_UINT8) 32 /* 0x20 */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag38
};

static const __midl_frag36_t __midl_frag36 =
{ 
/* long */
    0xa4,    /* FC64_RANGE */
    0x5,    /* FC64_INT32 */
    (NDR64_UINT16) 0 /* 0x0 */,
    (NDR64_INT64) 0 /* 0x0 */,
    (NDR64_INT64) 1048576 /* 0x100000 */
};

static const __midl_frag35_t __midl_frag35 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 2 /* 0x2 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag34_t __midl_frag34 =
{ 
/* long */
    0xa4,    /* FC64_RANGE */
    0x5,    /* FC64_INT32 */
    (NDR64_UINT16) 0 /* 0x0 */,
    (NDR64_INT64) 1 /* 0x1 */,
    (NDR64_INT64) 2 /* 0x2 */
};

static const __midl_frag33_t __midl_frag33 =
0x5    /* FC64_INT32 */;

static const __midl_frag32_t __midl_frag32 =
{ 
/* HANDLE */
    0x3c,    /* FC64_SYSTEM_HANDLE */
    (NDR64_UINT8) 4 /* 0x4 */,
    (NDR64_UINT32) 0 /* 0x0 */,
};

static const __midl_frag31_t __midl_frag31 =
{ 
/* struct _NDR64_CONTEXT_HANDLE_FORMAT */
    0x70,    /* FC64_BIND_CONTEXT */
    (NDR64_UINT8) 65 /* 0x41 */,
    (NDR64_UINT8) 0 /* 0x0 */,
    (NDR64_UINT8) 0 /* 0x0 */
};

static const __midl_frag30_t __midl_frag30 =
{ 
/* SubmitNativeRequest */
    { 
    /* SubmitNativeRequest */      /* procedure SubmitNativeRequest */
        (NDR64_UINT32) 19791936 /* 0x12e0040 */,    /* explicit handle */ /* IsIntrepreted, ServerMustSize, ClientMustSize, HasReturn, ServerCorrelation, HasExtensions */
        (NDR64_UINT32) 96 /* 0x60 */ ,  /* Stack size */
        (NDR64_UINT32) 60 /* 0x3c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 11 /* 0xb */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag31,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag32,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag33,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* operation */      /* parameter operation */
        &__midl_frag34,
        { 
        /* operation */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend */      /* parameter frontend */
        &__midl_frag35,
        { 
        /* frontend */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* bytes */      /* parameter bytes */
        &__midl_frag36,
        { 
        /* bytes */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* payload */      /* parameter payload */
        &__midl_frag37,
        { 
        /* payload */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    },
    { 
    /* target */      /* parameter target */
        &__midl_frag86,
        { 
        /* target */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        64 /* 0x40 */,   /* Stack offset */
    },
    { 
    /* receipt */      /* parameter receipt */
        &__midl_frag72,
        { 
        /* receipt */
            1,
            1,
            0,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* MustSize, MustFree, [out], SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        72 /* 0x48 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag89,
        { 
        /* request */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        80 /* 0x50 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag83,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        88 /* 0x58 */,   /* Stack offset */
    }
};

static const __midl_frag29_t __midl_frag29 =
0x13    /* FC64_ERROR_STATUS_T */;

static const __midl_frag27_t __midl_frag27 =
0x7    /* FC64_INT64 */;

static const __midl_frag23_t __midl_frag23 =
{ 
/* FrontendIoDisconnected */
    { 
    /* FrontendIoDisconnected */      /* procedure FrontendIoDisconnected */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 56 /* 0x38 */ ,  /* Stack size */
        (NDR64_UINT32) 68 /* 0x44 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 6 /* 0x6 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag31,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag32,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag33,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* frontend_instance */      /* parameter frontend_instance */
        &__midl_frag27,
        { 
        /* frontend_instance */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* frontend_generation */      /* parameter frontend_generation */
        &__midl_frag33,
        { 
        /* frontend_generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag29,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    }
};

static const __midl_frag17_t __midl_frag17 =
{ 
/* WorkerIoTransition */
    { 
    /* WorkerIoTransition */      /* procedure WorkerIoTransition */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 48 /* 0x30 */ ,  /* Stack size */
        (NDR64_UINT32) 52 /* 0x34 */,
        (NDR64_UINT32) 8 /* 0x8 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 5 /* 0x5 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag31,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag32,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag33,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* action */      /* parameter action */
        &__midl_frag33,
        { 
        /* action */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag29,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    }
};

static const __midl_frag14_t __midl_frag14 =
{ 
/* *long */
    0x20,    /* FC64_RP */
    (NDR64_UINT8) 12 /* 0xc */,
    (NDR64_UINT16) 0 /* 0x0 */,
    &__midl_frag33
};

static const __midl_frag8_t __midl_frag8 =
{ 
/* WorkerIoCheckpoint */
    { 
    /* WorkerIoCheckpoint */      /* procedure WorkerIoCheckpoint */
        (NDR64_UINT32) 17563712 /* 0x10c0040 */,    /* explicit handle */ /* IsIntrepreted, ClientMustSize, HasReturn, HasExtensions */
        (NDR64_UINT32) 64 /* 0x40 */ ,  /* Stack size */
        (NDR64_UINT32) 60 /* 0x3c */,
        (NDR64_UINT32) 40 /* 0x28 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 0 /* 0x0 */,
        (NDR64_UINT16) 7 /* 0x7 */,
        (NDR64_UINT16) 8 /* 0x8 */
    },
    { 
    /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
        { 
        /* struct _NDR64_BIND_AND_NOTIFY_EXTENSION */
            0x72,    /* FC64_BIND_PRIMITIVE */
            (NDR64_UINT8) 0 /* 0x0 */,
            0 /* 0x0 */,   /* Stack offset */
            (NDR64_UINT8) 0 /* 0x0 */,
            (NDR64_UINT8) 0 /* 0x0 */
        },
        (NDR64_UINT16) 0 /* 0x0 */      /* Notify index */
    },
    { 
    /* connection */      /* parameter connection */
        &__midl_frag31,
        { 
        /* connection */
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in] */
        (NDR64_UINT16) 0 /* 0x0 */,
        8 /* 0x8 */,   /* Stack offset */
    },
    { 
    /* process */      /* parameter process */
        &__midl_frag32,
        { 
        /* process */
            1,
            1,
            0,
            1,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* MustSize, MustFree, [in], ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        16 /* 0x10 */,   /* Stack offset */
    },
    { 
    /* generation */      /* parameter generation */
        &__midl_frag33,
        { 
        /* generation */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        24 /* 0x18 */,   /* Stack offset */
    },
    { 
    /* reason */      /* parameter reason */
        &__midl_frag33,
        { 
        /* reason */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        32 /* 0x20 */,   /* Stack offset */
    },
    { 
    /* request */      /* parameter request */
        &__midl_frag33,
        { 
        /* request */
            0,
            0,
            0,
            1,
            0,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [in], Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        40 /* 0x28 */,   /* Stack offset */
    },
    { 
    /* decision */      /* parameter decision */
        &__midl_frag33,
        { 
        /* decision */
            0,
            0,
            0,
            0,
            1,
            0,
            1,
            0,
            1,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            1
        },    /* [out], Basetype, SimpleRef, UseCache */
        (NDR64_UINT16) 0 /* 0x0 */,
        48 /* 0x30 */,   /* Stack offset */
    },
    { 
    /* error_status_t */      /* parameter error_status_t */
        &__midl_frag29,
        { 
        /* error_status_t */
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            (NDR64_UINT16) 0 /* 0x0 */,
            0
        },    /* [out], IsReturn, Basetype, ByValue */
        (NDR64_UINT16) 0 /* 0x0 */,
        56 /* 0x38 */,   /* Stack offset */
    }
};

static const __midl_frag1_t __midl_frag1 =
(NDR64_UINT32) 0 /* 0x0 */;
#ifdef __cplusplus
}
#endif


#include "poppack.h"


static const FormatInfoRef vdm_service_Ndr64ProcTable[] =
    {
    &__midl_frag17,
    &__midl_frag8,
    &__midl_frag17,
    &__midl_frag23,
    &__midl_frag30,
    &__midl_frag48,
    &__midl_frag58,
    &__midl_frag76,
    &__midl_frag84,
    &__midl_frag97,
    &__midl_frag111,
    &__midl_frag111,
    &__midl_frag118,
    &__midl_frag123,
    &__midl_frag130,
    &__midl_frag139,
    &__midl_frag162,
    &__midl_frag194,
    &__midl_frag178,
    &__midl_frag186,
    &__midl_frag194,
    &__midl_frag200,
    &__midl_frag207,
    &__midl_frag217,
    &__midl_frag229,
    &__midl_frag240,
    &__midl_frag249,
    &__midl_frag256,
    &__midl_frag266,
    &__midl_frag272,
    &__midl_frag283,
    &__midl_frag293,
    &__midl_frag306,
    &__midl_frag319,
    &__midl_frag339,
    &__midl_frag361,
    &__midl_frag354,
    &__midl_frag361,
    &__midl_frag367,
    &__midl_frag376,
    &__midl_frag383,
    &__midl_frag405,
    &__midl_frag447,
    &__midl_frag456,
    &__midl_frag478,
    &__midl_frag486,
    &__midl_frag492,
    &__midl_frag498,
    &__midl_frag507,
    &__midl_frag599,
    &__midl_frag522,
    &__midl_frag534,
    &__midl_frag541,
    &__midl_frag556,
    &__midl_frag565,
    &__midl_frag599,
    &__midl_frag581,
    &__midl_frag590,
    &__midl_frag599,
    &__midl_frag605,
    &__midl_frag615,
    &__midl_frag638,
    &__midl_frag638
    };


#ifdef __cplusplus
namespace {
#endif
static const MIDL_STUB_DESC vdm_service_StubDesc = 
    {
    (void *)& vdm_service___RpcClientInterface,
    MIDL_user_allocate,
    MIDL_user_free,
    &vdm_service__MIDL_AutoBindHandle,
    0,
    0,
    0,
    0,
    legacy__MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0xa0000, /* Ndr library version */
    0,
    0x8010274, /* MIDL Version 8.1.628 */
    0,
    0,
    0,  /* notify & notify_flag routine table */
    0x2000001, /* MIDL flag */
    0, /* cs routines */
    (void *)& vdm_service_ProxyInfo,   /* proxy/server info */
    0
    };
#ifdef __cplusplus
}
#endif

static const MIDL_SYNTAX_INFO vdm_service_SyntaxInfo [  2 ] = 
    {
    {
    {{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}},
    0,
    legacy__MIDL_ProcFormatString.Format,
    vdm_service_FormatStringOffsetTable,
    legacy__MIDL_TypeFormatString.Format,
    0,
    0,
    0
    }
    ,{
    {{0x71710533,0xbeba,0x4937,{0x83,0x19,0xb5,0xdb,0xef,0x9c,0xcc,0x36}},{1,0}},
    0,
    0 ,
    (unsigned short *) vdm_service_Ndr64ProcTable,
    0,
    0,
    0,
    0
    }
    };

static const MIDL_STUBLESS_PROXY_INFO vdm_service_ProxyInfo =
    {
    &vdm_service_StubDesc,
    legacy__MIDL_ProcFormatString.Format,
    vdm_service_FormatStringOffsetTable,
    (RPC_SYNTAX_IDENTIFIER*)&_RpcTransferSyntax_2_0,
    2,
    (MIDL_SYNTAX_INFO*)vdm_service_SyntaxInfo
    
    };

#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* defined(_M_AMD64)*/

