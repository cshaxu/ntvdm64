/* Standalone BaseSrv composition. S3 integration in progress: the current
 * endpoint offers registration/first-VDM and typed stream receipts, not DOS launch.
 * It is build-only until command/resource/worker and idle gates are complete. */
#include "lib-win32/handle/duplicate.h"
#include <windows.h>
#include <rpc.h>
#include <rpcasync.h>
#include <stdio.h>
#include <stdlib.h>
#include "legacy.h"
#include "ntsrv-exe/transport/rpc_security.h"
#include "compat/include/vdmapi.h"
#include "ntsrv-exe/opennt/include/base_service.h"
#include "common/protocol/version.h"
#include "common/protocol/frontend_protocol.h"
#include "ntsrv-exe/idle_policy.h"
static broker_rpc_scope scope;
static OPENNT_BASE_SERVICE *service;
static SRWLOCK idle_lock=SRWLOCK_INIT;
static HANDLE idle_timer;
static BASESRV_IDLE_POLICY idle_policy;
error_status_t Server_SubmitNativeRequest(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG operation,HANDLE frontend,ULONG bytes,BYTE *payload,
    HANDLE *target,HANDLE *receipt,ULONG *request)
{
    DWORD pid,error;
    if(!target || !receipt || !request){error=ERROR_INVALID_PARAMETER;goto complete;}
    *target=*receipt=NULL;*request=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceSubmitNativeRequest(connection,pid,generation,operation,
        frontend,bytes,payload,target,receipt,request);
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FinishNativeRequest(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG request,ULONG *exit_code,ULONG *target_completed)
{
    DWORD pid,error;
    if(!exit_code || !target_completed){error=ERROR_INVALID_PARAMETER;goto complete;}
    *exit_code=*target_completed=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceFinishNativeRequest(connection,pid,generation,
        request,exit_code,target_completed);
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_StartVdmWorker(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG characters,WCHAR *environment,
    ULONG show,HANDLE frontend,HANDLE *worker,HANDLE *parent,ULONG *receipt)
{
    DWORD pid,error;
    if(!worker || !parent || !receipt){error=ERROR_INVALID_PARAMETER;goto complete;}
    *worker=*parent=NULL;*receipt=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceStartVdmWorker(connection,pid,generation,
        characters,environment,show,frontend,worker,parent,receipt);
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_StartNativeWorker(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG native_type,HANDLE *worker)
{
    DWORD pid,error;
    if(!worker){error=ERROR_INVALID_PARAMETER;goto complete;}
    *worker=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceStartNativeWorker(connection,pid,generation,native_type,worker);
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_StartFrontend(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG window,ULONG borrowed,
    HANDLE *root,HANDLE *capability,HANDLE *restored)
{
    DWORD pid,error;
    if(!root || !capability || !restored){error=ERROR_INVALID_PARAMETER;goto complete;}
    *root=*capability=*restored=NULL;
    if(borrowed>1){error=ERROR_INVALID_PARAMETER;goto complete;}
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceStartFrontend(connection,pid,generation,
        (uint64_t)window,borrowed!=0,root,capability,restored);
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendCloseQuiesced(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceValidateNativeFrontend(connection,pid,generation,&key);
    if(!error)error=OpenNtBaseServiceFrontendCloseQuiesced(connection,pid,generation);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendConsoleRestored(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceValidateNativeFrontend(connection,pid,generation,&key);
    if(!error)error=OpenNtBaseServiceFrontendConsoleRestored(connection,pid,generation);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendStartupResult(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,HANDLE capability,ULONG status)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceFrontendStartupResult(connection,pid,generation,
        capability,status);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_WaitFrontendConsoleRestored(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,unsigned long generation)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceWaitFrontendConsoleRestored(connection,pid,generation);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
#define BASE_CHECK_REPLY_BYTES 40u
#define BASE_UPDATE_REPLY_BYTES 32u

static __declspec(noreturn) void basesrv_idle_fatal(PCSTR operation,DWORD error)
{
    if (!error) error=ERROR_GEN_FAILURE;
    fprintf(stderr,"ntsrv: fatal %s: %lu\n",operation,error); fflush(stderr);
    /* Broken retention/stop machinery cannot leave a silently resident broker.
     * Do not run DLL teardown while another RPC thread may hold its locks. */
    TerminateProcess(GetCurrentProcess(),error);
    abort();
}
/* idle_lock serializes Connect admission with the final empty decision.
 * Management observations never cancel or restart this five-second grace. */
static void basesrv_schedule_empty_locked(void)
{
    LARGE_INTEGER due;
    if (!idle_policy.stopping && !idle_policy.deadline && !idle_policy.pending &&
        service && basesrv_idle_arm(&idle_policy,GetTickCount64(),OpenNtBaseServiceIsEmpty(service))) {
        due.QuadPart=-(LONGLONG)BASESRV_EMPTY_GRACE_MS*10000;
        if (!SetWaitableTimer(idle_timer,&due,0,NULL,NULL,FALSE))
            basesrv_idle_fatal("SetWaitableTimer",GetLastError());
    }
}
static void basesrv_schedule_empty_stop(void)
{
    AcquireSRWLockExclusive(&idle_lock);
    basesrv_schedule_empty_locked();
    ReleaseSRWLockExclusive(&idle_lock);
}
static DWORD basesrv_begin_connect(void)
{
    DWORD error=ERROR_SUCCESS;
    AcquireSRWLockExclusive(&idle_lock);
    error=basesrv_idle_connect(&idle_policy);
    if(error==ERROR_ARITHMETIC_OVERFLOW)basesrv_idle_fatal("Connect count",error);
    if(!error) {
        if (!CancelWaitableTimer(idle_timer))
            basesrv_idle_fatal("CancelWaitableTimer",GetLastError());
    }
    ReleaseSRWLockExclusive(&idle_lock);
    return error;
}
static void basesrv_end_connect(void)
{
    AcquireSRWLockExclusive(&idle_lock);
    --idle_policy.pending;
    basesrv_schedule_empty_locked();
    ReleaseSRWLockExclusive(&idle_lock);
}
static BOOL basesrv_claim_empty_stop(void)
{
    BOOL stop=FALSE;
    ULONGLONG now;
    LARGE_INTEGER due;
    AcquireSRWLockExclusive(&idle_lock);
    now=GetTickCount64();
    if (!idle_policy.pending && idle_policy.deadline) {
        BASESRV_IDLE_DECISION decision=basesrv_idle_expire(&idle_policy,now,
            now>=idle_policy.deadline && OpenNtBaseServiceIsEmpty(service));
        if (decision==BASESRV_IDLE_REARM) {
            /* A wake consumed just before Connect rearmed the same timer. */
            due.QuadPart=-(LONGLONG)(idle_policy.deadline-now)*10000;
            if (!SetWaitableTimer(idle_timer,&due,0,NULL,NULL,FALSE))
                basesrv_idle_fatal("SetWaitableTimer",GetLastError());
        } else if (decision==BASESRV_IDLE_STOP) {
            stop=TRUE;
        }
    }
    ReleaseSRWLockExclusive(&idle_lock);
    return stop;
}
static DWORD basesrv_management_version(ULONG protocol,const unsigned char application_version[32])
{
    static const unsigned char expected[APP_VERSION_BYTES]=APP_VERSION;
    if (protocol!=APP_PROTOCOL_VERSION || !application_version ||
        memcmp(application_version,expected,sizeof(expected))) return ERROR_REVISION_MISMATCH;
    return ERROR_SUCCESS;
}
/* The service invokes this only after the retained, authenticated worker
 * process has actually exited and the original BaseSrv cleanup has run. */
static void WINAPI basesrv_worker_terminated(void *context)
{
    (void)context;
    basesrv_schedule_empty_stop();
}
/* Complete every finite RPC reply, including authentication/validation failure. */
static error_status_t basesrv_complete_rpc(PRPC_ASYNC_STATE async,DWORD error)
{
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_AttachFile(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG role,HANDLE stream,ULONG *receipt)
{
    DWORD pid,error;
    *receipt=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    return basesrv_complete_rpc(async,OpenNtBaseServiceAttachStream(connection,pid,generation,role,stream,receipt));
}
error_status_t Server_AttachPipe(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG role,HANDLE stream,ULONG *receipt)
{
    return Server_AttachFile(async,binding,connection,process,generation,role,stream,receipt);
}
error_status_t Server_RevokeStream(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG receipt)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    return basesrv_complete_rpc(async,OpenNtBaseServiceRevokeStream(connection,pid,generation,receipt));
}
error_status_t Server_TaskSnapshot(PRPC_ASYNC_STATE async,handle_t binding,HANDLE process,ULONG protocol,
    unsigned char application_version[32],ULONG *count,DTASKMGR_WORKER **entries)
{
    OPENNT_BASE_WORKER_INFO *local=NULL;
    DWORD pid,error;
    uint32_t actual=0,index;
    uint64_t service_epoch=0;
    if (!count || !entries) return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    *count=0; *entries=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    error=basesrv_management_version(protocol,application_version);
    if (!error) error=OpenNtBaseServiceSnapshotCopy(service,&service_epoch,&local,&actual);
    if (error) goto done;
    if (actual) {
        if ((size_t)actual>SIZE_MAX/sizeof(**entries)) {
            error=ERROR_ARITHMETIC_OVERFLOW;goto done;
        }
        *entries=MIDL_user_allocate(sizeof(**entries)*(size_t)actual);
        if (!*entries) { error=ERROR_NOT_ENOUGH_MEMORY; goto done; }
        for (index=0;index<actual;++index) {
            (*entries)[index].key.instance=(hyper)local[index].key.instance;
            (*entries)[index].key.category=local[index].key.category;
            (*entries)[index].key.generation=local[index].key.generation;
            (*entries)[index].key.object=(hyper)local[index].key.object;
            (*entries)[index].parent.instance=(hyper)local[index].parent.instance;
            (*entries)[index].parent.category=local[index].parent.category;
            (*entries)[index].parent.generation=local[index].parent.generation;
            (*entries)[index].parent.object=(hyper)local[index].parent.object;
            (*entries)[index].depth=local[index].depth;
            (*entries)[index].display_state=local[index].display_state;
            (*entries)[index].actions=local[index].actions;
            (*entries)[index].process_id=local[index].process_id;
            (*entries)[index].kind=local[index].kind;
            (*entries)[index].state=local[index].state;
            (*entries)[index].started_filetime=(hyper)local[index].started_filetime;
            (*entries)[index].task=local[index].task;
            (*entries)[index].stack_depth=local[index].stack_depth;
            (*entries)[index].frontend_vm=(hyper)local[index].frontend_vm;
            memcpy((*entries)[index].image,local[index].image,sizeof(local[index].image));
        }
    }
    *count=actual;
done:
    if (local) HeapFree(GetProcessHeap(),0,local);
    if (error && *entries) { MIDL_user_free(*entries); *entries=NULL; }
    if (error) *count=0;
    return basesrv_complete_rpc(async,error);
}
error_status_t Server_WorkerTaskTrace(PRPC_ASYNC_STATE async,handle_t binding,HANDLE process,ULONG protocol,
    unsigned char application_version[32],DTASKMGR_KEY *key,ULONG *coverage,
    ULONG *count,WORKER_TRACE_NODE **entries)
{
    OPENNT_BASE_MANAGEMENT_KEY selector;
    common_task_trace_node *local=NULL;
    uint32_t actual=0,flags=0;
    DWORD pid,error;
    if(!coverage || !count || !entries)return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    *coverage=0;*count=0;*entries=NULL;
    if(!key)return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    selector.instance=(uint64_t)key->instance;selector.category=key->category;
    selector.generation=key->generation;selector.object=(uint64_t)key->object;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=basesrv_management_version(protocol,application_version);
    if(!error)error=OpenNtBaseServiceTaskTrace(service,&selector,&flags,&local,&actual);
    if(!error && actual) {
        /* Identical fixed copied layouts; never serialize native pointers. */
        C_ASSERT(sizeof(WORKER_TRACE_NODE)==sizeof(common_task_trace_node));
        *entries=MIDL_user_allocate((size_t)actual*sizeof(**entries));
        if(!*entries)error=ERROR_NOT_ENOUGH_MEMORY;
        else memcpy(*entries,local,(size_t)actual*sizeof(**entries));
    }
    if(local)HeapFree(GetProcessHeap(),0,local);
    if(!error){*coverage=flags;*count=actual;}
    return basesrv_complete_rpc(async,error);
}
static DWORD basesrv_observe_native_creation(handle_t binding,HANDLE reporter,ULONG protocol,
    unsigned char application_version[32],HANDLE child,ULONG flags,hyper *node)
{
    DWORD pid,error;uint64_t identity=0;
    if(!node)return ERROR_INVALID_PARAMETER;
    *node=0;
    error=broker_rpc_peer_process(&scope,binding,reporter,&pid);
    if(!error)error=basesrv_management_version(protocol,application_version);
    if(!error)error=OpenNtBaseServiceObserveNativeCreation(service,reporter,child,flags,&identity);
    if(!error)*node=(hyper)identity;
    return error; /* Observation never schedules empty-service retirement. */
}
error_status_t Server_ObserveNativeCreationAsync(PRPC_ASYNC_STATE async,handle_t binding,HANDLE reporter,
    ULONG protocol,unsigned char application_version[32],HANDLE child,ULONG flags,hyper *node)
{
    DWORD result=basesrv_observe_native_creation(binding,reporter,protocol,application_version,child,flags,node);
    /* Same authenticated fact handler; async completion is not task completion. */
    (void)RpcAsyncCompleteCall(async,&result);
    return ERROR_SUCCESS; /* Actual reply is supplied through async completion. */
}
error_status_t Server_ObserveDosEventAsync(PRPC_ASYNC_STATE async,handle_t binding,
    VDM_CONNECTION connection,HANDLE process,ULONG generation,ULONG protocol,
    unsigned char application_version[32],DOS_OBSERVATION_FACT *fact,ULONG gap)
{
    DWORD pid,result;common_dos_observation copied;
    typedef char fact_abi[sizeof(copied)==sizeof(*fact)?1:-1];
    result=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!result)result=basesrv_management_version(protocol,application_version);
    if(!result && (!fact || gap>1))result=ERROR_INVALID_PARAMETER;
    if(!result) {
        memcpy(&copied,fact,sizeof(copied));
        result=OpenNtBaseServiceObserveDosEvent(connection,pid,generation,&copied,gap!=0);
    }
    (void)RpcAsyncCompleteCall(async,&result);
    return ERROR_SUCCESS;
}

error_status_t Server_CloseManagementNode(PRPC_ASYNC_STATE async,handle_t binding,HANDLE process,ULONG protocol,
    unsigned char application_version[32],DTASKMGR_KEY *key)
{
    DWORD pid,error;
    OPENNT_BASE_MANAGEMENT_KEY selector;
    if(!key){error=ERROR_INVALID_PARAMETER;goto complete;}
    selector.instance=(uint64_t)key->instance;selector.category=key->category;
    selector.generation=key->generation;selector.object=(uint64_t)key->object;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) goto complete;
    error=basesrv_management_version(protocol,application_version);
    if (!error) error=OpenNtBaseServiceCloseManagementNode(service,&selector);
    basesrv_schedule_empty_stop();
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
void *__RPC_USER midl_user_allocate(size_t bytes) { return malloc(bytes); }
void __RPC_USER midl_user_free(void *value) { free(value); }
void __RPC_USER VDM_CONNECTION_rundown(VDM_CONNECTION connection)
{
    /* No tasks yet; disconnect also drains retained input stream receipts. */
    if (OpenNtBaseServiceDisconnect(connection)) RaiseFailFastException(NULL,NULL,0);
    basesrv_schedule_empty_stop();
    fputs("basesrv: connection rundown completed\n",stderr); fflush(stderr);
}
static RPC_STATUS RPC_ENTRY authorize(RPC_IF_HANDLE interfaceId,void *binding)
{
    (void)interfaceId;
    return broker_rpc_authorize(&scope,binding);
}
/* RPC [out, system_handle] consumes its server-side handle.  Service
 * receipts remain owned by BaseSrv; export only independent duplicates. */
static DWORD export_handles(const HANDLE *source,ULONG count,HANDLE **output)
{
    ULONG index;
    DWORD error;
    *output=NULL;
    if (!count) return ERROR_SUCCESS;
    *output=MIDL_user_allocate(sizeof(**output)*count);
    if (!*output) return ERROR_NOT_ENOUGH_MEMORY;
    for (index=0;index<count;++index) {
        (*output)[index]=NULL;
        if (!source[index]) continue;
        error=win32_handle_duplicate(GetCurrentProcess(),source[index],GetCurrentProcess(),&(*output)[index]);
        if (error) {
            while (index) { --index; if ((*output)[index]) CloseHandle((*output)[index]); }
            MIDL_user_free(*output); *output=NULL;
            return error;
        }
    }
    return ERROR_SUCCESS;
}
error_status_t Server_Connect(PRPC_ASYNC_STATE async,handle_t binding,HANDLE process,ULONG protocol,
    unsigned char application_version[32],ULONG *server_protocol,
    unsigned char server_version[32],VDM_CONNECTION *connection,ULONG *generation,
    HANDLE *server,HANDLE *shutdown,HANDLE *console_close,HANDLE *wow_task_close)
{
    static const unsigned char expected[APP_VERSION_BYTES]=APP_VERSION;
    DWORD pid;
    RPC_STATUS status;
    *connection=NULL; *generation=0;
    *server=NULL;*shutdown=NULL;*console_close=NULL;*wow_task_close=NULL;
    *server_protocol=APP_PROTOCOL_VERSION;
    memcpy(server_version,expected,sizeof(expected));
    status=basesrv_begin_connect();
    if (status) goto complete;
    /* Every admitted attempt, including identity/version failure or an RPC
     * exception, releases its transient hold and rechecks empty retention. */
    __try {
        status=broker_rpc_peer_process(&scope,binding,process,&pid);
        if (status) __leave;
        if (protocol!=APP_PROTOCOL_VERSION || memcmp(application_version,expected,sizeof(expected))) {
            fprintf(stderr,"basesrv: version mismatch: local protocol=%u app=%s; peer protocol=%lu app=%.32s\n",
                APP_PROTOCOL_VERSION,APP_VERSION,protocol,(const char *)application_version);
            status=ERROR_REVISION_MISMATCH;
            __leave;
        }
        status=OpenNtBaseServiceConnect(service,process,(OPENNT_BASE_CONNECTION **)connection,generation);
        if(status)__leave;
        status=OpenNtBaseServiceConnectionControls(*connection,pid,*generation,shutdown,console_close,wow_task_close);
        if(!status && !DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),
            server,SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,0))status=GetLastError();
        if(status) {
            if(*shutdown)CloseHandle(*shutdown);
            if(*console_close)CloseHandle(*console_close);
            if(*wow_task_close)CloseHandle(*wow_task_close);
            *shutdown=NULL;*console_close=NULL;*wow_task_close=NULL;
            VDM_CONNECTION_rundown(*connection);
            *connection=NULL;*generation=0;
        }
    } __finally {
        basesrv_end_connect();
    }
complete:
    (void)RpcAsyncCompleteCall(async,&status);
    return ERROR_SUCCESS;
}
error_status_t Server_BindWowTask(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG task,USHORT htask,hyper *identity)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    *identity=0;
    if(!error)error=OpenNtBaseServiceBindWowTask(connection,pid,generation,task,htask,(uint64_t *)identity);
    (void)RpcAsyncCompleteCall(async,&error);return ERROR_SUCCESS;
}
error_status_t Server_RetireWowTask(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,hyper identity)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRetireWowTask(connection,pid,generation,(uint64_t)identity);
    (void)RpcAsyncCompleteCall(async,&error);return ERROR_SUCCESS;
}
error_status_t Server_TakeWowTaskClose(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,hyper *identity)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    *identity=0;
    if(!error)error=OpenNtBaseServiceTakeWowTaskClose(connection,pid,generation,(uint64_t *)identity);
    (void)RpcAsyncCompleteCall(async,&error);return ERROR_SUCCESS;
}
error_status_t Server_FailWowTaskClose(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,hyper identity)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceFailWowTaskClose(connection,pid,generation,(uint64_t)identity);
    (void)RpcAsyncCompleteCall(async,&error);return ERROR_SUCCESS;
}
error_status_t Server_ReportConsoleMembers(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG count,ULONG *members)
{
    DWORD pid;
    RPC_STATUS status=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!status)status=OpenNtBaseServiceReportConsoleMembers(connection,pid,generation,count,members);
    (void)RpcAsyncCompleteCall(async,&status);
    return ERROR_SUCCESS;
}
error_status_t Server_GetNextNativeCommand(handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG capacity,BYTE *payload,ULONG *bytes,HANDLE *caller_process,HANDLE *execution,HANDLE *frontend,ULONG *request,ULONG *caller_generation)
{
    DWORD pid,error;
    *bytes=0;*caller_process=NULL;*execution=NULL;*frontend=NULL;*request=0;*caller_generation=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    return error ? error : OpenNtBaseServiceGetNextNativeCommand(connection,pid,generation,
        capacity,payload,bytes,caller_process,execution,frontend,request,caller_generation);
}
error_status_t Server_NativeStartupResult(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG caller_generation,ULONG request,ULONG status,HANDLE target,HANDLE receipt)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceNativeStartupResult(connection,pid,generation,
        caller_generation,request,status,target,receipt);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_WorkerFrontendCapability(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE *capability)
{
    DWORD pid,error;
    *capability=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceWorkerFrontendCapability(connection,pid,generation,capability);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_AcquireConsoleContext(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE frontend,HANDLE *capability)
{
    DWORD pid,error;
    *capability=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceAcquireConsoleContext(connection,pid,generation,
        frontend,capability);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_BindConsoleContext(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE capability)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceBindConsoleContext(connection,pid,generation,capability);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_RegisterNativeBackend(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE frontend)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRegisterNativeBackend(connection,pid,generation,frontend);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}

error_status_t Server_RequestParticipantExit(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG exit_scope)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRequestParticipantExit(connection,pid,generation,exit_scope);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_WorkerIoCheckpoint(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG reason,ULONG request,ULONG *decision)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    *decision=WORKER_IO_KEEP;
    if(!error)error=OpenNtBaseServiceWorkerIoCheckpoint(connection,pid,generation,reason,request,decision);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_WorkerIoTransition(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG action)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceWorkerIoTransition(connection,pid,generation,action);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendIoDisconnected(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceFrontendIoDisconnectedInstance(connection,pid,generation,&key);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_WorkerIoReleaseEvent(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE *release)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    *release=NULL;
    if(!error)error=OpenNtBaseServiceWorkerIoReleaseEvent(connection,pid,generation,release);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_CompleteWorkerChannel(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG request,ULONG exit_code,ULONG io_error,ULONG io_flags)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceCompleteNativeRequest(connection,pid,generation,request,exit_code,io_error,io_flags);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_BindNativeTarget(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG request,HANDLE target,HANDLE receipt)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceBindNativeTarget(connection,pid,generation,request,target,receipt);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_RegisterFrontendRoot(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE capability,LONGLONG *frontend_instance,ULONG *frontend_generation)
{
    common_frontend_key key={0};
    *frontend_instance=0;*frontend_generation=0;
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRegisterNativeFrontend(connection,pid,generation,capability,&key);
    if(!error){*frontend_instance=(LONGLONG)key.instance;*frontend_generation=key.generation;}
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_RegisterFrontendLease(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation,LONGLONG console_window,ULONG creator_pid,ULONG borrowed,
    HANDLE retire,HANDLE restored)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceValidateNativeFrontend(connection,pid,generation,&key);
    if(!error)error=OpenNtBaseServiceRegisterFrontendLease(connection,pid,generation,
        (uint64_t)console_window,creator_pid,borrowed!=0,retire,restored);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendJoinCandidate(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation,ULONG *nonce,ULONG *candidate_pid)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    *nonce=*candidate_pid=0;
    if(!error)error=OpenNtBaseServiceValidateNativeFrontend(connection,pid,generation,&key);
    if(!error)error=OpenNtBaseServiceFrontendJoinCandidate(connection,pid,generation,nonce,candidate_pid);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendJoinDecision(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation,ULONG nonce,ULONG same_console)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceValidateNativeFrontend(connection,pid,generation,&key);
    if(!error)error=OpenNtBaseServiceFrontendJoinDecision(connection,pid,generation,nonce,same_console!=0);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendLeaseReady(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceValidateNativeFrontend(connection,pid,generation,&key);
    if(!error)error=OpenNtBaseServiceFrontendLeaseReady(connection,pid,generation);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_RetainFrontendRoot(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE capability,HANDLE *root,ULONG *root_generation)
{
    DWORD pid,error;
    *root=NULL;*root_generation=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRetainFrontendRoot(connection,pid,generation,
        capability,root,root_generation);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_RetireWorkerlessFrontend(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation,ULONG *retired)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error;
    if(!retired){error=ERROR_INVALID_PARAMETER;goto complete;}
    *retired=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRetireFrontendInstance(connection,pid,generation,&key,retired);
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendStateChanged(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation,HANDLE *state_changed)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error;
    if(!state_changed){error=ERROR_INVALID_PARAMETER;goto complete;}
    *state_changed=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceFrontendStateChangedInstance(connection,pid,generation,&key,state_changed);
complete:
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_RequestFrontend(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE capability)
{
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRequestFrontend(connection,pid,generation,capability);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_FrontendRequest(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation,ULONG *request,HANDLE *worker)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error;
    *request=0;*worker=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceFrontendRequestInstance(connection,pid,generation,&key,request,worker);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_AttachFrontendRequest(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,LONGLONG frontend_instance,ULONG frontend_generation,ULONG request,HANDLE channel,HANDLE ready)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceAttachFrontendRequestInstance(connection,pid,generation,&key,request,channel,ready);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_TakeFrontend(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE *pipe,HANDLE *frontend,ULONG *frontend_generation,HANDLE *ready)
{
    DWORD pid,error;
    *pipe=NULL; *frontend=NULL; *frontend_generation=0;*ready=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceTakeFrontend(connection,pid,generation,
        pipe,frontend,frontend_generation,ready);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_WaitFrontend(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,HANDLE *pipe,HANDLE *frontend,ULONG *frontend_generation,HANDLE *ready)
{
    DWORD pid,error;
    *pipe=NULL;*frontend=NULL;*frontend_generation=0;*ready=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceWaitFrontend(connection,pid,generation,
        pipe,frontend,frontend_generation,ready);
    (void)RpcAsyncCompleteCall(async,&error);
    return ERROR_SUCCESS;
}
error_status_t Server_First(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,ULONG generation,ULONG *first)
{
    DWORD pid;
    RPC_STATUS status;
    *first=0;
    status=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (status) return basesrv_complete_rpc(async,status);
    status=OpenNtBaseServiceFirst(connection,pid,generation,first);
    return basesrv_complete_rpc(async,status);
}
error_status_t Server_RegisterWowExec(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG window)
{
    DWORD pid;
    RPC_STATUS status=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (status) return basesrv_complete_rpc(async,status);
    return basesrv_complete_rpc(async,OpenNtBaseServiceRegisterWowExec(connection,pid,generation,window));
}
error_status_t Server_WowStarted(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG task)
{
    DWORD pid;
    RPC_STATUS status=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (status) return basesrv_complete_rpc(async,status);
    return basesrv_complete_rpc(async,OpenNtBaseServiceWowStarted(connection,pid,generation,task));
}
error_status_t Server_WowStartup(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,
    HANDLE process,ULONG generation,ULONG parent_receipt,HANDLE *event,ULONG *started)
{
    DWORD pid;
    BOOL value=FALSE;
    RPC_STATUS status;
    *event=NULL; *started=0;
    status=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (status) return basesrv_complete_rpc(async,status);
    /* Service returns an owned wait-only duplicate; RPC consumes that copy. */
    status=OpenNtBaseServiceWowStartup(connection,pid,generation,parent_receipt,event,&value);
    if (!status) *started=value ? 1u : 0u;
    return basesrv_complete_rpc(async,status);
}
error_status_t Server_Check(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG requestBytes,unsigned char *request,ULONG *parentEventCount,
    HANDLE **parentEvents,ULONG *parentReceipt,ULONG *replyBytes,
    unsigned char reply[BASE_CHECK_REPLY_BYTES])
{
    DWORD pid,error;
    uint32_t required=0;
    uint32_t parent_receipt=0;
    HANDLE parent_event=NULL;
    if (!parentEventCount || !parentEvents || !parentReceipt || !replyBytes || !reply) return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    *parentEventCount=0;*parentEvents=NULL;*parentReceipt=0;*replyBytes=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    error=OpenNtBaseServiceCheck(connection,pid,generation,request,requestBytes,
        reply,BASE_CHECK_REPLY_BYTES,&required,&parent_event,&parent_receipt);
    if (!error && required!=BASE_CHECK_REPLY_BYTES) return basesrv_complete_rpc(async,ERROR_INVALID_DATA);
    if (!error && parent_event) {
        error=export_handles(&parent_event,1,parentEvents);
        if (error) return basesrv_complete_rpc(async,error);
        *parentEventCount=1;
    }
    if (!error) *parentReceipt=(ULONG)parent_receipt;
    if (!error) *replyBytes=required;
    return basesrv_complete_rpc(async,error);
}
error_status_t Server_Get(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG requestBytes,unsigned char *request,ULONG *waitEventCount,HANDLE **waitEvents,
    ULONG *pipeStreamMask,ULONG *pipeStreamCount,HANDLE **pipeStreams,
    ULONG *fileStreamMask,ULONG *fileStreamCount,HANDLE **fileStreams,ULONG *replyBytes,
    unsigned char **reply)
{
    DWORD pid,error;
    uint32_t bytes=0;
    ULONG standard_count=0;
    ULONG index;
    HANDLE pipe_standard[3]={NULL,NULL,NULL};
    HANDLE file_standard[3]={NULL,NULL,NULL};
    void *source_reply=NULL;
    HANDLE wait_event=NULL;
    HANDLE standard[3]={NULL,NULL,NULL};
    if (!waitEventCount || !waitEvents || !pipeStreamMask || !pipeStreamCount || !pipeStreams ||
        !fileStreamMask || !fileStreamCount || !fileStreams || !replyBytes || !reply) return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    *waitEventCount=0; *waitEvents=NULL;
    *pipeStreamMask=0; *pipeStreamCount=0; *pipeStreams=NULL;
    *fileStreamMask=0; *fileStreamCount=0; *fileStreams=NULL;
    *replyBytes=0; *reply=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    error=OpenNtBaseServiceGet(connection,pid,generation,request,requestBytes,
        &source_reply,&bytes,&wait_event,standard,&standard_count);
    if (error) {
        fprintf(stderr,"basesrv: Get rejected %lu\n",error); fflush(stderr);
        return basesrv_complete_rpc(async,error);
    }
    if (wait_event) {
        error=export_handles(&wait_event,1,waitEvents);
        if (error) {
            OpenNtBaseServiceReleaseCommandReply(source_reply);
            return basesrv_complete_rpc(async,error);
        }
        *waitEventCount=1;
    }
    if (!bytes || !(*reply=MIDL_user_allocate(bytes))) {
        if (*waitEvents) { CloseHandle(**waitEvents); MIDL_user_free(*waitEvents);
            *waitEvents=NULL; *waitEventCount=0; }
        OpenNtBaseServiceReleaseCommandReply(source_reply);
        return basesrv_complete_rpc(async,ERROR_NOT_ENOUGH_MEMORY);
    }
    memcpy(*reply,source_reply,bytes);
    for (index=0;index<standard_count;++index) if (standard[index]) {
        if (GetFileType(standard[index])==FILE_TYPE_PIPE) {
            pipe_standard[*pipeStreamCount]=standard[index];
            *pipeStreamMask|=1u<<index;
            ++*pipeStreamCount;
        } else {
            file_standard[*fileStreamCount]=standard[index];
            *fileStreamMask|=1u<<index;
            ++*fileStreamCount;
        }
    }
    error=export_handles(pipe_standard,*pipeStreamCount,pipeStreams);
    if (!error) error=export_handles(file_standard,*fileStreamCount,fileStreams);
    if (error) {
        ULONG close_index;
        MIDL_user_free(*reply); *reply=NULL;
        if (*pipeStreams) {
            for (close_index=0;close_index<*pipeStreamCount;++close_index)
                if ((*pipeStreams)[close_index]) CloseHandle((*pipeStreams)[close_index]);
            MIDL_user_free(*pipeStreams); *pipeStreams=NULL;
        }
        if (*fileStreams) {
            for (close_index=0;close_index<*fileStreamCount;++close_index)
                if ((*fileStreams)[close_index]) CloseHandle((*fileStreams)[close_index]);
            MIDL_user_free(*fileStreams); *fileStreams=NULL;
        }
        *pipeStreamMask=*pipeStreamCount=*fileStreamMask=*fileStreamCount=0;
        if (*waitEvents) { CloseHandle(**waitEvents); MIDL_user_free(*waitEvents);
            *waitEvents=NULL; *waitEventCount=0; }
        OpenNtBaseServiceReleaseCommandReply(source_reply); return basesrv_complete_rpc(async,error);
    }
    /* Get consumed reservation ownership.  RPC has independently duplicated
     * each selected resource into the worker, so close the broker's source
     * copies now; do not let a resident broker keep a host-pipe writer open. */
    for (index=0;index<standard_count;++index) {
        ULONG previous;
        if (!standard[index]) continue;
        for (previous=0;previous<index;++previous)
            if (standard[previous]==standard[index]) break;
        if (previous==index) CloseHandle(standard[index]);
    }
    OpenNtBaseServiceReleaseCommandReply(source_reply);
    *replyBytes=bytes;
    return basesrv_complete_rpc(async,ERROR_SUCCESS);
}
error_status_t Server_Exit(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG isWow,ULONG wowTask,ULONG *closeWorkerWait)
{
    DWORD pid,error;
    BOOL close_wait=FALSE;
    unsigned long close_wait_wire=0;
    if (!closeWorkerWait || isWow>1u) return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    *closeWorkerWait=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    error=OpenNtBaseServiceExit(connection,pid,generation,(BOOL)isWow,wowTask,&close_wait);
    if (!error) {
        close_wait_wire=close_wait ? 1u : 0u;
        *closeWorkerWait=close_wait_wire;
    }
    return basesrv_complete_rpc(async,error);
}
error_status_t Server_Update(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG requestBytes,unsigned char *request,ULONG *parentEventCount,HANDLE **parentEvents,
    ULONG *parentReceipt,ULONG *replyBytes,unsigned char reply[BASE_UPDATE_REPLY_BYTES])
{
    DWORD pid,error;
    uint32_t required=0;
    uint32_t parent_receipt=0;
    HANDLE parent_event=NULL;
    if (!parentEventCount || !parentEvents || !parentReceipt || !replyBytes || !reply) return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    *parentEventCount=0; *parentEvents=NULL; *parentReceipt=0; *replyBytes=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    error=OpenNtBaseServiceUpdate(connection,pid,generation,request,requestBytes,reply,
        BASE_UPDATE_REPLY_BYTES,&required,&parent_event,&parent_receipt);
    if (error) {
        fprintf(stderr,"basesrv: Update rejected %lu\n",error); fflush(stderr);
        return basesrv_complete_rpc(async,error);
    }
    if (required!=BASE_UPDATE_REPLY_BYTES) return basesrv_complete_rpc(async,ERROR_INVALID_DATA);
    if (parent_event) {
        error=export_handles(&parent_event,1,parentEvents);
        if (error) return basesrv_complete_rpc(async,error);
        *parentEventCount=1;
    }
    *parentReceipt=(ULONG)parent_receipt;
    *replyBytes=required;
    return basesrv_complete_rpc(async,ERROR_SUCCESS);
}
error_status_t Server_ExitCode(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG parentReceipt,ULONG *exitCode)
{
    DWORD pid,error;
    if (!exitCode || !parentReceipt) return basesrv_complete_rpc(async,ERROR_INVALID_PARAMETER);
    *exitCode=0;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    error=OpenNtBaseServiceExitCode(connection,pid,generation,parentReceipt,exitCode);
    return basesrv_complete_rpc(async,error);
}
error_status_t Server_Reenter(PRPC_ASYNC_STATE async,handle_t binding,VDM_CONNECTION connection,HANDLE process,
    ULONG generation,ULONG increment)
{
    DWORD pid,error;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (error) return basesrv_complete_rpc(async,error);
    error=OpenNtBaseServiceReenter(connection,pid,generation,increment);
    return basesrv_complete_rpc(async,error);
}
error_status_t Server_Disconnect(PRPC_ASYNC_STATE async,handle_t binding,HANDLE process,ULONG generation,VDM_CONNECTION *connection)
{
    DWORD pid,result=broker_rpc_peer_process(&scope,binding,process,&pid);
    if (!result && !OpenNtBaseServicePeer(*connection,pid,generation)) result=ERROR_ACCESS_DENIED;
    if (!result) result=OpenNtBaseServiceDisconnect(*connection);
    if (!result) *connection=NULL;
    if (!result) basesrv_schedule_empty_stop();
    (void)RpcAsyncCompleteCall(async,&result);
    return ERROR_SUCCESS;
}
int main(void)
{
    WCHAR endpoint[128];
    RPC_STATUS result;
    if (!broker_rpc_capture_scope(&scope)) return (int)GetLastError();
    swprintf_s(endpoint,128,BROKER_RPC_ENDPOINT_FORMAT,scope.session,
        (ULONG)scope.logon.HighPart,scope.logon.LowPart,scope.package_id);
    /* ncalrpc's endpoint binding is exclusive. Duplicate startup never
     * dispatches or pretends to be ready; caller must authenticate the owner. */
    result=RpcServerUseProtseqEpW((RPC_WSTR)L"ncalrpc",RPC_C_PROTSEQ_MAX_REQS_DEFAULT,(RPC_WSTR)endpoint,NULL);
    if (result) return (int)result;
    result=RpcServerRegisterAuthInfoW(NULL,RPC_C_AUTHN_WINNT,NULL,NULL);
    if (result) return (int)result;
    service=OpenNtBaseServiceStart();
    if (!service) return GetLastError() ? (int)GetLastError() : ERROR_NOT_ENOUGH_MEMORY;
    if (!OpenNtBaseServiceConfigureEmptyNotify(service,basesrv_worker_terminated,NULL)) {
        DWORD error=GetLastError();
        (void)OpenNtBaseServiceStop(service);
        return (int)error;
    }
    result=RpcServerRegisterIf3(Server_vdm_service_v1_0_s_ifspec,NULL,NULL,
        RPC_IF_ALLOW_SECURE_ONLY | RPC_IF_ALLOW_LOCAL_ONLY,RPC_C_LISTEN_MAX_CALLS_DEFAULT,
        (unsigned)-1,authorize,NULL);
    if (!result) {
        idle_timer=CreateWaitableTimerW(NULL,FALSE,NULL);
        if (!idle_timer) basesrv_idle_fatal("CreateWaitableTimer",GetLastError());
        /* Arm only after listening succeeds, never race stop against startup. */
        result=RpcServerListen(1,RPC_C_LISTEN_MAX_CALLS_DEFAULT,TRUE);
    }
    if (!result) {
        /* Readiness is a successful client RPC, never this diagnostic line. */
        fwprintf(stdout,L"basesrv: listening on %ls\n",endpoint); fflush(stdout);
        /* Manual and launcher starts have the same five-second empty grace. */
        basesrv_schedule_empty_stop();
        for(;;) {
            HANDLE waits[2]={idle_timer,
                OpenNtBaseServiceFrontendLifetimeChanged(service)};
            DWORD wait,error=OpenNtBaseServiceReconcileFrontends(service);
            if(error)basesrv_idle_fatal("frontend reconciliation",error);
            wait=WaitForMultipleObjects(ARRAYSIZE(waits),waits,FALSE,INFINITE);
            if(wait==WAIT_OBJECT_0) {
                if(basesrv_claim_empty_stop())break;
            } else if(wait!=WAIT_OBJECT_0+1)
                basesrv_idle_fatal("lifetime wait",GetLastError());
        }
        result=RpcMgmtStopServerListening(NULL);
        if (result) basesrv_idle_fatal("RpcMgmtStopServerListening",result);
        result=RpcMgmtWaitServerListen();
        if (result) basesrv_idle_fatal("RpcMgmtWaitServerListen",result);
    }
    {
        RPC_STATUS cleanup=RpcServerUnregisterIf(Server_vdm_service_v1_0_s_ifspec,NULL,TRUE);
        if (!result && cleanup) result=cleanup;
    }
    if (idle_timer) CloseHandle(idle_timer);
    if (!OpenNtBaseServiceStop(service)) return ERROR_BUSY;
    return (int)result;
}

error_status_t Server_RegisterEmbeddedFrontend(PRPC_ASYNC_STATE async,handle_t binding,
    VDM_CONNECTION connection,HANDLE process,ULONG generation,LONGLONG payload,
    LONGLONG vm,LONGLONG incarnation,LONGLONG *frontend_instance,ULONG *frontend_generation,
    HANDLE *notification,HANDLE *retire)
{
    common_frontend_key key={0};
    common_frontend_location location={(uint64_t)payload,(uint64_t)vm,(uint64_t)incarnation};
    DWORD pid,error;
    *frontend_instance=0;*frontend_generation=0;*notification=*retire=NULL;
    error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceRegisterEmbeddedFrontend(connection,pid,generation,
        &location,&key,notification,retire);
    if(!error){*frontend_instance=(LONGLONG)key.instance;*frontend_generation=key.generation;}
    (void)RpcAsyncCompleteCall(async,&error);return ERROR_SUCCESS;
}

error_status_t Server_CloseFrontendInstance(PRPC_ASYNC_STATE async,handle_t binding,
    VDM_CONNECTION connection,HANDLE process,ULONG generation,LONGLONG frontend_instance,
    ULONG frontend_generation)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceCloseFrontendInstance(connection,pid,generation,&key);
    (void)RpcAsyncCompleteCall(async,&error);return ERROR_SUCCESS;
}

error_status_t Server_UnregisterFrontendInstance(PRPC_ASYNC_STATE async,handle_t binding,
    VDM_CONNECTION connection,HANDLE process,ULONG generation,LONGLONG frontend_instance,
    ULONG frontend_generation)
{
    common_frontend_key key={(uint64_t)frontend_instance,frontend_generation};
    DWORD pid,error=broker_rpc_peer_process(&scope,binding,process,&pid);
    if(!error)error=OpenNtBaseServiceUnregisterFrontendInstance(connection,pid,generation,&key);
    (void)RpcAsyncCompleteCall(async,&error);return ERROR_SUCCESS;
}
