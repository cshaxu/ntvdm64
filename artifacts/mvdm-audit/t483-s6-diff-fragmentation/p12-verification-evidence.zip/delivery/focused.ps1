$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
& test/observation/verify-wow-control-boundaries.ps1 -EvidenceRoot build/t483-s6-p12/focused-linked-verified
if($LASTEXITCODE){$LASTEXITCODE | Set-Content build/t483-s6-p12/focused.exit
exit $LASTEXITCODE}
& test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p12/task-order -Case task-order
$LASTEXITCODE | Set-Content build/t483-s6-p12/focused.exit
exit $LASTEXITCODE
