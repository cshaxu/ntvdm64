from pathlib import Path
import json,csv,hashlib,zipfile
r=Path.cwd();b=r/'build/t483-s6-p12';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
for n in ['cached','publish','bitmap-final','message-final','dde','focused','cleanup-bounds','full-isolated','review-check','verification','pipeline','delivery-supervisor']:
    assert (b/(n+'.exit')).read_text().strip()=='0',n
full=j(b/'full-isolated/timings.json')
assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json');pub=j(b/'runtime-publication/result.json')
for x in c['files']:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256']
assert hashlib.sha256((r/'assets/winnt.zip').read_bytes()).hexdigest().upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
manifest=j(b/'candidate-final/product-system32-manifest.json');assert len(manifest)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
    for x in manifest:assert hashlib.sha256((dest/x['Name']).read_bytes()).hexdigest().upper()==x['Sha256'].upper()
files=j(b/'census.json')['files']
global_counts={'files':len(files),'strict_equal':sum(x['original_sha256']==x['current_sha256'] for x in files),'filtered_zero':sum(not x['filtered']['blocks'] for x in files),'nonzero_files':sum(bool(x['filtered']['blocks']) for x in files),'blocks':sum(x['filtered']['blocks'] for x in files),'lines':sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),'reviewed_files':24,'remaining_files':231,'cumulative_reduction_blocks':23,'cumulative_reduction_lines':873}
receipt={'packet':'M0 T483 S6 P12','status':'Verified and published;Git delivery accompanies receipt','source_checkpoint':c,'reduction':{'blocks':2,'lines':102},'publication':pub,'full':full,'compiler_lines':j(b/'line-proof.json'),'global':global_counts,'failed_candidates':'Two assignment helpers failed actual linking;restoration and /Gy trial withdrawn. Final candidate passed full build.','winnt_zip_unchanged':True}
(a/'batch-p12-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
for name in ['handtabl-whole-file-review.json','userk-whole-file-review.json','wdde-whole-file-review.json']:
    p=a/name;d=j(p);d['delivery']='P12 cached full,published11x2,focused and Full20 passed;Git delivery accompanies receipt'
    if name!='wdde-whole-file-review.json':d['status']='Whole-file reviewed,implemented,verified and published;residual decisions remain pending owner'
    if name=='handtabl-whole-file-review.json':d['verification']['compile']='Final cached x86/x64 full build and link passed;Full20 and focused gates passed'
    p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
paths={'src/non-mvdm/windows/core/ntuser/kernel/handtabl.c','src/non-mvdm/windows/core/ntuser/kernel/userk.h','src/mvdm-host/wow32/wdde.c'}
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv']:
    rows=list(csv.DictReader(p.open(encoding='utf-8')));fields=list(rows[0])
    for x in rows:
        if x['path'] not in paths:continue
        if 'status' in fields:x['status']='reviewed-verified-p12-residuals-pending-owner'
        else:
            x['verification']='P12 cached full,publish11x2,focused,Full20 and governance passed'
            x['delivery']='P12;Git delivery accompanies receipt'
            if x['review_status']=='restored-local-pending-verification':x['review_status']='restored-verified-delivery-p12'
    with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8')
start=s.index('21/255 initial');end=s.index('\n| File |',start)
s=s[:start]+'''24/255 initial difference files reviewed;231 remain. Eighteen changed files
verified across P2-P12;six reviewed unchanged. Current census:1063 files
(1054 host C/H plus9 other text mirrors),511 original-byte matches,808 zero
normalized/error-masked differences,and255 nonzero files. P12 adds original
winerrp.h byte-exact;this is not itself a reduced difference point.
Current total2310 blocks/53650 lines;cumulative delivered reduction23 blocks/
873 lines. Mouse's earlier two-line counting correction remains separate.
'''+s[end:]
pos=s.index('\n\n\nThe canonical pending')
s=s[:pos]+'''\n| kernel/userk.h |27->27|117->115|P12 two added comments removed;Full20 passed|
| wow32/wdde.c |26->26|143->143|P12 reviewed unchanged;residual decisions pending|
| kernel/handtabl.c |26->24|1481->1381|P12 original declarations and KernelPtoH restored;Full20 passed|'''+s[pos:]
start=s.index('The canonical pending');end=s.index('## Current Technical Baseline',start)
s=s[:start]+'''The canonical pending backlog remains1641 rows/1646 historical R identifiers.
Partial restorations do not close residual owner decisions. Three complete
handtabl restorations removed from pending;remaining private-kernel and ABI
boundaries remain pending. Historical R identifiers are not current diff blocks.
Next file follows the worklist after handtabl;do not repeat completed reviews.

'''+s[end:]
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'''## Current Technical Baseline

P12 cached x86/x64 full builds passed. Package'''+pub['package']+''' contains11
images,published and hash-verified to assets/release and O:/winnt/system32.
Bitmap/message/DDE,controls/task-order,Full20 including real DOS4GW/NESticle,
shared-boundary and governance passed. Cleanup source audit passed;not a
runtime proof. Six compiler anchors and153 static original rows match.
Two assignment-helper candidates failed linking and were withdrawn;no stub
or /Gy build change retained. No guest or winnt.zip changes.

[P12 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p12-checkpoint.json)
and [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p12-verification-evidence.zip)
bind final source,package and tests. [Whole-file review](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/handtabl-whole-file-review.json)
records restorations and residual owner decisions. Git delivery accompanies receipt.

'''+s[end:]
if '## P12 Local Batch' in s:s=s[:s.index('## P12 Local Batch')]
p.write_text(s,encoding='utf-8',newline='\n');assert p.stat().st_size<16384
with (a/'README.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n[P12 receipt](batch-p12-checkpoint.json) and [evidence](p12-verification-evidence.zip):whole-file restorations,failed link controls,final cached build,publish11x2 and Full20. Net reduction2 blocks/102 lines;residual decisions pending.\n')
with zipfile.ZipFile(a/'p12-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for root,label in [(b,'delivery'),(r/'build/t483-s6-handtabl-review','source-review')]:
        for p in root.rglob('*'):
            if p.is_file() and p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.h','.c'] and not any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(root).parts):z.write(p,label+'/'+p.relative_to(root).as_posix())
    z.write(b/'runtime-publication/result.json','publication/result.json')
print('P12 verified receipt and documentation prepared')
