VPVOID FASTCALL stackalloc16(UINT cb)
{
    register PTD ptd;

    // get current task's 16bit stack

    ptd = CURRENTPTD();

    // grow ss:sp and return this imaginary pointer.

    if (ptd->dwFlags & TDF_INITCALLBACKSTACK) {
        ptd->vpCBStack = ptd->vpStack - cb;
        ptd->dwFlags &= ~TDF_INITCALLBACKSTACK;
    }
    else {
        ptd->vpCBStack -= cb;
    }

    return (VPVOID)ptd->vpCBStack;
}

DWORD FindParamMap(VOID* lpFindParam, DWORD lParam, UINT fMode)
{
    LPPARAMNODE lpn = gParamMap.pHead;    
    LPPARAMNODE lplast = NULL;
    DWORD dwRet = 0;
    BOOL fFound = FALSE;

#line 94
    switch(fMode) {

         case PARAM_16:
              while (NULL != lpn) {
                  if (lParam == lpn->dwPtr16) {
                      dwRet = lpn->dwPtr32;
                      break;
                  }
                  lplast = lpn;
                  lpn = lpn->pNext;
              }
              break;

         case PARAM_32:
              // We are looking for a 32-bit pointer
              // cases:
              // - exact match
              // - no match because ptr has moved (ouch!)

              while (NULL != lpn) {

                  INT i;

                  if (lParam == lpn->dwPtr32) {
                      fFound = TRUE;
                  }
                  else
                  if (lParam == (DWORD)GetPModeVDMPointer(lpn->dwPtr16, 0)) {
                      LOGDEBUG(LOG_ALWAYS, 
                               ("WPARAM: Pointer has moved: 16:16 @%lx was 32 @%lx now @%lx\n", 
                               lpn->dwPtr16, lpn->dwPtr32, lParam));
                      fFound = TRUE;
                  }
                  else {
                  
                      // look through the list of aliases

                      for (i = 0; i < (INT)lpn->nAliasCount; ++i) {
                           if (lpn->rgdwAlias[i] == lParam) {
                               fFound = TRUE;
                               break;
                           } 
                      }
                  }

                  if (fFound) {         // we found alias one way or the other...
                      dwRet = lpn->dwPtr16;
                      break;
                  }


                  lplast = lpn;
                  lpn = lpn->pNext;
              }
              break;
    }
     
    if (lpn)  {
        LPFINDPARAM lpfp = (LPFINDPARAM)lpFindParam;
        lpfp->lpNode = lpn;
        lpfp->lpLast = lplast;
    }
      
    return dwRet;
}

DWORD GetParam16(DWORD dwParam32)
{
    FINDPARAM fp;
    DWORD dwParam16;

    dwParam16 = FindParamMap(&fp, dwParam32, PARAM_32);
    if (dwParam16) {
        ++fp.lpNode->dwRefCount;
    }

    return dwParam16;
}

PVOID AddParamMap(DWORD dwPtr32, DWORD dwPtr16)
{
    LPPARAMNODE lpn;
    FINDPARAM fp;
    BOOL updated = FALSE;

    if (!dwPtr32) return NULL;

#line 193
     // see if it's there already
#line 194
    if (FindParamMap(&fp, dwPtr16, PARAM_16)) {

        lpn = fp.lpNode; // a bit faster ref
        
        ++lpn->dwRefCount; // increase ref count
        
        __try {
            updated = ParamMapUpdateNode(dwPtr32, PARAM_32, lpn) != NULL;
        } __finally {
            if (!updated) {
                DWORD error = GetLastError();
                DeleteParamMap(dwPtr16, PARAM_16, NULL);
                SetLastError(error);
            }
        }
        if (!updated) return NULL;
#line 201
    }
    else { 
        if (NULL != (lpn = CacheBlockAllocate(&gParamMap.blkCache, sizeof(*lpn)))) {
            lpn->dwPtr32 = dwPtr32;
            lpn->dwPtr16 = dwPtr16;
            lpn->pNext   = gParamMap.pHead;
            lpn->dwRefCount = 1;
#ifdef MAPPARAM_EXTRA
#line 209
#error Unsupported excluded original configuration
#endif
#line 211
            lpn->nAliasCount = 0;
            lpn->htask16 = CURRENTPTD()->htask16;
            gParamMap.pHead = lpn;
        }
    }

    return lpn ? (PVOID)lpn->dwPtr32 : NULL;
}

PVOID ParamMapUpdateNode(DWORD dwPtr, UINT fMode, VOID* lpNode)
{
    LPPARAMNODE lpn;
    PVOID pv;

    if (NULL == lpNode) {
        FINDPARAM fp;
        if (FindParamMap(&fp, dwPtr, fMode)) {
            lpn = fp.lpNode; // node found!
        }
        else {
            LOGDEBUG(LOG_ALWAYS, ("WOW: ParamMapUpdateNode could not find node\n"));
            // return here as we've failed to find node same as we got in
            return (PVOID)dwPtr;
        }
    }
    else {
        lpn = (LPPARAMNODE)lpNode;
    }

    // if pointer is up-to-date then exit
    pv = GetPModeVDMPointer(lpn->dwPtr16, 0);
    if ((DWORD)pv == lpn->dwPtr32) {
        return pv; // up-to-date
    }
#ifdef MAPPARAM_EXTRA
#line 285
#error Unsupported excluded original configuration
#line 289
#endif
#line 287

    if (!pv) return NULL;
#line 291

    if (lpn->nAliasCount < ARRAYCOUNT(lpn->rgdwAlias)) {

        lpn->rgdwAlias[lpn->nAliasCount++] = lpn->dwPtr32;
    }
    else {
        WOW32ASSERTMSG(FALSE, ("WOW:AddParamMap is out of alias space\n"));
        // so we will throw the oldest alias out - this will mean if they refer
        // to it - they are doomed... That is why we assert here!
        lpn->rgdwAlias[0] = lpn->dwPtr32;
    }

    lpn->dwPtr32 = (DWORD)pv; // new pointer here

    return pv;
}

BOOL DeleteParamMap(DWORD lParam, UINT fMode, BOOL* pfFreePtr)
{   
    FINDPARAM fp;
    LPPARAMNODE lpn = NULL;

    if (FindParamMap(&fp, lParam, fMode)) {
        lpn = fp.lpNode;
        
        if (!--lpn->dwRefCount) {

            if (NULL != fp.lpLast) {
                fp.lpLast->pNext = lpn->pNext;
            } 
            else {
                gParamMap.pHead = lpn->pNext;
            }

            if (NULL != pfFreePtr) {
#ifdef MAPPARAM_EXTRA
#line 337
#error Unsupported excluded original configuration
#else
#line 339
                *pfFreePtr = FALSE;
#endif
#line 341
            }
            CacheBlockFree(&gParamMap.blkCache, lpn);
        }
        else {
            LOGDEBUG(12, ("\nWOW: DeleteParamMap called refCount > 0 Node@%x\n", (DWORD)lpn));

            if (NULL != pfFreePtr) { // not done with mapping yet
                *pfFreePtr = FALSE;
            }
        }
    }
    else {
        LOGDEBUG(LOG_ALWAYS, ("\nWOW: DeleteParamMap called but param was not found\n"));
        if (NULL != pfFreePtr) {
            *pfFreePtr = TRUE; // we found none, assume free
        }
    }
     
    return NULL != lpn;
}

VOID FreeParamMap(HAND16 htask16)
{
    LPPARAMNODE lpn = gParamMap.pHead;    
    LPPARAMNODE lplast = NULL, lpnext;
    
    while (NULL != lpn) {

        lpnext = lpn->pNext;

        if (lpn->htask16 == htask16) {

            if (NULL != lplast) {
                lplast->pNext = lpnext;
            }
            else {
                gParamMap.pHead = lpnext;
            }

            CacheBlockFree(&gParamMap.blkCache, lpn); 
        }
        else {
            lplast = lpn; 
        }

        lpn = lpnext;
    }
}

BOOL FASTCALL WM32MDICreate(LPWM32MSGPARAMEX lpwm32mpex)
{
    INT cb;
    VPVOID vp;
    register PMDICREATESTRUCT16 pmcs16;
    LPMDICREATESTRUCT lParam = (LPMDICREATESTRUCT) lpwm32mpex->lParam;
    BOOL completed = FALSE; /* DIV-349: SEH AbnormalTermination includes return. */

    lpwm32mpex->lpfnM32 = WM32MDICreate;
    __try {
#line 1457
    if (lpwm32mpex->fThunk) {
        if (lParam) {

            lpwm32mpex->dwParam = (DWORD)0;
            if (lParam->szClass) {
                if ( HIWORD(lParam->szClass) == 0 ) {
                    vp = (VPVOID)lParam->szClass;
                }
                else {
                    cb = strlen(lParam->szClass)+1;
                    if (!(vp = malloc16(cb)))
                        goto Error;
                    lpwm32mpex->dwParam = vp; /* DIV-349: before copying class. */
#line 1469
                    putstr16(vp, lParam->szClass, cb);
                }
            }
            else {
                vp = (VPVOID)NULL;
            }

            //
            // pfs:windowsworks overwrite pszclass, so we need to save the
            // so that we can free the memory we just alloced
            //
            lpwm32mpex->dwParam = (DWORD)vp;

            if (lParam->szTitle) {
                cb = strlen(lParam->szTitle)+1;
                if (!(vp = malloc16(cb)))
                    goto Error;
                lpwm32mpex->dwTmp[0] = vp; /* DIV-349: before copying title. */
#line 1486
                putstr16(vp, lParam->szTitle, cb);
            }
            else {
                vp = (VPVOID)NULL;
            }

            // BUGBUG -- The assumption here is that GlobalAlloc will never
            // return a memory object that isn't word-aligned, so that we can
            // assign word-aligned words directly;  we have no idea whether the
            // memory is dword-aligned or not however, so dwords must always
            // be paranoidly stored with the STOREDWORD/STORELONG macros -JTP

            if (!(lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(sizeof(MDICREATESTRUCT16))))) /* DIV-349 */
#line 1499
                goto Error;

            GETVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, sizeof(MDICREATESTRUCT16), pmcs16);
            STOREDWORD(pmcs16->vpszClass, lpwm32mpex->dwParam);
            STOREDWORD(pmcs16->vpszTitle, vp);
            pmcs16->hOwner  = GETHINST16(lParam->hOwner);
            pmcs16->x       = (SHORT)lParam->x;
            pmcs16->y       = (SHORT)lParam->y;
            pmcs16->cx      = (SHORT)lParam->cx;
            pmcs16->cy      = (SHORT)lParam->cy;
            STORELONG(pmcs16->style, lParam->style);
            STORELONG(pmcs16->lParam, lParam->lParam);

            FLUSHVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, sizeof(MDICREATESTRUCT16), pmcs16);
            FREEVDMPTR(pmcs16);

            completed = TRUE; /* DIV-349: transfer ownership to the caller. */
#line 1515
            return (TRUE);

          Error:
            LOGDEBUG(LOG_ALWAYS,(" !!!! WM32MDICreate, WM_MDICREATE thunking failed !!!! Window %08lX ", lpwm32mpex->hwnd));
            wow_message_free16(&lpwm32mpex->dwParam, TRUE); /* DIV-349: original error order. */
            wow_message_free16(&lpwm32mpex->dwTmp[0], FALSE);
#line 1521
            return FALSE;
        }
    }
    else {
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            wow_message_free16(&lpwm32mpex->dwTmp[0], FALSE); /* DIV-349: consume before release. */

            //  if HIWORD(class) is zero, class is an atom, else a pointer.

#line 1536
            if (HIW16(lpwm32mpex->dwParam)) {
                wow_message_free16(&lpwm32mpex->dwParam, FALSE);
            }


#line 1541
            lpwm32mpex->lReturn = (LONG)HWND32(LOWORD(lpwm32mpex->lReturn));
            wow_message_free16(&lpwm32mpex->dwTmp[1], FALSE); /* DIV-349: preserve result conversion order. */
        }
    }

#line 1546
    return (TRUE);
    } __finally { /* DIV-349: nested construction can escape before transfer. */
        if (!completed) wow_message_unwind32(lpwm32mpex);
    }
#line 1547
}

BOOL FASTCALL WM32Create(LPWM32MSGPARAMEX lpwm32mpex)
{


    INT cb;
    VPVOID vpClass = 0;
    VPVOID vpName = 0;
    VPVOID vpCreateParams = 0;
    register PCREATESTRUCT16 pcws16;
    LPCREATESTRUCT lParam = (LPCREATESTRUCT) lpwm32mpex->lParam;

    if (lpwm32mpex->fThunk) {
        lpwm32mpex->lpfnM32 = WM32Create; /* DIVERGENCE(MVDM-HOST-DIV-349): also the direct CBT caller. */

#line 431
        if (HIWORD(lParam)) {

            // BUGBUG -- The assumption here is that GlobalAlloc will never
            // return a memory object that isn't word-aligned, so that we can
            // assign word-aligned words directly;  we have no idea whether the
            // memory is dword-aligned or not however, so dwords must always
            // be paranoidly stored with the STOREDWORD/STORELONG macros -JTP


            if (lParam->lpszClass) {
                if ( HIWORD(lParam->lpszClass) == 0 ) {
                    vpClass = (VPVOID)lParam->lpszClass;
                }
                else {
                    cb = strlen(lParam->lpszClass)+1;
                    if (!(vpClass = malloc16(cb)))
                        goto Error;
                    lpwm32mpex->dwTmp[0] = vpClass; /* DIV-349: before a throwing copy. */
#line 448
                    putstr16(vpClass, lParam->lpszClass, cb);
                }
            }

            if (lParam->lpszName) {
                cb = strlen(lParam->lpszName)+1;
                if (!(vpName = malloc16(cb)))
                    goto Error;
                lpwm32mpex->dwTmp[1] = vpName; /* DIV-349: completed acquisition. */
#line 456
                putstr16(vpName, lParam->lpszName, cb);
            }

            if (lpwm32mpex->pww == NULL) {
                lpwm32mpex->pww = (PWW)GetWindowLong(lpwm32mpex->hwnd, GWL_WOWWORDS);
                if (lpwm32mpex->pww == NULL)
                    return FALSE;   // Window is dead
            }

            if (lParam->lpCreateParams && (lpwm32mpex->pww->dwExStyle & WS_EX_MDICHILD) ) {
                // This works because wm32mdicreate thunk doesn't use any
                // parameters except lParam

                WM32MSGPARAMEX wm32mpexT = {0}; /* DIV-349: nested partial construction. */
                wm32mpexT.fThunk = lpwm32mpex->fThunk;
                wm32mpexT.hwnd = lpwm32mpex->hwnd;
                wm32mpexT.uMsg = WM_MDICREATE;
                wm32mpexT.uParam = lpwm32mpex->uParam;
                wm32mpexT.lParam = (LONG)lParam->lpCreateParams;
                wm32mpexT.pww = lpwm32mpex->pww;
                wm32mpexT.fFree = lpwm32mpex->fFree;
                wm32mpexT.Parm16.WndProc.lParam = 0;
                if (!WM32MDICreate(&wm32mpexT)) goto Error;
#line 479
                lpwm32mpex->dwParam = wm32mpexT.dwParam;
                lpwm32mpex->dwTmp[2] = wm32mpexT.dwTmp[0];
#line 480
                vpCreateParams = wm32mpexT.Parm16.WndProc.lParam;
                lpwm32mpex->dwTmp[3] = vpCreateParams;
#line 481
            }
            else {
                vpCreateParams = (VPVOID)lParam->lpCreateParams;
            }

            if (!(lpwm32mpex->Parm16.WndProc.lParam = stackalloc16(sizeof(CREATESTRUCT16))))
                return FALSE;

            GETVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, sizeof(CREATESTRUCT16), pcws16);

            STOREDWORD(pcws16->vpszClass, vpClass);
            STOREDWORD(pcws16->vpszWindow, vpName);
            STOREDWORD(pcws16->vpCreateParams, vpCreateParams);

            lpwm32mpex->dwTmp[0] = vpClass; // store for later freeing
            lpwm32mpex->dwTmp[1] = vpName;


            // BUGBUG 08-Apr-91 JeffPar -- What if hModule is for a 32-bit task?
#line 500
            pcws16->hInstance    = GETHINST16(lParam->hInstance);
            pcws16->hMenu    = GETHMENU16(lParam->hMenu);
            pcws16->hwndParent   = GETHWND16(lParam->hwndParent);
            pcws16->cy       = (SHORT)lParam->cy;
            pcws16->cx       = (SHORT)lParam->cx;
            pcws16->y        = (SHORT)lParam->y;
            pcws16->x        = (SHORT)lParam->x;
            STOREDWORD(pcws16->dwStyle, lParam->style);
            STOREDWORD(pcws16->dwExStyle, lParam->dwExStyle);

            FLUSHVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, sizeof(CREATESTRUCT16), pcws16);
            FREEVDMPTR(pcws16);

            return TRUE;

          Error:
            LOGDEBUG(LOG_ALWAYS,(" !!!! WM32Create, WM_CREATE thunking failed !!!! Window %08lX ", lpwm32mpex->hwnd));
            wow_message_release32(lpwm32mpex); /* DIV-349: consume captured keys. */
#line 519
            return (FALSE);

            // do some clean up
            // UnThunkWMCreate32(lParam, lpwm32mpex->Parm16.WndProc.lParam);

        } else {
            return TRUE;
        }




    }
    else {

        if (lpwm32mpex->Parm16.WndProc.lParam) {

            wow_message_release32(lpwm32mpex);

#line 572
            stackfree16((VPVOID) lpwm32mpex->Parm16.WndProc.lParam);
        }

        return TRUE;
    }

}

BOOL FASTCALL WM32GetText(LPWM32MSGPARAMEX lpwm32mpex)
{
    INT cb;
    LPSTR   psz;
    INT cbWrote;



    if (lpwm32mpex->fThunk) {

        if (CURRENTPTD()->dwWOWCompatFlags & WOWCF_DSBASEDSTRINGPOINTERS) {
            //
            // msworks 2.0a has a wndproc called EdWnProc() which when it gets
            // a WM_GETTEXT, assumes lParam is a based pointer whose segment
            // value is equal to winwork's ds. That is true under win3.1, but
            // if wow calls malloc16, it'll have a different segment value.
            // so instead alloc the space on the caller's stack. Since most
            // apps have SS == DS, this will fix apps that do this, including
            // msworks 2.0a.
            //

            lpwm32mpex->Parm16.WndProc.lParam = stackalloc16(lpwm32mpex->Parm16.WndProc.wParam);
        } else {
            lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex,
                malloc16(lpwm32mpex->Parm16.WndProc.wParam));
#line 731
        }
        if (!lpwm32mpex->Parm16.WndProc.lParam) return FALSE;

        //
        // non-zero fill to detect people who write more than they
        // say that they do!
        //
#line 737
        GETVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, lpwm32mpex->Parm16.WndProc.wParam, psz);
        RtlFillMemory(psz, lpwm32mpex->Parm16.WndProc.wParam, 0xff);
        FLUSHVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, lpwm32mpex->Parm16.WndProc.wParam, psz);
        FREEVDMPTR(psz);
        return (BOOL)lpwm32mpex->Parm16.WndProc.lParam;
    }
    else {
        // some apps return garbage in the high word.  safely assume
        // that cbWindowText < 64K
        HIW(lpwm32mpex->lReturn) = 0;

        // it is necessary to check the length of the buffer, specified in
        // lpwm32mpex->uParam. if number of bytes (lpwm32mpex->lReturn) that are to be copied is
        // EQUAL to the length of the buffer, then copy ONLY the bytes EQUAL
        // to the length of the buffer.
        //

        // Paradox is one of the apps where this condition is hit.
        // bug # 4272.


        //

        if (lpwm32mpex->Parm16.WndProc.lParam) {

            cb = lpwm32mpex->lReturn + 1;

            if (lpwm32mpex->uParam == 0) {
                // cb = 0 if lReturn == 0 && uParam == 0

                if (cb == 1)
                    cb--;
            }
            else if (cb == 2 || cb == 1) {
                // Here only if uParam != 0
                //
                // Determine how much of the buffer they touched!
                //
                // MyAdvancedLabelMaker returns 1 when they really return
                // more than 1.  Since the return 1, cb will be 2.  Then
                // We check to see how much of the buffer they really modified.
                // Then we lie and say that they really filled in that much
                // of the buffer.
                //
                // Sql administator also does this, except it returns 0
                // bug 7731

                GETVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, lpwm32mpex->Parm16.WndProc.wParam, psz);

                cbWrote = lpwm32mpex->uParam;
                while (cbWrote && (psz[cbWrote-1] == '\xff')) {
                    cbWrote--;
                }
                // copy out as many bytes as they wrote
                // distinguish between 'zerobytes written vs. one byte written'

                lpwm32mpex->lReturn = (cbWrote) ? (cbWrote - 1) : 0;
                cb = cbWrote;

                FREEVDMPTR(psz);
            }


            // cb = min(cb, wparam) only if wparam != 0
            // MSPROFIT: does
            //    ret = sendmessage(hwnd, wm_gettest, wparam = 0, lparam);
            //    where ret != 0. so we have to copy the necessary bytes into
            //    lparam eventhough wparam is zero. It does this for reading
            //    those ominprseent "$0.00" strings in the app (ledgers etc).
            //
            //                                   - nanduri

            if (lpwm32mpex->uParam && (UINT)cb > lpwm32mpex->uParam) {
                cb = lpwm32mpex->uParam;
            }

            getstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, cb);

            if (CURRENTPTD()->dwWOWCompatFlags & WOWCF_DSBASEDSTRINGPOINTERS) {
                stackfree16((VPVOID) lpwm32mpex->Parm16.WndProc.lParam);
            } else {
                wow_message_release32(lpwm32mpex); /* DIV-349: captured heap key. */
            }
        }
    }

    return (TRUE);
}

BOOL FASTCALL WM32SetText(LPWM32MSGPARAMEX lpwm32mpex)
{
    INT cb;


#line 661
    if (lpwm32mpex->fThunk) {
#line 662
        if (lpwm32mpex->lParam) {

            LONG lParam = (LONG)GetParam16(lpwm32mpex->lParam);
            if (lParam) {
                lpwm32mpex->Parm16.WndProc.lParam = lParam;
                lpwm32mpex->dwParam = WOW_TEXT_ACTIVE;
#line 667
                return (TRUE);
            }
 
            cb = strlen((LPSZ)lpwm32mpex->lParam)+1;

            // winworks2.0a requires DS based string pointers for this message
            if (CURRENTPTD()->dwWOWCompatFlags & WOWCF_DSBASEDSTRINGPOINTERS) {
                if (!(lpwm32mpex->Parm16.WndProc.lParam = stackalloc16(cb)))
                    return FALSE;
                lpwm32mpex->dwParam = WOW_TEXT_ACTIVE;
#line 676
            } else {
                if (!(lpwm32mpex->Parm16.WndProc.lParam = malloc16(cb)))
                    return FALSE;
                lpwm32mpex->dwParam = WOW_TEXT_ACTIVE;
#line 679
            }
            putstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, cb);
        }
    }
    else {
// BUGBUG 09-Apr-91 -- Should I copy back?
        if (!lpwm32mpex->dwParam) return TRUE;
        lpwm32mpex->dwParam = 0;
#line 685
        if (DeleteParamMap(lpwm32mpex->Parm16.WndProc.lParam, PARAM_16, NULL)) {
#line 686
            return TRUE;
        }

#line 689
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            if (CURRENTPTD()->dwWOWCompatFlags & WOWCF_DSBASEDSTRINGPOINTERS) {
                stackfree16((VPVOID) lpwm32mpex->Parm16.WndProc.lParam);
            } else {
                free16((VPVOID) lpwm32mpex->Parm16.WndProc.lParam);
            }
        }
    }

    return (TRUE);
}

BOOL FASTCALL WM32GetDlgCode(LPWM32MSGPARAMEX lpwm32mpex)
{

    if (lpwm32mpex->fThunk) {
        if (lpwm32mpex->lParam) {

            // BUGBUG -- The assumption here is that GlobalAlloc will never
            // return a memory object that isn't word-aligned, so that we can
            // assign word-aligned words directly;  we have no idea whether the
            // memory is dword-aligned or not however, so dwords must always
            // be paranoidly stored with the STOREDWORD/STORELONG macros -JTP

            if (!(lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(sizeof(MSG16))))) /* DIV-349 */
                return FALSE;

            putmsg16(lpwm32mpex->Parm16.WndProc.lParam, (LPMSG)lpwm32mpex->lParam);

            return TRUE;
        }
    }
    else {
        // Message structure doesn't need to be copied back does it? -Bob

        if (lpwm32mpex->Parm16.WndProc.lParam) {
            wow_message_release32(lpwm32mpex); /* DIV-349: no output replay. */
        }

    }
    return (TRUE);
}

BOOL FASTCALL WM32AskCBFormatName(LPWM32MSGPARAMEX lpwm32mpex)
{

    if (lpwm32mpex->fThunk) {
        lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(lpwm32mpex->Parm16.WndProc.wParam));
#line 1732
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            putstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, lpwm32mpex->uParam);
        }

        return (BOOL)lpwm32mpex->Parm16.WndProc.lParam;
    }
    else {
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            getstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, lpwm32mpex->uParam);
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback remains above. */
        }
    }

    return (TRUE);
}

BOOL FASTCALL WM32WinHelp (LPWM32MSGPARAMEX lpwm32mpex)
{
    static WORD msgWinHelp = 0;
    if (lpwm32mpex->fThunk) {
#line 2517
        lpwm32mpex->Parm16.WndProc.wMsg   = msgWinHelp ? msgWinHelp : (msgWinHelp = RegisterWindowMessage("WM_WINHELP"));
        lpwm32mpex->Parm16.WndProc.wParam = GETHWND16(lpwm32mpex->uParam);
        if (lpwm32mpex->lParam) {
            // lpwm32mpex->lParam is LPHLP - however we need only the firstword,ie the size of data

            HAND16  hMem16 = 0;
#line 2523
            VPVOID  vp;
            LPBYTE  lpT;
            WORD cb;

            cb = ((LPHLP)lpwm32mpex->lParam)->cbData;
            if (lpwm32mpex->dwParam = vp = GlobalAllocLock16(GMEM_DDESHARE | GMEM_MOVEABLE, cb, &hMem16)) { /* DIV-349: before copy. */
                GETMISCPTR(vp, lpT);
                RtlCopyMemory(lpT, (PVOID)lpwm32mpex->lParam, cb);
                FREEMISCPTR(lpT);
            }
            lpwm32mpex->Parm16.WndProc.lParam = hMem16;
            lpwm32mpex->dwParam = vp;
#line 2535
        }
    }
    else {
        // Make sure WinHelp is in the foreground
        SetForegroundWindow(lpwm32mpex->hwnd);
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            wow_message_release32(lpwm32mpex); /* DIV-349: activation is normal-only. */
        }
    }

    return (TRUE);
}

BOOL FASTCALL WM32SizeClipBoard(LPWM32MSGPARAMEX lpwm32mpex)
{
    HAND16 hMem16 = 0;
    VPVOID  vp;
    LPRECT  lp;



    if (lpwm32mpex->fThunk) {
#line 1681
        lpwm32mpex->Parm16.WndProc.wParam = GETHWND16(lpwm32mpex->uParam);

        vp = GlobalAllocLock16(GMEM_MOVEABLE, (lpwm32mpex->uMsg == WM_SIZECLIPBOARD) ?
                               sizeof(RECT) : sizeof(PAINTSTRUCT),  &hMem16);
        lpwm32mpex->dwParam = vp; /* DIV-349: before either lock/copy can escape. */
        lpwm32mpex->dwTmp[2] = hMem16;
#line 1685
        if (vp) {
            if (lp = (LPRECT) GlobalLock((HANDLE) lpwm32mpex->lParam)) {
                __try { /* DIV-349: native lock has its own owner. */
#line 1687
                if (lpwm32mpex->uMsg == WM_SIZECLIPBOARD) {
                    PUTRECT16(vp, lp);
                }
                else {
                    putpaintstruct16(vp, (LPPAINTSTRUCT) lp);
                }
                } __finally { GlobalUnlock((HANDLE) lpwm32mpex->lParam); }
            }
            else {
                LOGDEBUG(LOG_ALWAYS, ("WOW::WM32SizeClipboard: Couldn't lock 32 bit memory handle!\n"));
                // WOW32ASSERT (FALSE);
            }

            GlobalUnlock16(hMem16);
            lpwm32mpex->dwTmp[0] = 1; /* DIV-349: normal release must lock by stable handle. */
#line 1701
        }
        else {
            hMem16 = 0;
            LOGDEBUG(LOG_ALWAYS, ("WOW::WM32SizeClipboard: Couldn't allocate memory !\n"));
            WOW32ASSERT (FALSE);
        }

        LOW(lpwm32mpex->Parm16.WndProc.lParam) = (WORD) hMem16;
    }
    else {
        if (LOW(lpwm32mpex->Parm16.WndProc.lParam)) {
            wow_message_release32(lpwm32mpex); /* DIV-349: same lock/unlock/free sequence. */
        }
    }

    return (TRUE);
}

BOOL FASTCALL WM32DropObject(LPWM32MSGPARAMEX lpwm32mpex)
{
    register PDROPSTRUCT16 pds16;
    register LPDROPSTRUCT  lParam = (LPDROPSTRUCT)lpwm32mpex->lParam;

    if (lpwm32mpex->fThunk) {

        lpwm32mpex->Parm16.WndProc.wParam = (WORD)lpwm32mpex->uParam;

        // BUGBUG -- The assumption here is that GlobalAlloc will never
        // return a memory object that isn't word-aligned, so that we can
        // assign word-aligned words directly;  we have no idea whether the
        // memory is dword-aligned or not however, so dwords must always
        // be paranoidly stored with the STOREDWORD/STORELONG macros -JTP

        if (!(lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(sizeof(DROPSTRUCT16))))) /* DIVERGENCE(MVDM-HOST-DIV-349) */
            return FALSE;

        GETVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, sizeof(DROPSTRUCT16), pds16);

        pds16->hwndSource = GETHWND16(lParam->hwndSource);
        pds16->hwndSink   = GETHWND16(lParam->hwndSink);
        pds16->wFmt       = (WORD) lParam->wFmt;
        STOREDWORD(pds16->dwData, lParam->dwData);

        pds16->ptDrop.x = (SHORT)lParam->ptDrop.x;
        pds16->ptDrop.y = (SHORT)lParam->ptDrop.y;
        STOREDWORD(pds16->dwControlData, lParam->dwControlData);

        FLUSHVDMPTR(lpwm32mpex->Parm16.WndProc.lParam, sizeof(DROPSTRUCT16), pds16);
        FREEVDMPTR(pds16);

    } else {

        wow_message_release32(lpwm32mpex); /* DIV-349: before original cursor result conversion. */

        if (lpwm32mpex->uMsg == WM_QUERYDROPOBJECT) {

            //
            // Return value is either TRUE, FALSE,
            // or a cursor!
            //
            if (lpwm32mpex->lReturn && lpwm32mpex->lReturn != (LONG)TRUE) {
                lpwm32mpex->lReturn = (LONG)HCURSOR32(lpwm32mpex->lReturn);
            }
        }
    }

    return (TRUE);
}

BOOL FASTCALL  WM32CBDir (LPWM32MSGPARAMEX lpwm32mpex)
{
    DWORD owned = lpwm32mpex->dwParam; /* DIVERGENCE(MVDM-HOST-DIV-347): actual acquisition mode. */
#line 447
    if (lpwm32mpex->fThunk) {
#line 448
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - CB_GETEDITSEL));
        if (lpwm32mpex->lParam) {
            INT cb;

            if (W32CheckThunkParamFlag()) {
                LONG lParam = (LONG)GetParam16(lpwm32mpex->lParam);
                if (lParam) {
                    lpwm32mpex->Parm16.WndProc.lParam = lParam;
                    lpwm32mpex->dwParam = WOW_TEXT_ACTIVE | WOW_TEXT_MAPPED;
#line 456
                    return (TRUE);
                }
            }

            cb = strlen((LPSZ)lpwm32mpex->lParam)+1;
            lpwm32mpex->Parm16.WndProc.lParam = malloc16(cb);
            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;
            lpwm32mpex->dwParam = WOW_TEXT_ACTIVE;
#line 464
            putstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, cb);
        }
    } else {
        lpwm32mpex->dwParam = 0;
        if (owned & WOW_TEXT_MAPPED) {
            DeleteParamMap(lpwm32mpex->Parm16.WndProc.lParam, PARAM_16, NULL);
#line 469
            return TRUE;
#line 471
        }
        if (!(owned & WOW_TEXT_ACTIVE)) return TRUE;
#line 472
        if (lpwm32mpex->Parm16.WndProc.lParam)
            free16((VPVOID) lpwm32mpex->Parm16.WndProc.lParam);
    }

    return(TRUE);
}

BOOL FASTCALL WM32EMGetRect (LPWM32MSGPARAMEX lpwm32mpex)
{
    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - EM_GETSEL));
        lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(sizeof(RECT16)));
#line 108
        if (!(lpwm32mpex->Parm16.WndProc.lParam))
            return FALSE;
    } else {
        GETRECT16( lpwm32mpex->Parm16.WndProc.lParam, (LPRECT)lpwm32mpex->lParam );
        if (lpwm32mpex->Parm16.WndProc.lParam)
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
    }

    return (TRUE);
}

BOOL FASTCALL WM32EMSetRect (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - EM_GETSEL));
        lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(sizeof(RECT16)));
#line 132
        if (!(lpwm32mpex->Parm16.WndProc.lParam))
            return FALSE;
        PUTRECT16( lpwm32mpex->Parm16.WndProc.lParam, (LPRECT)lpwm32mpex->lParam );
    } else {
        if (lpwm32mpex->Parm16.WndProc.lParam)
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
    }

    return (TRUE);
}

BOOL FASTCALL WM32EMReplaceSel (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - EM_GETSEL));
        if (lpwm32mpex->lParam) {
            INT cb;

            cb = strlen((LPSZ)lpwm32mpex->lParam)+1;

            // winworks2.0a requires DS based string pointers for this message

            if (CURRENTPTD()->dwWOWCompatFlags & WOWCF_DSBASEDSTRINGPOINTERS) {
                lpwm32mpex->Parm16.WndProc.lParam = stackalloc16(cb);
            } else {
                lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(cb));
#line 183
            }

            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;
            putstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, cb);
        }
    } else {
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            if (CURRENTPTD()->dwWOWCompatFlags & WOWCF_DSBASEDSTRINGPOINTERS) {
                stackfree16((VPVOID) lpwm32mpex->Parm16.WndProc.lParam);
            } else {
                wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
            }
        }
    }

    return (TRUE);
}

#pragma warning(push)
#pragma warning(disable:4244)
BOOL FASTCALL WM32EMGetLine (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - EM_GETSEL));
        if (lpwm32mpex->lParam) {
            INT cb;
            PBYTE lp;

            // the first WORD is what USER uses.

            cb = *(UNALIGNED WORD *)(lpwm32mpex->lParam);
            lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(cb));
#line 233
            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;
            ALLOCVDMPTR(lpwm32mpex->Parm16.WndProc.lParam,2,lp);
            *((UNALIGNED WORD *)lp) = cb;
            FLUSHVDMPTR(lpwm32mpex->Parm16.WndProc.lParam,2,lp);  /* first 2 bytes modified */
        }
    } else {
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            PBYTE lp;

            GETMISCPTR(lpwm32mpex->Parm16.WndProc.lParam,lp);
            RtlCopyMemory((PBYTE)lpwm32mpex->lParam,lp,lpwm32mpex->lReturn);
            FREEVDMPTR(lp);
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
        }
    }

    LOGDEBUG(3,(" Window %08lX is receiving Control Message %s(%08x)\n", lpwm32mpex->hwnd, (LPSZ)GetWMMsgName(lpwm32mpex->uMsg), lpwm32mpex->uMsg));

    return (TRUE);
}
#pragma warning(pop)

BOOL FASTCALL WM32EMSetTabStops (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - EM_GETSEL));
        if (lpwm32mpex->uParam != 0) {
            lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(lpwm32mpex->uParam * sizeof(WORD)));
#line 321
            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;
            putintarray16((VPINT16)lpwm32mpex->Parm16.WndProc.lParam, (INT)lpwm32mpex->uParam, (LPINT)lpwm32mpex->lParam);
        }
    } else {
        if (lpwm32mpex->Parm16.WndProc.lParam)
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */

    }

    return (TRUE);
}

BOOL FASTCALL  WM32CBAddString (LPWM32MSGPARAMEX lpwm32mpex)
{
    PWW pww;




    if ( lpwm32mpex->fThunk ) {
        if (!(pww = lpwm32mpex->pww)) {
            if (pww = FindPWW (lpwm32mpex->hwnd, WOWCLASS_UNKNOWN))
                lpwm32mpex->pww = pww;
            else
                return FALSE;
        }

        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - CB_GETEDITSEL));

        //
        // Determine if this combobox has string pointers or handles passed
        // in with CB_ADDSTRING messages.  Normal comboboxes have string
        // pointers passed.  Owner-draw comboboxes that don't have the
        // CBS_HASSTRINGS style bit set have handles passed in.  These handles
        // are simply passed back to the owner at paint time.  If the
        // CBS_HASSTRINGS style bit is set, strings are used instead of
        // handles as the "cookie" which is passed back to the application
        // at paint time.
        //
        // We treat lpwm32mpex->dwParam as a BOOL indicating this combobox
        // takes handles instead of strings.
        //

        lpwm32mpex->dwParam =
            (pww->dwStyle & (CBS_OWNERDRAWFIXED | CBS_OWNERDRAWVARIABLE)) &&
            !(pww->dwStyle & CBS_HASSTRINGS);

        if ( !lpwm32mpex->dwParam ) {        // if strings are used
            if (lpwm32mpex->lParam) {
                INT cb;

                cb = strlen((LPSZ)lpwm32mpex->lParam)+1;
                lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(cb));
#line 410
                if (!(lpwm32mpex->Parm16.WndProc.lParam))
                    return FALSE;
                putstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, cb);
            }
        }
    } else {
        if ( !lpwm32mpex->dwParam ) {        // if strings are used
            if (lpwm32mpex->Parm16.WndProc.lParam) {
                getstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, -1);
                wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
            }
        }
    }

    LOGDEBUG(3,(" Window %08lX is receiving Control Message %s(%08x)\n", lpwm32mpex->hwnd, (LPSZ)GetWMMsgName(lpwm32mpex->uMsg), lpwm32mpex->uMsg));

    return(TRUE);

}

BOOL FASTCALL WM32CBGetLBText (LPWM32MSGPARAMEX lpwm32mpex)
{
    PWW   pww;



    if ( lpwm32mpex->fThunk ) {
        INT cb;

        if (!(pww = lpwm32mpex->pww)) {
            if (pww = FindPWW (lpwm32mpex->hwnd, WOWCLASS_UNKNOWN))
                lpwm32mpex->pww = pww;
            else
                return FALSE;
        }

        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - CB_GETEDITSEL));

        //
        // Determine if this combobox has string pointers or handles passed
        // in with CB_ADDSTRING messages.  Normal comboboxes have string
        // pointers passed.  Owner-draw comboboxes that don't have the
        // CBS_HASSTRINGS style bit set have handles passed in.  These handles
        // are simply passed back to the owner at paint time.  If the
        // CBS_HASSTRINGS style bit is set, strings are used instead of
        // handles as the "cookie" which is passed back to the application
        // at paint time.
        //
        // We treat lpwm32mpex->dwParam as a BOOL indicating this combobox
        // takes handles instead of strings.
        //

        lpwm32mpex->dwParam =
            (pww->dwStyle & (CBS_OWNERDRAWFIXED | CBS_OWNERDRAWVARIABLE)) &&
            !(pww->dwStyle & CBS_HASSTRINGS);

        //
        // Determine the size of the buffer to allocate on the 16-bit side
        // to receive the text.
        //

        if (lpwm32mpex->dwParam) {           // if handles are used
            cb = 4;
        } else {
            cb = SendMessage(lpwm32mpex->hwnd, CB_GETLBTEXTLEN, lpwm32mpex->uParam, 0);
            if (cb == CB_ERR) {
                //
                // lpwm32mpex->dwTmp[0] is initialized to 0 so that nothing
                // gets copied to the buffer by getstr16() while unthunking
                // this message.
                //
                // bug # 24415, ChandanC
                //

                cb = SIZE_BOGUS;
                lpwm32mpex->dwTmp[0] = 0;
            }
            else {
                //
                // Add one for NULL character.
                //
                cb = cb + 1;
                (INT) lpwm32mpex->dwTmp[0] = (INT) -1;
            }
        }
        if (lpwm32mpex->lParam) {
            BYTE *lpT;

            // See comment on similar code below

            lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(cb));
#line 555
            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;
            GETVDMPTR((lpwm32mpex->Parm16.WndProc.lParam), sizeof(BYTE), lpT);
            *lpT = 0;
            FREEVDMPTR(lpT);
        }
    }
    else {
        if (lpwm32mpex->lParam && lpwm32mpex->Parm16.WndProc.lParam) {
            if (lpwm32mpex->dwParam) {       // if handles are used
                UNALIGNED DWORD *lpT;
                GETVDMPTR((lpwm32mpex->Parm16.WndProc.lParam), sizeof(DWORD), lpT);
                *(UNALIGNED DWORD *)lpwm32mpex->lParam = *lpT;
                FREEVDMPTR(lpT);
            }
            else {
                getstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam,
                         (INT) lpwm32mpex->dwTmp[0]);
            }

            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */

        }
    }

    return(TRUE);
}

BOOL FASTCALL WM32CBGetDropDownControlRect (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - CB_GETEDITSEL));
        lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(sizeof(RECT16)));
#line 594
        if (!(lpwm32mpex->Parm16.WndProc.lParam))
            return FALSE;
    } else {
        GETRECT16( lpwm32mpex->Parm16.WndProc.lParam, (LPRECT)lpwm32mpex->lParam );
        if (lpwm32mpex->Parm16.WndProc.lParam)
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
    }

    return(TRUE);
}

BOOL FASTCALL WM32LBGetText (LPWM32MSGPARAMEX lpwm32mpex)
{
    PWW   pww;



    if ( lpwm32mpex->fThunk ) {
        INT cb;

        if (!(pww = lpwm32mpex->pww)) {
            if (pww = FindPWW (lpwm32mpex->hwnd, WOWCLASS_UNKNOWN))
                lpwm32mpex->pww = pww;
            else
                return FALSE;
        }

        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - LB_ADDSTRING + 1));

        //
        // Determine if this listbox has string pointers or handles passed
        // in with LB_ADDSTRING messages.  Owner-draw listboxes that don't
        // have the LBS_HASSTRINGS style bit set have handles passed in.
        // These handles are simply passed back to the owner at paint time.
        // If the LBS_HASSTRINGS style bit is set, strings are used instead of
        // handles as the "cookie" which is passed back to the application
        // at paint time.
        //
        // We treat lpwm32mpex->dwParam as a BOOL indicating this listbox
        // takes handles instead of strings.
        //

        lpwm32mpex->dwParam =
            (pww->dwStyle & (LBS_OWNERDRAWFIXED | LBS_OWNERDRAWVARIABLE)) &&
            !(pww->dwStyle & LBS_HASSTRINGS);

        if (lpwm32mpex->dwParam) {    // if this listbox takes handles
            cb = 4;
        }
        else {
            cb = SendMessage(lpwm32mpex->hwnd, LB_GETTEXTLEN, lpwm32mpex->uParam, 0);

            // Check for LB_ERR (which is -1) on the above SendMessage().
            // When cb is equal to LB_ERR make the size as SIZE_BOGUS (256 bytes),
            // and allocate a buffer just in case if the app diddles the lParam.
            // We will free the buffer while unthunking the message (LB_GETTEXT).
            // This fix makes the app MCAD happy.
            // ChandanC 4-21-93.

            if (cb == LB_ERR) {
                cb = SIZE_BOGUS;
            }
            else {
                //
                // Add one for NULL character.
                //
                cb = cb + 1;
            }

        }

        if (lpwm32mpex->lParam) {
            BYTE *lpT;

            lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(cb));
#line 728
            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;

            // The reason for this code to be here is that sometimes thunks 
            // are executed on a buffer that has not been initialized, e.g.
            // if the hooks are installed by a wow app. That means we will 
            // alloc 16-bit buffer while thunking (boils down to uninitialized
            // data buffer and will try to copy the buffer back while unthunking
            // overwriting the stack sometimes (as user allocates temp bufs from
            // the stack). This code initializes data so problem is avoided
            // App: Grammatik/Windows v6.0 -- VadimB

            GETVDMPTR((lpwm32mpex->Parm16.WndProc.lParam), sizeof(BYTE), lpT);
            *lpT = 0;
            FREEVDMPTR(lpT);
        }
    }
    else {

        if ((lpwm32mpex->lReturn != LB_ERR) && lpwm32mpex->lParam && lpwm32mpex->Parm16.WndProc.lParam) {
            if (lpwm32mpex->dwParam) {   // if this listbox takes handles
                UNALIGNED DWORD *lpT;
                GETVDMPTR((lpwm32mpex->Parm16.WndProc.lParam), sizeof(DWORD), lpT);
                *(UNALIGNED DWORD *)lpwm32mpex->lParam = *lpT;
                FREEVDMPTR(lpT);
            }
            else {
                getstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, -1);
            }
        }

        if (lpwm32mpex->Parm16.WndProc.lParam) {
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
        }
    }

    return(TRUE);
}

BOOL FASTCALL WM32LBDir (LPWM32MSGPARAMEX lpwm32mpex)
{
    INT cb;
    VPVOID vp;


    if (lpwm32mpex->fThunk) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - LB_ADDSTRING + 1));
        if (lpwm32mpex->lParam) {
            cb = strlen((LPSTR)lpwm32mpex->lParam)+1;
            if (!(vp = wow_message_heap32(lpwm32mpex, malloc16(cb)))) {
#line 816
                LOGDEBUG(0,(" WOW32.DLL : WM32LBDir() :: Could not allocate memory for string, ChandanC\n"));
                WOW32ASSERT(vp);
                return FALSE;
            }
            putstr16(vp, (LPSTR) lpwm32mpex->lParam, cb);
            lpwm32mpex->Parm16.WndProc.lParam = vp;
        }
    }
    else {
        if (lpwm32mpex->Parm16.WndProc.lParam) {
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
        }
    }

    return(TRUE);
}

BOOL FASTCALL WM32LBGetSelItems (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - LB_ADDSTRING + 1));
        if (lpwm32mpex->lParam) {
            INT cb;

            cb = lpwm32mpex->uParam * sizeof(WORD);
            lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(cb));
#line 847
            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;

        }
    } else {
        getintarray16((VPRECT16)lpwm32mpex->Parm16.WndProc.lParam, (INT)lpwm32mpex->uParam, (LPINT)lpwm32mpex->lParam);
        if (lpwm32mpex->Parm16.WndProc.lParam)
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
    }

    return(TRUE);
}

BOOL FASTCALL WM32LBSetTabStops (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - LB_ADDSTRING + 1));
        if (lpwm32mpex->uParam != 0) {
            lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(lpwm32mpex->uParam * sizeof(WORD)));
#line 872
            if (!(lpwm32mpex->Parm16.WndProc.lParam))
                return FALSE;
            putintarray16((VPRECT16)lpwm32mpex->Parm16.WndProc.lParam, (INT)lpwm32mpex->uParam, (LPINT)lpwm32mpex->lParam);
        }
    } else {
        if (lpwm32mpex->Parm16.WndProc.lParam)
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
    }

    return(TRUE);
}

BOOL FASTCALL WM32LBGetItemRect (LPWM32MSGPARAMEX lpwm32mpex)
{

    if ( lpwm32mpex->fThunk ) {
        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - LB_ADDSTRING + 1));
        lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(sizeof(RECT16)));
#line 894
        if (!(lpwm32mpex->Parm16.WndProc.lParam))
            return FALSE;
    } else {
        GETRECT16( lpwm32mpex->Parm16.WndProc.lParam, (LPRECT)lpwm32mpex->lParam );
        if (lpwm32mpex->Parm16.WndProc.lParam)
            wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
    }

    LOGDEBUG(3,(" Window %08lX is receiving Control Message %s(%08x)\n", lpwm32mpex->hwnd, (LPSZ)GetWMMsgName(lpwm32mpex->uMsg), lpwm32mpex->uMsg));

    return(TRUE);

}

BOOL FASTCALL WM32LBAddString (LPWM32MSGPARAMEX lpwm32mpex)
{
    PWW   pww;


    if ( lpwm32mpex->fThunk ) {
        if (!(pww = lpwm32mpex->pww)) {
            if (pww = FindPWW (lpwm32mpex->hwnd, WOWCLASS_UNKNOWN))
                lpwm32mpex->pww = pww;
            else
                return FALSE;
        }

        lpwm32mpex->Parm16.WndProc.wMsg = (WORD) (WM_USER + (lpwm32mpex->uMsg - LB_ADDSTRING + 1));

        //
        // Determine if this listbox has string pointers or handles passed
        // in with LB_ADDSTRING messages.  Owner-draw listboxes that don't
        // have the LBS_HASSTRINGS style bit set have handles passed in.
        // These handles are simply passed back to the owner at paint time.
        // If the LBS_HASSTRINGS style bit is set, strings are used instead of
        // handles as the "cookie" which is passed back to the application
        // at paint time.
        //
        // We treat lpwm32mpex->dwParam as a BOOL indicating this listbox
        // takes handles instead of strings.
        //

        lpwm32mpex->dwParam =
            (pww->dwStyle & (LBS_OWNERDRAWFIXED | LBS_OWNERDRAWVARIABLE)) &&
            !(pww->dwStyle & LBS_HASSTRINGS);

        if ( !lpwm32mpex->dwParam ) {   // if this listbox takes strings
            if (lpwm32mpex->lParam) {
                INT cb;

                cb = strlen((LPSZ)lpwm32mpex->lParam)+1;
                lpwm32mpex->Parm16.WndProc.lParam = wow_message_heap32(lpwm32mpex, malloc16(cb));
#line 954
                if (!(lpwm32mpex->Parm16.WndProc.lParam))
                    return FALSE;
                putstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, cb);
            }
        }
    } else {
        if ( !lpwm32mpex->dwParam ) {   // if this listbox takes strings
            if (lpwm32mpex->Parm16.WndProc.lParam) {
                getstr16((VPSZ)lpwm32mpex->Parm16.WndProc.lParam, (LPSZ)lpwm32mpex->lParam, -1);
                wow_message_release32(lpwm32mpex); /* DIV-349: original copyback is unchanged. */
            }
        }
    }

    return(TRUE);
}

BOOL FASTCALL WM32msgSHAREVIOLATION(LPWM32MSGPARAMEX lpwm32mpex)
{
    INT cb;
    PLONG plParamNew = &lpwm32mpex->Parm16.WndProc.lParam;


    if (lpwm32mpex->fThunk) {
        if (lpwm32mpex->lParam) {
            cb = strlen((LPSZ)lpwm32mpex->lParam)+1;
            if (!(*plParamNew = wow_message_heap32(lpwm32mpex, malloc16(cb)))) { /* DIV-349 */
                return(FALSE);
            }
            putstr16((VPSZ)*plParamNew, (LPSZ)lpwm32mpex->lParam, cb);
        }
    } else {
        if (*plParamNew) {
            wow_message_release32(lpwm32mpex); /* DIV-349: consume once. */
        }
    }

    return (TRUE);
}

LONG ThunkCbtHook(INT nCode, LONG wParam, LONG lParam,
                                                     LPHOOKSTATEDATA lpHSData)
{
    LONG lReturn = FALSE;
    PARM16 Parm16;

    VPVOID vp;
    PMOUSEHOOKSTRUCT16 pMHStruct16;
    PCBTACTIVATESTRUCT16 pCbtAStruct16;
    VPCREATESTRUCT16     vpcs16;
    PCBT_CREATEWND16     pCbtCWnd16;
    WM32MSGPARAMEX       wm32mpex = {0}; /* DIVERGENCE(MVDM-HOST-DIV-349): actual independent CREATE owner. */
    wow_message_stack stack;
    BOOL fCallback;
    wow_message_stack_enter(&stack);
    __try {

#line 660
    Parm16.HookProc.nCode = (SHORT)nCode;
    Parm16.HookProc.wParam = (SHORT)wParam;
    Parm16.HookProc.lParam = lParam;

    switch(nCode) {
        case HCBT_MOVESIZE:

            // wParam = HWND, lParam = LPRECT

            Parm16.HookProc.wParam = GETHWND16(wParam);
            vp = stackalloc16(sizeof(RECT16));

            PUTRECT16(vp, (LPRECT)lParam);

            Parm16.HookProc.lParam = vp;

            break;

        case HCBT_MINMAX:

            // wParam = HWND, lParam = SW_*  --- a command

            Parm16.HookProc.wParam = GETHWND16(wParam);
            break;

        case HCBT_QS:

            // wParam = 0, lParam = 0

            break;

        case HCBT_CREATEWND:

            // wParam = HWND, lParam = LPCBT_CREATEWND

            wm32mpex.fThunk = THUNKMSG;
            wm32mpex.hwnd = (HWND)wParam;
            wm32mpex.uMsg = 0;
            wm32mpex.uParam = 0;
            wm32mpex.lParam = (LONG)((LPCBT_CREATEWND)lParam)->lpcs;
            wm32mpex.pww = (PWW)GetWindowLong((HWND)wParam, GWL_WOWWORDS);
            /*
             * WM32Create now requires that pww be initialized
             */
#line 704
            if (!wm32mpex.pww || !WM32Create(&wm32mpex))
                return FALSE;
            vpcs16 = wm32mpex.Parm16.WndProc.lParam;
            lReturn = wm32mpex.lReturn;

            vp = stackalloc16(sizeof(CBT_CREATEWND16));

            GETMISCPTR(vp, pCbtCWnd16);
            STOREDWORD(pCbtCWnd16->vpcs, vpcs16);
            STOREWORD(pCbtCWnd16->hwndInsertAfter,
            GETHWNDIA16(((LPCBT_CREATEWND)lParam)->hwndInsertAfter));

            Parm16.HookProc.wParam = GETHWND16(wParam);
            Parm16.HookProc.lParam = vp;

            FLUSHVDMPTR(vp, sizeof(CBT_CREATEWND16), pCbtCWnd16);
            FREEVDMPTR(pCbtCWnd16);
            break;

        case HCBT_DESTROYWND:

            // wParam = HWND, lParam = 0

            Parm16.HookProc.wParam = GETHWND16(wParam);
            break;

        case HCBT_ACTIVATE:

            // wParam = HWND, lParam = LPCBTACTIVATESTRUCT

            vp = stackalloc16(sizeof(CBTACTIVATESTRUCT16));

            GETMISCPTR(vp, pCbtAStruct16);
            PUTCBTACTIVATESTRUCT16(pCbtAStruct16, ((LPCBTACTIVATESTRUCT)lParam));

            Parm16.HookProc.wParam = GETHWND16(wParam);
            Parm16.HookProc.lParam = vp;

            FLUSHVDMPTR(vp, sizeof(CBTACTIVATESTRUCT16), pCbtAStruct16);
            FREEVDMPTR(pCbtAStruct16);
            break;

        case HCBT_CLICKSKIPPED:

            // wParam = mouse message, lParam = LPMOUSEHOOKSTRUCT

            vp = stackalloc16(sizeof(MOUSEHOOKSTRUCT16));

            GETMISCPTR(vp, pMHStruct16);
            PUTMOUSEHOOKSTRUCT16(pMHStruct16, (LPMOUSEHOOKSTRUCT)lParam);

            Parm16.HookProc.lParam = vp;

            FLUSHVDMPTR(vp, sizeof(MOUSEHOOKSTRUCT16), pMHStruct16);
            FREEVDMPTR(pMHStruct16);
            break;

        case HCBT_KEYSKIPPED:

            // wParam, lParam   -- keyup/down message params

            break;

        case HCBT_SYSCOMMAND:

            // wParam = SC_ syscomand, lParam = DWORD(x,y)

            break;

        case HCBT_SETFOCUS:

            // wParam = HWND, lParam = HWND

            Parm16.HookProc.wParam = GETHWND16(wParam);
            Parm16.HookProc.lParam = GETHWND16(lParam);
            break;

        default:
            LOGDEBUG(LOG_ALWAYS, ("ThunkCbtHook: Unknown HCBT_ code\n"));
            break;
    }

    fCallback = CallBack16(RET_HOOKPROC, &Parm16, lpHSData->Proc16, (PVPVOID)&lReturn); /* DIV-349 */

    switch(nCode) {
        case HCBT_MOVESIZE:

            GETRECT16(vp, (LPRECT)lParam);
            stackfree16(vp);
            break;

        case HCBT_CREATEWND:
            GETMISCPTR(vp, pCbtCWnd16);
            ((LPCBT_CREATEWND)lParam)->hwndInsertAfter =
                               HWNDIA32(FETCHWORD(pCbtCWnd16->hwndInsertAfter));
            FREEVDMPTR(pCbtCWnd16);
            wm32mpex.fThunk = UNTHUNKMSG;
            wm32mpex.lReturn = lReturn;
            WM32Create(&wm32mpex);
            lReturn = wm32mpex.lReturn;
            stackfree16(vp);
            break;


        case HCBT_ACTIVATE:

            GETMISCPTR(vp, pCbtAStruct16);
            GETCBTACTIVATESTRUCT16(pCbtAStruct16, (LPCBTACTIVATESTRUCT)lParam);
            FREEVDMPTR(pCbtAStruct16);
            stackfree16(vp);
            break;

        case HCBT_CLICKSKIPPED:

            GETMISCPTR(vp, pMHStruct16);
            GETMOUSEHOOKSTRUCT16(pMHStruct16, (LPMOUSEHOOKSTRUCT)lParam);
            FREEVDMPTR(pMHStruct16);
            stackfree16(vp);
            break;

        // case HCBT_MINMAX:
        // case HCBT_QS:
        // case HCBT_DESTROYWND:
        // case HCBT_KEYSKIPPED:
        // case HCBT_SYSCOMMAND:
        // case HCBT_SETFOCUS:

        default:
            break;
    }

    // the value in LOWORD is the valid return value

    stack.completed = fCallback; /* DIV-349: all original output conversion has returned. */
#line 837
    return (LONG)(BOOL)LOWORD(lReturn);
    } __finally {
        __try { wow_message_unwind32(&wm32mpex); }
        __finally { wow_message_stack_leave(&stack, AbnormalTermination()); }
    }
#line 838
}

VOID GetEventMessage16(PEVENTMSG16 pEventMsg16, LPEVENTMSG  lpEventMsg)
{
    lpEventMsg->message   = FETCHWORD(pEventMsg16->message);
    lpEventMsg->time      = FETCHLONG(pEventMsg16->time);
    if ((lpEventMsg->message >= WM_KEYFIRST) && (lpEventMsg->message <= WM_KEYLAST)) {
        // Key event
        lpEventMsg->paramL =  FETCHWORD(pEventMsg16->paramL);
        lpEventMsg->paramH =  FETCHWORD(pEventMsg16->paramH) & 0x8000;
        lpEventMsg->paramH |= (lpEventMsg->paramL & 0xFF00) >> 8;
        lpEventMsg->paramL &= 0xFF;
    }
    else {
        // Mouse event
        lpEventMsg->paramL = FETCHWORD(pEventMsg16->paramL);
        lpEventMsg->paramH = FETCHWORD(pEventMsg16->paramH);
    }
}

LONG ThunkJournalHook(INT nCode, LONG wParam, LPEVENTMSG lpEventMsg,
                                                     LPHOOKSTATEDATA lpHSData)
{
    LONG lReturn;
    VPVOID vp;
    PEVENTMSG16 pEventMsg16;
    PARM16 Parm16;
    wow_message_stack stack; /* DIVERGENCE(MVDM-HOST-DIV-349): EVENTMSG stack transaction. */
    wow_message_stack_enter(&stack);
    __try {

#line 1124
    if ( lpEventMsg ) {
        vp = stackalloc16(sizeof(EVENTMSG16));


        // The WIN32 EVENTMSG structure has an additional field 'hwnd', which
        // is not there in WIN31 EVENTMSG structure. This field can be ignored
        // without any repercussions.

        if (lpHSData->iHook == WH_JOURNALRECORD) {
            GETMISCPTR(vp, pEventMsg16);
            PUTEVENTMSG16(pEventMsg16, lpEventMsg);
            FLUSHVDMPTR(vp, sizeof(EVENTMSG16), pEventMsg16);
            FREEVDMPTR(pEventMsg16);
        }


    } else {
        // lpEventMsg can be NULL indicating that no message data is requested.
        // If this is the case, there is no need to copy data for either
        // journal record or playback.
        vp = (VPVOID)0;
    }

    Parm16.HookProc.nCode = (SHORT)nCode;
    Parm16.HookProc.wParam = (SHORT)wParam;
    Parm16.HookProc.lParam = vp;

    stack.completed = CallBack16(RET_HOOKPROC, &Parm16, lpHSData->Proc16, (PVPVOID)&lReturn); /* DIV-349 */

    if ( lpEventMsg ) {
        GETMISCPTR(vp, pEventMsg16);

        if (lpHSData->iHook == WH_JOURNALPLAYBACK) {
            GetEventMessage16(pEventMsg16, lpEventMsg);

#ifdef  DEBUG
#line 1160
#error Excluded unsupported DEBUG WOW profile
#endif
#line 1164

        } else {
            WOW32ASSERT(lpHSData->iHook == WH_JOURNALRECORD);
            WOW32ASSERT(aw32Msg[FETCHWORD(pEventMsg16->message)].lpfnM32 == WM32NoThunking);

            // If the app modified the message then copy the new message info
            // (rather than copying it every time we only copy it if the
            // app change the message)
            if (FETCHWORD(pEventMsg16->message) != lpEventMsg->message) {
                GetEventMessage16(pEventMsg16, lpEventMsg);
            }
        }

        FREEVDMPTR(pEventMsg16);
        stackfree16(vp);
    }

    } __finally { wow_message_stack_leave(&stack, AbnormalTermination()); }
#line 1181
    return lReturn;
#line 1182
}

LONG ThunkMouseHook(INT nCode, LONG wParam, LPMOUSEHOOKSTRUCT lpMHStruct,
                                                     LPHOOKSTATEDATA lpHSData)
{
    LONG lReturn;
    VPVOID vp;
    PMOUSEHOOKSTRUCT16 pMHStruct16;
    PARM16 Parm16;
    wow_message_stack stack; /* DIVERGENCE(MVDM-HOST-DIV-349): MOUSEHOOK stack transaction. */
    wow_message_stack_enter(&stack);
    __try {

#line 1231
    vp = stackalloc16(sizeof(MOUSEHOOKSTRUCT16));

    GETMISCPTR(vp, pMHStruct16);
    PUTMOUSEHOOKSTRUCT16(pMHStruct16, lpMHStruct);

    Parm16.HookProc.nCode = (SHORT)nCode;
    Parm16.HookProc.wParam = (SHORT)wParam;
    Parm16.HookProc.lParam = vp;

    FLUSHVDMPTR(vp, sizeof(MOUSEHOOKSTRUCT16), pMHStruct16);
    FREEVDMPTR(pMHStruct16);

    stack.completed = CallBack16(RET_HOOKPROC, &Parm16, lpHSData->Proc16, (PVPVOID)&lReturn); /* DIV-349 */

    GETMISCPTR(vp, pMHStruct16);
    GETMOUSEHOOKSTRUCT16(pMHStruct16, lpMHStruct);
    FREEVDMPTR(pMHStruct16);
    stackfree16(vp);
    } __finally { wow_message_stack_leave(&stack, AbnormalTermination()); }
#line 1249
    return (LONG)(BOOL)LOWORD(lReturn);
#line 1250
}

BOOL FASTCALL ThunkWMMsg16(LPMSGPARAMEX lpmpex) { LONG lParam=lpmpex->Parm16.WndProc.lParam; PLONG plParamNew=&lpmpex->lParam; switch(lpmpex->Parm16.WndProc.wMsg) {
    case WM_SETTEXT:    // 00Ch, <SLPre,SLPost   >
    case WM_WININICHANGE:   // 01Ah, <SLPre,       LS>
    case WM_DEVMODECHANGE:  // 01Bh, <SLPre,       LS>
        {
            LONG lParamMap;

#line 220
            GETPSZPTR(lParam, (LPSZ)lParamMap);
            if (lParamMap) lpmpex->MsgBuffer->text.flags = WOW_TEXT_ACTIVE;
#line 221
            *plParamNew = (LONG)AddParamMap(lParamMap, lParam);
            if (*plParamNew)
                lpmpex->MsgBuffer->text.flags |= WOW_TEXT_MAPPED;
            else
                *plParamNew = lParamMap;
#line 222
            if (lParamMap != *plParamNew) {
                FREEPSZPTR((LPSZ)lParamMap);
            }

        }
        break;


} return TRUE; }

VOID FASTCALL UnThunkWMMsg16(LPMSGPARAMEX lpmpex) { switch(lpmpex->Parm16.WndProc.wMsg) {
    case WM_SETTEXT:        // 00Ch, <SLPre,SLPost   >
    case WM_WININICHANGE:   // 01Ah, <SLPre,       LS>
    case WM_DEVMODECHANGE:  // 01Bh, <SLPre,       LS>
        {
            DWORD owned = lpmpex->MsgBuffer->text.flags;
            BOOL fFreePtr = TRUE;
            lpmpex->MsgBuffer->text.flags = 0;
            if (owned & WOW_TEXT_MAPPED)
                DeleteParamMap(lpmpex->Parm16.WndProc.lParam, PARAM_16, &fFreePtr);
#line 1172
            if (fFreePtr) {
                FREEPSZPTR((LPSZ)lpmpex->lParam);
            }
        }
        break;


} }

BOOL FASTCALL ThunkCBMsg16(LPMSGPARAMEX lpmpex)
{
    register PWW pww;
    WORD wMsg = lpmpex->Parm16.WndProc.wMsg;

    LOGDEBUG(7,("    Thunking 16-bit combo box message %s(%04x)\n", (LPSZ)GetCBMsgName(wMsg), wMsg));

    // Sudeepb - 04-Mar-1996
    // Fix the broken thunking for CBEC_SETCOMBOFOCUS and CBEC_KILLCOMBOFOCUS.
    // It was broken when NT user merged with Win95 where CB_MAX has changed.
    // the following code is written in such a manner that the only dependency
    // we have is that CBEC_SETCOMBOFOCUS precedes CBEC_KILLCOMBOFOCUS which
    // will always be true.


    if (wMsg == OLDCBEC_SETCOMBOFOCUS || wMsg == OLDCBEC_KILLCOMBOFOCUS) {
        lpmpex->uMsg = (WORD)(wMsg - OLDCBEC_SETCOMBOFOCUS + CBEC_SETCOMBOFOCUS);
        return  TRUE;
    }

    wMsg -= WM_USER;

    //
    // For app defined (control) messages that are out of range
    // return TRUE.
    //
    // ChandanC Sept-15-1992
    //

    if (wMsg < (CB_FINDSTRINGEXACT - CB_GETEDITSEL + 4)) {

        switch(lpmpex->uMsg = wMsg + CB_GETEDITSEL) {
            case CB_SELECTSTRING:
            case CB_FINDSTRINGEXACT:
            case CB_FINDSTRING:
            case CB_INSERTSTRING:
            case CB_ADDSTRING:
                if (!(pww = lpmpex->pww))
                    return FALSE;
        
                if (!(pww->dwStyle & (CBS_OWNERDRAWFIXED|CBS_OWNERDRAWVARIABLE)) ||
                       (pww->dwStyle & (CBS_HASSTRINGS))) {
                    GETPSZPTR(lpmpex->Parm16.WndProc.lParam, (LPSZ)lpmpex->lParam);
                }
                break;
        
        
            case CB_GETLBTEXT:
                if (NULL != (pww = lpmpex->pww)) {
	                register PTHUNKTEXTDWORD pthkdword = (PTHUNKTEXTDWORD)lpmpex->MsgBuffer;

	                //  see comments in the file wmsglb.c 
                    //

	                pthkdword->fDWORD = (pww->dwStyle & (CBS_OWNERDRAWFIXED|CBS_OWNERDRAWVARIABLE)) &&
	                                    !(pww->dwStyle & (CBS_HASSTRINGS));
	
	                if (pthkdword->fDWORD) {
	                    lpmpex->lParam = (LPARAM)(LPVOID)&pthkdword->dwDataItem;
                        break;
	                }
	            }
                else {
                    register PTHUNKTEXTDWORD pthkdword = (PTHUNKTEXTDWORD)lpmpex->MsgBuffer;
                    pthkdword->fDWORD = FALSE;
                }
                
                GETPSZPTR(lpmpex->Parm16.WndProc.lParam, (LPSZ)lpmpex->lParam);
                break;
	 
            case CB_DIR:
#line 137
                GETPSZPTR(lpmpex->Parm16.WndProc.lParam, (LPSZ)lpmpex->lParam);
                if (lpmpex->lParam) lpmpex->MsgBuffer->text.flags = WOW_TEXT_ACTIVE;

#line 139
                if (W32CheckThunkParamFlag()) {
                    if (AddParamMap(lpmpex->lParam, lpmpex->Parm16.WndProc.lParam))
                        lpmpex->MsgBuffer->text.flags |= WOW_TEXT_MAPPED;
#line 141
                }
                break;

            case CB_GETDROPPEDCONTROLRECT:
                lpmpex->lParam = (LONG)lpmpex->MsgBuffer;
                break;
        }
    }
    return TRUE;
}

VOID FASTCALL UnThunkCBMsg16(LPMSGPARAMEX lpmpex)
{
    if (lpmpex->Parm16.WndProc.wMsg == OLDCB_DIR) {
        DWORD owned = lpmpex->MsgBuffer->text.flags;
        lpmpex->MsgBuffer->text.flags = 0;
        if (owned & WOW_TEXT_MAPPED)
            DeleteParamMap(lpmpex->Parm16.WndProc.lParam, PARAM_16, NULL);
        return;
    }
#line 155
    switch(lpmpex->uMsg) {

        case CB_GETLBTEXT:
	        {
	           register PTHUNKTEXTDWORD pthkdword = (PTHUNKTEXTDWORD)lpmpex->MsgBuffer;
	
	           if (pthkdword->fDWORD) { 
	                // this is a dword, not a string
	                // assign the dword as unaligned
	                UNALIGNED DWORD *lpdwDataItem;
	
	                GETVDMPTR((lpmpex->Parm16.WndProc.lParam), sizeof(DWORD), lpdwDataItem);
	                *lpdwDataItem = pthkdword->dwDataItem;
	                FREEVDMPTR(lpdwDataItem);
	                break;
	           }
	 
	        }
	
	        // fall through to the common code

        case CB_ADDSTRING:
        case CB_FINDSTRING:
        case CB_FINDSTRINGEXACT:
        case CB_INSERTSTRING:
        case CB_SELECTSTRING:
            FREEPSZPTR((LPSZ)lpmpex->lParam);
            break;

#line 192
        case CB_GETDROPPEDCONTROLRECT:
            if (lpmpex->lParam) {
                putrect16((VPRECT16)lpmpex->Parm16.WndProc.lParam, (LPRECT)lpmpex->lParam);
            }
            break;
    }
}

/* ADAPTER-WOW-095: original unthunkers own rollback and release. */

extern BOOL WINAPI wow_user_worker_active(void);
/* Original wcall16.h aliases these names but its referenced winntwow.h
 * declarations are absent from this selected SDK facade. Exact x86 ABI. */
extern VPVOID WINAPI WOWGlobalLockSize16(HMEM16, LPDWORD);
extern HMEM16 WINAPI WOWGlobalUnlockFree16(VPVOID);

/* ADAPTER-WOW-101: use the original allocators, not a second resource map.
 * dwTmp[1] is the captured heap token except in CREATE/MDICREATE/COPYDATA.
 * No other original converter uses that slot (CB_GETLBTEXT uses dwTmp[0]). */
DWORD WINAPI wow_message_heap32(LPWM32MSGPARAMEX message, DWORD value)
{
    message->dwTmp[1] = value;
    return value;
}

void WINAPI wow_message_free16(DWORD *key, BOOL class_atom)
{
    DWORD value = *key;
    *key = 0;
    if (value && (!class_atom || HIWORD(value)) && wow_user_worker_active())
        free16(value);
}

static void release_mdi(DWORD *class_key, DWORD *title_key, DWORD *record_key)
{
    __try { wow_message_free16(title_key, FALSE); }
    __finally {
        __try { wow_message_free16(class_key, TRUE); }
        __finally { wow_message_free16(record_key, FALSE); }
    }
}

void WINAPI wow_message_release32(LPWM32MSGPARAMEX message)
{
    DWORD value, handle, unlocked;
    if (message->uMsg == WM_COPYDATA) return; /* Original protocol owns it. */
    if (message->lpfnM32 == WM32Create) {
        __try { release_mdi(&message->dwParam, &message->dwTmp[2], &message->dwTmp[3]); }
        __finally {
            __try { wow_message_free16(&message->dwTmp[0], TRUE); }
            __finally { wow_message_free16(&message->dwTmp[1], FALSE); }
        }
    } else if (message->lpfnM32 == WM32MDICreate) {
        release_mdi(&message->dwParam, &message->dwTmp[0], &message->dwTmp[1]);
    } else if (message->lpfnM32 == WM32SizeClipBoard || message->lpfnM32 == WM32WinHelp) {
        value = message->dwParam;
        handle = message->dwTmp[2];
        unlocked = message->dwTmp[0];
        message->dwParam = message->dwTmp[0] = message->dwTmp[2] = 0;
        if (value && wow_user_worker_active()) {
            if (message->lpfnM32 == WM32SizeClipBoard && unlocked)
                value = WOWGlobalLockSize16((HMEM16)handle, NULL);
            WOWGlobalUnlockFree16(value);
        }
    } else {
        wow_message_free16(&message->dwTmp[1], FALSE);
    }
}

void WINAPI wow_message_stack_enter(wow_message_stack *scope)
{
    DWORD error = GetLastError();
    PTD ptd = CURRENTPTD();
    scope->task = ptd;
    scope->cursor = ptd ? ptd->vpCBStack : 0;
    scope->init = ptd ? ptd->dwFlags & TDF_INITCALLBACKSTACK : 0;
    scope->task16 = ptd ? ptd->htask16 : 0;
    scope->completed = FALSE;
    SetLastError(error);
}

void WINAPI wow_message_stack_leave(wow_message_stack *scope, BOOL abnormal)
{
    DWORD error = GetLastError();
    PTD ptd;
    if ((!scope->completed || abnormal) && wow_user_worker_active()) {
        ptd = CURRENTPTD();
        /* Inspect only the live authority, never dereference a retired TD. */
        if (ptd && ptd == scope->task && ptd->htask16 == scope->task16) {
            ptd->vpCBStack = scope->cursor;
            if (!(ptd->dwFlags & TDF_IGNOREINPUT))
                ptd->dwFlags = (ptd->dwFlags & ~TDF_INITCALLBACKSTACK) | scope->init;
        }
    }
    SetLastError(error);
}

void WINAPI wow_message_unwind32(LPWM32MSGPARAMEX message)
{
    DWORD error = GetLastError();
    if (message->uMsg == WM_COPYDATA && message->dwParam) {
        message->fThunk = UNTHUNKMSG;
        (void)WM32CopyData(message);
    }
    /* ADAPTER-WOW-098: only these original input-only unthunkers are pure. */
    if ((message->lpfnM32 == WM32SetText || message->lpfnM32 == WM32CBDir) &&
            message->dwParam) {
        message->fThunk = UNTHUNKMSG;
        (void)message->lpfnM32(message);
    }
    /* Release only captured call-owned keys; never replay output unthunkers. */
    __try { wow_message_release32(message); }
    __finally { SetLastError(error); }
}

void WINAPI wow_message_unwind16(LPMSGPARAMEX message)
{
    DWORD error = GetLastError();
    if (message->Parm16.WndProc.wMsg == WM_COPYDATA &&
            message->MsgBuffer->copydata.flags)
        UnThunkWMMsg16(message);
    if (((message->lpfnUnThunk16 == UnThunkWMMsg16 &&
              (message->Parm16.WndProc.wMsg == WM_SETTEXT ||
               message->Parm16.WndProc.wMsg == WM_WININICHANGE ||
               message->Parm16.WndProc.wMsg == WM_DEVMODECHANGE)) ||
             (message->lpfnUnThunk16 == UnThunkCBMsg16 &&
              message->Parm16.WndProc.wMsg == OLDCB_DIR)) &&
            (message->MsgBuffer->text.flags & WOW_TEXT_ACTIVE))
        message->lpfnUnThunk16(message);
    SetLastError(error);
}


static UINT fixture_common_dialog_filter(UINT uMsg,UINT msgWOWCHOOSEFONT) { wow_message_stack stack; WM32MSGPARAMEX wm32mpex = {0}; wow_message_stack_enter(&stack); __try {
            if (uMsg == msgWOWCHOOSEFONT) {
                //
                // no wow app will expect this, so don't send it.
                //
#line 770
                return(FALSE);
            }
return 1;
    } __finally {
        __try { wow_message_unwind32(&wm32mpex); }
        __finally { wow_message_stack_leave(&stack, !stack.completed || AbnormalTermination()); }
    }
#line 845
}


static LONG fixture_notification_current(HWND hwnd,UINT uMsg,UINT uParam,LONG lParam) { wow_message_stack stack; WM32MSGPARAMEX wm32mpex = {0}; (void)uParam; (void)lParam; wow_message_stack_enter(&stack); __try {
    if (uMsg == EM_SCROLLCARET) {
        WNDPROC EditWndProc;

        // find the 32-bit EditWindowProc
        // We should only be in this state if the app has subclassed so this
        // call should be safe.

        EditWndProc = (WNDPROC)GetStdClassWndProc(WOWCLASS_EDIT);

        if (EditWndProc) {
            CallWindowProc(EditWndProc, hwnd, EM_SCROLLCARET, 0, 0);
        }
        else {
            LOGDEBUG(LOG_ALWAYS,("    W32Win16WndProc ERROR: cannot find 32-bit EditWindowProc\n"));
        }
        stack.completed = TRUE; /* DIV-349: successful native-only notification. */
#line 130
        return 0;   // notification message, no return code
    }
return -1;
    } __finally {
        __try { wow_message_unwind32(&wm32mpex); }
        __finally { wow_message_stack_leave(&stack, AbnormalTermination()); }
    }
#line 249
}


static LONG fixture_notification_omitted(HWND hwnd,UINT uMsg,UINT uParam,LONG lParam) { wow_message_stack stack; WM32MSGPARAMEX wm32mpex = {0}; (void)uParam; (void)lParam; wow_message_stack_enter(&stack); __try {
    if (uMsg == EM_SCROLLCARET) {
        WNDPROC EditWndProc;

        // find the 32-bit EditWindowProc
        // We should only be in this state if the app has subclassed so this
        // call should be safe.

        EditWndProc = (WNDPROC)GetStdClassWndProc(WOWCLASS_EDIT);

        if (EditWndProc) {
            CallWindowProc(EditWndProc, hwnd, EM_SCROLLCARET, 0, 0);
        }
        else {
            LOGDEBUG(LOG_ALWAYS,("    W32Win16WndProc ERROR: cannot find 32-bit EditWindowProc\n"));
        }

#line 130
        return 0;   // notification message, no return code
    }
return -1;
    } __finally {
        __try { wow_message_unwind32(&wm32mpex); }
        __finally { wow_message_stack_leave(&stack, AbnormalTermination()); }
    }
#line 249
}


HWND FASTCALL ThunkMsg16(LPMSGPARAMEX lpmpex)
{
    BOOL f;
    register PWW pww = NULL;
    INT iClass;
    WORD wMsg = lpmpex->Parm16.WndProc.wMsg;

#line 123
    lpmpex->uMsg = wMsg;
    lpmpex->uParam = INT32(lpmpex->Parm16.WndProc.wParam);  // Sign extend
    lpmpex->lParam =lpmpex->Parm16.WndProc.lParam;
    lpmpex->hwnd   = HWND32(lpmpex->Parm16.WndProc.hwnd);


    if (wMsg < WM_USER) {
        iClass = (aw32Msg[wMsg].lpfnM32 == WM32NoThunking) ?
                                         WOWCLASS_NOTHUNK :  WOWCLASS_WIN16;
    }
    else {
        pww = FindPWW(lpmpex->hwnd, WOWCLASS_UNKNOWN);
        if (pww) {
            iClass =  (lpmpex->iMsgThunkClass) ?
                                      lpmpex->iMsgThunkClass :  pww->iClass;
        }
        else {
            iClass = 0;
        }
    }

    lpmpex->iClass = iClass;
    if (iClass == WOWCLASS_NOTHUNK) {
        f = TRUE;
    }
    else {
        lpmpex->lpfnUnThunk16 = apfnUnThunkMsg16[iClass]; // for optimization
        lpmpex->pww = pww;
        WOW32ASSERT(iClass <= NUMEL(apfnThunkMsg16));
        f = (apfnThunkMsg16[iClass])(lpmpex);
    }

    WOW32ASSERTMSG(f, "    WARNING Will Robinson: 16-bit message thunk failure\n");
    lpmpex->fThunkSucceeded = f;

#line 157
    return (f) ? lpmpex->hwnd : (HWND)NULL;

}

LONG W32DialogFunc(HWND hdlg, UINT uMsg, DWORD uParam, LPARAM lParam)
{
    BOOL fSuccess;
    register PWW pww;
    WM32MSGPARAMEX wm32mpex = {0}; /* DIVERGENCE(MVDM-HOST-DIV-344): call-owned conversion. */
    wow_message_stack stack; /* DIVERGENCE(MVDM-HOST-DIV-349): before construction. */
    wow_message_stack_enter(&stack);
    __try {
#line 30
    BOOL   fMessageNeedsThunking;

#ifdef WOWPROFILE  // for MSG profiling only (debugger extension)
#line 33
#error Excluded unsupported WOW profiling configuration
#endif // WOWPROFILE
#line 36

    // If the app has GP Faulted we don't want to pass it any more input
    // This should be removed when USER32 does clean up on task death so
    // it doesn't call us - mattfe june 24 92

    if (CURRENTPTD()->dwFlags & TDF_IGNOREINPUT) {
        LOGDEBUG(6,("    W32DialogFunc Ignoring Input Messsage %04X\n",uMsg));
        WOW32ASSERTMSG(!gfIgnoreInputAssertGiven,
                       "WCD32CommonDialogProc: TDF_IGNOREINPUT hack was used, shouldn't be, "
                       "please email DaveHart with repro instructions.  Hit 'g' to ignore this "
                       "and suppress this assertion from now on.\n");
        gfIgnoreInputAssertGiven = TRUE;
        goto SilentError;
    }

    if (!(pww = (PWW) GetWindowLong(hdlg, GWL_WOWWORDS))) {
        LOGDEBUG(LOG_ALWAYS,("    W32DialogFunc ERROR: cannot find alias for window %08lx\n", hdlg));
        goto Error;
    }

    // If pww->vpfnDlgProc is NULL, then something is broken;  we
    // certainly can't continue because we don't know what 16-bit func to call

    if (!pww->vpfnDlgProc) {
        LOGDEBUG(LOG_ALWAYS,("    W32DialogFunc ERROR: no window proc for message %04x Dlg = %08lx\n", uMsg, hdlg ));
        goto Error;
    }

    wm32mpex.Parm16.WndProc.hwnd   = GETHWND16(hdlg);
    wm32mpex.Parm16.WndProc.wMsg   = (WORD)uMsg;
    wm32mpex.Parm16.WndProc.wParam = (WORD)uParam;
    wm32mpex.Parm16.WndProc.lParam = (LONG)lParam;
    wm32mpex.Parm16.WndProc.hInst  = 0;   // Forces AX = SS on WndProc entry,
                                          // for Win 3.1 compatibility.

    fMessageNeedsThunking =  (uMsg < 0x400) &&
                                  (aw32Msg[uMsg].lpfnM32 != WM32NoThunking);
    if (fMessageNeedsThunking) {
        LOGDEBUG(3,("%04X (%s)\n", CURRENTPTD()->htask16, (aw32Msg[uMsg].lpszW32)));

#ifdef WOWPROFILE  // for MSG profiling only (debugger extension)
#line 77
#error Excluded unsupported WOW profiling configuration
#endif // WOWPROFILE
#line 79

        wm32mpex.fThunk = THUNKMSG;
        wm32mpex.hwnd = hdlg;
        wm32mpex.uMsg = uMsg;
        wm32mpex.uParam = uParam;
        wm32mpex.lParam = lParam;
        wm32mpex.pww = pww;
        wm32mpex.fFree = TRUE; /* DIV-344: same synchronous contract as WndProc. */
#line 86
        wm32mpex.lpfnM32 = aw32Msg[uMsg].lpfnM32;
        if (!(wm32mpex.lpfnM32)(&wm32mpex)) {
                LOGDEBUG(LOG_ERROR,("    W32DialogFunc ERROR: cannot thunk 32-bit message %04x\n", uMsg));
                goto Error;
        }

#ifdef WOWPROFILE  // for MSG profiling only (debugger extension)
#line 93
#error Excluded unsupported WOW profiling configuration
#endif  // WOWPROFILE
#line 97

    }
    else {
        LOGDEBUG(6,("    No Thunking was required for the 32-bit message %s(%04x)\n", (LPSZ)GetWMMsgName(uMsg), uMsg));
    }

    BlockWOWIdle(FALSE);

    fSuccess = CallBack16(RET_WNDPROC, &wm32mpex.Parm16, pww->vpfnDlgProc, (PVPVOID)&wm32mpex.lReturn);

    BlockWOWIdle(TRUE);

    // the callback function of a dialog is of type FARPROC whose return value
    // is of type 'int'. Since dx:ax is copied into lReturn in the above
    // CallBack16 call, we need to zero out the hiword, otherwise we will be
    // returning an erroneous value.

    wm32mpex.lReturn = (LONG)((SHORT)(LOWORD(wm32mpex.lReturn)));

    if (fMessageNeedsThunking) {

#ifdef WOWPROFILE  // for MSG profiling only (debugger extension)
#line 119
#error Excluded unsupported WOW profiling configuration
#endif // WOWPROFILE
#line 123


        //
        // if you send a message to a dialog what gets returned
        // to the caller is the dlg's msgresult window long.
        // app dialog functions will call
        //     SetWindowLong(hdlg, DWL_MSGRESULT, n);
        // during message processing so the right thing gets returned.
        // scottlu says we only need to do this for wm_gettext, it's
        // the only message whose result is an output count.
        //

        if (uMsg == WM_GETTEXT  &&  wm32mpex.lReturn != 0) {
            wm32mpex.lReturn = GetWindowLong(hdlg, DWL_MSGRESULT);
        }

        wm32mpex.fThunk = UNTHUNKMSG;
        (wm32mpex.lpfnM32)(&wm32mpex);

#ifdef WOWPROFILE  // for MSG profiling only (debugger extension)
#line 143
#error Excluded unsupported WOW profiling configuration
#endif // WOWPROFILE
#line 146

    }

    if (!fSuccess)
        goto Error;

    stack.completed = TRUE; /* DIV-349: not the shared failure-return label. */
#line 152
Done:

    return wm32mpex.lReturn;

Error:
    LOGDEBUG(6,("    W32DialogFunc WARNING: cannot call back, using default message handling\n"));
SilentError:
    wm32mpex.lReturn = 0;
    goto Done;
    } __finally {
        __try { wow_message_unwind32(&wm32mpex); }
        __finally { wow_message_stack_leave(&stack, AbnormalTermination()); }
    }
#line 161
}

ULONG FASTCALL WU32IsDialogMessage(PVDMFRAME pFrame)
{
    ULONG ul;
    MSG t2;
    register PISDIALOGMESSAGE16 parg16;
    MSGPARAMEX mpex = {0}; /* DIVERGENCE(MVDM-HOST-DIV-344): call-owned conversion. */
    __try {
#line 1078
    PMSG16 pMsg16;

    GETARGPTR(pFrame, sizeof(ISDIALOGMESSAGE16), parg16);
    GETMISCPTR(parg16->f2, pMsg16);

    mpex.Parm16.WndProc.hwnd = pMsg16->hwnd;
    mpex.Parm16.WndProc.wMsg = pMsg16->message;
    mpex.Parm16.WndProc.wParam = pMsg16->wParam;
    mpex.Parm16.WndProc.lParam = pMsg16->lParam;
    mpex.iMsgThunkClass = WOWCLASS_UNKNOWN;

    ThunkMsg16(&mpex);
    if (!mpex.fThunkSucceeded) { FREEARGPTR(parg16); RETURN(0); }

#line 1091
    GETFRAMEPTR(((PTD)CURRENTPTD())->vpStack, pFrame);
    GETARGPTR(pFrame, sizeof(ISDIALOGMESSAGE16), parg16);

    t2.message   = mpex.uMsg;
    t2.wParam    = mpex.uParam;
    t2.lParam    = mpex.lParam;
    t2.hwnd      = HWND32(FETCHWORD(pMsg16->hwnd));
    t2.time      = FETCHLONG(pMsg16->time);
    t2.pt.x      = FETCHSHORT(pMsg16->pt.x);
    t2.pt.y      = FETCHSHORT(pMsg16->pt.y);

    ul = GETBOOL16(IsDialogMessage(
    HWND32(parg16->f1),
    &t2
    ));

    if (MSG16NEEDSTHUNKING(&mpex)) {
        mpex.uMsg   = t2.message;
        mpex.uParam = t2.wParam;
        mpex.lParam = t2.lParam;
        (mpex.lpfnUnThunk16)(&mpex);
    }

    FREEARGPTR(parg16);
    RETURN(ul);
    } __finally {
        wow_message_unwind16(&mpex);
    }
#line 1116
}