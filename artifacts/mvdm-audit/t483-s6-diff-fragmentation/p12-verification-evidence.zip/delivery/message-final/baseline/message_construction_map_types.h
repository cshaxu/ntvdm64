typedef struct tagParamNode* LPPARAMNODE;

typedef struct tagParamNode {
  LPPARAMNODE pNext;

  DWORD dwPtr32;    // flat pointer
  DWORD dwPtr16;
  DWORD dwFlags;    // flags just in case
  DWORD dwRefCount; // reference count

#ifdef MAPPARAM_EXTRA
  DWORD cbExtra;     // buffer size
#endif

  DWORD nAliasCount;  // index for an alias array
  DWORD rgdwAlias[MAXNODEALIAS];

  // word sized member of the struct -- alignment alert
  HAND16 htask16;    // this is HAND16 really - keep simple and aligned

} PARAMNODE, *LPPARAMNODE;

typedef struct tagMapParam {

  LPPARAMNODE pHead;

  BLKCACHE  blkCache;

} MAPPARAM, *LPMAPPARAM;

typedef struct tagFindParam {
  LPPARAMNODE lpNode;
  LPPARAMNODE lpLast;
} FINDPARAM, *LPFINDPARAM;

MAPPARAM gParamMap;