#pragma pack(push,1)
typedef struct _PARMWP {    /* wp */
    LONG    lParam;     //
    WORD    wParam;     //
    WORD    wMsg;       //
    WORD    hwnd;       //
    WORD    hInst;      // hInstance of window that we are returning to
} PARMWP;


/* EnumPropsProc callback function parameter format
 */
typedef struct _PARMEPP {   /* epp */
    HAND16  hData;
    VPVOID  vpString;
    HWND16  hwnd;
} PARMEPP;


/* EnumWindows/EnumChildWindows/EnumTaskWindows callback function parameter format
 */
typedef struct _PARMEWP {       /* ewp */
    LONG    lParam;             // app-defined data
    HWND16  hwnd;               // 16-bit window handle
} PARMEWP;


/* EnumFonts callback function parameter format
 */
typedef struct _PARMEFP {       /* efp */
    VPVOID  vpData;     // app-defined data
    SHORT   nFontType;      //
    VPVOID  vpTextMetric;   // pointer to TEXTMETRIC16
    VPVOID  vpLogFont;      // pointer to LOGFONT16
} PARMEFP;


/* EnumObj callback function parameter format
 */
typedef struct _PARMEOP {       /* eop */
    VPVOID  vpData;     // app-defined data
    VPVOID  vpLogObject;
} PARMEOP;


/* EnumMetaFile callback function parameter format
 */
typedef struct _PARMEMP {       /* emp */
    VPVOID  vpData;     // app-defined data
    SHORT   nObjects;       // # objects
    VPVOID  vpMetaRecord;   // pointer to METARECORD16
    VPVOID  vpHandleTable;  // pointer to HANDLETABLE16
    HDC16   hdc;        // hdc
} PARMEMP;

/* Hook Callback function parameter format
 */
typedef struct _PARMHKP {       /* hkp */
    VPVOID  lParam;
    SHORT   wParam;
    SHORT   nCode;          // action code
} PARMHKP;

/* Subclass Callback function parameter format
 */
typedef struct _PARMSCP {       /* scp */
    SHORT    iOrdinal;          // oridnal number;
} PARMSCP;

/* LineDDA Callback function parameter format
 */
typedef struct _PARMDDA {   /* dda */
    VPVOID vpData;
    SHORT  y;
    SHORT  x;
} PARMDDA;

/* Graystring callback function parameter format
 */
typedef struct _PARMGST {   /* gst */
    SHORT n;
    DWORD data;
    HDC16 hdc;
} PARMGST;


typedef struct _PARMDIR { /* cdir */
    SHORT wDrive;
    VPSZ  vpDir;  // directory name
} PARMDIR;

typedef struct _PARMSAP { /* sap */
    SHORT  code;    //
    HAND16 hPr;
} PARMSAP;


/* WordBreakProc callback function parameter format
 */
typedef struct _PARMWBP {       /* wbp */
    SHORT   action;
    SHORT   cbEditText;
    SHORT   ichCurrentWord;
    VPVOID  lpszEditText;
} PARMWBP;


/*++

  MultiMedia callback definitions added, and also to _PARM16 - MikeTri

--*/

/* midiInOpen (MidiInFunc) Callback function parameter format
 */

typedef struct _PARMMIF {       /* mif */
    DWORD     dwParam2;
    DWORD     dwParam1;
    DWORD     dwInstance;
    WORD      wMsg;
    HMIDIIN16 hMidiIn;
} PARMMIF;

/* midiOutOpen (MidiOutFunc) Callback function parameter format
 */

typedef struct _PARMMOF {       /* mof */
    DWORD      dwParam2;
    DWORD      dwParam1;
    DWORD      dwInstance;
    WORD       wMsg;
    HMIDIOUT16 hMidiOut;
} PARMMOF;

/* mmioInstallIOProc (IOProc) Callback function parameter format
 */

typedef struct _PARMIOP {      /* iop */
    LONG      lParam2;
    LONG      lParam1;
    WORD      wMsg;
    VPVOID    lpmmioinfo;
} PARMIOP;

/* timeSetEvent (TimeFunc) Callback function parameter format
 */

typedef struct _PARMTIF {       /* tif */
    DWORD     dw2;
    DWORD     dw1;
    DWORD     dwUser;
    WORD      wMsg;
    WORD      wID;
} PARMTIF;

/* waveInOpen (WaveInFunc) Callback function parameter format
 */

typedef struct _PARMWIF {       /* wif */
    DWORD     dwParam2;
    DWORD     dwParam1;
    DWORD     dwInstance;
    WORD      wMsg;
    HWAVEIN16 hWaveIn;
} PARMWIF;

/* waveOutOpen (WaveOutFunc) Callback function parameter format
 */

typedef struct _PARMWOF {       /* wof */
    DWORD      dwParam2;
    DWORD      dwParam1;
    DWORD      dwInstance;
    WORD       wMsg;
    HWAVEOUT16 hWaveOut;
} PARMWOF;

/* WOWCallback16 function parameter format
 */

typedef struct _PARMWCB16 {       /* wcb16 */
    WORD       wArgs[8];
} PARMWCB16;

/* PARM16 is the union of all the callback parameter structures
 */
typedef union _PARM16 {     /* parm16 */
    PARMWP  WndProc;        // for window procs
    PARMEWP EnumWndProc;        // for window enum functions
    PARMEFP EnumFontProc;       // for font enum functions
    PARMEOP EnumObjProc;       // for obj enum functions
    PARMEMP EnumMetaProc;       // for metafile enum functions
    PARMEPP EnumPropsProc;  // for properties
    PARMHKP HookProc;           // for Hooks
    PARMSCP SubClassProc;   // for subclass thunks
    PARMDDA LineDDAProc;    // for LineDDA
    PARMGST GrayStringProc; // for GrayString
    PARMDIR CurDir;
    PARMSAP SetAbortProc;   // for SetAbortProc
    PARMMIF MidiInFunc;         // for midiInOpen functions - MikeTri 27-Mar-1992
    PARMMOF MidiOutFunc;        // for midiOutOpen functions
    PARMIOP IOProc;             // for mmioInstallIOProc functions
    PARMTIF TimeFunc;           // for timeSetEvent functions
    PARMWIF WaveInFunc;         // for waveInOpen functions
    PARMWOF WaveOutFunc;        // for waveOutOpen functions
    PARMWBP WordBreakProc;      // for WordBreakProc
    PARMWCB16 WOWCallback16;    // for WOWCallback16
} PARM16, *PPARM16;
typedef struct _POINT16 {       /* pt16 */
    SHORT   x;
    SHORT   y;
} POINT16;
typedef struct _MSG16 {         /* msg16 */
    HWND16  hwnd;
    WORD    message;
    WORD    wParam;
    LONG    lParam;
    DWORD   time;
    POINT16 pt;
} MSG16;
typedef struct _CREATESTRUCT16 {    /* cws16 */
    VPBYTE  vpCreateParams;
    HAND16  hInstance;
    HMENU16 hMenu;
    HWND16  hwndParent;
    SHORT   cy;
    SHORT   cx;
    SHORT   y;
    SHORT   x;
    DWORD   dwStyle;
    VPSZ    vpszWindow;
    VPSZ    vpszClass;
    DWORD   dwExStyle;
} CREATESTRUCT16;
typedef CREATESTRUCT16 UNALIGNED *PCREATESTRUCT16;
typedef struct _MDICREATESTRUCT16 {     /* mcs16 */
    VPSZ    vpszClass;
    VPSZ    vpszTitle;
    HTASK16 hOwner;
    SHORT   x;
    SHORT   y;
    SHORT   cx;
    SHORT   cy;
    LONG    style;
    LONG    lParam;                     // app-defined stuff
} MDICREATESTRUCT16;
typedef MDICREATESTRUCT16 UNALIGNED *PMDICREATESTRUCT16;
typedef struct _RECT16 {        /* rc16 */
    SHORT   left;
    SHORT   top;
    SHORT   right;
    SHORT   bottom;
} RECT16;
typedef RECT16 UNALIGNED *PRECT16;
typedef struct _DROPSTRUCT16 {
    HWND16  hwndSource;
    HWND16  hwndSink;
    WORD    wFmt;
    DWORD   dwData;
    POINT16 ptDrop;
    DWORD   dwControlData;
} DROPSTRUCT16;
typedef DROPSTRUCT16 UNALIGNED *PDROPSTRUCT16;
typedef struct _MOUSEHOOKSTRUCT16 { /* mhs16 */
    POINT16 pt;
    HWND16  hwnd;
    WORD    wHitTestCode;
    DWORD   dwExtraInfo;
} MOUSEHOOKSTRUCT16;
typedef MOUSEHOOKSTRUCT16 UNALIGNED *PMOUSEHOOKSTRUCT16;
typedef VPVOID VPCREATESTRUCT16;
typedef struct _CBT_CREATEWND16 {  /* cbtcw16 */
    VPCREATESTRUCT16 vpcs;
    HWND16           hwndInsertAfter;
} CBT_CREATEWND16;
typedef CBT_CREATEWND16 UNALIGNED *PCBT_CREATEWND16;
typedef struct _CBTACTIVATESTRUCT16 { /* cbtas16 */
    BOOL16    fMouse;
    HWND16    hWndActive;
} CBTACTIVATESTRUCT16;
typedef CBTACTIVATESTRUCT16 UNALIGNED *PCBTACTIVATESTRUCT16;typedef struct _EVENTMSG16 {  /* evmsg16 */
    WORD    message;
    WORD    paramL;
    WORD    paramH;
    DWORD   time;
} EVENTMSG16;
typedef EVENTMSG16 UNALIGNED *PEVENTMSG16;
#pragma pack(pop)
typedef struct _WM32MSGPARAMEX *LPWM32MSGPARAMEX;
typedef BOOL   (FASTCALL LPFNM32PROTO)(LPWM32MSGPARAMEX lpwm32mpex);
typedef LPFNM32PROTO *LPFNM32;

typedef struct _WM32MSGPARAMEX {
    HWND hwnd;
    UINT uMsg;
    UINT uParam;
    LONG lParam;
    PARM16 Parm16;
    LPFNM32 lpfnM32;    // function address
    BOOL fThunk;
    LONG lReturn;
    PWW  pww;
    DWORD dwParam;
    BOOL fFree;
    /* DIVERGENCE(MVDM-HOST-DIV-345): final slots own nested MDI title/struct. */
    DWORD dwTmp[4];
} WM32MSGPARAMEX;
#define WM_QUERYDROPOBJECT  0x022B