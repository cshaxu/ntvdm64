@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
cl /nologo /TC /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\original" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-original-TC.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-original-TC.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-original-TC.exit"
cl /nologo /TP /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\original" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-original-TP.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-original-TP.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-original-TP.exit"
cl /nologo /TC /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\extern-c" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-extern-c-TC.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-extern-c-TC.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-extern-c-TC.exit"
cl /nologo /TP /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\extern-c" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-extern-c-TP.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-extern-c-TP.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-extern-c-TP.exit"
cl /nologo /TC /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\no-import" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-no-import-TC.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-no-import-TC.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-no-import-TC.exit"
cl /nologo /TP /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\no-import" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-no-import-TP.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-no-import-TP.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x86-no-import-TP.exit"
call "C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
cl /nologo /TC /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\original" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-original-TC.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-original-TC.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-original-TC.exit"
cl /nologo /TP /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\original" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-original-TP.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-original-TP.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-original-TP.exit"
cl /nologo /TC /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\extern-c" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-extern-c-TC.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-extern-c-TC.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-extern-c-TC.exit"
cl /nologo /TP /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\extern-c" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-extern-c-TP.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-extern-c-TP.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-extern-c-TP.exit"
cl /nologo /TC /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\no-import" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-no-import-TC.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-no-import-TC.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-no-import-TC.exit"
cl /nologo /TP /c /I "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\no-import" /Fo"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-no-import-TP.obj" "O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\header.c" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-no-import-TP.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\x64-no-import-TP.exit"
echo 0 >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\complete.exit"
