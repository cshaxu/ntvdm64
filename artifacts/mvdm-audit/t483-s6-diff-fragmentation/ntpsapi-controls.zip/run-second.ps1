$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$p=Start-Process $env:ComSpec -ArgumentList @('/d','/c',('"'+$root+'\second.cmd"')) -WorkingDirectory $root -WindowStyle Hidden -PassThru -RedirectStandardOutput ($root+'\second-commands.log') -RedirectStandardError ($root+'\second-commands.err')
@{pid=$p.Id;start=(Get-Date).ToString('o');timeout_ms=120000}|ConvertTo-Json|Set-Content ($root+'\second-child.json')
if (!$p.WaitForExit(120000)) { Stop-Process -Id $p.Id -Force; 124|Set-Content ($root+'\second-runner.exit');exit 124 }
$p.ExitCode|Set-Content ($root+'\second-runner.exit')
exit $p.ExitCode
