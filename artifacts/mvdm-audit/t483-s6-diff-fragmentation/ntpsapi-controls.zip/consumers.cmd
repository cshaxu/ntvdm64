@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
cl @"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\nt_eoi.rsp" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\nt_eoi.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\nt_eoi.exit"
cl @"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\nt_timer.rsp" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\nt_timer.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\nt_timer.exit"
cl @"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\wkman.rsp" >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\wkman.log" 2>&1
echo %errorlevel% >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\wkman.exit"
echo 0 >"O:\repos.hobby\ntvdm64\build\t483-s6-ntpsapi-review\consumers-complete.exit"
