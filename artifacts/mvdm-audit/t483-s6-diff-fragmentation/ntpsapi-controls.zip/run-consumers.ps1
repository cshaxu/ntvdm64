$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$p=Start-Process $env:ComSpec -ArgumentList @('/d','/c',('"'+$root+'\consumers.cmd"')) -WorkingDirectory $root -WindowStyle Hidden -PassThru -RedirectStandardOutput ($root+'\consumers-commands.log') -RedirectStandardError ($root+'\consumers-commands.err')
@{pid=$p.Id;start=(Get-Date).ToString('o');timeout_ms=120000}|ConvertTo-Json|Set-Content ($root+'\consumers-child.json')
if (!$p.WaitForExit(120000)) { Stop-Process -Id $p.Id -Force; 124|Set-Content ($root+'\consumers-runner.exit');exit 124 }
$p.ExitCode|Set-Content ($root+'\consumers-runner.exit')
exit $p.ExitCode
