#include <windows.h>
#include <winternl.h>
#include <ntpsapi.h>
