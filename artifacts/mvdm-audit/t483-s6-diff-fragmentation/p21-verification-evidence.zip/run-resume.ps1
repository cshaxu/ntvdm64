$ErrorActionPreference='Stop'
$exe='C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe'
$p=Start-Process $exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"$PSScriptRoot/resume-pipeline.ps1") -WorkingDirectory O:/repos.hobby/ntvdm64 -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/resume-pipeline.log" -RedirectStandardError "$PSScriptRoot/resume-pipeline.stderr"
$p.Id|Set-Content "$PSScriptRoot/pipeline-child.pid"
if(!$p.WaitForExit(2400000)){ & taskkill.exe /PID $p.Id /T /F; 'timeout'|Set-Content "$PSScriptRoot/pipeline-supervisor.exit"; exit 1 }
$p.ExitCode|Set-Content "$PSScriptRoot/pipeline-supervisor.exit"
exit $p.ExitCode
