from pathlib import Path
import json,hashlib,csv,subprocess
r=Path.cwd();b=r/'build/t483-s6-p21';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
old='src/non-mvdm/windows/core/ntuser/client/wow.c'
p=r/'test/observation/verify-wow32-s1-formal-graph.ps1';s=p.read_text(encoding='utf-8').replace("'control-body-dmmnem', 'wow-dialog-lookup',","'control-body-dmmnem',")
s=s.replace("if ($link -notmatch '\\bobj/wow32-dll/wow_button_resources", "if ($link -notmatch '\\bobj/compat/wow-dialog-lookup\\.obj\\b') {\n    throw 'The compat dialog lookup must be linked into the formal graph.'\n}\nif ($link -notmatch '\\bobj/wow32-dll/wow_button_resources")
wr(p,s)
p=r/'test/adapter-mvdm-host-out/wow/wow_dialog_navigation_fixture.c';s=p.read_text(encoding='utf-8');s=s.replace('CHECK(_GetDlgItem(&root, 1) == &first);','CHECK(_GetDlgItem(&root, 1) == &first);\n    CHECK(_GetDlgItem(&root, 2) == &last);\n    CHECK(_GetDlgItem(&last, 2) == NULL);');wr(p,s)
retired={}
for rel in ['artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv','artifacts/mvdm-audit/t483-remaining-reaudit/pending-decisions.csv','artifacts/mvdm-audit/t483-s6-diff-fragmentation/file-worklist.csv','artifacts/mvdm-audit/t483-s6-diff-fragmentation/owner-review-order.csv']:
 p=r/rel;s=p.read_text(encoding='utf-8-sig');lines=s.splitlines(keepends=True);removed=[x for x in lines if old in x];assert removed,rel;retired[rel]=removed;wr(p,''.join(x for x in lines if old not in x))
c=json.loads((r/'build/t483-s6-p19/census.json').read_text(encoding='utf-8-sig'));c['files']=[x for x in c['files'] if x['path']!=old]
for x in c['files']:assert sha(r/x['path'])==x['current_sha256'],x['path']
wr(b/'census.json',json.dumps(c,indent=2)+'\n')
review=dict(packet='M0 T483 S6 P21',file=old,original_sha256='1ece9db0e35238434843bb73ece92dd66000a44bc6b1148a08bcabf1329f8d9a',before_sha256='b8e6073c1a208e6e97a60be15e3129743d7ea4213a572e443f927bbb141912fa',retired_blocks=21,retired_lines=832,classification='Owner-approved extraction, not original restoration',function='_GetDlgItem',original_lines=[251,265],target='src/compat/wow_dialog_lookup.c',retired_register_rows=retired,other_mirrors_unchanged=True,status='Local implementation; delivery pending',boundary='GetSystemMetrics original guest assembly retains version adjustment; native thunk calls modern USER32. No complete equivalence or new runtime fault claimed. This extraction does not change that path.')
wr(a/'client-wow-compat-extraction.json',json.dumps(review,indent=2)+'\n');wr(b/'source-review.json',json.dumps(review,indent=2)+'\n')
p=r/'src/non-mvdm/README.md';wr(p,p.read_text(encoding='utf-8')+'\nT483 S6 P21 supersedes the client/wow.c subset admission above: owner-approved\nextraction retains _GetDlgItem in src/compat/wow_dialog_lookup.c and retires\nthis mirror. Historical provenance and review records remain evidence only.\n')
p=a/'README.md';wr(p,p.read_text(encoding='utf-8')+'\n[P21 owner-approved dialog lookup extraction](client-wow-compat-extraction.json)\nretires client/wow.c:21 non-error blocks/832 lines. Local implementation;\ncached full,publish11x2,focused,lifecycle,Full and Git delivery pending.\n')
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['src/compat/wow_dialog_lookup.c']
files=[dict(path=x,sha256=sha(r/x)) for x in paths if (r/x).is_file() and (x.startswith('src/') or x.startswith('tools/') or x.startswith('test/'))]
wr(b/'source-checkpoint.json',json.dumps(dict(files=files,deleted=[old],source_files=len(files)),indent=2)+'\n')
wr(b/'line-proof.json',json.dumps(dict(files=[],reason='No retained mirror source modified. Extracted function equals pinned original lines251-265; remaining mirror hashes match P19.'))+'\n')
orig=Path('O:/repos.external/OpenNT/windows/core/ntuser/client/wow.c').read_bytes().decode('latin1').splitlines();new=(r/'src/compat/wow_dialog_lookup.c').read_text(encoding='utf-8');assert new.splitlines()[7:]==orig[250:265]
print('Registers removed:',{k:len(v) for k,v in retired.items()});print('Mirror identity verified',len(c['files']))
