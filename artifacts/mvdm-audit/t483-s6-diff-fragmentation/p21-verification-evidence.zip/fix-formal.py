from pathlib import Path
import json,hashlib
r=Path.cwd();b=r/'build/t483-s6-p21';p=r/'test/observation/verify-wow32-s1-formal-graph.ps1';s=p.read_text(encoding='utf-8').replace("'clglobal', 'control-lookaside', 'dialog-template'","'clglobal', 'dialog-template'");p.write_text(s,encoding='utf-8',newline='\n')
c=json.loads((b/'source-checkpoint.json').read_text(encoding='utf-8'))
for x in c['files']:
 if x['path']==p.relative_to(r).as_posix():x['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
(b/'source-checkpoint.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
(b/'formal-graph-correction.json').write_text(json.dumps(dict(cause='Stale control-lookaside expected object after P235 consolidation into rtlinit',commit='de4012edc',action='Remove obsolete duplicate object expectation; rtlinit remains mandatory; require new compat lookup object',production_change=False),indent=2)+'\n',encoding='utf-8')
s=(b/'pipeline.ps1').read_text(encoding='utf-8');start=s.index(" & test/observation/verify-wow32-s1-formal-graph.ps1")
s="$ErrorActionPreference='Stop'\nSet-Location O:/repos.hobby/ntvdm64\ntry {\n if((Get-Content \"$PSScriptRoot/focused.exit\").Trim() -ne '0'){throw 'Focused incomplete'}\n"+s[start:]
(b/'resume-pipeline.ps1').write_text(s,encoding='utf-8',newline='\n')
s=(b/'run-pipeline.ps1').read_text(encoding='utf-8').replace('"$PSScriptRoot/pipeline.ps1"','"$PSScriptRoot/resume-pipeline.ps1"').replace('"$PSScriptRoot/pipeline.log"','"$PSScriptRoot/resume-pipeline.log"').replace('"$PSScriptRoot/pipeline.stderr"','"$PSScriptRoot/resume-pipeline.stderr"');(b/'run-resume.ps1').write_text(s,encoding='utf-8',newline='\n')
