$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 if((Get-Content "$PSScriptRoot/focused.exit").Trim() -ne '0'){throw 'Focused incomplete'}
 & test/observation/verify-wow32-s1-formal-graph.ps1 -BuildRoot build/.ninja/msvc-x86-release/wow32
 if($LASTEXITCODE){throw 'Formal WOW graph failed'}
 '0'|Set-Content "$PSScriptRoot/formal-graph.exit"
 & 'C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe' -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p21/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'Cleanup exception/lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 & "$PSScriptRoot/full-isolated.ps1"
 if($LASTEXITCODE){throw 'Full failed'}
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
 exit 0
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
