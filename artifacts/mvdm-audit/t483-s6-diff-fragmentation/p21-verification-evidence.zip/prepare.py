from pathlib import Path
import json,hashlib,csv
r=Path.cwd(); b=r/'build/t483-s6-p21'; a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
def write(p,s): p.write_text(s,encoding='utf-8',newline='\n')
def edit(p,f): write(p,f(p.read_text(encoding='utf-8')))
p=r/'docs/states/CURRENT.md';edit(p,lambda s:s+'\n## P21 In Progress\n\nOwner approves extraction of client/wow.c::_GetDlgItem into compat, preserving\nits original algorithm and callers. Only this file is admitted;no next-file\nprogression. Update product/fixture selection and active difference registers;\ncached full build,publish11x2,focused,lifecycle,Full,commit and push required.\nThe system-metrics compatibility boundary remains recorded,not declared fixed.\n')
old=r/'src/non-mvdm/windows/core/ntuser/client/wow.c'
original=Path('O:/repos.external/OpenNT/windows/core/ntuser/client/wow.c').read_bytes().decode('latin1').splitlines()
body='\n'.join(original[250:265]);assert body.startswith('PWND _GetDlgItem(')
new=r/'src/compat/wow_dialog_lookup.c'
write(new,'/* Copyright (c) 1985-92, Microsoft Corporation.\n * Derived from OpenNT windows/core/ntuser/client/wow.c:251-265, revision\n * 5c5b979ec08c17d3ca2eb70e8aad62d26515d01c.\n * Owner-approved T483 S6 P21 extraction; original child-list lookup.\n */\n#include "control-client/precomp.h"\n\n'+body+'\n')
old.unlink()
p=r/'tools/build/New-T404S5Wow32ProviderNinja.ps1'
edit(p,lambda s:s.replace("'dmmnem','wow','winmgrc'","'dmmnem','winmgrc'").replace("foreach ($viewBody in @('winmgr','wow')) {",'''$objects.Add('obj/compat/wow-dialog-lookup.obj')
$ninja.Add('build obj/compat/wow-dialog-lookup.obj: cc ' + (ConvertTo-NinjaPath (Join-Path $root 'src/compat/wow_dialog_lookup.c')))
$ninja.Add('  cflags = $cflags $control_user_flags /DWOW_ORIGINAL_EDIT_CLIENT')
foreach ($viewBody in @('winmgr','wow')) {'''))
p=r/'tools/build/New-T447S3CallBoundaryNinja.ps1'
edit(p,lambda s:s.replace("'dmmnem','wow','winmgrc'","'dmmnem','winmgrc'").replace("$units += ,@('original_keyboard'",'''$units += ,@('dialog_lookup', 'src/compat/wow_dialog_lookup.c', '/DWOW_ORIGINAL_EDIT_CLIENT')
$controlObjects += 'obj/dialog_lookup.obj'
$units += ,@('original_keyboard' ''').replace("'original_keyboard' ,","'original_keyboard',").replace('obj/original_wow.obj','obj/dialog_lookup.obj'))
p=r/'test/observation/verify-wow32-s1-formal-graph.ps1';edit(p,lambda s:s.replace("'control-body-wow'","'wow-dialog-lookup'"))
p=r/'src/compat/README.md';edit(p,lambda s:s+'\n`wow_dialog_lookup.c` retains OpenNT client/wow.c::_GetDlgItem (251-265),\nrevision 5c5b979ec08c17d3ca2eb70e8aad62d26515d01c. Owner-approved P21\nextraction preserves the original PWND child-list algorithm and ABI. Product\nand dialog-navigation fixture link this same implementation.\n')
p=r/'docs/etc/operations/policy/source-policy.md';edit(p,lambda s:s+'\n### T483 S6 P21 owner-approved dialog lookup extraction\n\nThe owner approves retiring non-mvdm/windows/core/ntuser/client/wow.c and\nretaining its sole selected _GetDlgItem function (original lines 251-265) in\nsrc/compat/wow_dialog_lookup.c with provenance. Preserve its algorithm, ABI\nand callers. This file-specific reclassification does not restore omitted\nUSER services or establish equivalence of all modern system metrics.\n')
for name in ['run-cached.ps1','cached.cmd','cached-x86.cmd','cached-x64.cmd','run-pipeline.ps1','pipeline.ps1','publish-before-full.ps1','full-isolated.ps1','stage.ps1','final-docs.ps1']:
 s=(r/'build/t483-s6-p19'/name).read_text(encoding='utf-8-sig').replace('t483-s6-p19','t483-s6-p21')
 if name=='stage.ps1':s=s.replace('t483-s6-p18','t483-s6-p19')
 write(b/name,s)
print('Extraction and runner preparation complete')
