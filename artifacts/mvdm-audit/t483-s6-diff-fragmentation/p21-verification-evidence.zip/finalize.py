from pathlib import Path
import json,hashlib,zipfile,csv,re
r=Path.cwd();b=r/'build/t483-s6-p21';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
for name in ['cached','publish','focused','formal-graph','lifecycle','full-isolated','pipeline-supervisor']:
 assert (b/(name+'.exit')).read_text().strip()=='0',name
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
full=j(b/'full-isolated/timings.json');assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');passed=re.findall(r'^wow_[^ ]+ exit=0 elapsed_seconds=',log,re.M);assert len(passed)==38,len(passed)
assert 'WOW_USER_TASK_LIFECYCLE errors=0' in (b/'resume-pipeline.log').read_text(encoding='utf-8-sig')
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=31,remaining_files=222,retired_reviewed_files=2,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=151,owner_retired_lines=10069,total_census_reduction_blocks=191,total_census_reduction_lines=11263)
assert (counts['files'],counts['blocks'],counts['lines'])==(1061,2142,43260)
pub=j(b/'runtime-publication/result.json');review=j(a/'client-wow-compat-extraction.json');review['status']='Cached full,publish11x2,focused38,lifecycle and Full20 passed;governance and Git accompany receipt';wr(a/'client-wow-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P21',status='Build publication tests verified;governance and Git accompany receipt',source_checkpoint=c,publication=pub,full=full,focused=dict(passed=38,count=38,dialog_lookup='Existing real-source navigation fixture extended with later-sibling hit and leaf miss'),lifecycle='errors=0',global_counts=counts,limits=['Owner-approved source reclassification, not restoration','Other mirrors unchanged by hash','System-metrics compatibility remains a source-review boundary, not claimed fixed','No next-file admission'])
wr(a/'batch-p21-checkpoint.json',json.dumps(receipt,indent=2)+'\n')
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8');s=s.replace('live population is32 reviewed/254','live population is31 reviewed/253').replace('1062 files\n(1053 host','1061 files\n(1052 host').replace('and254 nonzero files','and253 nonzero files').replace('Current delivered total2163 blocks/44092 lines.','Current delivered total2142 blocks/43260 lines.').replace('has1635 rows','has1631 rows').replace('| client/wow.c |21->21|832->832|No source change;94 original logical rows match;residual decisions pending|','| client/wow.c |21->retired|832->retired|P21 compat extraction;focused38 and Full20 passed|')
s=s.replace('P19 retires one already\nreviewed file by owner approval;','P19 and P21 retire two already\nreviewed files by owner approval;')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP21 cached full,WOW focused38,lifecycle and Full20 passed.\nPackage '+pub['package']+' contains11 images,published and hash-verified\nto assets/release and O:/winnt/system32. Full includes real DOS4GW/NESticle.\nThe owner-approved dialog lookup extraction changes no other mirror or guest.\n[P21 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p21-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p21-verification-evidence.zip).\n\n'+s[end:]
s=s.replace('## P21 In Progress','## P21 Delivery').replace('cached full build,publish11x2,focused,lifecycle,Full,commit and push required.','Cached full,publish11x2,focused38,lifecycle and Full20 passed;Git accompanies receipt.')
s+='\nP21 retires21 blocks/832 lines;combined P19/P21 retire151 blocks/10069 lines.\nTogether with original restoration reductions40 blocks/1194 lines,the census\nis down191 blocks/11263 lines. Main register2703 rows;pending1631 rows.\nNo next-file admission.\n';wr(p,s);assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('Local implementation;\ncached full,publish11x2,focused,lifecycle,Full and Git delivery pending.','Cached full,publish11x2,focused38,lifecycle and Full20 passed;Git accompanies receipt.');s+='\n[P21 receipt](batch-p21-checkpoint.json) and [verification evidence](p21-verification-evidence.zip).\nCurrent census:1061 files,253 nonzero,2142 blocks/43260 lines.\nP20 usage-ratio reports remain the immutable pre-extraction snapshot;client/wow.c is now retired.\n';wr(p,s)
with zipfile.ZipFile(a/'p21-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):continue
  if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv'] or (p.suffix=='.png' and 'dos4gw-nesticle' in p.parts):z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print(counts)
