$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 $build=$null
 if($build){if(!$build.WaitForExit(1800000)){throw 'Owned build wait expired;do not restart'}}
 if(!(Test-Path "$PSScriptRoot/cached.exit") -or (Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build failed or missing terminal result'}
 & "$PSScriptRoot/stage-publish.ps1"
 if($LASTEXITCODE){throw 'Publication failed'}
 & "$PSScriptRoot/verification.ps1"
 if($LASTEXITCODE){throw 'Verification failed'}
 0|Set-Content "$PSScriptRoot/pipeline.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
