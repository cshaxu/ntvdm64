$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$hostExe=(Get-Process -Id $PID).Path
try {
 & $hostExe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-message-construction.ps1 -BuildRoot O:/repos.hobby/ntvdm64/build/t483-s6-p6/message-final -CompilerDriver O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32/msvc-x86.cmd -Transaction
 if($LASTEXITCODE){throw 'Message transaction failed'}
 0|Set-Content "$PSScriptRoot/message-final.exit"
 foreach($step in @('focused','full-isolated','review-check')) {
  & $hostExe -NoProfile -ExecutionPolicy Bypass -File "$PSScriptRoot/$step.ps1"
  if($LASTEXITCODE){throw "$step failed"}
 }
 0|Set-Content "$PSScriptRoot/verification.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/verification.exit";exit 1}