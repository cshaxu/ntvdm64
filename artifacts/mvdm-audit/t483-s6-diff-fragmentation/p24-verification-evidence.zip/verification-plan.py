from pathlib import Path
import re,json,hashlib,subprocess
r=Path.cwd();b=r/'build/t483-s6-p24'
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
p=r/'test/observation/verify-wow32-s1-formal-graph.ps1';s=p.read_text(encoding='utf-8').replace("'dialog-template', 'dialog-memory',","'dialog-template',").replace("'private-word-setter', 'default-window-bits',","'private-word-setter',");wr(p,s)
orig=Path('O:/repos.external/OpenNT/windows/core/ntuser/client/client.c').read_bytes().decode('latin1').replace('\r\n','\n')
review=json.loads((b/'source-review.json').read_text(encoding='utf-8'));proof={}
for unit,names in review['units'].items():
 s=(r/('src/compat/'+unit+'.c')).read_text(encoding='utf-8')
 for n in names:
  def body(t):
   m=re.search(r'(?m)^[^\n]*\b'+n+r'\(',t);start=t.index('{',m.start());d=0
   for e in range(start,len(t)):
    if t[e]=='{':d+=1
    elif t[e]=='}':
     d-=1
     if d==0:return t[start:e+1]
  assert body(orig)==body(s),n
  proof[n]='Exact original function body'
wr(b/'original-bodies.json',json.dumps(proof,indent=2)+'\n');wr(b/'original-bodies.exit','0\n')
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['src/compat/'+n+'.c' for n in review['units']]
files=[dict(path=x,sha256=hashlib.sha256((r/x).read_bytes()).hexdigest()) for x in paths if (r/x).is_file() and x.startswith(('src/','test/','tools/'))]
wr(b/'source-checkpoint.json',json.dumps(dict(files=files,deleted=[review['file']],source_files=len(files)),indent=2)+'\n')
wr(b/'line-proof.json',json.dumps(dict(files=[],reason='All1058 retained mirrors match P23 by SHA256. No retained #error or #line changed; eight extracted original bodies exact.'))+'\n')
s=(r/'build/t483-s6-p23/pipeline.ps1').read_text(encoding='utf-8').replace('t483-s6-p23','t483-s6-p24');wr(b/'pipeline.ps1',s)
print(proof)
