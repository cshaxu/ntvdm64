from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p24';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','original-bodies','ownership','controls','formal-graph','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=221,retired_reviewed_files=5,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=208,owner_retired_lines=20517,total_census_reduction_blocks=248,total_census_reduction_lines=21711)
assert (counts['files'],counts['blocks'],counts['lines'])==(1058,2085,32812)
for name,count in [('review-register.csv',2653),('pending-decisions.csv',1601)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'client-compat-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'client-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P24',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved extraction, not original restoration','All retained mirrors and original guest unchanged','Eight original bodies and ntcftxt.h preserved; registration/wait adapters unchanged','No next-file admission'])
wr(a/'batch-p24-checkpoint.json',json.dumps(receipt,indent=2)+'\n')
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8')
s=s.replace('33/255 initial difference files reviewed;222 remain. P19,P21,P22 and P23 retire four already\nreviewed files by owner approval;live population is29 reviewed/251,222 remain.', '34/255 initial difference files reviewed;221 remain. P19,P21-P24 retire five\nreviewed files by owner approval;live population is29 reviewed/250,221 remain.')
s=s.replace('1060 files','1058 files').replace('1059 files','1058 files').replace('(1050 host','(1049 host').replace('and251 nonzero files','and250 nonzero files').replace('Current delivered total2093 blocks/36376 lines.','Current delivered total2085 blocks/32812 lines.')
s=s.replace('The canonical pending backlog has1608 rows after retiring kernel/ntstubs,client/wow,kernel/input and kernel/handtabl records,','The canonical pending backlog has1601 rows after retiring five owner-approved mirror files,')
s=s.replace('| kernel/handtabl.c |24->retired|1381->retired|P23 compat extraction;original ownership and targeted lifecycle passed|','| kernel/handtabl.c |24->retired|1381->retired|P23 compat extraction;original ownership and targeted lifecycle passed|\n| client/client.c |8->retired|3564->retired|P24 five compat units;original bodies and targeted lifecycle passed|')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP24 cached build and owner-selected targeted verification passed:eight original\nfunction bodies,ownership/cleanup source proof,focused controls,formal graph and\nactual WOW lifecycle. Full was not run,per owner approval. Package '+pub['package']+'\ncontains11 images,published and hash-verified to assets/release and O:/winnt/system32.\nOther mirrors,guest and winnt.zip are unchanged.\n[P24 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p24-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p24-verification-evidence.zip).\n\n'+s[end:]
s=s.replace('## P24 In Progress','## P24 Delivery');s+='\nP24 retires8 blocks/3564 lines;combined extractions retire208 blocks/20517 lines.\nWith original restoration40 blocks/1194 lines,the census is down248 blocks/21711 lines.\nMain register2653 rows;pending1601 rows. Cached build,targeted tests and\npublish11x2 passed;governance and Git accompany receipt. No next-file admission.\n';wr(p,s);assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('lines retired by owner approval. Cached build,targeted tests and delivery pending.','lines retired by owner approval. Cached build,targeted tests and publish11x2 passed.');s+='\n[P24 receipt](batch-p24-checkpoint.json) and [verification evidence](p24-verification-evidence.zip).\nCurrent census:1058 files,250 nonzero,2085 blocks/32812 lines.\nThe P20 ratio snapshot predates the now-retired client/client.c.\n';wr(p,s)
with zipfile.ZipFile(a/'p24-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):continue
  if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv']:z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print(counts)
