$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build incomplete'}
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publication failed'}
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-cleanup-bounds.ps1
 if($LASTEXITCODE){throw 'Original ownership/cleanup source proof failed'}
 '0'|Set-Content "$PSScriptRoot/ownership.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-control-boundaries.ps1 -EvidenceRoot build/t483-s6-p24/control-evidence
 if($LASTEXITCODE){throw 'Focused controls failed'}
 '0'|Set-Content "$PSScriptRoot/controls.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow32-s1-formal-graph.ps1 -BuildRoot build/.ninja/msvc-x86-release/wow32
 if($LASTEXITCODE){throw 'Formal graph failed'}
 '0'|Set-Content "$PSScriptRoot/formal-graph.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p24/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'WOW lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
