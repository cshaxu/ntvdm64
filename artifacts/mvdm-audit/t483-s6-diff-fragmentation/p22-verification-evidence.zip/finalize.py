from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p22';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','original-bodies','native-input','input-lifetime','formal-graph','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=30,remaining_files=222,retired_reviewed_files=3,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=176,owner_retired_lines=15572,total_census_reduction_blocks=216,total_census_reduction_lines=16766)
assert (counts['files'],counts['blocks'],counts['lines'])==(1060,2117,37757)
for name,count in [('review-register.csv',2687),('pending-decisions.csv',1617)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'input-compat-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'input-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P22',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner explicitly approved related targeted verification only',global_counts=counts,limits=['Owner-approved extraction, not original restoration','Other mirrors and original guest unchanged','Original Recalc2 explicit current-thread parameter retained','Native input fixtures use owned private desktops; no Computer Use','No next-file admission'])
wr(a/'batch-p22-checkpoint.json',json.dumps(receipt,indent=2)+'\n')
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8').replace('P19 and P21 retire two already','P19,P21 and P22 retire three already').replace('live population is31 reviewed/253','live population is30 reviewed/252').replace('1061 files\n(1052 host','1060 files\n(1051 host').replace('and253 nonzero files','and252 nonzero files').replace('Current delivered total2142 blocks/43260 lines.','Current delivered total2117 blocks/37757 lines.').replace('| kernel/input.c |26->25|5527->5503|P13 original declarations restored;Full20 and input services/lifetime passed|','| kernel/input.c |25->retired|5503->retired|P22 compat extraction;targeted input and lifecycle passed|').replace('The canonical pending backlog has1631 rows after retiring six kernel/ntstubs and four client/wow pending records,','The canonical pending backlog has1617 rows after retiring kernel/ntstubs,client/wow and kernel/input records,')
s=s.replace('Seven scattered\nharmless macros would increase file blocks26->27;owner approval remains pending.','The later P22 owner-approved extraction retires the input mirror and its\nprevious residual macro decisions;history remains in the extraction record.')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'## Current Technical Baseline\n\nP22 cached build and owner-selected targeted verification passed:original input\nbodies,native input services,input lifetime,formal graph and actual WOW lifecycle.\nFull was not run,per explicit owner approval. Package '+pub['package']+'\ncontains11 images,published and hash-verified to assets/release and O:/winnt/system32.\nOther mirrors,guest and winnt.zip are unchanged.\n[P22 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p22-checkpoint.json)\nand [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p22-verification-evidence.zip).\n\n'+s[end:]
s=s.replace('## P22 In Progress','## P22 Delivery');s+='\nP22 retires25 blocks/5503 lines;combined extractions retire176 blocks/15572 lines.\nWith original restoration40 blocks/1194 lines,the census is down216 blocks/16766 lines.\nMain register2687 rows;pending1617 rows. All targeted checks and publish11x2\npassed;governance and Git accompany receipt. No next-file admission.\n';wr(p,s);assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('Local implementation;\nowner-approved cached build and targeted tests,then publish11x2 and Git pending.','Cached build,targeted input/lifecycle verification and publish11x2 passed;Git accompanies receipt.');s+='\n[P22 receipt](batch-p22-checkpoint.json) and [verification evidence](p22-verification-evidence.zip).\nCurrent census:1060 files,252 nonzero,2117 blocks/37757 lines.\nThe P20 ratio snapshot also predates the now-retired kernel/input.c.\n';wr(p,s)
with zipfile.ZipFile(a/'p22-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if not p.is_file() or any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):continue
  if p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv']:z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print(counts)
