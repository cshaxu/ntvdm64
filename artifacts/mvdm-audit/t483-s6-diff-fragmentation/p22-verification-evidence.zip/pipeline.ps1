$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build incomplete'}
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-recovered-owner-bodies.ps1 -InputOnly
 if($LASTEXITCODE){throw 'Original input bodies failed'}
 '0'|Set-Content "$PSScriptRoot/original-bodies.exit"
 foreach($step in @(@('native-input','verify-native-input-services.ps1'),@('input-lifetime','verify-wow-input-lifetime.ps1'))) {
  & $exe -NoProfile -ExecutionPolicy Bypass -File "test/observation/$($step[1])" -CompilerDriver O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32/msvc-x86.cmd -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -BuildRoot "O:/repos.hobby/ntvdm64/build/t483-s6-p22/$($step[0])"
  if($LASTEXITCODE){throw "$($step[0]) failed"}
  '0'|Set-Content "$PSScriptRoot/$($step[0]).exit"
 }
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow32-s1-formal-graph.ps1 -BuildRoot build/.ninja/msvc-x86-release/wow32
 if($LASTEXITCODE){throw 'Formal graph failed'}
 '0'|Set-Content "$PSScriptRoot/formal-graph.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p22/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'WOW lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publication failed'}
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
