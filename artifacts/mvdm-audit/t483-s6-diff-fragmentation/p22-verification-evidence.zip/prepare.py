from pathlib import Path
import re,json,hashlib,csv,subprocess
r=Path.cwd();b=r/'build/t483-s6-p22';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def edit(p,f):wr(p,f(p.read_text(encoding='utf-8')))
p=r/'docs/states/CURRENT.md';edit(p,lambda s:s+'\n## P22 In Progress\n\nOwner approves extraction of kernel/input.c AddAttachment/Recalc2 into compat.\nPreserve both algorithms and the existing explicit current-thread argument.\nOnly this file is admitted. Owner replaces Full with related targeted tests:\ncached build,input membership/native focus/input lifetime,WOW lifecycle and\nformal graph verification,then publish11x2,commit,push. No Full claim.\n')
old='src/non-mvdm/windows/core/ntuser/kernel/input.c';p=r/old;before=sha(p);s=p.read_text(encoding='utf-8');s=re.sub(r'^#line.*\n','',s,flags=re.M)
def body(t,n):return re.search(r'(?ms)^void '+n+r'\(.*?^\}',t).group()
bodies=[body(s,n) for n in ['AddAttachment','Recalc2']]
orig=Path('O:/repos.external/OpenNT/windows/core/ntuser/kernel/input.c');assert sha(orig)=='b7656bca55e892a42ba825be0324211450ad298c40717e1ae5a889d084467529'
os=orig.read_bytes().decode('latin1').replace('\r\n','\n')
assert bodies[0]==body(os,'AddAttachment')
assert bodies[1].replace('PQ pqAttach,\n    PTHREADINFO ptiCurrent)','PQ pqAttach)')==body(os,'Recalc2')
new=r/'src/compat/wow_input_membership.c';wr(new,'/* Copyright (c) 1985-91, Microsoft Corporation.\n * Derived from OpenNT windows/core/ntuser/kernel/input.c, AddAttachment and\n * Recalc2, revision 5c5b979ec08c17d3ca2eb70e8aad62d26515d01c.\n * Owner-approved T483 S6 P22 extraction. Recalc2 retains the existing\n * explicit current-thread argument; original membership algorithms unchanged.\n */\n#include "wow_input_group_bindings.h"\n\n'+'\n\n'.join(bodies)+'\n');p.unlink()
p=r/'tools/build/New-T404S5Wow32ProviderNinja.ps1';edit(p,lambda s:s.replace('obj/opennt-user/input.obj','obj/compat/wow-input-membership.obj').replace(old,'src/compat/wow_input_membership.c'))
for name in ['verify-native-input-services.ps1','verify-wow-input-lifetime.ps1']:
 p=r/'test/observation'/name;edit(p,lambda s:s.replace('obj/opennt-user/input.obj','obj/compat/wow-input-membership.obj').replace(old,'src/compat/wow_input_membership.c'))
p=r/'test/observation/verify-wow32-s1-formal-graph.ps1';edit(p,lambda s:s.replace("'taskman', 'input', 'profile'","'taskman', 'profile'").replace("if ($link -notmatch '\\bobj/compat/wow-dialog-lookup", "if ($link -notmatch '\\bobj/compat/wow-input-membership\\.obj\\b') {\n    throw 'The compat input membership must be linked into the formal graph.'\n}\nif ($link -notmatch '\\bobj/compat/wow-dialog-lookup"))
p=r/'test/observation/verify-wow-recovered-owner-bodies.ps1';edit(p,lambda s:s.replace("    @{ File='input.c'; Name='RecalcThreadAttachment'; Source=$inputSource },\n",'').replace("    $path = Join-Path $RepositoryRoot ('src/non-mvdm/windows/core/ntuser/kernel/' + $check.File)","    $path = if ($check.File -eq 'input.c') {\n        Join-Path $RepositoryRoot 'src/compat/wow_input_membership.c'\n    } else { Join-Path $RepositoryRoot ('src/non-mvdm/windows/core/ntuser/kernel/' + $check.File) }").replace("if ($mirror -match '(?<!\\r)\\n')", "if ($check.File -ne 'input.c' -and $mirror -match '(?<!\\r)\\n')").replace('Six owner bodies','Five owner bodies'))
# Retired wrapper is no longer part of this original-body assertion.
p=r/'test/observation/verify-wow-recovered-owner-bodies.ps1';edit(p,lambda s:re.sub(r"        'RecalcThreadAttachment' \{.*?\n        \}\n",'',s,flags=re.S))
for rel,text in [('src/compat/README.md','\n`wow_input_membership.c` retains OpenNT kernel/input.c AddAttachment/Recalc2,\nrevision 5c5b979ec08c17d3ca2eb70e8aad62d26515d01c, by owner-approved P22\nextraction. The original algorithms and existing explicit current-thread ABI\nremain; modern native queue attachment stays with the existing caller.\n'),('src/non-mvdm/README.md','\nT483 S6 P22 supersedes the kernel/input.c subset admission: AddAttachment and\nRecalc2 now reside in src/compat/wow_input_membership.c. Historical mirror\nrecords remain provenance only; no other kernel input services are admitted.\n'),('docs/etc/operations/policy/source-policy.md','\n### T483 S6 P22 owner-approved input membership extraction\n\nThe owner approves retiring non-mvdm/windows/core/ntuser/kernel/input.c,\nretaining AddAttachment and Recalc2 in src/compat/wow_input_membership.c with\nprovenance. Preserve both original algorithms and the existing explicit\ncurrent-thread argument. This scoped extraction does not admit the omitted\nNT4 kernel input queues or change modern USER32 input ownership.\n')]:
 p=r/rel;edit(p,lambda s:s+text)
retired={}
for rel in ['artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv','artifacts/mvdm-audit/t483-remaining-reaudit/pending-decisions.csv','artifacts/mvdm-audit/t483-s6-diff-fragmentation/file-worklist.csv','artifacts/mvdm-audit/t483-s6-diff-fragmentation/owner-review-order.csv']:
 p=r/rel;lines=p.read_text(encoding='utf-8-sig').splitlines(keepends=True);retired[rel]=[x for x in lines if old in x];assert retired[rel];wr(p,''.join(x for x in lines if old not in x))
c=json.loads((r/'build/t483-s6-p21/census.json').read_text(encoding='utf-8-sig'));c['files']=[x for x in c['files'] if x['path']!=old]
for x in c['files']:assert sha(r/x['path'])==x['current_sha256'],x['path']
wr(b/'census.json',json.dumps(c,indent=2)+'\n')
review=dict(packet='M0 T483 S6 P22',file=old,original_sha256=sha(orig),before_sha256=before,retired_blocks=25,retired_lines=5503,classification='Owner-approved extraction, not original restoration',target='src/compat/wow_input_membership.c',original_body_equivalence={'AddAttachment':'exact','Recalc2':'exact after removing only existing explicit current-thread signature parameter'},retired_register_rows=retired,other_mirrors_unchanged=True,status='Local implementation; delivery pending',verification_scope='Owner-approved cached build and related targeted tests, no Full')
wr(a/'input-compat-extraction.json',json.dumps(review,indent=2)+'\n');wr(b/'source-review.json',json.dumps(review,indent=2)+'\n')
p=a/'README.md';edit(p,lambda s:s+'\n[P22 owner-approved input membership extraction](input-compat-extraction.json)\nretires kernel/input.c:25 non-error blocks/5503 lines. Local implementation;\nowner-approved cached build and targeted tests,then publish11x2 and Git pending.\nFull is explicitly not required for this batch.\n')
for name in ['run-cached.ps1','cached.cmd','cached-x86.cmd','cached-x64.cmd','run-pipeline.ps1','publish-before-full.ps1','stage.ps1','final-docs.ps1']:
 s=(r/'build/t483-s6-p21'/name).read_text(encoding='utf-8-sig').replace('t483-s6-p21','t483-s6-p22')
 if name=='stage.ps1':s=s.replace('t483-s6-p19','t483-s6-p21')
 wr(b/name,s)
print('Retired rows',{k:len(v) for k,v in retired.items()});print('Other mirrors unchanged',len(c['files']))
