from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();b=r/'build/t483-s6-p22'
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
p=r/'test/observation/verify-wow-recovered-owner-bodies.ps1';s=p.read_text(encoding='utf-8').replace("    [string]$OriginalRoot = 'O:/repos.external/OpenNT',","    [string]$OriginalRoot = 'O:/repos.external/OpenNT',\n    [switch]$InputOnly,")
s=s.replace('foreach ($check in $checks) {',"if ($InputOnly) { $checks = @($checks | Where-Object { $_.File -eq 'input.c' }) }\nforeach ($check in $checks) {")
s=s.replace("$probePath = Join-Path $OriginalRoot", "if ($InputOnly) { return }\n$probePath = Join-Path $OriginalRoot");wr(p,s)
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['src/compat/wow_input_membership.c']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[dict(path=x,sha256=sha(r/x)) for x in paths if (r/x).is_file() and x.startswith(('src/','test/','tools/'))]
wr(b/'source-checkpoint.json',json.dumps(dict(files=files,deleted=['src/non-mvdm/windows/core/ntuser/kernel/input.c'],source_files=len(files)),indent=2)+'\n')
wr(b/'line-proof.json',json.dumps(dict(files=[],reason='No retained mirror modified; all1060 match P21 by hash. Two extracted function bodies match fixed original apart from existing Recalc2 context parameter.'))+'\n')
wr(b/'pipeline.ps1', '''$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$exe=(Get-Process -Id $PID).Path
try {
 if((Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached build incomplete'}
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-recovered-owner-bodies.ps1 -InputOnly
 if($LASTEXITCODE){throw 'Original input bodies failed'}
 '0'|Set-Content "$PSScriptRoot/original-bodies.exit"
 foreach($step in @(@('native-input','verify-native-input-services.ps1'),@('input-lifetime','verify-wow-input-lifetime.ps1'))) {
  & $exe -NoProfile -ExecutionPolicy Bypass -File "test/observation/$($step[1])" -CompilerDriver O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32/msvc-x86.cmd -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -BuildRoot "O:/repos.hobby/ntvdm64/build/t483-s6-p22/$($step[0])"
  if($LASTEXITCODE){throw "$($step[0]) failed"}
  '0'|Set-Content "$PSScriptRoot/$($step[0]).exit"
 }
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow32-s1-formal-graph.ps1 -BuildRoot build/.ninja/msvc-x86-release/wow32
 if($LASTEXITCODE){throw 'Formal graph failed'}
 '0'|Set-Content "$PSScriptRoot/formal-graph.exit"
 & $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-wow-task-lifecycle.ps1 -ProviderBuildRoot build/.ninja/msvc-x86-release/wow32 -WorkerBuildRoot build/.ninja/msvc-x86-release/worker -BuildRoot build/t483-s6-p22/lifecycle -Case task-lifecycle
 if($LASTEXITCODE){throw 'WOW lifecycle failed'}
 '0'|Set-Content "$PSScriptRoot/lifecycle.exit"
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publication failed'}
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
''')
