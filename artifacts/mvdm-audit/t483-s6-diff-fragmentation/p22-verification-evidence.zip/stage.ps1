if(!(Test-Path "$PSScriptRoot/source-review.json")){throw 'Missing source proof'}
$ErrorActionPreference='Stop'
$r=(Get-Location).Path
$cache="$r/build/t483-s6-p22/cache-final"; Copy-Item "$r/build/t483-s6-p21/cache-final" $cache -Recurse
$x86="$r/build/.ninja/msvc-x86-release"; $x64="$r/build/.ninja/msvc-x64-release"
foreach($n in @('ntvdm.exe','VCDEX.DLL','VDMREDIR.dll','nthook32.dll')){Copy-Item "$x86/worker/$n" "$cache/$n" -Force}
foreach($pair in @(@('ntvwm.exe','worker'),@('ntcon.exe','frontend'),@('ntmon.exe','monitor'),@('run16.exe','launcher'),@('ntsrv.exe','service'),@('nthook64.dll','hook'))){Copy-Item "$x64/$($pair[1])/$($pair[0])" "$cache/$($pair[0])" -Force}
& "$r/tools/build/Stage-System32ProductPackage.ps1" -BaselineRoot "$r/build/t483-s6-p21/candidate-final" -BuildCache $cache -Wow32 "$x86/wow32/wow32.dll" -OutputRoot "$r/build/t483-s6-p22/candidate-final" -Vcdex "$cache/VCDEX.DLL" -NativeHook "$cache/nthook32.dll" -NativeHook64 "$cache/nthook64.dll" -NativeWorker "$cache/ntvwm.exe" -NativeFrontend "$cache/ntcon.exe" -NativeMonitor "$cache/ntmon.exe" -NativeLauncher "$cache/run16.exe" -NativeService "$cache/ntsrv.exe"





if($LASTEXITCODE){exit $LASTEXITCODE}
'0'|Set-Content build/t483-s6-p22/stage.exit

$manifest=Get-Content "$r/build/t483-s6-p22/candidate-final/product-system32-manifest.json" -Raw|ConvertFrom-Json
foreach($row in $manifest){Copy-Item "$r/build/t483-s6-p22/candidate-final/system32/$($row.Name)" "$cache/$($row.Name)" -Force}
