$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 & test/observation/verify-wow-message-construction.ps1 -BuildRoot O:/repos.hobby/ntvdm64/build/t483-s6-p5/message-final -CompilerDriver O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32/msvc-x86.cmd -Transaction
 if($LASTEXITCODE){throw 'Message transaction failed'}
 0|Set-Content "$PSScriptRoot/message-final.exit"
 & (Get-Process -Id $PID).Path -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-keyboard-buffer-count.ps1 -BuildRoot O:/repos.hobby/ntvdm64/build/t483-s6-p5/keyboard-origin -OriginReturn
 if($LASTEXITCODE){throw "Keyboard origin failed"}
 & (Get-Process -Id $PID).Path -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-keyboard-buffer-count.ps1 -BuildRoot O:/repos.hobby/ntvdm64/build/t483-s6-p5/keyboard-bios -BiosJoin
 if($LASTEXITCODE){throw "Keyboard BIOS failed"}
 0|Set-Content "$PSScriptRoot/keyboard.exit"
 & "$PSScriptRoot/focused.ps1"
 if($LASTEXITCODE){throw 'Focused failed'}
 & "$PSScriptRoot/full-isolated.ps1"
 if($LASTEXITCODE){throw 'Full failed'}
 & "$PSScriptRoot/review-check.ps1"
 if($LASTEXITCODE){throw 'Review failed'}
 0|Set-Content "$PSScriptRoot/verification.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/verification.exit";exit 1}
