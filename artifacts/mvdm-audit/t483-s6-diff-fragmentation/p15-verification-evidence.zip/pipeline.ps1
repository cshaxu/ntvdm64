$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 & "$PSScriptRoot/stage.ps1"
 if($LASTEXITCODE){throw 'Stage failed'}
 & "$PSScriptRoot/publish-before-full.ps1"
 if($LASTEXITCODE){throw 'Publish failed'}
 & test/observation/verify-keyboard-controller-pic.ps1 -OutputRoot build/t483-s6-p15/keyboard-controller
 if($LASTEXITCODE){throw 'Keyboard controller/PIC failed'}
 & 'C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe' -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-keyboard-origin-device.ps1 -BuildRoot O:/repos.hobby/ntvdm64/build/t483-s6-p15/keyboard-origin
 if($LASTEXITCODE){throw 'Keyboard provenance failed'}
 '0'|Set-Content "$PSScriptRoot/keyboard.exit"
 & "$PSScriptRoot/full-isolated.ps1"
 if($LASTEXITCODE){throw 'Full failed'}
 '0'|Set-Content "$PSScriptRoot/pipeline.exit"
 exit 0
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/pipeline.exit";exit 1}
