from pathlib import Path
import csv, hashlib, json, re, zipfile
r=Path.cwd();b=r/'build/t483-s6-p15';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cached','publish','keyboard','wow-environment-pair','full-isolated-clean','full-clean-supervisor']:
    assert (b/(name+'.exit')).read_text().strip()=='0',name
full=j(b/'full-isolated-clean/timings.json')
assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
assert any(x['Gate']=='dos4gw-nesticle' and x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256']
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
manifest=j(b/'candidate-final/product-system32-manifest.json');assert len(manifest)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
    for x in manifest:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
controller=(b/'keyboard-controller/controller.txt').read_text(encoding='utf-8-sig')
assert 'assertions=90 failures=0' in controller
files=j(b/'census.json')['files'];path='src/mvdm-host/softpc.new/base/keymouse/keyba.c'
row=next(x for x in files if x['path']==path)
assert row['filtered']==dict(blocks=24,added=49,deleted=7)
assert len(row['excluded'])==69 and not row['issues']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_files=29,remaining_files=226,cumulative_reduction_blocks=31,cumulative_reduction_lines=955)
assert counts['blocks']==2302 and counts['lines']==53568 and counts['files']==1063
pub=j(b/'runtime-publication/result.json')
environment_pair=j(b/'wow-environment-pair/result.json')
assert environment_pair[0]['expectedWindow'] and not environment_pair[1]['expectedWindow']
receipt=dict(failed_attempt='Initial Full failed WOW frontier after in-process VS environment import. Same-package clean/VS-imported pair reproduced difference; subsequent Full executes in a clean process. No product change or assertion waiver.',environment_pair=environment_pair,packet='M0 T483 S6 P15',status='Built, published and keyboard/Full verified; governance/Git delivery follows receipt',source_checkpoint=c,reduction=dict(blocks=0,lines=16),publication=pub,full=full,global_counts=counts,keyboard_controller=j(b/'keyboard-controller/result.json'),preprocessor_proof='keyba-preprocessor-proof.zip: exact product-command before/candidate code identical',winnt_zip_unchanged=True,limits=['Historical necessity evidence reused and separately identified; no new failure baseline claim.','No original conditional framework or excluded branch changed.','Remaining state/provenance/reset boundaries still pending owner decision.'])
(a/'batch-p15-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
p=a/'keyba-whole-file-review.json';d=j(p);d['verification']='Exact product preprocessing identical;cached x86/x64 full,publish11x2,actual keyboard/PIC90,origin-device and Full20 passed';d['delivery']='P15;governance/Git follows receipt';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv']:
    with p.open(encoding='utf-8-sig',newline='') as f:reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
    for x in rows:
        if x['path']!=path:continue
        if 'remaining_blocks' in fields:x['status']='reviewed-verified-p15-residuals-pending-owner'
        elif x['review_status']=='pending-decision':x['verification']=d['verification'];x['delivery']='P15;Git delivery accompanies receipt'
    with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8')
s=s.replace('Twenty-one changed files\nverified across P2-P14;seven reviewed unchanged;one local P15 candidate.','Twenty-two changed files\nverified across P2-P15;seven reviewed unchanged.')
s=s.replace('939 lines;additional16 lines restored locally,not delivered.','955 lines.')
pos=s.index('\n\n\nThe canonical pending');s=s[:pos]+'\n| keymouse/keyba.c |24->24|72->56|P15 added guard pairs removed;actual keyboard90 and Full20 passed|'+s[pos:]
rows=list(csv.DictReader((a/'file-worklist.csv').open(encoding='utf-8')));n=next(x for x in rows if x['rank']=='30')
s=s.replace('Next file is src/mvdm-host/softpc.new/base/keymouse/keyba.c.','Next file is '+n['path']+'.')
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'''## Current Technical Baseline

P15 cached x86/x64 full,actual keyboard/PIC90,origin-device and Full20 passed.
Package'''+pub['package']+''' contains11 images,published and
hash-verified to assets/release and O:/winnt/system32. Full includes actual
DOS4GW/NESticle. No guest or winnt.zip changes. Before/candidate selected
preprocessed code is identical;all69 excluded bodies and original frameworks
remain. Governance and Git delivery follow the evidence receipt.

[P15 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p15-checkpoint.json)
and [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p15-verification-evidence.zip)
bind source,package and tests. Remaining owner decisions are not approved by test success.

'''+s[end:]
if '\nP15 keyba whole-file audit complete:' in s:s=s[:s.index('\nP15 keyba whole-file audit complete:')]
p.write_text(s.rstrip()+'\n',encoding='utf-8',newline='\n');assert p.stat().st_size<16384
p=a/'README.md';s=p.read_text(encoding='utf-8').replace('P15 delivery pending.','P15 build/publication/keyboard/Full passed;Git delivery follows receipt.')
s+='\n[P15 receipt](batch-p15-checkpoint.json) and [evidence](p15-verification-evidence.zip):keyba24->24 points,72->56 lines;keyboard/PIC90 and Full20 passed.\n';p.write_text(s,encoding='utf-8',newline='\n')
with zipfile.ZipFile(a/'p15-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in b.rglob('*'):
        if p.is_file() and p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.txt','.csv'] and not any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):z.write(p,p.relative_to(b).as_posix())
        elif p.is_file() and p.suffix=='.png' and 'dos4gw-nesticle' in p.parts:z.write(p,p.relative_to(b).as_posix())
    z.write(b/'runtime-publication/result.json','publication/result.json')
print('P15 verified receipt ready',counts)
