$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
. ./test/observation/isolated_package_cleanup.ps1
$runtime=New-PhysicalRuntimeStage "$PSScriptRoot/candidate-final"
$scope=New-IsolatedPackageScope $runtime
$log="$PSScriptRoot/wow-environment-pair"
New-Item -ItemType Directory $log -ErrorAction Stop|Out-Null
$rows=@()
try {
 foreach($case in @('clean','vs-imported')){
  if($case -eq 'vs-imported'){
   $vs='C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat'
   $lines=& cmd.exe /d /s /c ('call "'+$vs+'" -arch=x86 -host_arch=x64 >nul && set')
   foreach($line in $lines){$i=$line.IndexOf('=');if($i -gt 0){Set-Item -LiteralPath ('env:'+$line.Substring(0,$i)) -Value $line.Substring($i+1)}}
  }
  $env:PATH=(Get-PackageBinaryRoot $runtime)+';'+(Join-Path $env:SystemRoot 'System32')
  $env:MVDM_OBSERVER_PRIVATE_DESKTOP='1';$env:MVDM_OBSERVER_SHORT_HISTORY='1'
  Remove-Item Env:MVDM_OBSERVER_MILESTONE_INPUT,Env:MVDM_OBSERVER_WINDOW_INPUT -ErrorAction SilentlyContinue
  $environment=[Environment]::GetEnvironmentVariables()
  $chars=1;foreach($key in $environment.Keys){$chars+=([string]$key).Length+([string]$environment[$key]).Length+2}
  & ./test/observation/observe-wow-frontiers.ps1 -Observer ./build/.ninja/msvc-x64-release/message-probes/console-startup-observer.exe -WindowObserver ./build/t483-s5-p79-final/observers-x64/worker-window-snapshot.exe -Prefix $case -PackageRoot $runtime -ProcessPackageRoot $runtime -LogRoot $log -WaitTarget -Guests WINMINE.EXE
  $text=Get-Content "$log/$case-winmine-windows.txt" -Raw -Encoding UTF8
  $last=($text -split 'sample-ms=')[-1]
  $found=$last -match 'visible=1 class=(?:00C900A800C000D7 text=00C900A800C000D7|004D0069006E00650073007700650065007000650072 text=004D0069006E00650073007700650065007000650072)'
  $rows+=@{case=$case;environmentChars=$chars;environmentVariables=$environment.Count;expectedWindow=$found;workerAlive=$last.Contains('alive=1')}
  Stop-IsolatedPackageScope $scope|Out-Null
 }
 $rows|ConvertTo-Json|Set-Content -Encoding UTF8 "$log/result.json"
 if(!$rows[0].expectedWindow -or $rows[1].expectedWindow){throw 'Environment contamination hypothesis not established'}
 '0'|Set-Content "$PSScriptRoot/wow-environment-pair.exit"
} catch {$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/wow-environment-pair.exit";exit 1}
finally {Stop-IsolatedPackageScope $scope|Out-Null;Remove-PhysicalRuntimeStage $runtime}
