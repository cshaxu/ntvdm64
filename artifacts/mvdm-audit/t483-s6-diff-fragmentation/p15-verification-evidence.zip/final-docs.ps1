$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 & tools/governance/Verify-DocumentationGovernance.ps1
 if($LASTEXITCODE){throw 'Governance failed'}
 & tools/governance/Test-DocumentationRelativeLinks.ps1
 if($LASTEXITCODE){throw 'Relative links failed'}
 git diff --check
 if($LASTEXITCODE){throw 'Diff check failed'}
 '0'|Set-Content "$PSScriptRoot/final-docs.exit"
}catch{$_|Out-String|Write-Output;'1'|Set-Content "$PSScriptRoot/final-docs.exit";exit 1}
