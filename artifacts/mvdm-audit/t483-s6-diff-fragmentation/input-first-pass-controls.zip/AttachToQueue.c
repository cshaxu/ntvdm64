/****************************** Module Header ******************************\
* Module Name: input.c
*
* Copyright (c) 1985-91, Microsoft Corporation
*
* This module contains the core functions of the input sub-system
*
* History:
* 10-18-90 DavidPe      Created.
* 02-14-91 mikeke       Added Revalidation code
\***************************************************************************/

#include "wow_input_group_bindings.h"
#pragma hdrstop

//#define MARKPATH
#ifdef MARKPATH
#error
#endif


#line 22
#ifdef TRACESYSPEEK // is defined in userk.h
#error
#line 56
#endif //TRACESYSPEEK

#line 58
#if DBG
#error
#line 84
#endif  // DBG

int LangToggleKeyState = 0;

PVOID KeyStateLookasideBase;
PVOID KeyStateLookasideBounds;
#line 91
#if DBG
#error
#line 97
#endif // DBG

#define CANCEL_ACTIVESTATE  0
#define CANCEL_FOCUSSTATE   1
#define CANCEL_CAPTURESTATE 2

#define KEYSTATESIZE    (CBKEYSTATE + CBKEYSTATERECENTDOWN)


/*
 * xxxGetNextSysMsg return values
 */
#define PQMSG_PLAYBACK       ((PQMSG)1)
#line 238
#ifdef MARKPATH
#error
#line 243
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif
#line 1154
#ifdef SYSMODALWINDOWS
#error
#line 1181
#endif //LATER
#line 1409
#if 0
#error
#line 1430
#endif
#line 1641
#if DBG
#error
#endif // DBG
#line 1647
#if DBG
#error
#line 1653
#endif // DBG
#line 1669
#if DBG
#error
#endif // DBG
#line 1679
#if DBG
#error
#endif // DBG
#line 1764
#if (CBKEYSTATERECENTDOWN % 4) != 0
#error "CBKEYSTATERECENTDOWN assumed to be an integral number of DWORDs"
#endif
#line 2295
#ifdef NEVER
#error
#line 2309
#endif
#line 2924
#ifdef TRACESYSPEEK
#error
#endif

#line 2928
#ifdef DEBUG
#error
#line 2949
#endif
#line 2957
#ifdef DEBUG
#error
#line 2964
#endif
#line 2971
#ifdef DEBUG
#error
#endif
#line 3188
#if DBG
#error
#line 3230
#endif  // DBG
#line 3307
#ifdef FE_IME
#error
#endif
#ifdef MARKPATH
#error
#line 3320
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif
#line 4551
#ifdef FE_IME
#error
#line 4575
#endif
#line 4750
#ifdef FE_IME
#error
#line 4757
#else
#line 4759
#endif
#line 4764
#if DBG
#error
#line 4767
#endif  // DBG
#line 4991
/***************************************************************************\
* RecalcThreadAttachment
* Recalc2
* AddAttachment
* CheckAttachment
*
* Runs through all the attachinfo fields for all threads and calculates
* which threads share which queues. Puts calculated result in pqAttach
* field in each threadinfo structure. This is a difficult problem
* whose only solution in iterative. The basic algorithm is:
*
* 0. Find next unattached thread and attach a queue to it. If none, stop.
* 1. Loop through all threads: If thread X assigned to this queue or any
*    of X's attach requests assigned to this queue, assign X and all X's
*    attachments to this queue. Remember if we ever attach a 16 bit thread.
* 2. If thread X is a 16 bit thread and we've already attached another
*    16 bit thread, assign X and all X's attachments to this queue.
* 3. If any change found in 1-2, goto 1
* 4. Goto 0
*
* 12-11-92 ScottLu      Created.
* 01-Oct-1993 mikeke    Fixed to work with MWOWs
\***************************************************************************/

void AddAttachment(
    PTHREADINFO pti,
    PQ pqAttach,
    LPBOOL pfChanged)
{
    if (pti->pqAttach != pqAttach) {
        /*
         * LATER
         * !!! This is totally screwed up,  The only reason that this thing
         * could be non null is because two threads are going through
         * attachthreadintput() at the same time.  No one can predict
         * what kind of problems are going to be caused by that.
         * We leave the critical section in one place where we send
         * WM_CANCELMODE below.  We should figure out how to remove
         * the sendmessage.
         *
         * If there already is a queue there, as there may be, destroy it.
         * Note that DestroyQueue() will only get rid of the queue if the
         * thread reference count goes to 0.
         */
        PQ pqDestroy = pti->pqAttach;
        pti->pqAttach = pqAttach;
        if (pqDestroy != NULL)
            DestroyQueue(pqDestroy, pti);
        pqAttach->cThreads++;
        *pfChanged = TRUE;
    }
}

void Recalc2(
    PQ pqAttach,
    PTHREADINFO ptiCurrent)
#line 5046
{
    PATTACHINFO pai;
    PTHREADINFO pti;
    BOOL fChanged;
    PLIST_ENTRY pHead, pEntry;

    /*
     * Keep adding attachments until everything that should be attached to this
     * queue is attached
     */
    do {
        fChanged = FALSE;

        /*
         * If a thread is attached to this Q attach all of it's attachments
         * and MWOW buddies if they aren't already attached.
         */
        pHead = &PtiCurrent()->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if (pti->pqAttach == pqAttach) {
                /*
                 * check each of the attachments to see if this thread is attached
                 * to any other threads
                 */
                for (pai = gpai; pai != NULL; pai = pai->paiNext) {
                    /*
                     * if they weren't attached already, attach them
                     */
                    if (pai->pti1 == pti || pai->pti2 == pti) {
                        AddAttachment(
                                (pai->pti1 == pti) ? pai->pti2 : pai->pti1,
                                pqAttach,
                                &fChanged);
                    }
                }

                /*
                 * If this is a 16bit thread attach to all other threads in
                 * it's MWOW
                 */
                if (pti->TIF_flags & TIF_16BIT) {
                    PTHREADINFO ptiAttach;
                    PLIST_ENTRY pHeadAttach, pEntryAttach;

                    pHeadAttach = &pti->rpdesk->PtiList;
                    for (pEntryAttach = pHeadAttach->Flink;
                            pEntryAttach != pHeadAttach;
                            pEntryAttach = pEntryAttach->Flink) {
                        ptiAttach = CONTAINING_RECORD(pEntryAttach, THREADINFO, PtiLink);

                        if (ptiAttach->TIF_flags & TIF_16BIT &&
                            ptiAttach->ppi == pti->ppi) {
                            AddAttachment(ptiAttach, pqAttach, &fChanged);
                        }
                    }
                }
            }
        }
    } while (fChanged);
}
#line 5295
#if DBG
#error
#line 5299
#endif
#line 5316
#if DBG
#error
#line 5320
#endif

#line 5493
void AttachToQueue(
    PTHREADINFO pti,
    PQ   pqAttach,
    PQ   pqJournal,
    BOOL fJoiningForeground)
{
    PQMSG pqmsgT;
    PQ pqDestroy;

    /*
     * Check active state.
     */
    switch (CheckTransferState(pti, pqAttach,
            FIELD_OFFSET(Q, spwndActive), fJoiningForeground)) {
    case CTS_CANCELOLD:
        CancelInputState(pti, CANCEL_ACTIVESTATE);
        break;

    case CTS_TRANSFER:
        Lock(&pqAttach->spwndActive, pti->pq->spwndActive);

        /*
         * The caret usually follows the focus window, which follows
         * the active window...
         */
        if (pti->pq->caret.spwnd != NULL) {

            if (GETPTI(pti->pq->caret.spwnd) == pti) {
                /*
                 * Just copy the entire caret structure... that way we
                 * don't need to deal with locking/unlocking the spwnd.
                 */
                if (pqAttach->caret.spwnd == NULL) {
                    pqAttach->caret = pti->pq->caret;
                    pti->pq->caret.spwnd = NULL;
                }
            }
        }
        break;
    }

    /*
     * Check focus state.
     */
    switch (CheckTransferState(pti, pqAttach,
            FIELD_OFFSET(Q, spwndFocus), fJoiningForeground)) {
    case CTS_CANCELOLD:
        CancelInputState(pti, CANCEL_FOCUSSTATE);
        break;

    case CTS_TRANSFER:
        Lock(&pqAttach->spwndFocus, pti->pq->spwndFocus);
        break;
    }

    /*
     * Check capture state.
     */
    switch (CheckTransferState(pti, pqAttach,
            FIELD_OFFSET(Q, spwndCapture), fJoiningForeground)) {
    case CTS_CANCELOLD:
        CancelInputState(pti, CANCEL_CAPTURESTATE);
        break;

    case CTS_TRANSFER:
        Lock(&pqAttach->spwndCapture, pti->pq->spwndCapture);
        pqAttach->codeCapture = pti->pq->codeCapture;
        break;
    }

    /*
     * Check mouse tracking state.
     */
    switch (CheckTransferState(pti, pqAttach,
            FIELD_OFFSET(Q, spwndLastMouseMessage), fJoiningForeground)) {
    case CTS_CANCELOLD:
        ResetMouseTracking(pti->pq, NULL);
        break;

    case CTS_TRANSFER:
        Lock(&pqAttach->spwndLastMouseMessage, pti->pq->spwndLastMouseMessage);
        pqAttach->QF_flags |= pti->pq->QF_flags & (QF_TRACKMOUSEHOVER | QF_TRACKMOUSELEAVE);
        break;
    }

    /*
     * Check spwndActivePrev state.  This check has some considerations.
     * If the CTS_TRANSFER is returned, it usually means there was no
     * prev-active in the attach-queue, and it will use the first
     * window it encounters.  Since we walk the thread-list, a out-of-zorder
     * window could be chosen.  So, to counter this, we'll check the
     * attach-queue-next-prev against the thread-previous window to see
     * if it is truly the next-zorder window.
     */
    switch (CheckTransferState(pti, pqAttach,
            FIELD_OFFSET(Q, spwndActivePrev), fJoiningForeground)) {
    case CTS_TRANSFER:
        Lock(&pqAttach->spwndActivePrev, pti->pq->spwndActivePrev);
        break;

    case CTS_CANCELOLD:

        /*
         * Check to see if the previous window is what we would expect it
         * to be.
         */
        if (pqAttach->spwndActive &&
            (pqAttach->spwndActivePrev && pti->pq->spwndActivePrev) &&
            (pqAttach->spwndActive->spwndNext == pti->pq->spwndActivePrev)) {

            Lock(&pqAttach->spwndActivePrev, pti->pq->spwndActivePrev);
        }
        break;
    }

    if (pti == pti->pq->ptiSysLock) {
        pqAttach->QF_flags = pti->pq->QF_flags;

        /*
         *  Fix for 29967 "Start menu disappears when clicked  and Office
         *  taskbar has focus!". Win95 uses a global counter instead of this
         *  flag. In NT when we click on Office taskbar and then on the Start
         *  Menu, MSoffice calls AttachThreadInput() which changes the Start
         *  Menu's queue and the new queue has the QF_ACTIVATIONCHANGE flag on.
         *  Inside the xxxMNLoop we test if this flag is on and if it is we
         *  exit the menu.
         */
        if (!IsInsideMenuLoop(pti)) {
            pqAttach->QF_flags &= ~QF_ACTIVATIONCHANGE;
        }
    }

    if (gspwndCursor != NULL && pti == GETPTI(gspwndCursor)) {
        LockQCursor(pqAttach, pti->pq->spcurCurrent);
    }

    /*
     * Each thread has its own cursor level, which is a count of the number
     * of times that app has called show/hide cursor. This gets added into
     * the queue's count for a completely accurate count every time this
     * queue recalculation is done.
     */
    pqAttach->iCursorLevel += pti->iCursorLevel;

    /*
     * Pump up the new queue with the right input variables.
     */
    pqAttach->ptiMouse    = pti;
    pqAttach->ptiKeyboard = pti;

    /*
     * Grab the alt-tab window if it exists and we don't already have
     * one.  Queues other than the RIT can have alt-tab windows, so
     * we must make sure we clean up the extra windows.
     */
    if (pti->pq->spwndAltTab != NULL && GETPTI(pti->pq->spwndAltTab) == pti &&
            pqAttach->spwndAltTab == NULL) {
        Lock(&pqAttach->spwndAltTab, pti->pq->spwndAltTab);
        Unlock(&pti->pq->spwndAltTab);
        pqAttach->QF_flags |= QF_INALTTAB;
        pti->pq->QF_flags &= ~QF_INALTTAB;
    }

    pqDestroy = pti->pq;

    /*
     * Don't increment the thread count here because we already incremented
     * it when we put it in pti->pqAttach. Since we're moving it from pqAttach
     * to pq, we don't mess with the reference count.
     */
    pti->pq = pqAttach;

    /*
     * If the thread is using the journal queue, leave the message list
     * alone.  Otherwise, redistribute the messages.
     */
    if (pqDestroy != pqJournal) {

        /*
         * Remember the current message list so it can get redistributed taking
         * into account ptiAttach's new queue.
         */
        pqmsgT = pqDestroy->mlInput.pqmsgRead;
        pqDestroy->mlInput.pqmsgRead      = NULL;
        pqDestroy->mlInput.pqmsgWriteLast = NULL;
        pqDestroy->mlInput.cMsgs          = 0;

        /*
         * Now redistribute the input messages from the old queue they go into the
         * right queues.
         *
         * Preserve the 'idSysPeek' when redistributing the queue
         */
        RedistributeInput(pqmsgT, pqDestroy);

        /*
         * Officially attach the new queue to this thread. Note that DestroyQueue()
         * doesn't actually destroy anything until the thread reference count goes
         * to 0.
         */
        DestroyQueue(pqDestroy, pti);

    } else {
        UserAssert(pqDestroy->cThreads);
        pqDestroy->cThreads--;
    }
}
