$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process $env:ComSpec -ArgumentList '/d /c build\t483-s6-p13\zone.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/zone.stdout" -RedirectStandardError "$PSScriptRoot/zone.stderr"
$p.Id|Set-Content "$PSScriptRoot/zone-child.pid"
if(!$p.WaitForExit(600000)){taskkill /pid $p.Id /t /f;124|Set-Content "$PSScriptRoot/zone.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/zone.exit"
exit $p.ExitCode
