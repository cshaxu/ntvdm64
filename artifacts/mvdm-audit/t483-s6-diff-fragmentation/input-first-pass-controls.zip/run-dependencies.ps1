$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process $env:ComSpec -ArgumentList '/d /c build\t483-s6-p13\dependencies.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/dependencies.stdout" -RedirectStandardError "$PSScriptRoot/dependencies.stderr"
$p.Id|Set-Content "$PSScriptRoot/dependencies-child.pid"
if(!$p.WaitForExit(600000)){taskkill /pid $p.Id /t /f;124|Set-Content "$PSScriptRoot/dependencies.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/dependencies.exit"
exit $p.ExitCode
