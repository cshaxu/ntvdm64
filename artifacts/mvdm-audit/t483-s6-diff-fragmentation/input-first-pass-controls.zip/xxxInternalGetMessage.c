/****************************** Module Header ******************************\
* Module Name: input.c
*
* Copyright (c) 1985-91, Microsoft Corporation
*
* This module contains the core functions of the input sub-system
*
* History:
* 10-18-90 DavidPe      Created.
* 02-14-91 mikeke       Added Revalidation code
\***************************************************************************/

#include "wow_input_group_bindings.h"
#pragma hdrstop

//#define MARKPATH
#ifdef MARKPATH
#error
#endif


#line 22
#ifdef TRACESYSPEEK // is defined in userk.h
#error
#line 56
#endif //TRACESYSPEEK

#line 58
#if DBG
#error
#line 84
#endif  // DBG

int LangToggleKeyState = 0;

PVOID KeyStateLookasideBase;
PVOID KeyStateLookasideBounds;
#line 91
#if DBG
#error
#line 97
#endif // DBG

#define CANCEL_ACTIVESTATE  0
#define CANCEL_FOCUSSTATE   1
#define CANCEL_CAPTURESTATE 2

#define KEYSTATESIZE    (CBKEYSTATE + CBKEYSTATERECENTDOWN)


/*
 * xxxGetNextSysMsg return values
 */
#define PQMSG_PLAYBACK       ((PQMSG)1)
#line 238
#ifdef MARKPATH
#error
#line 243
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif
#line 1154
#ifdef SYSMODALWINDOWS
#error
#line 1181
#endif //LATER
#line 1409
#if 0
#error
#line 1430
#endif
#line 1641
#if DBG
#error
#endif // DBG
#line 1647
#if DBG
#error
#line 1653
#endif // DBG
#line 1669
#if DBG
#error
#endif // DBG
#line 1679
#if DBG
#error
#endif // DBG
#line 1764
#if (CBKEYSTATERECENTDOWN % 4) != 0
#error "CBKEYSTATERECENTDOWN assumed to be an integral number of DWORDs"
#endif
#line 2295
#ifdef NEVER
#error
#line 2309
#endif
#line 2924
#ifdef TRACESYSPEEK
#error
#endif

#line 2928
#ifdef DEBUG
#error
#line 2949
#endif
#line 2957
#ifdef DEBUG
#error
#line 2964
#endif
#line 2971
#ifdef DEBUG
#error
#endif
#line 3188
#if DBG
#error
#line 3230
#endif  // DBG
#line 3307
#ifdef FE_IME
#error
#endif
#ifdef MARKPATH
#error
#line 3320
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif
#line 4551
#ifdef FE_IME
#error
#line 4575
#endif
#line 4750
#ifdef FE_IME
#error
#line 4757
#else
#line 4759
#endif
#line 4764
#if DBG
#error
#line 4767
#endif  // DBG
#line 4991
/***************************************************************************\
* RecalcThreadAttachment
* Recalc2
* AddAttachment
* CheckAttachment
*
* Runs through all the attachinfo fields for all threads and calculates
* which threads share which queues. Puts calculated result in pqAttach
* field in each threadinfo structure. This is a difficult problem
* whose only solution in iterative. The basic algorithm is:
*
* 0. Find next unattached thread and attach a queue to it. If none, stop.
* 1. Loop through all threads: If thread X assigned to this queue or any
*    of X's attach requests assigned to this queue, assign X and all X's
*    attachments to this queue. Remember if we ever attach a 16 bit thread.
* 2. If thread X is a 16 bit thread and we've already attached another
*    16 bit thread, assign X and all X's attachments to this queue.
* 3. If any change found in 1-2, goto 1
* 4. Goto 0
*
* 12-11-92 ScottLu      Created.
* 01-Oct-1993 mikeke    Fixed to work with MWOWs
\***************************************************************************/

void AddAttachment(
    PTHREADINFO pti,
    PQ pqAttach,
    LPBOOL pfChanged)
{
    if (pti->pqAttach != pqAttach) {
        /*
         * LATER
         * !!! This is totally screwed up,  The only reason that this thing
         * could be non null is because two threads are going through
         * attachthreadintput() at the same time.  No one can predict
         * what kind of problems are going to be caused by that.
         * We leave the critical section in one place where we send
         * WM_CANCELMODE below.  We should figure out how to remove
         * the sendmessage.
         *
         * If there already is a queue there, as there may be, destroy it.
         * Note that DestroyQueue() will only get rid of the queue if the
         * thread reference count goes to 0.
         */
        PQ pqDestroy = pti->pqAttach;
        pti->pqAttach = pqAttach;
        if (pqDestroy != NULL)
            DestroyQueue(pqDestroy, pti);
        pqAttach->cThreads++;
        *pfChanged = TRUE;
    }
}

void Recalc2(
    PQ pqAttach,
    PTHREADINFO ptiCurrent)
#line 5046
{
    PATTACHINFO pai;
    PTHREADINFO pti;
    BOOL fChanged;
    PLIST_ENTRY pHead, pEntry;

    /*
     * Keep adding attachments until everything that should be attached to this
     * queue is attached
     */
    do {
        fChanged = FALSE;

        /*
         * If a thread is attached to this Q attach all of it's attachments
         * and MWOW buddies if they aren't already attached.
         */
        pHead = &PtiCurrent()->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if (pti->pqAttach == pqAttach) {
                /*
                 * check each of the attachments to see if this thread is attached
                 * to any other threads
                 */
                for (pai = gpai; pai != NULL; pai = pai->paiNext) {
                    /*
                     * if they weren't attached already, attach them
                     */
                    if (pai->pti1 == pti || pai->pti2 == pti) {
                        AddAttachment(
                                (pai->pti1 == pti) ? pai->pti2 : pai->pti1,
                                pqAttach,
                                &fChanged);
                    }
                }

                /*
                 * If this is a 16bit thread attach to all other threads in
                 * it's MWOW
                 */
                if (pti->TIF_flags & TIF_16BIT) {
                    PTHREADINFO ptiAttach;
                    PLIST_ENTRY pHeadAttach, pEntryAttach;

                    pHeadAttach = &pti->rpdesk->PtiList;
                    for (pEntryAttach = pHeadAttach->Flink;
                            pEntryAttach != pHeadAttach;
                            pEntryAttach = pEntryAttach->Flink) {
                        ptiAttach = CONTAINING_RECORD(pEntryAttach, THREADINFO, PtiLink);

                        if (ptiAttach->TIF_flags & TIF_16BIT &&
                            ptiAttach->ppi == pti->ppi) {
                            AddAttachment(ptiAttach, pqAttach, &fChanged);
                        }
                    }
                }
            }
        }
    } while (fChanged);
}
#line 5295
#if DBG
#error
#line 5299
#endif
#line 5316
#if DBG
#error
#line 5320
#endif

#line 220
BOOL xxxInternalGetMessage(
    LPMSG lpMsg,
    HWND hwndFilter,
    UINT msgMin,
    UINT msgMax,
    UINT flags,
    BOOL fGetMessage)
{
    UINT fsWakeBits;
    UINT fsWakeMask;
    PTHREADINFO pti;
    PW32PROCESS W32Process;
    PWND pwndFilter;
    BOOL fLockPwndFilter;
    TL tlpwndFilter;
    BOOL fRemove;
    BOOL fExit;
    PQ pq;
#ifdef MARKPATH
    DWORD pathTaken = 0;

#define PATHTAKEN(x)  pathTaken  |= x
#define DUMPPATHTAKEN() if (gfMarkPath) DbgPrint("xxxInternalGetMessage path:%08x\n", pathTaken)
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif

    CheckCritIn();

    pti = PtiCurrent();

    /*
     * PeekMessage accepts NULL, 0x0000FFFF, and -1 as valid HWNDs.
     * If hwndFilter is invalid we can't just return FALSE because that will
     * hose existing badly behaved apps who might attempt to dispatch
     * the random contents of pmsg.
     */
    if ((hwndFilter == (HWND)-1) || (hwndFilter == (HWND)0x0000FFFF)) {
        hwndFilter = (HWND)1;
    }

    if ((hwndFilter != NULL) && (hwndFilter != (HWND)1)) {
        if ((pwndFilter = ValidateHwnd(hwndFilter)) == NULL) {
            lpMsg->hwnd = NULL;
            lpMsg->message = WM_NULL;
            PATHTAKEN(1);
            DUMPPATHTAKEN();
            if (fGetMessage)
                return -1;
            else
                return 0;
        }

        ThreadLockAlwaysWithPti(pti, pwndFilter, &tlpwndFilter);
        fLockPwndFilter = TRUE;

    } else {
        pwndFilter = (PWND)hwndFilter;
        fLockPwndFilter = FALSE;
    }

    /*
     * Add one to our spin count. At this end of this routine we'll check
     * to see if the spin count gets >= CSPINBACKGROUND. If so we'll put this
     * process into the background.
     */
    pti->pClientInfo->cSpins++;

    /*
     * Check to see if the startglass is on, and if so turn it off and update.
     */
    W32Process = W32GetCurrentProcess();
    if (W32Process->W32PF_Flags & W32PF_STARTGLASS) {

        /*
         * This app is no longer in "starting" mode. Recalc when to hide
         * the app starting cursor.
         */
        W32Process->W32PF_Flags &= ~W32PF_STARTGLASS;
        CalcStartCursorHide(NULL, 0);
    }

    /*
     * Next check to see if any .dlls need freeing in
     * the context of this client (used for windows hooks).
     */
    if (pti->ppi->cSysExpunge != gcSysExpunge) {
        pti->ppi->cSysExpunge = gcSysExpunge;
        if (pti->ppi->dwhmodLibLoadedMask & gdwSysExpungeMask)
            xxxDoSysExpunge(pti);
    }

    /*
     * Set up BOOL fRemove local variable from for ReadMessage()
     */
    fRemove = flags & PM_REMOVE;

    /*
     * Unlock the system queue if it's owned by us.
     */
    /*
     * If we're currently processing a message, unlock the input queue
     * because the sender, who is blocked, might be the owner, and in order
     * to reply, the receiver may need to read keyboard / mouse input.
     */
    /*
     * If this thread has the input queue locked and the last message removed
     * is the last message we looked at, then unlock - we're ready for anyone
     * to get the next message.
     */
    pq = pti->pq;
    if (   (pti->psmsCurrent != NULL)
        || (pq->ptiSysLock == pti && pq->idSysLock == pti->idLast)
       ) {
        CheckSysLock(1, pq, NULL);
        pq->ptiSysLock = NULL;
        PATHTAKEN(2);
    } else if (pq->ptiSysLock && (pq->ptiSysLock->cVisWindows == 0) &&
            (pti->pDeskInfo->asphkStart[WH_JOURNALPLAYBACK + 1] != NULL)) {
        /*
         * If the thread that has the system queue lock has no windows visible
         * (can happen if it just hid its last window), don't expect it to call
         * GetMessage() again! - unlock the system queue. --- ScottLu
         * This condition creates a hole by which a second thread attached to
         * the same queue as thread 1 can alter pq->idSysPeek during a callback
         * made by thread 1 so that thread 1 will delete the wrong message
         * (losing keystrokes - causing Shift to appear be stuck down editing a
         * Graph5 caption embedded in Word32 document #5032.  However, MSTEST
         * requires this hole, so allow it if Journal Playback is occurring
         * #8850 (yes, a hack)  Chicago also has this behavior.  --- IanJa
         */
        CheckSysLock(2, pq, NULL);
        pq->ptiSysLock = NULL;
        PATHTAKEN(3);
    }
    if (pq->ptiSysLock != pti) {
        pti->pcti->CTIF_flags &= ~CTIF_SYSQUEUELOCKED;
    }

    /*
     * If msgMax == 0 then msgMax = -1: that makes our range checking only
     * have to deal with msgMin < msgMax.
     */
    if (msgMax == 0)
        msgMax--;

    /*
     * Compute the QS* mask that corresponds to the message range.
     */
    fsWakeMask = CalcWakeMask(msgMin, msgMax);
    pti->fsChangeBitsRemoved = 0;

    /*
     * If we can yield and one or more events were skipped,
     * set the wakebits for event
     */
    if (!(flags & PM_NOYIELD) && pti->TIF_flags & TIF_DELAYEDEVENT) {
        pti->pcti->fsWakeBits |= QS_EVENT;
        pti->pcti->fsChangeBits |= QS_EVENT;
        pti->TIF_flags &= ~TIF_DELAYEDEVENT;
    }

    while (TRUE) {

        /*
         * Restore any wake bits saved while journalling
         */
        pti->pcti->fsWakeBits |= pti->pcti->fsWakeBitsJournal;

        /*
         * If we need to recalc queue attachments, do it here. Do it on the
         * right desktop or else the queues will get created in the wrong
         * heap.
         */
        if (pti->rpdesk == gpdeskRecalcQueueAttach) {
            gpdeskRecalcQueueAttach = NULL;

            if (pti->rpdesk != NULL && !FJOURNALRECORD() && !FJOURNALPLAYBACK()) {
                ReattachThreads(FALSE);
                PATHTAKEN(4);
            }
        }

        /*
         * Remember what change bits we're clearing. This is important to
         * fix a bug in the input model: If an app receives a sent message
         * from within SleepThread(), then does PostMessage() (which sets
         * QS_POSTMESSAGE), then does a PeekMessage(...) for some different
         * posted message (clears QS_POSTMESSAGE in fsChangeBits), then returns
         * back into SleepThread(), it won't wake up to retrieve that newly
         * posted message because the change bits are cleared.
         *
         * What we do is remember the change bits that are being cleared.
         * Then, when we return to SleepThread(), we put these remembered
         * bits back into the change bits that also have corresponding
         * bits in the wakebits (so we don't set changebits that represent
         * input that isn't there anymore). This way, the app will retrieve
         * the newly posted message refered to earlier.
         * - scottlu
         */
        pti->fsChangeBitsRemoved |= pti->pcti->fsChangeBits & fsWakeMask;

        /*
         * Clear the change bits that we're looking at, in order to detect
         * incoming events that may occur the last time we checked the wake
         * bits.
         */
        pti->pcti->fsChangeBits &= ~fsWakeMask;

        /*
         * Check to see if we have any input we want.
         */
        xxxReceiveMessages(pti);
        if ((pti->pcti->fsWakeBits & fsWakeMask) == 0) {
            PATHTAKEN(8);
            goto NoMessages;
        }
        fsWakeBits = pti->pcti->fsWakeBits;

        /*
         * If the queue lock is != NULL (ptiSysLock) and it is this thread that
         * locked it, then go get the message from the system queue. This is
         * to prevent messages posted after a PeekMessage/no-remove from being
         * seen before the original message from the system queue. (Aldus
         * Pagemaker requires this) (bobgu 8/5/87).
         */
        if (pti->pq->ptiSysLock == pti &&
                (pti->pq->QF_flags & QF_LOCKNOREMOVE)) {
            /*
             * Does the caller want mouse / keyboard?
             */
            if (fsWakeBits & fsWakeMask & (QS_INPUT | QS_EVENT)) {
                if (xxxScanSysQueue(pti, lpMsg, pwndFilter,
                        msgMin, msgMax, flags,
                        fsWakeBits & fsWakeMask & (QS_INPUT | QS_EVENT))) {

                    PATHTAKEN(0x10);
                    break;
                }
            }
        }

        /*
         * See if there's a message in the application queue.
         */
        if (fsWakeBits & fsWakeMask & QS_POSTMESSAGE) {
            if (xxxReadPostMessage(pti, lpMsg, pwndFilter,
                    msgMin, msgMax, fRemove)) {
                PATHTAKEN(0x20);
                break;
            }
        }

        /*
         * Time to scan the raw input queue for input. First check to see
         * if the caller wants mouse / keyboard input.
         */
        if (fsWakeBits & fsWakeMask & (QS_INPUT | QS_EVENT)) {
            if (xxxScanSysQueue(pti, lpMsg, pwndFilter,
                    msgMin, msgMax, flags,
                    fsWakeBits & fsWakeMask & (QS_INPUT | QS_EVENT))) {
                PATHTAKEN(0x40);
                break;
            }
        }

        /*
         * Get new input bits, check for SendMsgs.
         */
        xxxReceiveMessages(pti);
        if ((pti->pcti->fsWakeBits & fsWakeMask) == 0) {
            PATHTAKEN(0x80);
            goto NoMessages;
        }
        fsWakeBits = pti->pcti->fsWakeBits;

        /*
         * Does the caller want paint messages? If so, try to find a paint.
         */
        if (fsWakeBits & fsWakeMask & QS_PAINT) {
            if (DoPaint(pwndFilter, lpMsg)) {
                PATHTAKEN(0x100);
                break;
            }
        }

        /*
         * We must yield for 16 bit apps before checking timers or an app
         * that has a fast timer could chew up all the time and never let
         * anyone else run.
         *
         * NOTE: This could cause PeekMessage() to yield TWICE, if the user
         * is filtering with a window handle. If the DoTimer() call fails
         * then we end up yielding again.
         */
        if (!(flags & PM_NOYIELD)) {
            /*
             * This is the point where windows would yield.  Here we wait to wake
             * up any threads waiting for this thread to hit "idle state".
             */
            WakeInputIdle(pti);

            /*
             * Yield and receive pending messages.
             */
            xxxUserYield(pti);

            /*
             * Check new input buts and receive pending messages.
             */
            xxxReceiveMessages(pti);
            if ((pti->pcti->fsWakeBits & fsWakeMask) == 0) {

                PATHTAKEN(0x200);
                goto NoMessages;
            }
            fsWakeBits = pti->pcti->fsWakeBits;
        }

        /*
         * Does the app want timer messages, and if there one pending?
         */
        if (fsWakeBits & fsWakeMask & QS_TIMER) {
            if (DoTimer(pwndFilter, msgMin, msgMax)) {
                /*
                 * DoTimer() posted the message into the app's queue,
                 * so start over and we'll grab it from there.
                 */

                PATHTAKEN(0x400);
                continue;
            }
        }

NoMessages:
        /*
         * Looks like we have no input. If we're being called from GetMessage()
         * then go to sleep until we find something.
         */
        if (!fGetMessage) {
            /*
             * This is one last check for pending sent messages. It also
             * yields. Win3.1 does this.
             */
            if (!(flags & PM_NOYIELD)) {
                /*
                 * This is the point where windows yields. Here we wait to wake
                 * up any threads waiting for this thread to hit "idle state".
                 */
                WakeInputIdle(pti);

                /*
                 * Yield and receive pending messages.
                 */
                xxxUserYield(pti);
            }
            PATHTAKEN(0x800);
            goto FalseExit;
        }

        /*
         * This is a getmessage not a peekmessage, so sleep. When we sleep,
         * WakeInputIdle() is called to wake up any apps waiting on this
         * app to go idle.
         */
        if (!xxxSleepThread(fsWakeMask, 0, TRUE))
            goto FalseExit;
    }

    /*
     * If we're here then we have input for this queue. Call the
     * GetMessage() hook with this input.
     */
    if (IsHooked(pti, WHF_GETMESSAGE))
        xxxCallHook(HC_ACTION, flags, (DWORD)lpMsg, WH_GETMESSAGE);

    /*
     * If called from PeekMessage(), return TRUE.
     */
    if (!fGetMessage) {
        PATHTAKEN(0x1000);
        goto TrueExit;
    }

    /*
     * Being called from GetMessage(): return FALSE if the message is WM_QUIT,
     * TRUE otherwise.
     */
    if (lpMsg->message == WM_QUIT) {
        PATHTAKEN(0x2000);
        goto FalseExit;
    }

    /*
     * Fall through to TrueExit...
     */

TrueExit:
    /*
     * Update timeLastRead. We use this for hung app calculations.
     */
    SET_TIME_LAST_READ(pti);
    fExit = TRUE;
    PATHTAKEN(0x4000);
    goto Exit;

FalseExit:
    fExit = FALSE;

Exit:
    if (fLockPwndFilter)
        ThreadUnlock(&tlpwndFilter);

    /*
     * see CheckProcessBackground() comment above
     * Check to see if we need to move this process into background
     * priority.
     */
    if (pti->pClientInfo->cSpins >= CSPINBACKGROUND) {

        pti->pClientInfo->cSpins = 0;

        if (!(pti->TIF_flags & TIF_SPINNING)) {

            pti->TIF_flags |= TIF_SPINNING;
            pti->pClientInfo->dwTIFlags = pti->TIF_flags;

            if (!(pti->ppi->W32PF_Flags & W32PF_FORCEBACKGROUNDPRIORITY)) {

                pti->ppi->W32PF_Flags |= W32PF_FORCEBACKGROUNDPRIORITY;

                if (pti->ppi == gppiWantForegroundPriority) {
                    SetForegroundPriority(pti, FALSE);
                }
            }
        }

        /*
         * For spinning Message loops, we need to take the 16bit-thread out
         * of the scheduler temporarily so that other processes can get a chance
         * to run.  This is appearent in OLE operations where a 16bit foreground
         * thread starts an OLE activation on a 32bit process.  The 32bit process
         * gets starved of CPU while the 16bit thread spins.
         */
        if (pti->TIF_flags & TIF_16BIT) {

            /*
             * Take the 16bit thread out of the scheduler.  This wakes any
             * other 16bit thread needing time, and takes the current thread
             * out.  We will do a brief sleep so that apps can respond in time.
             * When done, we will reschedule the thread.  The WakeInputIdle()
             * should have been called in the no-messages section, so we have
             * already set the Idle-Event.
             */
            xxxSleepTask(FALSE, HEVENT_REMOVEME);

            LeaveCrit();
            ZwYieldExecution();
            CheckForClientDeath();
            EnterCrit();

            xxxDirectedYield(DY_OLDYIELD);
        }
    }

    PATHTAKEN(0x8000);
    DUMPPATHTAKEN();
    return fExit;
}
