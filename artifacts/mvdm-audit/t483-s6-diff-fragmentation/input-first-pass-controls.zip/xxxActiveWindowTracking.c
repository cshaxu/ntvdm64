/****************************** Module Header ******************************\
* Module Name: input.c
*
* Copyright (c) 1985-91, Microsoft Corporation
*
* This module contains the core functions of the input sub-system
*
* History:
* 10-18-90 DavidPe      Created.
* 02-14-91 mikeke       Added Revalidation code
\***************************************************************************/

#include "wow_input_group_bindings.h"
#pragma hdrstop

//#define MARKPATH
#ifdef MARKPATH
#error
#endif


#line 22
#ifdef TRACESYSPEEK // is defined in userk.h
#error
#line 56
#endif //TRACESYSPEEK

#line 58
#if DBG
#error
#line 84
#endif  // DBG

int LangToggleKeyState = 0;

PVOID KeyStateLookasideBase;
PVOID KeyStateLookasideBounds;
#line 91
#if DBG
#error
#line 97
#endif // DBG

#define CANCEL_ACTIVESTATE  0
#define CANCEL_FOCUSSTATE   1
#define CANCEL_CAPTURESTATE 2

#define KEYSTATESIZE    (CBKEYSTATE + CBKEYSTATERECENTDOWN)


/*
 * xxxGetNextSysMsg return values
 */
#define PQMSG_PLAYBACK       ((PQMSG)1)
#line 238
#ifdef MARKPATH
#error
#line 243
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif
#line 1154
#ifdef SYSMODALWINDOWS
#error
#line 1181
#endif //LATER
#line 1409
#if 0
#error
#line 1430
#endif
#line 1641
#if DBG
#error
#endif // DBG
#line 1647
#if DBG
#error
#line 1653
#endif // DBG
#line 1669
#if DBG
#error
#endif // DBG
#line 1679
#if DBG
#error
#endif // DBG
#line 1764
#if (CBKEYSTATERECENTDOWN % 4) != 0
#error "CBKEYSTATERECENTDOWN assumed to be an integral number of DWORDs"
#endif
#line 2295
#ifdef NEVER
#error
#line 2309
#endif
#line 2924
#ifdef TRACESYSPEEK
#error
#endif

#line 2928
#ifdef DEBUG
#error
#line 2949
#endif
#line 2957
#ifdef DEBUG
#error
#line 2964
#endif
#line 2971
#ifdef DEBUG
#error
#endif
#line 3188
#if DBG
#error
#line 3230
#endif  // DBG
#line 3307
#ifdef FE_IME
#error
#endif
#ifdef MARKPATH
#error
#line 3320
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif
#line 4551
#ifdef FE_IME
#error
#line 4575
#endif
#line 4750
#ifdef FE_IME
#error
#line 4757
#else
#line 4759
#endif
#line 4764
#if DBG
#error
#line 4767
#endif  // DBG
#line 4991
/***************************************************************************\
* RecalcThreadAttachment
* Recalc2
* AddAttachment
* CheckAttachment
*
* Runs through all the attachinfo fields for all threads and calculates
* which threads share which queues. Puts calculated result in pqAttach
* field in each threadinfo structure. This is a difficult problem
* whose only solution in iterative. The basic algorithm is:
*
* 0. Find next unattached thread and attach a queue to it. If none, stop.
* 1. Loop through all threads: If thread X assigned to this queue or any
*    of X's attach requests assigned to this queue, assign X and all X's
*    attachments to this queue. Remember if we ever attach a 16 bit thread.
* 2. If thread X is a 16 bit thread and we've already attached another
*    16 bit thread, assign X and all X's attachments to this queue.
* 3. If any change found in 1-2, goto 1
* 4. Goto 0
*
* 12-11-92 ScottLu      Created.
* 01-Oct-1993 mikeke    Fixed to work with MWOWs
\***************************************************************************/

void AddAttachment(
    PTHREADINFO pti,
    PQ pqAttach,
    LPBOOL pfChanged)
{
    if (pti->pqAttach != pqAttach) {
        /*
         * LATER
         * !!! This is totally screwed up,  The only reason that this thing
         * could be non null is because two threads are going through
         * attachthreadintput() at the same time.  No one can predict
         * what kind of problems are going to be caused by that.
         * We leave the critical section in one place where we send
         * WM_CANCELMODE below.  We should figure out how to remove
         * the sendmessage.
         *
         * If there already is a queue there, as there may be, destroy it.
         * Note that DestroyQueue() will only get rid of the queue if the
         * thread reference count goes to 0.
         */
        PQ pqDestroy = pti->pqAttach;
        pti->pqAttach = pqAttach;
        if (pqDestroy != NULL)
            DestroyQueue(pqDestroy, pti);
        pqAttach->cThreads++;
        *pfChanged = TRUE;
    }
}

void Recalc2(
    PQ pqAttach,
    PTHREADINFO ptiCurrent)
#line 5046
{
    PATTACHINFO pai;
    PTHREADINFO pti;
    BOOL fChanged;
    PLIST_ENTRY pHead, pEntry;

    /*
     * Keep adding attachments until everything that should be attached to this
     * queue is attached
     */
    do {
        fChanged = FALSE;

        /*
         * If a thread is attached to this Q attach all of it's attachments
         * and MWOW buddies if they aren't already attached.
         */
        pHead = &PtiCurrent()->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if (pti->pqAttach == pqAttach) {
                /*
                 * check each of the attachments to see if this thread is attached
                 * to any other threads
                 */
                for (pai = gpai; pai != NULL; pai = pai->paiNext) {
                    /*
                     * if they weren't attached already, attach them
                     */
                    if (pai->pti1 == pti || pai->pti2 == pti) {
                        AddAttachment(
                                (pai->pti1 == pti) ? pai->pti2 : pai->pti1,
                                pqAttach,
                                &fChanged);
                    }
                }

                /*
                 * If this is a 16bit thread attach to all other threads in
                 * it's MWOW
                 */
                if (pti->TIF_flags & TIF_16BIT) {
                    PTHREADINFO ptiAttach;
                    PLIST_ENTRY pHeadAttach, pEntryAttach;

                    pHeadAttach = &pti->rpdesk->PtiList;
                    for (pEntryAttach = pHeadAttach->Flink;
                            pEntryAttach != pHeadAttach;
                            pEntryAttach = pEntryAttach->Flink) {
                        ptiAttach = CONTAINING_RECORD(pEntryAttach, THREADINFO, PtiLink);

                        if (ptiAttach->TIF_flags & TIF_16BIT &&
                            ptiAttach->ppi == pti->ppi) {
                            AddAttachment(ptiAttach, pqAttach, &fChanged);
                        }
                    }
                }
            }
        }
    } while (fChanged);
}
#line 5295
#if DBG
#error
#line 5299
#endif
#line 5316
#if DBG
#error
#line 5320
#endif

#line 2005
int xxxActiveWindowTracking(
    PWND pwnd,
    UINT uMsg,
    int iHitTest)
{
    static POINT gptLastTrack = {0, 0};

    BOOL fSuccess;
    PWND pwndActivate;
    TL tlpwndActivate;
    int iRet;
    Q *pq;

    CheckLock(pwnd);
    UserAssert(SPI_UP(ACTIVEWINDOWTRACKING));

    /*
     * Some times we fake mouse moves to let apps know where the
     *  mouse is or to force them to wake up.
     * We don't have a way to detect these so here is my hack
     *  to ignore them.
     * This is to prevent activation from returning to the window
     *  the mouse is on after a window has been activated using
     *  the keyboard (alt-tab or ctrl-esc-run; xxxCapture calls
     *  SetFMouseMoved).
     * LATER: GerardoB
     * Note that as soon as you move the mouse, then activation
     *  will change anyway. In the future, we could add a
     *  snap-mouse-to-foreground-queue (or active window) option
     *  so we'll move the mouse into the window activated by the
     *  keyboard.
     */
    if ((ptCursor.x == gptLastTrack.x) && (ptCursor.y == gptLastTrack.y)) {
        return MA_PASSTHRU;
    }
    gptLastTrack = ptCursor;

    /*
     * If someone is in menu mode, bail
     */
    if (IsSomeOneInMenuMode()) {
        return MA_PASSTHRU;
    }

    pwndActivate = pwnd;

    /*
     * Find the top parent
     */
    while (TestwndChild(pwndActivate)) {
        pwndActivate = pwndActivate->spwndParent;
    }

    /*
     * If disabled, get a enabled popup owned by it.
     * This test is the same as calling FBadWindow (05/31/96)
     *  because we already know it's not NULL and it must
     *  be visible (the mouse is on it)
     */
    UserAssert(TestWF(pwndActivate, WFVISIBLE));
    if (TestWF(pwndActivate, WFDISABLED)) {
        /*
         * This is what we do elsewhere when someone clicks on a
         *  disabled non-active window. It might be cheaper to check
         *  pwnd->spwndLastActive first (we might need to walk up
         *  the owner chain though, as this is where we set spwndLastAcitve
         *  when activating a new window. see xxxActivateThisWindow).
         * But let's do the same here; this should be fixed/improved
         *  in DWP_GetEnabledPopup anyway. There might be a reason
         *  why we don't grab spwndLastActive if OK.... perhaps it has
         *  something to do with nested owner windows
         */
         pwndActivate = DWP_GetEnabledPopup(pwndActivate);
    }

    /*
     * Bail if we didn't find one
     */
    if (pwndActivate == NULL) {
        return MA_PASSTHRU;
    }

    /*
     * If already active in the foreground queue, nothing to do
     */
    pq = GETPTI(pwndActivate)->pq;
    if ((pq == gpqForeground) && (pwndActivate == pq->spwndActive)) {
        return MA_PASSTHRU;
    }

    /*
     * Don't activate the desktop
     */
    if (pwndActivate == PWNDDESKTOP(pwndActivate)) {
        return MA_PASSTHRU;
    }

    /*
     * We're going to callback, so lock if needed
     */
    if (pwnd != pwndActivate) {
        ThreadLockAlways(pwndActivate, &tlpwndActivate);
    }


    /*
     * Let's ask if it's OK to do this
     */
    iRet = (int)xxxSendMessage(pwnd, WM_MOUSEACTIVATE,
            (DWORD)(HW(pwndActivate)), MAKELONG((SHORT)iHitTest, uMsg));


    switch (iRet) {
        case MA_ACTIVATE:
        case MA_ACTIVATEANDEAT:
            /*
             * Activate the window without bring it to the top.
             * LATER: GerardoB
             * What about an option that would do the window tracking
             *  bringing the window to the top? As easy as not passing
             *  the *_NOZORDER flag  (I guess...)
             */
            if (pq == gpqForeground) {
                fSuccess = xxxActivateThisWindow(pwndActivate, 0, ATW_NOZORDER);
            } else {
                fSuccess = xxxSetForegroundWindow2(pwndActivate, NULL, SFW_SWITCH | SFW_NOZORDER);
            }

            /*
             * Eat the message if activation failed.
             */
            if (!fSuccess) {
                iRet = MA_SKIP;
            } else if (iRet == MA_ACTIVATEANDEAT) {
               iRet = MA_SKIP;
            }
            break;

        case MA_NOACTIVATEANDEAT:
            iRet = MA_SKIP;
            break;


        case MA_NOACTIVATE:
        default:
            iRet = MA_PASSTHRU;
            break;
    }

    if (pwnd != pwndActivate) {
        ThreadUnlock(&tlpwndActivate);
    }

    return iRet;

}
