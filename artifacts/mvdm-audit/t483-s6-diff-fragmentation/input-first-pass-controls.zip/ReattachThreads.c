/****************************** Module Header ******************************\
* Module Name: input.c
*
* Copyright (c) 1985-91, Microsoft Corporation
*
* This module contains the core functions of the input sub-system
*
* History:
* 10-18-90 DavidPe      Created.
* 02-14-91 mikeke       Added Revalidation code
\***************************************************************************/

#include "wow_input_group_bindings.h"
#pragma hdrstop

//#define MARKPATH
#ifdef MARKPATH
#error
#endif


#line 22
#ifdef TRACESYSPEEK // is defined in userk.h
#error
#line 56
#endif //TRACESYSPEEK

#line 58
#if DBG
#error
#line 84
#endif  // DBG

int LangToggleKeyState = 0;

PVOID KeyStateLookasideBase;
PVOID KeyStateLookasideBounds;
#line 91
#if DBG
#error
#line 97
#endif // DBG

#define CANCEL_ACTIVESTATE  0
#define CANCEL_FOCUSSTATE   1
#define CANCEL_CAPTURESTATE 2

#define KEYSTATESIZE    (CBKEYSTATE + CBKEYSTATERECENTDOWN)


/*
 * xxxGetNextSysMsg return values
 */
#define PQMSG_PLAYBACK       ((PQMSG)1)
#line 238
#ifdef MARKPATH
#error
#line 243
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif
#line 1154
#ifdef SYSMODALWINDOWS
#error
#line 1181
#endif //LATER
#line 1409
#if 0
#error
#line 1430
#endif
#line 1641
#if DBG
#error
#endif // DBG
#line 1647
#if DBG
#error
#line 1653
#endif // DBG
#line 1669
#if DBG
#error
#endif // DBG
#line 1679
#if DBG
#error
#endif // DBG
#line 1764
#if (CBKEYSTATERECENTDOWN % 4) != 0
#error "CBKEYSTATERECENTDOWN assumed to be an integral number of DWORDs"
#endif
#line 2295
#ifdef NEVER
#error
#line 2309
#endif
#line 2924
#ifdef TRACESYSPEEK
#error
#endif

#line 2928
#ifdef DEBUG
#error
#line 2949
#endif
#line 2957
#ifdef DEBUG
#error
#line 2964
#endif
#line 2971
#ifdef DEBUG
#error
#endif
#line 3188
#if DBG
#error
#line 3230
#endif  // DBG
#line 3307
#ifdef FE_IME
#error
#endif
#ifdef MARKPATH
#error
#line 3320
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif
#line 4551
#ifdef FE_IME
#error
#line 4575
#endif
#line 4750
#ifdef FE_IME
#error
#line 4757
#else
#line 4759
#endif
#line 4764
#if DBG
#error
#line 4767
#endif  // DBG
#line 4991
/***************************************************************************\
* RecalcThreadAttachment
* Recalc2
* AddAttachment
* CheckAttachment
*
* Runs through all the attachinfo fields for all threads and calculates
* which threads share which queues. Puts calculated result in pqAttach
* field in each threadinfo structure. This is a difficult problem
* whose only solution in iterative. The basic algorithm is:
*
* 0. Find next unattached thread and attach a queue to it. If none, stop.
* 1. Loop through all threads: If thread X assigned to this queue or any
*    of X's attach requests assigned to this queue, assign X and all X's
*    attachments to this queue. Remember if we ever attach a 16 bit thread.
* 2. If thread X is a 16 bit thread and we've already attached another
*    16 bit thread, assign X and all X's attachments to this queue.
* 3. If any change found in 1-2, goto 1
* 4. Goto 0
*
* 12-11-92 ScottLu      Created.
* 01-Oct-1993 mikeke    Fixed to work with MWOWs
\***************************************************************************/

void AddAttachment(
    PTHREADINFO pti,
    PQ pqAttach,
    LPBOOL pfChanged)
{
    if (pti->pqAttach != pqAttach) {
        /*
         * LATER
         * !!! This is totally screwed up,  The only reason that this thing
         * could be non null is because two threads are going through
         * attachthreadintput() at the same time.  No one can predict
         * what kind of problems are going to be caused by that.
         * We leave the critical section in one place where we send
         * WM_CANCELMODE below.  We should figure out how to remove
         * the sendmessage.
         *
         * If there already is a queue there, as there may be, destroy it.
         * Note that DestroyQueue() will only get rid of the queue if the
         * thread reference count goes to 0.
         */
        PQ pqDestroy = pti->pqAttach;
        pti->pqAttach = pqAttach;
        if (pqDestroy != NULL)
            DestroyQueue(pqDestroy, pti);
        pqAttach->cThreads++;
        *pfChanged = TRUE;
    }
}

void Recalc2(
    PQ pqAttach,
    PTHREADINFO ptiCurrent)
#line 5046
{
    PATTACHINFO pai;
    PTHREADINFO pti;
    BOOL fChanged;
    PLIST_ENTRY pHead, pEntry;

    /*
     * Keep adding attachments until everything that should be attached to this
     * queue is attached
     */
    do {
        fChanged = FALSE;

        /*
         * If a thread is attached to this Q attach all of it's attachments
         * and MWOW buddies if they aren't already attached.
         */
        pHead = &PtiCurrent()->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if (pti->pqAttach == pqAttach) {
                /*
                 * check each of the attachments to see if this thread is attached
                 * to any other threads
                 */
                for (pai = gpai; pai != NULL; pai = pai->paiNext) {
                    /*
                     * if they weren't attached already, attach them
                     */
                    if (pai->pti1 == pti || pai->pti2 == pti) {
                        AddAttachment(
                                (pai->pti1 == pti) ? pai->pti2 : pai->pti1,
                                pqAttach,
                                &fChanged);
                    }
                }

                /*
                 * If this is a 16bit thread attach to all other threads in
                 * it's MWOW
                 */
                if (pti->TIF_flags & TIF_16BIT) {
                    PTHREADINFO ptiAttach;
                    PLIST_ENTRY pHeadAttach, pEntryAttach;

                    pHeadAttach = &pti->rpdesk->PtiList;
                    for (pEntryAttach = pHeadAttach->Flink;
                            pEntryAttach != pHeadAttach;
                            pEntryAttach = pEntryAttach->Flink) {
                        ptiAttach = CONTAINING_RECORD(pEntryAttach, THREADINFO, PtiLink);

                        if (ptiAttach->TIF_flags & TIF_16BIT &&
                            ptiAttach->ppi == pti->ppi) {
                            AddAttachment(ptiAttach, pqAttach, &fChanged);
                        }
                    }
                }
            }
        }
    } while (fChanged);
}
#line 5295
#if DBG
#error
#line 5299
#endif
#line 5316
#if DBG
#error
#line 5320
#endif

#line 5701
BOOL ReattachThreads(
    BOOL fJournalAttach)
{
    PTHREADINFO ptiCurrent = PtiCurrent();
    PTHREADINFO pti;
    PQ          pqForegroundPrevNew;
    PQ          pqForegroundNew;
    PQ          pqAttach;
    PQ          pqJournal;
    PLIST_ENTRY pHead, pEntry;

    /*
     * In all cases, do not leave do any send messages or any callbacks!
     * This is because this code is called from
     * SetWindowsHook(WH_JOURNALPLAYBACK | WH_JOURNALRECORD). No app currently
     * calling this routine expects to be called before this routine returns.
     * (If you do callback before it returns, you'll break at least Access
     * for Windows). - scottlu
     */

    /*
     * Don't recalc attach info if this is a journal attach, because
     * the journal attach code has already done this for us.
     */
    if (!fJournalAttach) {

        /*
         * Now recalculate all the different queue groups, based on the
         * attach requests. This fills in the pqAttach of each thread info
         * with the new queue this thread belongs to. Always takes into
         * account all attachment requests.
         */
        RecalcThreadAttachment();

        /*
         * Make a guess about which queue is the journal queue.
         */
        pqJournal = gpqForeground;
        if (pqJournal == NULL)
            pqJournal = ptiCurrent->pq;

        /*
         * If the queue is only used by one thread, perform normal processing.
         */
        if (pqJournal->cThreads == 1) {
            pqJournal = NULL;
        } else {

            /*
             * Lock the queue to ensure that it stays valid
             * until we have redistributed the input.
             */
            (pqJournal->cLockCount)++;
        }
    } else {
        pqJournal = NULL;
    }

    /*
     * What will be the new foreground queue?
     */
    pqForegroundNew = NULL;
    if (gpqForeground != NULL && gpqForeground->spwndActive != NULL) {
        pqForegroundNew = GETPTI(gpqForeground->spwndActive)->pqAttach;
    }

    pqForegroundPrevNew = NULL;
    if (gpqForegroundPrev != NULL && gpqForegroundPrev->spwndActivePrev != NULL) {
        pqForegroundPrevNew = GETPTI(gpqForegroundPrev->spwndActivePrev)->pqAttach;
    }

    while (TRUE) {
        /*
         * We need to leave the critical section in this code, so just
         * find the next threadinfo to attach, then leave the loop before
         * leaving the critical section.
         */
        pHead = &ptiCurrent->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if(pti->pqAttach == pti->pq) {
                pti->pqAttach = NULL;
            }
            else if(pti->pqAttach != NULL) {
                break;
            }

        }

        /*
         * If all threads have been attached, we're all done!
         */
        if (pEntry == pHead)
            break;

        /*
         * It is crucial that we NULL out pqAttach for this queue once
         * we have it in a local variable because the NULL-ness of this
         * field is checked in attach operations.
         */
        pqAttach = pti->pqAttach;
        pti->pqAttach = NULL;

        AttachToQueue(pti, pqAttach, pqJournal, pqForegroundNew == pqAttach);
    }

    /*
     * If we are doing a journal detach, redistribute the input messages
     * from the old queue.
     */
    if (pqJournal != NULL) {
        PQMSG pqmsgRedist;

        UserAssert(pqJournal->cLockCount);
        (pqJournal->cLockCount)--;
        pqmsgRedist = pqJournal->mlInput.pqmsgRead;

        pqJournal->mlInput.pqmsgRead      = NULL;
        pqJournal->mlInput.pqmsgWriteLast = NULL;
        pqJournal->mlInput.cMsgs          = 0;
        RedistributeInput(pqmsgRedist, pqJournal);

        /*
         * Only destroy the queue if it is no longer is use.
         */
        if (pqJournal->cThreads == 0) {
            pqJournal->cThreads = 1;    // prevent underflow
            DestroyQueue(pqJournal, pti);
        }
    }

    /*
     * If the current thread is not on the active desktop, do not
     * change the global foreground state.
     */
    if (PtiCurrent()->rpdesk != grpdeskRitInput)
        return TRUE;

    /*
     * We're done attaching. gptiForeground hasn't changed... but
     * gpqForeground has!  Try not to leave NULL as the foreground.
     */
    gpqForeground = pqForegroundNew;
    gpqForegroundPrev = pqForegroundPrevNew;

    if (gpqForeground == NULL) {
        PWND pwndNewForeground;
        PTHREADINFO pti = PtiCurrent();

        pwndNewForeground = _GetNextQueueWindow(pti->rpdesk->pDeskInfo->spwnd->spwndChild, 0, FALSE);

        /*
         * Don't use xxxSetForegroundWindow2 because we must not leave
         * the critical section.  There is no currently active foreground
         * so all that is needed is to post an activate event to the
         * new foreground queue.
         */
        if (pwndNewForeground != NULL) {
            PostEventMessage(GETPTI(pwndNewForeground),
                    GETPTI(pwndNewForeground)->pq,QEVENT_ACTIVATE, NULL, 0,
                    0 , (DWORD)HWq(pwndNewForeground));
        }
    }

    SetFMouseMoved();

    return TRUE;
}
