/****************************** Module Header ******************************\
* Module Name: input.c
*
* Copyright (c) 1985-91, Microsoft Corporation
*
* This module contains the core functions of the input sub-system
*
* History:
* 10-18-90 DavidPe      Created.
* 02-14-91 mikeke       Added Revalidation code
\***************************************************************************/

#include "wow_input_group_bindings.h"
#pragma hdrstop

//#define MARKPATH
#ifdef MARKPATH
#error
#endif


#line 22
#ifdef TRACESYSPEEK // is defined in userk.h
#error
#line 56
#endif //TRACESYSPEEK

#line 58
#if DBG
#error
#line 84
#endif  // DBG

int LangToggleKeyState = 0;

PVOID KeyStateLookasideBase;
PVOID KeyStateLookasideBounds;
#line 91
#if DBG
#error
#line 97
#endif // DBG

#define CANCEL_ACTIVESTATE  0
#define CANCEL_FOCUSSTATE   1
#define CANCEL_CAPTURESTATE 2

#define KEYSTATESIZE    (CBKEYSTATE + CBKEYSTATERECENTDOWN)


/*
 * xxxGetNextSysMsg return values
 */
#define PQMSG_PLAYBACK       ((PQMSG)1)
#line 238
#ifdef MARKPATH
#error
#line 243
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif
#line 1154
#ifdef SYSMODALWINDOWS
#error
#line 1181
#endif //LATER
#line 1409
#if 0
#error
#line 1430
#endif
#line 1641
#if DBG
#error
#endif // DBG
#line 1647
#if DBG
#error
#line 1653
#endif // DBG
#line 1669
#if DBG
#error
#endif // DBG
#line 1679
#if DBG
#error
#endif // DBG
#line 1764
#if (CBKEYSTATERECENTDOWN % 4) != 0
#error "CBKEYSTATERECENTDOWN assumed to be an integral number of DWORDs"
#endif
#line 2295
#ifdef NEVER
#error
#line 2309
#endif
#line 2924
#ifdef TRACESYSPEEK
#error
#endif

#line 2928
#ifdef DEBUG
#error
#line 2949
#endif
#line 2957
#ifdef DEBUG
#error
#line 2964
#endif
#line 2971
#ifdef DEBUG
#error
#endif
#line 3188
#if DBG
#error
#line 3230
#endif  // DBG
#line 3307
#ifdef FE_IME
#error
#endif
#ifdef MARKPATH
#error
#line 3320
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif
#line 4551
#ifdef FE_IME
#error
#line 4575
#endif
#line 4750
#ifdef FE_IME
#error
#line 4757
#else
#line 4759
#endif
#line 4764
#if DBG
#error
#line 4767
#endif  // DBG
#line 4991
/***************************************************************************\
* RecalcThreadAttachment
* Recalc2
* AddAttachment
* CheckAttachment
*
* Runs through all the attachinfo fields for all threads and calculates
* which threads share which queues. Puts calculated result in pqAttach
* field in each threadinfo structure. This is a difficult problem
* whose only solution in iterative. The basic algorithm is:
*
* 0. Find next unattached thread and attach a queue to it. If none, stop.
* 1. Loop through all threads: If thread X assigned to this queue or any
*    of X's attach requests assigned to this queue, assign X and all X's
*    attachments to this queue. Remember if we ever attach a 16 bit thread.
* 2. If thread X is a 16 bit thread and we've already attached another
*    16 bit thread, assign X and all X's attachments to this queue.
* 3. If any change found in 1-2, goto 1
* 4. Goto 0
*
* 12-11-92 ScottLu      Created.
* 01-Oct-1993 mikeke    Fixed to work with MWOWs
\***************************************************************************/

void AddAttachment(
    PTHREADINFO pti,
    PQ pqAttach,
    LPBOOL pfChanged)
{
    if (pti->pqAttach != pqAttach) {
        /*
         * LATER
         * !!! This is totally screwed up,  The only reason that this thing
         * could be non null is because two threads are going through
         * attachthreadintput() at the same time.  No one can predict
         * what kind of problems are going to be caused by that.
         * We leave the critical section in one place where we send
         * WM_CANCELMODE below.  We should figure out how to remove
         * the sendmessage.
         *
         * If there already is a queue there, as there may be, destroy it.
         * Note that DestroyQueue() will only get rid of the queue if the
         * thread reference count goes to 0.
         */
        PQ pqDestroy = pti->pqAttach;
        pti->pqAttach = pqAttach;
        if (pqDestroy != NULL)
            DestroyQueue(pqDestroy, pti);
        pqAttach->cThreads++;
        *pfChanged = TRUE;
    }
}

void Recalc2(
    PQ pqAttach,
    PTHREADINFO ptiCurrent)
#line 5046
{
    PATTACHINFO pai;
    PTHREADINFO pti;
    BOOL fChanged;
    PLIST_ENTRY pHead, pEntry;

    /*
     * Keep adding attachments until everything that should be attached to this
     * queue is attached
     */
    do {
        fChanged = FALSE;

        /*
         * If a thread is attached to this Q attach all of it's attachments
         * and MWOW buddies if they aren't already attached.
         */
        pHead = &PtiCurrent()->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if (pti->pqAttach == pqAttach) {
                /*
                 * check each of the attachments to see if this thread is attached
                 * to any other threads
                 */
                for (pai = gpai; pai != NULL; pai = pai->paiNext) {
                    /*
                     * if they weren't attached already, attach them
                     */
                    if (pai->pti1 == pti || pai->pti2 == pti) {
                        AddAttachment(
                                (pai->pti1 == pti) ? pai->pti2 : pai->pti1,
                                pqAttach,
                                &fChanged);
                    }
                }

                /*
                 * If this is a 16bit thread attach to all other threads in
                 * it's MWOW
                 */
                if (pti->TIF_flags & TIF_16BIT) {
                    PTHREADINFO ptiAttach;
                    PLIST_ENTRY pHeadAttach, pEntryAttach;

                    pHeadAttach = &pti->rpdesk->PtiList;
                    for (pEntryAttach = pHeadAttach->Flink;
                            pEntryAttach != pHeadAttach;
                            pEntryAttach = pEntryAttach->Flink) {
                        ptiAttach = CONTAINING_RECORD(pEntryAttach, THREADINFO, PtiLink);

                        if (ptiAttach->TIF_flags & TIF_16BIT &&
                            ptiAttach->ppi == pti->ppi) {
                            AddAttachment(ptiAttach, pqAttach, &fChanged);
                        }
                    }
                }
            }
        }
    } while (fChanged);
}
#line 5295
#if DBG
#error
#line 5299
#endif
#line 5316
#if DBG
#error
#line 5320
#endif

#line 2864
void xxxSkipSysMsg(
    PTHREADINFO pti,
    PQMSG pqmsg)
{
    PQMSG pqmsgT;
    BOOL  fDown;
    BYTE  vk;

    /*
     * If idSysPeek is 0, then the pqmsg that we were looking at has been
     * deleted, probably because of a callout from ScanSysQueue, and that
     * callout then called PeekMessage(fRemove == TRUE), and then returned.
     */
    if (pti->pq->idSysPeek == 0)
        return;

    if (pti->pDeskInfo->asphkStart[WH_JOURNALPLAYBACK + 1] != NULL) {
        /*
         * Tell the journal playback hook that we're done
         * with this message now.
         */
        PHOOK phk = PhkFirst(PtiCurrent(), WH_JOURNALPLAYBACK);
        UserAssert(phk);

        phk->flags |= HF_NEEDHC_SKIP;
    } else {
        if (pti->pDeskInfo->asphkStart[WH_JOURNALRECORD + 1] != NULL) {
            /*
             * We've processed a new message: tell the journal record
             * hook what the message is.
             */
            xxxCallJournalRecordHook(pqmsg);
        }

        /*
         * If idSysPeek is 0 now, it means we've been recursed into yet
         * again. This would confuse a journalling app, but it would confuse
         * us more because we'd fault. Return if idSysPeek is 0.
         */
        if ((pqmsgT = (PQMSG)pti->pq->idSysPeek) == NULL)
            return;

        /*
         * Delete this message from the input queue. Make sure pqmsgT isn't
         * 1: this could happen if an app unhooked a journal record hook
         * during a callback from xxxScanSysQueue.
         */
        if (pqmsgT != PQMSG_PLAYBACK) {
            /*
             * There are cases when idSysPeek points to a different message
             * than the one we are trying to remove. This can happen if
             * two threads enters in xxxScanSysQueue, sets the idSysPeek and
             * after this their queues got redistributed. The first thread
             * will have the idSysPeek preserved but the second one has to
             * search the queue for its message. - ask CLupu
             */
            if (!EqualMsg(pqmsgT, pqmsg)) {

                PQMSG pqmsgS;

#ifdef TRACESYSPEEK
                gnSysPeekSearch++;
#endif

#ifdef DEBUG
                KdPrint((
                        "\nDifferent message than idSysPeek\n\n"
                        "pqmsg   = %08lx  idSysPeek = %08lx\n"
                        "pti     = %08lx  pti       = %08lx\n"
                        "msg     = %08lx  msg       = %08lx\n"
                        "hwnd    = %08lx  hwnd      = %08lx\n"
                        "wParam  = %08lx  wParam    = %08lx\n"
                        "lParam  = %08lx  lParam    = %08lx\n"
                        "time    = %08lx  time      = %08lx\n"
                        "Extra   = %08lx  Extra     = %08lx\n"
                        "\npqmsgT  = %08lx\n\n",
                        pqmsg,              pqmsgT,
                        pqmsg->pti,         pqmsgT->pti,
                        pqmsg->msg.message, pqmsgT->msg.message,
                        pqmsg->msg.hwnd,    pqmsgT->msg.hwnd,
                        pqmsg->msg.wParam,  pqmsgT->msg.wParam,
                        pqmsg->msg.lParam,  pqmsgT->msg.lParam,
                        pqmsg->msg.time,    pqmsgT->msg.time,
                        pqmsg->ExtraInfo,   pqmsgT->ExtraInfo,
                        pqmsgT));
#endif
                /*
                 * Begin to search for this message
                 */
                pqmsgS = pti->pq->mlInput.pqmsgRead;

                while (pqmsgS != NULL) {
                    if (EqualMsg(pqmsgS, pqmsg)) {
#ifdef DEBUG
                        KdPrint(("Deleting pqmsg %lx, pti %lx\n",
                               pqmsgS, pqmsgS->pti));

                        KdPrint(("m %04lx, w %lx, l %lx, t %lx\n",
                               pqmsgS->msg.message, pqmsgS->msg.hwnd,
                               pqmsgS->msg.lParam, pqmsgS->msg.time));
#endif
                        pqmsgT = pqmsgS;
                        break;
                    }
                    pqmsgS = pqmsgS->pqmsgNext;
                }
                if (pqmsgS == NULL) {
#ifdef DEBUG
                    KdPrint(("Didn't find a matching message. No message removed\n"));
#endif
                    return;
                }
            }

            if (pqmsgT == (PQMSG)pti->pq->idSysPeek) {
                /*
                 * We'll remove this message from the input queue
                 * so set idSysPeek to 0.
                 */
                CheckPtiSysPeek(1, pti->pq, 0);
                pti->pq->idSysPeek = 0;
            }
            DelQEntry(&pti->pq->mlInput, pqmsgT);
        }
    }

    fDown = TRUE;
    vk = 0;

    switch (pqmsg->msg.message) {
    case WM_MOUSEMOVE:
    case WM_QUEUESYNC:
    default:
        /*
         * No state change.
         */
        break;

    case WM_KEYUP:
    case WM_SYSKEYUP:
        fDown = FALSE;

        /*
         * Fall through.
         */
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
        vk = LOBYTE(LOWORD(pqmsg->msg.wParam));
        break;

    case WM_LBUTTONUP:
        fDown = FALSE;

        /*
         * Fall through.
         */
    case WM_LBUTTONDOWN:
        vk = VK_LBUTTON;
        break;

    case WM_RBUTTONUP:
        fDown = FALSE;

        /*
         * Fall through.
         */
    case WM_RBUTTONDOWN:
        vk = VK_RBUTTON;
        break;

    case WM_MBUTTONUP:
        fDown = FALSE;

        /*
         * Fall through.
         */
    case WM_MBUTTONDOWN:
        vk = VK_MBUTTON;
        break;
    }

    /*
     * Set toggle and down bits appropriately.
     */
    if ((vk == VK_SHIFT) || (vk == VK_MENU) || (vk == VK_CONTROL)) {
        BYTE vkHanded, vkOtherHand;
        /*
         * Convert this virtual key into a differentiated (Left/Right) key
         * depending on the extended key bit.
         */
        vkHanded = (vk - VK_SHIFT) * 2 + VK_LSHIFT +
                ((pqmsg->msg.lParam & EXTENDED_BIT) ? 1 : 0);
        vkOtherHand = vkHanded ^ 1;

        if (vk == VK_SHIFT) {
            /*
             * Clear extended bit for r.h. Shift, since it isn't really
             * extended (bit was set to indicate right-handed)
             */
            pqmsg->msg.lParam &= ~EXTENDED_BIT;
        }

        /*
         * Update the key state for the differentiated (Left/Right) key.
         */
        UpdateKeyState(pti->pq, vkHanded, fDown);

        /*
         * Update key state for the undifferentiated (logical) key.
         */
        if (fDown || !TestKeyStateDown(pti->pq, vkOtherHand)) {
            UpdateKeyState(pti->pq, vk, fDown);
        }
    } else {
        UpdateKeyState(pti->pq, vk, fDown);
    }
}
