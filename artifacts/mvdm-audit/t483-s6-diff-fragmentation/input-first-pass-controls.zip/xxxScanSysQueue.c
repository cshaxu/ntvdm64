/****************************** Module Header ******************************\
* Module Name: input.c
*
* Copyright (c) 1985-91, Microsoft Corporation
*
* This module contains the core functions of the input sub-system
*
* History:
* 10-18-90 DavidPe      Created.
* 02-14-91 mikeke       Added Revalidation code
\***************************************************************************/

#include "wow_input_group_bindings.h"
#pragma hdrstop

//#define MARKPATH
#ifdef MARKPATH
#error
#endif


#line 22
#ifdef TRACESYSPEEK // is defined in userk.h
#error
#line 56
#endif //TRACESYSPEEK

#line 58
#if DBG
#error
#line 84
#endif  // DBG

int LangToggleKeyState = 0;

PVOID KeyStateLookasideBase;
PVOID KeyStateLookasideBounds;
#line 91
#if DBG
#error
#line 97
#endif // DBG

#define CANCEL_ACTIVESTATE  0
#define CANCEL_FOCUSSTATE   1
#define CANCEL_CAPTURESTATE 2

#define KEYSTATESIZE    (CBKEYSTATE + CBKEYSTATERECENTDOWN)


/*
 * xxxGetNextSysMsg return values
 */
#define PQMSG_PLAYBACK       ((PQMSG)1)
#line 238
#ifdef MARKPATH
#error
#line 243
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif
#line 1154
#ifdef SYSMODALWINDOWS
#error
#line 1181
#endif //LATER
#line 1409
#if 0
#error
#line 1430
#endif
#line 1641
#if DBG
#error
#endif // DBG
#line 1647
#if DBG
#error
#line 1653
#endif // DBG
#line 1669
#if DBG
#error
#endif // DBG
#line 1679
#if DBG
#error
#endif // DBG
#line 1764
#if (CBKEYSTATERECENTDOWN % 4) != 0
#error "CBKEYSTATERECENTDOWN assumed to be an integral number of DWORDs"
#endif
#line 2295
#ifdef NEVER
#error
#line 2309
#endif
#line 2924
#ifdef TRACESYSPEEK
#error
#endif

#line 2928
#ifdef DEBUG
#error
#line 2949
#endif
#line 2957
#ifdef DEBUG
#error
#line 2964
#endif
#line 2971
#ifdef DEBUG
#error
#endif
#line 3188
#if DBG
#error
#line 3230
#endif  // DBG
#line 3307
#ifdef FE_IME
#error
#endif
#ifdef MARKPATH
#error
#line 3320
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif
#line 4551
#ifdef FE_IME
#error
#line 4575
#endif
#line 4750
#ifdef FE_IME
#error
#line 4757
#else
#line 4759
#endif
#line 4764
#if DBG
#error
#line 4767
#endif  // DBG
#line 4991
/***************************************************************************\
* RecalcThreadAttachment
* Recalc2
* AddAttachment
* CheckAttachment
*
* Runs through all the attachinfo fields for all threads and calculates
* which threads share which queues. Puts calculated result in pqAttach
* field in each threadinfo structure. This is a difficult problem
* whose only solution in iterative. The basic algorithm is:
*
* 0. Find next unattached thread and attach a queue to it. If none, stop.
* 1. Loop through all threads: If thread X assigned to this queue or any
*    of X's attach requests assigned to this queue, assign X and all X's
*    attachments to this queue. Remember if we ever attach a 16 bit thread.
* 2. If thread X is a 16 bit thread and we've already attached another
*    16 bit thread, assign X and all X's attachments to this queue.
* 3. If any change found in 1-2, goto 1
* 4. Goto 0
*
* 12-11-92 ScottLu      Created.
* 01-Oct-1993 mikeke    Fixed to work with MWOWs
\***************************************************************************/

void AddAttachment(
    PTHREADINFO pti,
    PQ pqAttach,
    LPBOOL pfChanged)
{
    if (pti->pqAttach != pqAttach) {
        /*
         * LATER
         * !!! This is totally screwed up,  The only reason that this thing
         * could be non null is because two threads are going through
         * attachthreadintput() at the same time.  No one can predict
         * what kind of problems are going to be caused by that.
         * We leave the critical section in one place where we send
         * WM_CANCELMODE below.  We should figure out how to remove
         * the sendmessage.
         *
         * If there already is a queue there, as there may be, destroy it.
         * Note that DestroyQueue() will only get rid of the queue if the
         * thread reference count goes to 0.
         */
        PQ pqDestroy = pti->pqAttach;
        pti->pqAttach = pqAttach;
        if (pqDestroy != NULL)
            DestroyQueue(pqDestroy, pti);
        pqAttach->cThreads++;
        *pfChanged = TRUE;
    }
}

void Recalc2(
    PQ pqAttach,
    PTHREADINFO ptiCurrent)
#line 5046
{
    PATTACHINFO pai;
    PTHREADINFO pti;
    BOOL fChanged;
    PLIST_ENTRY pHead, pEntry;

    /*
     * Keep adding attachments until everything that should be attached to this
     * queue is attached
     */
    do {
        fChanged = FALSE;

        /*
         * If a thread is attached to this Q attach all of it's attachments
         * and MWOW buddies if they aren't already attached.
         */
        pHead = &PtiCurrent()->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if (pti->pqAttach == pqAttach) {
                /*
                 * check each of the attachments to see if this thread is attached
                 * to any other threads
                 */
                for (pai = gpai; pai != NULL; pai = pai->paiNext) {
                    /*
                     * if they weren't attached already, attach them
                     */
                    if (pai->pti1 == pti || pai->pti2 == pti) {
                        AddAttachment(
                                (pai->pti1 == pti) ? pai->pti2 : pai->pti1,
                                pqAttach,
                                &fChanged);
                    }
                }

                /*
                 * If this is a 16bit thread attach to all other threads in
                 * it's MWOW
                 */
                if (pti->TIF_flags & TIF_16BIT) {
                    PTHREADINFO ptiAttach;
                    PLIST_ENTRY pHeadAttach, pEntryAttach;

                    pHeadAttach = &pti->rpdesk->PtiList;
                    for (pEntryAttach = pHeadAttach->Flink;
                            pEntryAttach != pHeadAttach;
                            pEntryAttach = pEntryAttach->Flink) {
                        ptiAttach = CONTAINING_RECORD(pEntryAttach, THREADINFO, PtiLink);

                        if (ptiAttach->TIF_flags & TIF_16BIT &&
                            ptiAttach->ppi == pti->ppi) {
                            AddAttachment(ptiAttach, pqAttach, &fChanged);
                        }
                    }
                }
            }
        }
    } while (fChanged);
}
#line 5295
#if DBG
#error
#line 5299
#endif
#line 5316
#if DBG
#error
#line 5320
#endif

#line 3275
BOOL xxxScanSysQueue(
    PTHREADINFO ptiCurrent,
    LPMSG lpMsg,
    PWND pwndFilter,
    UINT msgMinFilter,
    UINT msgMaxFilter,
    DWORD flags,
    DWORD fsReason)
{
    QMSG qmsg;
    HWND hwnd;
    PWND pwnd;
    UINT message;
    UINT wParam;
    LONG lParam;
    PTHREADINFO ptiKeyWake, ptiMouseWake, ptiEventWake;
    POINT pt;
    UINT codeMouseDown;
    BOOL fMouseHookCalled;
    BOOL fKbdHookCalled;
    BOOL fOtherApp;
    int part;
    MOUSEHOOKSTRUCT mhs;
    PWND pwndT;
    BOOL fPrevDown;
    BOOL fDown;
    BOOL fAlt;
    UINT key;
    TL tlpwnd;
    TL tlpwndT;
    BOOL fRemove = (flags & PM_REMOVE);
    PWND pwndMouse;
#ifdef FE_IME
    DWORD dwImmRet = 0;
#endif
#ifdef MARKPATH
    DWORD pathTaken = 0;
    DWORD pathTaken2 = 0;
    DWORD pathTaken3 = 0;

#define PATHTAKEN(x)  pathTaken  |= x
#define PATHTAKEN2(x) pathTaken2 |= x
#define PATHTAKEN3(x) pathTaken3 |= x
#define DUMPPATHTAKEN() if (gfMarkPath) DbgPrint("xxxScanSysQueue path:%08x %08x %08x\n", pathTaken, pathTaken2, pathTaken3)
#define DUMPSUBPATHTAKEN(p, x) if (gfMarkPath && p & x) { DbgPrint("  %08x %08x %08x\n", pathTaken, pathTaken2, pathTaken3); pathTaken = pathTaken2 = pathTaken3 = 0; }
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif

    UserAssert((fsReason & ~(QS_EVENT | QS_INPUT)) == 0 &&
               (fsReason & (QS_EVENT | QS_INPUT)) != 0);

    /*
     * If we are looking at a peeked message currently (recursion into this
     * routine) and the only reason we got here was because of an event
     * message (an app was filtering for a non-input message), then just
     * return so we don't screw up idSysPeek. If we do enter this code
     * idSysPeek will get set back to 0, and when we return back into
     * the previous xxxScanSysQueue(), SkipSysMsg() will do nothing, so the
     * message won't get removed. (MS Publisher 2.0 does this).
     */
    if (fsReason == QS_EVENT) {
        if (ptiCurrent->pq->idSysPeek != 0) {
            PATHTAKEN(1);
            DUMPPATHTAKEN();
            return FALSE;
        }
    }

    fDown = FALSE;
    fMouseHookCalled = FALSE;
    fKbdHookCalled = FALSE;

    /*
     * Lock the queue if it's currently unlocked.
     */
    if (ptiCurrent->pq->ptiSysLock == NULL) {
        CheckSysLock(3, ptiCurrent->pq, ptiCurrent);
        ptiCurrent->pq->ptiSysLock = ptiCurrent;
        ptiCurrent->pcti->CTIF_flags |= CTIF_SYSQUEUELOCKED;
    }

    /*
     * Flag to tell if locker was removing messages. If not, then next time
     * Get/PeekMessage is called, the input message list is scanned before the
     * post msg list.
     *
     * Under Win3.1, this flag only gets modified for key and mouse messages.
     * Since under NT ScanSysQueue() can be called to execute event messages,
     * we make this check to be compatible.
     */
    if (fsReason & QS_INPUT) {
        if (fRemove) {
            PATHTAKEN(2);
            ptiCurrent->pq->QF_flags &= ~QF_LOCKNOREMOVE;
        } else {
            PATHTAKEN(4);
            ptiCurrent->pq->QF_flags |= QF_LOCKNOREMOVE;
        }
    }

    /*
     * Return FALSE if the current thread is not the one that lock this queue.
     */
    if (ptiCurrent->pq->ptiSysLock != ptiCurrent) {
        PATHTAKEN(8);
        DUMPPATHTAKEN();
        return FALSE;
    }

    ptiEventWake = ptiKeyWake = ptiMouseWake = NULL;

    /*
     * Initialize the thread lock structure here so we can unlock/lock in
     * the main loop.
     */
    pwnd = NULL;
    ThreadLockWithPti(ptiCurrent, pwnd, &tlpwnd);

RestartScan:
    CheckPtiSysPeek(2, ptiCurrent->pq, 0);
    ptiCurrent->pq->idSysPeek = 0;

ContinueScan:
    while (TRUE) {
        DWORD idSysPeek;

        DUMPSUBPATHTAKEN(pathTaken, 0xf0);
        /*
         * Store idSysPeek in a local which forces pq to be reloaded
         * in case it changed during the xxx call (the compiler can
         * evaluate the LValue at any time)
         */
        idSysPeek = (DWORD)xxxGetNextSysMsg(ptiCurrent,
                (PQMSG)ptiCurrent->pq->idSysPeek, &qmsg);
        CheckPtiSysPeek(3, ptiCurrent->pq, idSysPeek);
        ptiCurrent->pq->idSysPeek = idSysPeek;

        if (ptiCurrent->pq->idSysPeek == 0) {
            /*
             * If we are only looking for event messages and we didn't
             * find any, then clear the QS_EVENT bit
             */
            if (fsReason == QS_EVENT)
                ClearWakeBit(ptiCurrent, QS_EVENT, FALSE);
            PATHTAKEN(0x10);
            goto NoMessages;
        }

        /*
         * pwnd should be locked for the duration of this routine.
         * For most messages right out of GetNextSysMsg, this is
         * NULL.
         */
        ThreadUnlock(&tlpwnd);
        pwnd = RevalidateHwnd(qmsg.msg.hwnd);
        ThreadLockWithPti(ptiCurrent, pwnd, &tlpwnd);

        /*
         * See if this is an event message. If so, execute it regardless
         * of message and window filters, but only if it is the first element
         * of the input queue.
         */
        if (qmsg.dwQEvent != 0) {
            PTHREADINFO pti;

            PATHTAKEN(0x20);
            /*
             * Most event messages can be executed out of order relative to
             * its place in the queue. There are some examples were this is
             * not allowed, and we check that here. For example, we would not
             * want a keystate synchronization event to be processed before
             * the keystrokes that came before it in the queue!
             *
             * We need to have most event messages be able to get processed
             * out of order because apps can be filtering for message ranges
             * that don't include input (like dde) - those scenarios still
             * need to process events such as deactivate event messages even
             * if there is input in the input queue.
             */
            switch (qmsg.dwQEvent) {
            case QEVENT_UPDATEKEYSTATE:
                /*
                 * If the message is not the next message in the queue, don't
                 * process it.
                 */
                if (ptiCurrent->pq->idSysPeek !=
                        (DWORD)ptiCurrent->pq->mlInput.pqmsgRead) {
                    PATHTAKEN(0x40);
                    continue;
                }
                break;
            }

            /*
             * If this event isn't for this thread, wake the thread it is
             * for.  A NULL qmsg.hti means that any thread can process
             * the event.
             */
            if (qmsg.pti != NULL && (pti = qmsg.pti) != ptiCurrent) {

                /*
                 * If somehow this event message got into the wrong queue,
                 * then ignore it.
                 */
                UserAssert(pti->pq == ptiCurrent->pq);
                if (pti->pq != ptiCurrent->pq) {
                    CleanEventMessage((PQMSG)ptiCurrent->pq->idSysPeek);
                    DelQEntry(&ptiCurrent->pq->mlInput,
                            (PQMSG)ptiCurrent->pq->idSysPeek);
                    PATHTAKEN(0x80);
                    goto RestartScan;
                }

                /*
                 * If ptiEventWake is already set, it means we've already
                 * found a thread to wake for event.
                 */
                if (ptiEventWake == NULL)
                    ptiEventWake = pti;

                /*
                 * Clear idSysPeek so that the targeted thread
                 * can always get it.  Look at the test at the
                 * start of this routine for more info.
                 */
                CheckPtiSysPeek(4, ptiCurrent->pq, 0);
                ptiCurrent->pq->idSysPeek = 0;
                PATHTAKEN(0x100);
                goto NoMessages;
            }

            /*
             * If this is called with PM_NOYIELD from a 16-bit app, skip
             * processing any event that can generate activation messages.  An
             * example is printing from PageMaker 5.0.  Bug #12662.
             */
            if ((flags & PM_NOYIELD) && (ptiCurrent->TIF_flags & TIF_16BIT)) {
                PATHTAKEN(0x200);
                switch (qmsg.dwQEvent) {

                /*
                 * The following events are safe to process if no yield
                 * is to occur.
                 */
                case QEVENT_UPDATEKEYSTATE:
                case QEVENT_ASYNCSENDMSG:
                    break;

                /*
                 * Skip all other events.
                 */
                default:
                    ptiCurrent->TIF_flags |= TIF_DELAYEDEVENT;
                    PATHTAKEN(0x400);
                    goto ContinueScan;
                }
            }

            /*
             * Delete this before it gets processed so there are no
             * recursion problems.
             */
            DelQEntry(&ptiCurrent->pq->mlInput,
                    (PQMSG)ptiCurrent->pq->idSysPeek);

            /*
             * Clear idSysPeek before processing any events messages, because
             * they may recurse and want to use idSysPeek.
             */
            CheckPtiSysPeek(5, ptiCurrent->pq, 0);
            ptiCurrent->pq->idSysPeek = 0;
            xxxProcessEventMessage(ptiCurrent, &qmsg);

            /*
             * Restart the scan from the start so we start with 0 in
             * pq->idSysPeek (since that message is now gone!).
             */
            PATHTAKEN(0x800);
            goto RestartScan;
        }

        /*
         * If the reason we called was just to process event messages, don't
         * enumerate any other mouse or key messages!
         */
        if (fsReason == QS_EVENT) {
            PATHTAKEN(0x1000);
            continue;
        }

        switch (message = qmsg.msg.message) {
        case WM_QUEUESYNC:
            PATHTAKEN(0x2000);
            /*
             * This message is for CBT. Its parameters should already be
             * set up correctly.
             */
            wParam = 0;
            lParam = qmsg.msg.lParam;

            /*
             * Check if this is intended for the current app. Use the mouse
             * bit for WM_QUEUESYNC.
             */
            if (pwnd != NULL && GETPTI(pwnd) != ptiCurrent) {
                /*
                 * If this other app isn't going to read from this
                 * queue, then skip this message. This can happen with
                 * WM_QUEUESYNC if the app passed a window handle
                 * to the wrong queue. This isn't likely to happen in
                 * this case because WM_QUEUESYNCs come in while journalling,
                 * which has all threads sharing the same queue.
                 */
                if (GETPTI(pwnd)->pq != ptiCurrent->pq) {
                    PATHTAKEN(0x4000);
                    goto SkipMessage;
                }

                if (ptiMouseWake == NULL)
                    ptiMouseWake = GETPTI(pwnd);
                PATHTAKEN(0x8000);
                goto NoMessages;
            }

            if (!CheckMsgFilter(message, msgMinFilter, msgMaxFilter)) {
                PATHTAKEN(0x10000);
                goto NoMessages;
            }

            /*
             * Eat the message.
             */
            if (fRemove) {
                xxxSkipSysMsg(ptiCurrent, &qmsg);
            }

            /*
             * !!HARDWARE HOOK!! goes here.
             */

            /*
             * Return the message.
             */
            PATHTAKEN(0x20000);
            goto ReturnMessage;
            break;

        /*
         * Mouse message or generic hardware messages
         * Key messages are handled in case statements
         * further down in this switch.
         */
        default:
ReprocessMsg:
            DUMPSUBPATHTAKEN(pathTaken, 0x40000);
            PATHTAKEN(0x40000);
            /*
             * !!GENERIC HARDWARE MESSAGE!! support goes here.
             */

            /*
             * Take the mouse position out of the message.
             */
            pt.x = (int)(short)LOWORD(qmsg.msg.lParam);
            pt.y = (int)(short)HIWORD(qmsg.msg.lParam);

            /*
             * Assume we have a capture.
             */
            part = HTCLIENT;

            /*
             * We have a special global we use for when we're full screen.
             * All mouse input will go to this window.
             */
            if (gspwndScreenCapture != NULL) {
                /*
                 * Change the mouse coordinates to full screen.
                 */
                pwnd = gspwndScreenCapture;
                lParam = MAKELONG((WORD)qmsg.msg.pt.x,
                        (WORD)qmsg.msg.pt.y);
                PATHTAKEN(0x80000);
            } else if ((pwnd = ptiCurrent->pq->spwndCapture) == NULL) {
                PATHTAKEN(0x100000);
                /*
                 * We don't have the capture. Figure out which window owns
                 * this message.
                 *
                 * NOTE: Use gptiRit and not ptiCurrent to get the desktop
                 * window because if ptiCurrent is the thread that created
                 * the main desktop, it's associated desktop is the logon
                 * desktop - don't want to hittest against the logon desktop
                 * while switched into the main desktop!
                 */
                pwndT = gptiRit->rpdesk->pDeskInfo->spwnd;
                ThreadLockWithPti(ptiCurrent, pwndT, &tlpwndT);
                hwnd = xxxWindowHitTest(pwndT, pt, &part, TRUE);
                ThreadUnlock(&tlpwndT);

                if ((pwnd = RevalidateHwnd(hwnd)) == NULL) {
                    pwnd = ptiCurrent->rpdesk->pDeskInfo->spwnd;
                    PATHTAKEN(0x200000);
                }

                if (part == HTCLIENT) {
                    /*
                     * Part of the client... normal mouse message.
                     * NO_CAP_CLIENT means "not captured, in client area
                     * of window".
                     */
                    ptiCurrent->pq->codeCapture = NO_CAP_CLIENT;
                    PATHTAKEN(0x400000);
                } else {
                    /*
                     * Not part of the client... must be an NCMOUSEMESSAGE.
                     * NO_CAP_SYS is a creative name by raor which means
                     * "not captured, in system area of window."
                     */
                    ptiCurrent->pq->codeCapture = NO_CAP_SYS;
                    PATHTAKEN(0x800000);
                }
            }

            /*
             * We've reassigned pwnd, so lock it.
             */
            ThreadUnlock(&tlpwnd);
            ThreadLockWithPti(ptiCurrent, pwnd, &tlpwnd);

            if (fOtherApp = (GETPTI(pwnd) != ptiCurrent)) {

                PATHTAKEN(0x1000000);
                /*
                 * If this other app isn't going to read from this
                 * queue, then skip this message. This can happen if
                 * the RIT queues up a message thinking it goes to
                 * a particular hwnd, but then by the time GetMessage()
                 * is called for that thread, it doesn't go to that hwnd
                 * (like in the case of mouse messages, window rearrangement
                 * happens which changes which hwnd the mouse hits on).
                 */
                if (GETPTI(pwnd)->pq != ptiCurrent->pq) {
                    _SetCursor(SYSCUR(ARROW));
                    ResetMouseTracking(ptiCurrent->pq, NULL);
                    PATHTAKEN(0x2000000);
                    goto SkipMessage;
                }

                /*
                 * If we haven't already found a message that is intended
                 * for another app, remember that we have one.
                 */
                if (ptiMouseWake == NULL) {
                    ptiMouseWake = GETPTI(pwnd);
                    PATHTAKEN(0x4000000);
                }
            }

            /*
             * Map mouse coordinates based on hit test area code.
             */
            switch (ptiCurrent->pq->codeCapture) {
            case CLIENT_CAPTURE:
            case NO_CAP_CLIENT:
                pt.x -= pwnd->rcClient.left;
                pt.y -= pwnd->rcClient.top;
                PATHTAKEN2(2);
                break;

            case WINDOW_CAPTURE:
                pt.x -= pwnd->rcWindow.left;
                pt.y -= pwnd->rcWindow.top;
                PATHTAKEN2(4);
                break;
            }

            /*
             * Do mouse hover processing.
             */
            pwndMouse = (part == HTCLIENT) ? pwnd : NULL;
            if (pwndMouse != ptiCurrent->pq->spwndLastMouseMessage) {
                MouseEnter(ptiCurrent->pq, pwndMouse);
            } else if (ptiCurrent->pq->QF_flags & QF_TRACKMOUSEHOVER) {
                switch (message) {
                default:
                    if (PtInRect(&ptiCurrent->pq->rcMouseHover, pt))
                        break;
                    // FALL THROUGH

                case WM_LBUTTONDOWN:
                case WM_LBUTTONUP:
                case WM_RBUTTONDOWN:
                case WM_RBUTTONUP:
                case WM_MBUTTONDOWN:
                case WM_MBUTTONUP:
                    ResetMouseHover(pt);
                }
            }

            /*
             * Now see if it matches the window handle filter. If not,
             * get the next message.
             */
            if (!CheckPwndFilter(pwnd, pwndFilter)) {
                PATHTAKEN(0x8000000);
                continue;
            }

            /*
             * See if we need to map to a double click.
             */
            codeMouseDown = 0;
            switch (message) {
            case WM_LBUTTONDOWN:
            case WM_RBUTTONDOWN:
            case WM_MBUTTONDOWN:
                if (TestCF(pwnd, CFDBLCLKS) ||
                        ptiCurrent->pq->codeCapture == NO_CAP_SYS ||
                        IsMenuStarted(ptiCurrent)) {
                    codeMouseDown++;
                    PATHTAKEN(0x10000000);
                    if (qmsg.msg.time <= ptiCurrent->pq->timeDblClk &&
                            pwnd == PW(ptiCurrent->pq->hwndDblClk) &&
                            PtInRect(&ptiCurrent->pq->rcDblClk, qmsg.msg.pt) &&
                            message == ptiCurrent->pq->msgDblClk) {
                        message += (WM_LBUTTONDBLCLK - WM_LBUTTONDOWN);
                        codeMouseDown++;
                        PATHTAKEN(0x20000000);
                    }
                }

            // FALL THROUGH!!!

            case WM_LBUTTONUP:
            case WM_RBUTTONUP:
            case WM_MBUTTONUP:

                /*
                 * Note that the mouse button went up or down if we were
                 * in menu status mode of alt-key down
                 */

                PATHTAKEN(0x40000000);
                if (ptiCurrent->pq->QF_flags & QF_FMENUSTATUS) {
                    ptiCurrent->pq->QF_flags |= QF_FMENUSTATUSBREAK;
                    PATHTAKEN(0x80000000);
                }
            }

            /*
             * Map message number based on hit test area code.
             */
            if (ptiCurrent->pq->codeCapture == NO_CAP_SYS) {
                message += (UINT)(WM_NCMOUSEMOVE - WM_MOUSEMOVE);
                wParam = (UINT)part;
                PATHTAKEN2(1);
            }

            /*
             * Message number has been mapped: see if it fits the filter.
             * If not, get the next message.
             */
            if (!CheckMsgFilter(message, msgMinFilter, msgMaxFilter)) {
                PATHTAKEN2(8);
                continue;
            }

            /*
             * If message is for another app but it fits our filter, then
             * we should stop looking for messages: this will ensure that
             * we don't keep looking and find and process a message that
             * occured later than the one that should be processed by the
             * other guy.
             */
            if (fOtherApp) {
                PATHTAKEN2(0x10);
                goto NoMessages;
            }

            /*
             * If we're doing full drag, the mouse messages should go to
             * the xxxMoveSize PeekMessage loop. So we get the next message.
             * This can happen when an application does a PeekMessage in
             * response to a message sent inside the movesize dragging loop.
             * This causes the dragging loop to not get the WM_LBUTTONUP
             * message and dragging continues after the button is up
             * (fix for Micrografx Draw). -johannec
             */
            if (message >= WM_MOUSEFIRST && message <= WM_MOUSELAST &&
                    ptiCurrent->TIF_flags & TIF_MOVESIZETRACKING) {
                PATHTAKEN2(0x20);
                continue;
            }

            /*
             * Let us call the mouse hook to find out if this click is
             * permitted by it.
             *
             * We want to inform the mouse hook before we test for
             * HTNOWHERE and HTERROR; Otherwise, the mouse hook won't
             * get these messages (sankar 12/10/91).
             */
            if (IsHooked(ptiCurrent, WHF_MOUSE)) {
                fMouseHookCalled = TRUE;
                mhs.pt = qmsg.msg.pt;
                mhs.hwnd = HW(pwnd);
                mhs.wHitTestCode = (UINT)part;
                mhs.dwExtraInfo = qmsg.ExtraInfo;

                if (xxxCallMouseHook(message, &mhs, fRemove)) {
                    /*
                     * Not allowed by mouse hook; so skip it.
                     */
                    PATHTAKEN2(0x40);
                    goto SkipMessage;
                }
                PATHTAKEN2(0x80);
            }

            /*
             * If a HTERROR or HTNOWHERE occured, send the window the
             * WM_SETCURSOR message so it can beep or whatever. Then skip
             * the message and try the next one.
             */
            switch (part) {
            case HTERROR:
            case HTNOWHERE:
                /*
                 * Now set the cursor shape.
                 */
                xxxSendMessage(pwnd, WM_SETCURSOR, (DWORD)HW(pwnd),
                        MAKELONG(part, qmsg.msg.message));

                /*
                 * Skip the message.
                 */
                PATHTAKEN2(0x100);
                goto SkipMessage;
                break;
            }

            if (fRemove) {
                PATHTAKEN2(0x200);
                /*
                 * Since the processing of a down click may cause the next
                 * message to be interpreted as a double click, we only want
                 * to do the double click setup if we're actually going to
                 * remove the message.  Otherwise, the next time we read the
                 * same message it would be interpreted as a double click.
                 */
                switch (codeMouseDown) {
                case 1:
                    /*
                     * Down clock: set up for later possible double click.
                     */
                    ptiCurrent->pq->msgDblClk = qmsg.msg.message;
                    ptiCurrent->pq->timeDblClk = qmsg.msg.time + dtDblClk;
                    ptiCurrent->pq->hwndDblClk = HW(pwnd);
                    SetRect(&ptiCurrent->pq->rcDblClk,
                            qmsg.msg.pt.x - SYSMET(CXDOUBLECLK) / 2,
                            qmsg.msg.pt.y - SYSMET(CYDOUBLECLK) / 2,
                            qmsg.msg.pt.x + SYSMET(CXDOUBLECLK) / 2,
                            qmsg.msg.pt.y + SYSMET(CYDOUBLECLK) / 2);
                    PATHTAKEN2(0x400);
                    break;

                case 2:
                    /*
                     * Double click: finish processing.
                     */
                    ptiCurrent->pq->timeDblClk = 0L;
                    PATHTAKEN2(0x800);
                    break;

                default:
                    PATHTAKEN2(0x1000);
                    break;
                }

                /*
                 * Set mouse cursor and allow app to activate window
                 * only if we're removing the message.
                 */
                switch (xxxMouseActivate(ptiCurrent, pwnd,
                        qmsg.msg.message, &qmsg.msg.pt, part)) {
SkipMessage:
                case MA_SKIP:
                    DUMPSUBPATHTAKEN(pathTaken2, 0x2000);
                    PATHTAKEN2(0x2000);
                    xxxSkipSysMsg(ptiCurrent, &qmsg);

                    /*
                     * Inform the CBT hook that we skipped a mouse click.
                     */
                    if (fMouseHookCalled) {
                        if (IsHooked(ptiCurrent, WHF_CBT)) {
                            xxxCallHook(HCBT_CLICKSKIPPED, message,
                                    (DWORD)&mhs, WH_CBT);
                            PATHTAKEN2(0x4000);
                        }
                        fMouseHookCalled = FALSE;
                    }

                    /*
                     * Inform the CBT hook that we skipped a key
                     */
                    if (fKbdHookCalled) {
                        if (IsHooked(ptiCurrent, WHF_CBT)) {
                            xxxCallHook(HCBT_KEYSKIPPED, wParam, lParam,
                                    WH_CBT);
                            PATHTAKEN2(0x8000);
                        }
                        fKbdHookCalled = FALSE;
                    }

                    /*
                     * If we aren't removing messages, don't reset idSysPeek
                     * otherwise we will go into an infinite loop if
                     * the keyboard hook says to ignore the message.
                     * (bobgu 4/7/87).
                     */
                    if (!fRemove) {
                        PATHTAKEN2(0x10000);
                        goto ContinueScan;
                    } else {
                        PATHTAKEN2(0x20000);
                        goto RestartScan;
                    }
                    break;

                case MA_REHITTEST:
                    /*
                     * Reprocess the message.
                     */
                    PATHTAKEN2(0x40000);
                    goto ReprocessMsg;
                }
            }

            /*
             * Eat the message from the input queue (and set the keystate
             * table).
             */
            PATHTAKEN2(0x80000);
            if (fRemove) {
                xxxSkipSysMsg(ptiCurrent, &qmsg);
            }

            if (fRemove && fMouseHookCalled && IsHooked(ptiCurrent, WHF_CBT)) {
                xxxCallHook(HCBT_CLICKSKIPPED, message,
                        (DWORD)&mhs, WH_CBT);
            }
            fMouseHookCalled = FALSE;

            /*
             * Calculate virtual key state bitmask for wParam.
             */
            if (message >= WM_MOUSEFIRST) {
                /*
                 * This is a USER mouse message. Calculate the bit mask for the
                 * virtual key state.
                 */
                wParam = GetMouseKeyFlags(ptiCurrent->pq);
                PATHTAKEN2(0x100000);
            }

            lParam = MAKELONG((short)pt.x, (short)pt.y);
            PATHTAKEN2(0x200000);
            goto ReturnMessage;
            break;

        case WM_KEYDOWN:
        case WM_SYSKEYDOWN:
            fDown = TRUE;

            /*
             * If we are sending keyboard input to an app that has been
             * spinning then boost it back up.  If we don't you use spinning
             * apps like Write or Project and do two builds in the
             * background.  Note the app will also be unboosted again shortly
             * after you stop typing by the old logic. #11188
             */
            if (ptiCurrent->TIF_flags & TIF_SPINNING)
                CheckProcessForeground(ptiCurrent);

            /*
             * Apps doing journal playback sometimes put trash in the hiword
             * of wParam... zero it out here.
             */
            wParam = qmsg.msg.wParam & 0xFF;

            /*
             * Clear QF_FMENUSTATUS if a key other than Alt it hit
             * since this means the break of the Alt wouldn't be a
             * menu key anymore.
             */
            if (wParam != VK_MENU)
                ptiCurrent->pq->QF_flags &= ~(QF_FMENUSTATUS|QF_FMENUSTATUSBREAK);

            /*
             * Check if it is the PrintScrn key.
             */
            fAlt = TestKeyStateDown(ptiCurrent->pq, VK_MENU);
            if (wParam == VK_SNAPSHOT &&
                ((fAlt && !(ptiCurrent->fsReserveKeys & CONSOLE_ALTPRTSC)) ||
                 (!fAlt && !(ptiCurrent->fsReserveKeys & CONSOLE_PRTSC)))) {

                /*
                 * Remove this message from the input queue.
                 */
                PATHTAKEN2(0x400000);
                xxxSkipSysMsg(ptiCurrent, &qmsg);

                /*
                 * PRINTSCREEN          -> Snap the whole screen.
                 * ALT-PRINTSCREEN      -> Snap the current window.
                 */
                pwndT = ptiCurrent->pq->spwndActive;
                if (!fAlt) {
                    pwndT = ptiCurrent->rpdesk->pDeskInfo->spwnd;
                }

                if (pwndT != NULL) {
                    ThreadLockAlwaysWithPti(ptiCurrent, pwndT, &tlpwndT);
                    xxxSnapWindow(pwndT);
                    ThreadUnlock(&tlpwndT);
                }

                PATHTAKEN2(0x800000);
                goto RestartScan;
            }

            /*
             * Check for keyboard language toggle.  Build the key state
             * here for use during key up processing (where the layout
             * switching takes place.  This code is skipped if layout
             * switching via the keyboard is disabled.
             */
            if (LangToggle[0].bVkey && (LangToggleKeyState < 8)) {
                DWORD i;
                BYTE scancode = LOBYTE(HIWORD(qmsg.msg.lParam));
                BYTE vkey = LOBYTE(qmsg.msg.wParam);

                for (i = 0; i < cLangToggleKeys; i++) {
                    if (LangToggle[i].bScan) {
                        if (LangToggle[i].bScan == scancode) {
                            LangToggleKeyState |= LangToggle[i].iBitPosition;
                            break;
                        }
                    } else {
                        if (LangToggle[i].bVkey == vkey) {
                            LangToggleKeyState |= LangToggle[i].iBitPosition;
                            break;
                        }
                    }
                }

                if (i == cLangToggleKeys) {
                    LangToggleKeyState = 8;   // not a language toggle combination
                }
            }

            /*
             * Check for hot keys being hit if any are defined.
             */
            if (gcHotKey != 0) {
                key = wParam;

                if (TestKeyStateDown(ptiCurrent->pq, VK_MENU))
                    key |= 0x0400;

                if (TestKeyStateDown(ptiCurrent->pq, VK_CONTROL))
                    key |= 0x0200;

                if (TestKeyStateDown(ptiCurrent->pq, VK_SHIFT))
                    key |= 0x0100;

                pwndT = HotKeyToWindow(key);

                if (pwndT != NULL) {
                    _PostMessage(ptiCurrent->pq->spwndActive, WM_SYSCOMMAND,
                                (WPARAM)SC_HOTKEY, (LONG)HWq(pwndT));

                    /*
                     * Remove this message from the input queue.
                     */
                    xxxSkipSysMsg(ptiCurrent, &qmsg);
                    PATHTAKEN2(0x1000000);
                    goto RestartScan;
                }
                PATHTAKEN2(0x2000000);
            }

            /*
             * Fall through.
             */

        case WM_SYSKEYUP:
        case WM_KEYUP:
            wParam = qmsg.msg.wParam & 0xFF;

            /*
             * Process keyboard toggle keys only if this is
             * a break event and fRemove == TRUE.  Some apps,
             * for instance Word 95, call PeekMessage with
             * PM_NOREMOVE followed by a call with PM_REMOVE.
             * We only want to process this once.  Skip all
             * of this is layout switching via the keyboard
             * is disabled.
             */
            if (!fDown && fRemove && LangToggle[0].bVkey) {
                BOOL bDropToggle = FALSE;
                DWORD dwDirection = 0;
                PKL pkl;
                // PWND pwndTop;

                pwnd = ptiCurrent->pq->spwndFocus;
                if (pwnd == NULL) {
                    pwnd = ptiCurrent->pq->spwndActive;
                    if (!pwnd) {
                        goto NoLayoutSwitch;
                    }
                }
                pkl = GETPTI(pwnd)->spklActive;
                UserAssert(pkl != NULL);

                switch (LangToggleKeyState) {

                case KLT_LEFTSHIFT:
                   bDropToggle = TRUE;
                   dwDirection = LANGCHANGE_BACKWARD;
                   pkl = HKLtoPKL((HKL)HKL_NEXT);
                   break;

                case KLT_RIGHTSHIFT:
                   bDropToggle = TRUE;
                   dwDirection = LANGCHANGE_FORWARD;
                   pkl = HKLtoPKL((HKL)HKL_PREV);
                   break;

                case KLT_BOTHSHIFTS:
                   pkl = gspklBaseLayout;
                   break;

                default:
                   goto NoLayoutSwitch;
                   break;
                }

                if (pkl == NULL) {
                    pkl = GETPTI(pwnd)->spklActive;
                }

                UserAssert(gspklBaseLayout != NULL);

                // One day Memphis and Windows NT should come up with a better
                // strategy.  This one goes up too far, bypassing Word when
                // using wordmail. - IanJa
                // if ((pwndTop = GetTopLevelWindow(pwnd)) != NULL) {
                //    pwnd = pwndTop;
                // }
                _PostMessage(
                    pwnd,
                    WM_INPUTLANGCHANGEREQUEST,
                    (DWORD)(((pkl->bCharsets & gSystemCPB) ? TRUE : FALSE) | dwDirection),
                    (LONG)pkl->hkl
                    );

NoLayoutSwitch:

                if (bDropToggle) {
                    /*
                     * Clear this key from the key state so that multiple key
                     * presses will work (i.e., Alt+Shft+Shft).  We don't do
                     * this when both shift keys are pressed simultaneously to
                     * avoid two activates.
                     */
                    DWORD i;
                    BYTE scancode = LOBYTE(HIWORD(qmsg.msg.lParam));
                    BYTE vkey = LOBYTE(qmsg.msg.wParam);

                    for (i = 0; i < cLangToggleKeys; i++) {
                        if (LangToggle[i].bScan) {
                            if (LangToggle[i].bScan == scancode) {
                                LangToggleKeyState &= ~(LangToggle[i].iBitPosition);
                            }
                        } else {
                            if (LangToggle[i].bVkey == vkey) {
                                LangToggleKeyState &= ~(LangToggle[i].iBitPosition);
                            }
                        }
                    }
                } else {
                    LangToggleKeyState = 0;
                }
            }

            /*
             * Convert F10 to syskey for new apps.
             */
            if (wParam == VK_F10)
                message |= (WM_SYSKEYDOWN - WM_KEYDOWN);

            if (TestKeyStateDown(ptiCurrent->pq, VK_CONTROL) &&
                    wParam == VK_ESCAPE) {
                message |= (WM_SYSKEYDOWN - WM_KEYDOWN);
            }

            /*
             * Clear the 'simulated keystroke' bit for all applications except
             * console so it can pass it to 16-bit vdms. VDM keyboards need to
             * distinguish between AltGr (where Ctrl keystroke is simulated)
             * and a real Ctrl+Alt. Check TIF_CSRSSTHREAD for the console
             * input thread because it lives in the server. This is a cheap
             * way to check for it.
             */
            if (!(ptiCurrent->TIF_flags & TIF_CSRSSTHREAD))
                qmsg.msg.lParam &= ~FAKE_KEYSTROKE;
            PATHTAKEN2(0x4000000);

            /*
             * Fall through.
             */

            /*
             * Some apps want to be able to feed WM_CHAR messages through
             * the playback hook. Why? Because they want to be able to
             * convert a string of characters info key messages
             * and feed them to themselves or other apps. Unfortunately,
             * there are no machine independent virtual key codes for
             * some characters (for example '$'), so they need to send
             * those through as WM_CHARs. (6/10/87).
             */

        case WM_CHAR:
            wParam = qmsg.msg.wParam & 0xFF;

            /*
             * Assign the input to the focus window. If there is no focus
             * window, assign it to the active window as a SYS message.
             */
            pwnd = ptiCurrent->pq->spwndFocus;
            if (ptiCurrent->pq->spwndFocus == NULL) {
                if ((pwnd = ptiCurrent->pq->spwndActive) != NULL) {
                    if (CheckMsgFilter(message, WM_KEYDOWN, WM_DEADCHAR)) {
                        message += (WM_SYSKEYDOWN - WM_KEYDOWN);
                        PATHTAKEN2(0x8000000);
                    }
                } else {
                    PATHTAKEN2(0x10000000);
                    goto SkipMessage;
                }
            }

            /*
             * If there is no active window or focus window, eat this
             * message.
             */
            if (pwnd == NULL) {
                PATHTAKEN2(0x20000000);
                goto SkipMessage;
            }

            ThreadUnlock(&tlpwnd);
            ThreadLockAlwaysWithPti(ptiCurrent, pwnd, &tlpwnd);

            /*
             * Check if this is intended for the current app.
             */
            if (fOtherApp = (GETPTI(pwnd) != ptiCurrent)) {

                /*
                 * If this other app isn't going to read from this
                 * queue, then skip this message. This can happen if
                 * the RIT queues up a message thinking it goes to
                 * a particular hwnd, but then by the time GetMessage()
                 * is called for that thread, it doesn't go to that hwnd
                 * (like in the case of mouse messages, window rearrangement
                 * happens which changes which hwnd the mouse hits on).
                 */
                if (GETPTI(pwnd)->pq != ptiCurrent->pq) {
                    PATHTAKEN2(0x40000000);
                    goto SkipMessage;
                }

                /*
                 * If the current thread is in the menu loop then we need
                 * to give it the input
                 */
                if (IsInsideMenuLoop(ptiCurrent)) {
                    pwnd = ptiCurrent->pMenuState->pGlobalPopupMenu->spwndNotify;
                    fOtherApp = (GETPTI(pwnd) != ptiCurrent);

                    /*
                     * We've reassigned pwnd, so lock it.
                     */
                    ThreadUnlock(&tlpwnd);
                    ThreadLockWithPti(ptiCurrent, pwnd, &tlpwnd);
                    PATHTAKEN2(0x80000000);
                }

                /*
                 * If not for us, then remember who it is for.
                 */
                if (ptiKeyWake == NULL) {
                    PATHTAKEN3(1);
                    ptiKeyWake = GETPTI(pwnd);
                }
            }

            /*
             * See if this thing matches our filter.
             */
            if (!CheckMsgFilter(message, msgMinFilter, msgMaxFilter) ||
                    !CheckPwndFilter(pwnd, pwndFilter)) {
                PATHTAKEN3(2);
                continue;
            }

            /*
             * This message matches our filter. If it is not for us then
             * stop searching to make sure the real owner processes this
             * message first.
             */
            if (fOtherApp) {
                PATHTAKEN3(4);
                goto NoMessages;
            }

            /*
             * Generate some special messages if we are removing and we are
             * not inside the menu loop.
             */
            if (fRemove && !IsInsideMenuLoop(ptiCurrent)) {

                /*
                 * Generate a WM_CONTEXTMENU for the VK_APPS key
                 */
                if ((wParam == VK_APPS) && (message == WM_KEYUP)) {
                    _PostMessage(pwnd, WM_CONTEXTMENU, (WPARAM)PtoH(pwnd), -1);
                }

                /*
                 * If this is a WM_KEYDOWN message for F1 key then we must generate
                 * the WM_KEYF1 message.
                 */
                if ((wParam == VK_F1) && (message == WM_KEYDOWN)) {
                    _PostMessage(pwnd, WM_KEYF1, 0, 0);
                }
            }


            /*
             * If one Shift key is released while the other Shift key is held
             * down, this keystroke is normally skipped, presumably to prevent
             * applications from thinking that the shift condition no longer
             * applies.
             */
            if (wParam == VK_SHIFT) {
                BYTE vkHanded, vkOtherHand;

                if (qmsg.msg.lParam & EXTENDED_BIT) {
                    vkHanded = VK_RSHIFT;
                } else {
                    vkHanded = VK_LSHIFT;
                }
                vkOtherHand = vkHanded ^ 1;

                if (!fDown && TestKeyStateDown(ptiCurrent->pq, vkOtherHand)) {
                    /*
                     * Unlike normal apps, Console MUST be sent a Shift break
                     * even when the other Shift key is still down, since it
                     * has to be passed on to VDM, which maintains it's own
                     * state. Check TIF_CSRSSTHREAD for the console input
                     * thread because it lives in the server. This is a cheap
                     * way to check for it.
                     */
                    if ((ptiCurrent->TIF_flags & TIF_CSRSSTHREAD) == 0) {
                        /*
                         * We ignore this key event, so we must update
                         * it's key state whether fRemove is TRUE or not.
                         * (ignoring an key event is same as removing it)
                         */
                        qmsg.msg.wParam = vkHanded;
                        xxxSkipSysMsg(ptiCurrent, &qmsg);
                        PATHTAKEN3(8);
                        goto RestartScan;
                    }
                    PATHTAKEN3(0x10);
                }
            }

            /*
             * Get the previous up/down state of the key here since
             * SkipSysMsg() sets the key state table and destroys
             * the previous state info.
             */
            fPrevDown = FALSE;
            if (TestKeyStateDown(ptiCurrent->pq, wParam))
                fPrevDown = TRUE;

            /*
             * Eat the message from the input queue and set the keystate
             * table.
             */
            PATHTAKEN3(0x20);
            if (fRemove) {
                xxxSkipSysMsg(ptiCurrent, &qmsg);
            }

            /*
             * This gets us the LOWORD of lParam, the repeat count,
             * the bit in the hi byte indicating whether this is an extended
             * key, and the scan code.  We also need to re-get the wParam in
             * case xxxSkipSysMsg called a hook which modified the message.
             * AfterDark's password protection does this.
             */
            lParam = qmsg.msg.lParam;
            wParam = qmsg.msg.wParam;

            /*
             * Indicate if it was previously down.
             */
            if (fPrevDown)
                lParam |= 0x40000000;           // KF_REPEAT

            /*
             * Set the transition bit.
             */
            switch (message) {
            case WM_KEYUP:
            case WM_SYSKEYUP:
                lParam |= 0x80000000;           // KF_UP
                break;
            }

            /*
             * Set the alt key down bit.
             */
            if (TestKeyStateDown(ptiCurrent->pq, VK_MENU)) {
                lParam |= 0x20000000;           // KF_ALTDOWN
            }

            /*
             * Set the menu state flag.
             */
            if (IsMenuStarted(ptiCurrent)) {
                lParam |= 0x10000000;           // KF_MENUMODE
            }

            /*
             * Set the dialog state flag.
             */
            if (ptiCurrent->pq->QF_flags & QF_DIALOGACTIVE) {
                lParam |= 0x08000000;           // KF_DLGMODE
            }

            /*
             * 0x80000000 is set if up, clear if down
             * 0x40000000 is previous up/down state of key
             * 0x20000000 is whether the alt key is down
             * 0x10000000 is whether currently in menumode.
             * 0x08000000 is whether in dialog mode
             * 0x04000000 is not used
             * 0x02000000 is not used
             * 0x01000000 is whether this is an extended keyboard key
             *
             * Low word is repeat count, low byte hiword is scan code,
             * hi byte hiword is all these bits.
             */
#ifdef FE_IME
            /*
             * Callback the client IME before calling the keyboard hook.
             * If the vkey is one of the IME hotkeys, the vkey will not
             * be passed to the keyboard hook.
             * If IME needs this vkey, VK_PROCESSKEY will be put into the
             * application queue instead of real vkey.
             */
            if ( fRemove &&
                 ! IsMenuStarted(ptiCurrent) &&
                 ! (ptiCurrent->TIF_flags & TIF_DISABLEIME) &&
                 ptiCurrent->pq->spwndFocus != NULL
               )
            {
                dwImmRet = xxxImmProcessKey( ptiCurrent->pq,
                                             ptiCurrent->pq->spwndFocus,
                                             message,
                                             wParam,
                                             lParam);
                if ( dwImmRet & IPHK_HOTKEY ) {
                    dwImmRet = 0;
                    goto SkipMessage;
                }
            }
#endif

            /*
             * If we are removing the message, call the keyboard hook
             * with HC_ACTION, otherwise call the hook with HC_NOREM
             * to let it know that the message is not being removed.
             */
            if (IsHooked(ptiCurrent, WHF_KEYBOARD)) {
                fKbdHookCalled = TRUE;
                if (xxxCallHook(fRemove ? HC_ACTION : HC_NOREMOVE,
                        wParam, lParam, WH_KEYBOARD)) {
                    PATHTAKEN3(0x40);
                    goto SkipMessage;
                }
            }

            if (fKbdHookCalled && fRemove && IsHooked(ptiCurrent, WHF_CBT)) {
                xxxCallHook(HCBT_KEYSKIPPED, wParam, lParam, WH_CBT);
                PATHTAKEN3(0x80);
            }

            fKbdHookCalled = FALSE;
            PATHTAKEN3(0x100);
            goto ReturnMessage;

        case WM_MOUSEWHEEL:
            /*
             * If we are sending keyboard input to an app that has been
             * spinning then boost it back up.  If we don't you use spinning
             * apps like Write or Project and do two builds in the
             * background.  Note the app will also be unboosted again shortly
             * after you stop typing by the old logic. #11188
             */
            if (ptiCurrent->TIF_flags & TIF_SPINNING)
                CheckProcessForeground(ptiCurrent);

            /*
             * Assign the input to the focus window. If there is no focus
             * window, or we are in a menu loop, eat this message.
             */
            pwnd = ptiCurrent->pq->spwndFocus;
            if (pwnd == NULL || IsInsideMenuLoop(ptiCurrent)) {
                PATHTAKEN2(0x20000000);
                goto SkipMessage;
            }

            ThreadUnlock(&tlpwnd);
            ThreadLockAlwaysWithPti(ptiCurrent, pwnd, &tlpwnd);

            /*
             * Check if this is intended for the current app.
             */
            if (fOtherApp = (GETPTI(pwnd) != ptiCurrent)) {

                /*
                 * If this other app isn't going to read from this
                 * queue, then skip this message. This can happen if
                 * the RIT queues up a message thinking it goes to
                 * a particular hwnd, but then by the time GetMessage()
                 * is called for that thread, it doesn't go to that hwnd
                 * (like in the case of mouse messages, window rearrangement
                 * happens which changes which hwnd the mouse hits on).
                 */
                if (GETPTI(pwnd)->pq != ptiCurrent->pq) {
                    PATHTAKEN2(0x40000000);
                    goto SkipMessage;
                }

                /*
                 * If not for us, then remember who it is for.
                 */
                if (ptiKeyWake == NULL) {
                    PATHTAKEN3(1);
                    ptiKeyWake = GETPTI(pwnd);
                }
            }

            /*
             * See if this thing matches our filter.
             * NOTE: We need to check whether the caller is filtering
             * for all mouse messages - if so, we assume the caller
             * wants mouse wheel messages too.
             */
            if (    !CheckMsgFilter(WM_MOUSEWHEEL, msgMinFilter, msgMaxFilter) ||
                    !CheckPwndFilter(pwnd, pwndFilter)) {
                PATHTAKEN3(2);
                continue;
            }

            /*
             * This message matches our filter. If it is not for us then
             * stop searching to make sure the real owner processes this
             * message first.
             */
            if (fOtherApp) {
                PATHTAKEN3(4);
                goto NoMessages;
            }

            /*
             * Eat the message from the input queue and set the keystate
             * table.
             */
            PATHTAKEN3(0x20);
            if (fRemove) {
                xxxSkipSysMsg(ptiCurrent, &qmsg);
            }

            wParam = GetMouseKeyFlags(ptiCurrent->pq);
            UserAssert(LOWORD(qmsg.msg.wParam) == 0);
            UserAssert(HIWORD(wParam) == 0);
            wParam |= qmsg.msg.wParam;
            lParam = qmsg.msg.lParam;

            /*
             * If we are removing the message, call the mouse hook
             * with HC_ACTION, otherwise call the hook with HC_NOREM
             * to let it know that the message is not being removed.
             */
            if (IsHooked(ptiCurrent, WHF_MOUSE)) {
                fMouseHookCalled = TRUE;
                mhs.pt = qmsg.msg.pt;
                mhs.hwnd = HW(pwnd);
                mhs.wHitTestCode = HTNOWHERE;
                mhs.dwExtraInfo = qmsg.ExtraInfo;
                if (xxxCallMouseHook(message, &mhs, fRemove)) {
                    /*
                     * Not allowed by mouse hook; so skip it.
                     */
                    PATHTAKEN3(0x40);
                    goto SkipMessage;
                }
            }

            if (fMouseHookCalled && fRemove && IsHooked(ptiCurrent, WHF_CBT)) {
                /*
                 * CONSIDER: Add new HCBT_ constant for the mouse wheel?
                 */
                xxxCallHook(HCBT_CLICKSKIPPED, message, (DWORD) &mhs, WH_CBT);
                PATHTAKEN3(0x80);
            }

            fMouseHookCalled = FALSE;
            PATHTAKEN3(0x100);
            goto ReturnMessage;
        } /* End of switch (message = qmsg.msg.message) */
    } /* End of the GetNextSysMsg() loop */

ReturnMessage:
    ptiCurrent->ptLast = qmsg.msg.pt;
    ptiCurrent->timeLast = qmsg.msg.time;
    ptiCurrent->pq->ExtraInfo = qmsg.ExtraInfo;

    /*
     * idSysLock value of 1 indicates that the message came from the input
     * queue.
     */
    ptiCurrent->idLast = ptiCurrent->pq->idSysLock = 1;

    /*
     * Now see if our input bit is set for this input. If it isn't, set ours
     * and clear the guy who had it previously.
     */
    TransferWakeBit(ptiCurrent, message);

    /*
     * Clear the input bits if no messages in the input queue.
     */
    ClearWakeBit(ptiCurrent, QS_MOUSE | QS_KEY | QS_EVENT | QS_TRANSFER, TRUE);

    /*
     * Get the message and split.
     */
    lpMsg->hwnd = HW(pwnd);
    lpMsg->message = message;
#ifdef FE_IME
    /*
     * If the IME claims that it needs this vkey, replace it
     * with VK_PROCESSKEY. The real vkey has been saved in
     * the input context in the client side.
     */
    lpMsg->wParam = ( dwImmRet & IPHK_PROCESSBYIME ) ? VK_PROCESSKEY : wParam;
#else
    lpMsg->wParam = wParam;
#endif
    lpMsg->lParam = lParam;
    lpMsg->time = qmsg.msg.time;
    lpMsg->pt = qmsg.msg.pt;

#if DBG
    if (gfLogPlayback && ptiCurrent->pq->idSysPeek == (int)PQMSG_PLAYBACK)
        LogPlayback(pwnd, lpMsg);
#endif  // DBG

    ThreadUnlock(&tlpwnd);

    PATHTAKEN3(0x200);
    DUMPPATHTAKEN();
    return TRUE;

NoMessages:
    /*
     * The message was for another app, or none were found that fit the
     * filter.
     */

    /*
     * Unlock the system queue.
     */
    ptiCurrent->pq->idSysLock  = 0;
    CheckSysLock(4, ptiCurrent->pq, NULL);
    ptiCurrent->pq->ptiSysLock = NULL;
    ptiCurrent->pcti->CTIF_flags &= ~CTIF_SYSQUEUELOCKED;

    /*
     * Wake up someone else if we found a message for him.  QS_TRANSFER
     * signifies that the thread was woken due to input transfer
     * from another thread, rather than from a real input event.
     */
    if (ptiKeyWake != NULL || ptiMouseWake != NULL || ptiEventWake != NULL) {
        PATHTAKEN3(0x400);
        if (ptiKeyWake != NULL) {
            SetWakeBit(ptiKeyWake, QS_KEY | QS_TRANSFER);
            ClearWakeBit(ptiCurrent, QS_KEY | QS_TRANSFER, FALSE);
            PATHTAKEN3(0x800);
        }

        if (ptiMouseWake != NULL) {
            SetWakeBit(ptiMouseWake, QS_MOUSE | QS_TRANSFER);
            ClearWakeBit(ptiCurrent, QS_MOUSE | QS_TRANSFER, FALSE);
            PATHTAKEN3(0x1000);
        }

        if (ptiEventWake != NULL) {
            SetWakeBit(ptiEventWake, QS_EVENTSET);
            ClearWakeBit(ptiCurrent, QS_EVENT, FALSE);
            PATHTAKEN3(0x2000);
        } else if (FJOURNALPLAYBACK()) {

            /*
             * If journal playback is occuring, clear the input bits.  This will
             * help prevent a race condition between two threads that call
             * WaitMessage/PeekMessage.  This can occur when embedding an OLE
             * object.  An example is inserting a Word object into an Excel
             * spreadsheet.
             * Also clear change bits else this thread might not xxxSleepThread.
             */
            ptiCurrent->pcti->fsWakeBitsJournal |= (ptiCurrent->pcti->fsWakeBits &
                    (QS_MOUSE | QS_KEY | QS_TRANSFER));
            ClearWakeBit(ptiCurrent, QS_MOUSE | QS_KEY | QS_TRANSFER, FALSE);
            ptiCurrent->pcti->fsChangeBits &= ~(QS_MOUSE | QS_KEY | QS_TRANSFER);
        }
    } else {
        /*
         * Clear the input bits if no messages in the input queue.
         */
        ptiCurrent->pcti->fsWakeBitsJournal = 0;
        ClearWakeBit(ptiCurrent, QS_MOUSE | QS_KEY | QS_EVENT |
                QS_TRANSFER, TRUE);
        PATHTAKEN3(0x4000);
    }

    ThreadUnlock(&tlpwnd);

    PATHTAKEN3(0x8000);
    DUMPPATHTAKEN();
    return FALSE;
}
