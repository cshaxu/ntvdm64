$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process $env:ComSpec -ArgumentList '/d /c build\t483-s6-p13\declarations.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/declarations.stdout" -RedirectStandardError "$PSScriptRoot/declarations.stderr"
$p.Id|Set-Content "$PSScriptRoot/declarations-child.pid"
if(!$p.WaitForExit(600000)){taskkill /pid $p.Id /t /f;124|Set-Content "$PSScriptRoot/declarations.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/declarations.exit"
exit $p.ExitCode
