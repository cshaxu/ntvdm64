$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process $env:ComSpec -ArgumentList '/d /c build\t483-s6-p13\proof-final.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/proof-final.stdout" -RedirectStandardError "$PSScriptRoot/proof-final.stderr"
$p.Id|Set-Content "$PSScriptRoot/proof-final-child.pid"
if(!$p.WaitForExit(600000)){taskkill /pid $p.Id /t /f;124|Set-Content "$PSScriptRoot/proof-final.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/proof-final.exit"
exit $p.ExitCode
