/****************************** Module Header ******************************\
* Module Name: input.c
*
* Copyright (c) 1985-91, Microsoft Corporation
*
* This module contains the core functions of the input sub-system
*
* History:
* 10-18-90 DavidPe      Created.
* 02-14-91 mikeke       Added Revalidation code
\***************************************************************************/

#include "wow_input_group_bindings.h"
#pragma hdrstop

//#define MARKPATH
#ifdef MARKPATH
#error
#endif


#line 22
#ifdef TRACESYSPEEK // is defined in userk.h
#error
#line 56
#endif //TRACESYSPEEK

#line 58
#if DBG
#error
#line 84
#endif  // DBG

int LangToggleKeyState = 0;

PVOID KeyStateLookasideBase;
PVOID KeyStateLookasideBounds;
#line 91
#if DBG
#error
#line 97
#endif // DBG

#define CANCEL_ACTIVESTATE  0
#define CANCEL_FOCUSSTATE   1
#define CANCEL_CAPTURESTATE 2

#define KEYSTATESIZE    (CBKEYSTATE + CBKEYSTATERECENTDOWN)


/*
 * xxxGetNextSysMsg return values
 */
#define PQMSG_PLAYBACK       ((PQMSG)1)
#line 238
#ifdef MARKPATH
#error
#line 243
#else
#define PATHTAKEN(x)
#define DUMPPATHTAKEN()
#endif
#line 1154
#ifdef SYSMODALWINDOWS
#error
#line 1181
#endif //LATER
#line 1409
#if 0
#error
#line 1430
#endif
#line 1641
#if DBG
#error
#endif // DBG
#line 1647
#if DBG
#error
#line 1653
#endif // DBG
#line 1669
#if DBG
#error
#endif // DBG
#line 1679
#if DBG
#error
#endif // DBG
#line 1764
#if (CBKEYSTATERECENTDOWN % 4) != 0
#error "CBKEYSTATERECENTDOWN assumed to be an integral number of DWORDs"
#endif
#line 2295
#ifdef NEVER
#error
#line 2309
#endif
#line 2924
#ifdef TRACESYSPEEK
#error
#endif

#line 2928
#ifdef DEBUG
#error
#line 2949
#endif
#line 2957
#ifdef DEBUG
#error
#line 2964
#endif
#line 2971
#ifdef DEBUG
#error
#endif
#line 3188
#if DBG
#error
#line 3230
#endif  // DBG
#line 3307
#ifdef FE_IME
#error
#endif
#ifdef MARKPATH
#error
#line 3320
#else
#define PATHTAKEN(x)
#define PATHTAKEN2(x)
#define PATHTAKEN3(x)
#define DUMPPATHTAKEN()
#define DUMPSUBPATHTAKEN(p, x)
#endif
#line 4551
#ifdef FE_IME
#error
#line 4575
#endif
#line 4750
#ifdef FE_IME
#error
#line 4757
#else
#line 4759
#endif
#line 4764
#if DBG
#error
#line 4767
#endif  // DBG
#line 4991
/***************************************************************************\
* RecalcThreadAttachment
* Recalc2
* AddAttachment
* CheckAttachment
*
* Runs through all the attachinfo fields for all threads and calculates
* which threads share which queues. Puts calculated result in pqAttach
* field in each threadinfo structure. This is a difficult problem
* whose only solution in iterative. The basic algorithm is:
*
* 0. Find next unattached thread and attach a queue to it. If none, stop.
* 1. Loop through all threads: If thread X assigned to this queue or any
*    of X's attach requests assigned to this queue, assign X and all X's
*    attachments to this queue. Remember if we ever attach a 16 bit thread.
* 2. If thread X is a 16 bit thread and we've already attached another
*    16 bit thread, assign X and all X's attachments to this queue.
* 3. If any change found in 1-2, goto 1
* 4. Goto 0
*
* 12-11-92 ScottLu      Created.
* 01-Oct-1993 mikeke    Fixed to work with MWOWs
\***************************************************************************/

void AddAttachment(
    PTHREADINFO pti,
    PQ pqAttach,
    LPBOOL pfChanged)
{
    if (pti->pqAttach != pqAttach) {
        /*
         * LATER
         * !!! This is totally screwed up,  The only reason that this thing
         * could be non null is because two threads are going through
         * attachthreadintput() at the same time.  No one can predict
         * what kind of problems are going to be caused by that.
         * We leave the critical section in one place where we send
         * WM_CANCELMODE below.  We should figure out how to remove
         * the sendmessage.
         *
         * If there already is a queue there, as there may be, destroy it.
         * Note that DestroyQueue() will only get rid of the queue if the
         * thread reference count goes to 0.
         */
        PQ pqDestroy = pti->pqAttach;
        pti->pqAttach = pqAttach;
        if (pqDestroy != NULL)
            DestroyQueue(pqDestroy, pti);
        pqAttach->cThreads++;
        *pfChanged = TRUE;
    }
}

void Recalc2(
    PQ pqAttach,
    PTHREADINFO ptiCurrent)
#line 5046
{
    PATTACHINFO pai;
    PTHREADINFO pti;
    BOOL fChanged;
    PLIST_ENTRY pHead, pEntry;

    /*
     * Keep adding attachments until everything that should be attached to this
     * queue is attached
     */
    do {
        fChanged = FALSE;

        /*
         * If a thread is attached to this Q attach all of it's attachments
         * and MWOW buddies if they aren't already attached.
         */
        pHead = &PtiCurrent()->rpdesk->PtiList;
        for (pEntry = pHead->Flink; pEntry != pHead; pEntry = pEntry->Flink) {
            pti = CONTAINING_RECORD(pEntry, THREADINFO, PtiLink);

            if (pti->pqAttach == pqAttach) {
                /*
                 * check each of the attachments to see if this thread is attached
                 * to any other threads
                 */
                for (pai = gpai; pai != NULL; pai = pai->paiNext) {
                    /*
                     * if they weren't attached already, attach them
                     */
                    if (pai->pti1 == pti || pai->pti2 == pti) {
                        AddAttachment(
                                (pai->pti1 == pti) ? pai->pti2 : pai->pti1,
                                pqAttach,
                                &fChanged);
                    }
                }

                /*
                 * If this is a 16bit thread attach to all other threads in
                 * it's MWOW
                 */
                if (pti->TIF_flags & TIF_16BIT) {
                    PTHREADINFO ptiAttach;
                    PLIST_ENTRY pHeadAttach, pEntryAttach;

                    pHeadAttach = &pti->rpdesk->PtiList;
                    for (pEntryAttach = pHeadAttach->Flink;
                            pEntryAttach != pHeadAttach;
                            pEntryAttach = pEntryAttach->Flink) {
                        ptiAttach = CONTAINING_RECORD(pEntryAttach, THREADINFO, PtiLink);

                        if (ptiAttach->TIF_flags & TIF_16BIT &&
                            ptiAttach->ppi == pti->ppi) {
                            AddAttachment(ptiAttach, pqAttach, &fChanged);
                        }
                    }
                }
            }
        }
    } while (fChanged);
}
#line 5295
#if DBG
#error
#line 5299
#endif
#line 5316
#if DBG
#error
#line 5320
#endif

#line 5165
void RedistributeInput(
    PQMSG pqmsgS,
    PQ    pqRedist)
{
    PTHREADINFO ptiSave;
    PTHREADINFO ptiT;
    PQMSG *ppqmsgD;
    PQMSG pqmsgT;
    PMLIST pmlInput;

    /*
     * Since the thread attaching or unattaching may have left a queue
     * shared by other threads, the messages we are going to requeue
     * may have multiple destinations. On top of this, once we find
     * a home queue for a message, it needs to be inserted in the
     * list ordered by its time stamp (older messages go at the end).
     */

    /*
     * Loop through a given dest's messages to find where to insert
     * the source messages, based on message time stamp. Be sure
     * to deal with empty message lists (meaning, check for NULL).
     */

    ptiT = NULL;
    ppqmsgD = NULL;
    pmlInput = NULL;

    while (pqmsgS != NULL) {

        /*
         * Find out where this message should go.
         */
        ptiSave = ptiT;
        ptiT = pqmsgS->pti;

        /*
         * Get rid of some event messages.
         *
         * QEVENT_UPDATEKEYSTATE: key state already up to date
         */
        if (pqmsgS->dwQEvent == QEVENT_UPDATEKEYSTATE) {
            ptiT = NULL;
        }

        if (ptiT == NULL) {
            /*
             * Unlink it. pqmsgS should be the first in the list
             */

            UserAssert(!pqmsgS->pqmsgPrev);
            if (pqmsgS->pqmsgNext != NULL) {
                pqmsgS->pqmsgNext->pqmsgPrev = NULL;
            }

            pqmsgT = pqmsgS;
            pqmsgS = pqmsgS->pqmsgNext;

            /*
             * Clean it / free it.
             */
            CleanEventMessage(pqmsgT);
            FreeQEntry(pqmsgT);

            ptiT = ptiSave;
            continue;
        }

        /*
         * Point to the pointer that points to the first message
         * that this message should go to, so that pointer is easy to
         * update, no matter where it is.
         */
        if (ppqmsgD == NULL || ptiSave != ptiT) {

            /*
             * If the source is younger than the last message in the
             * destination, go to the end.  Otherwise, start at the
             * head of the desination list and find a place to insert
             * the message.
             */
            if (ptiT->pq->mlInput.pqmsgWriteLast != NULL &&
                    pqmsgS->msg.time >= ptiT->pq->mlInput.pqmsgWriteLast->msg.time) {
                ppqmsgD = &ptiT->pq->mlInput.pqmsgWriteLast->pqmsgNext;
            } else {
                ppqmsgD = &ptiT->pq->mlInput.pqmsgRead;
            }

            pmlInput = &ptiT->pq->mlInput;
        }

        /*
         * If we're not at the end of the destination AND the destination
         * message time is younger than the source time, go on to
         * the next message.
         */
        while (*ppqmsgD != NULL && ((*ppqmsgD)->msg.time <= pqmsgS->msg.time)) {
            ppqmsgD = &((*ppqmsgD)->pqmsgNext);
        }

        /*
         * Link in the source before the dest message. Update
         * it's next and prev pointers. Update the dest prev
         * pointer.
         */
        pqmsgT = pqmsgS;
        pqmsgS = pqmsgS->pqmsgNext;
        pqmsgT->pqmsgNext = *ppqmsgD;

        if (*ppqmsgD != NULL) {
            pqmsgT->pqmsgPrev = (*ppqmsgD)->pqmsgPrev;
            (*ppqmsgD)->pqmsgPrev = pqmsgT;
        } else {
            pqmsgT->pqmsgPrev = pmlInput->pqmsgWriteLast;
            pmlInput->pqmsgWriteLast = pqmsgT;
        }
        *ppqmsgD = pqmsgT;
        ppqmsgD = &pqmsgT->pqmsgNext;
        pmlInput->cMsgs++;

        /*
         * Preserve the 'idSysPeek' from the old queue.
         * Carefull if the redistributed queue is the same as ptiT->pq.
         */
        if (pqmsgT == (PQMSG)(pqRedist->idSysPeek) && (pqRedist != ptiT->pq)) {

            if (ptiT->pq->idSysPeek == 0) {
                CheckPtiSysPeek(6, ptiT->pq, pqRedist->idSysPeek);
                ptiT->pq->idSysPeek = pqRedist->idSysPeek;
            }
#if DBG
            else
                KdPrint(("idSysPeek %lx already set in pq %lx\n",
                    ptiT->pq->idSysPeek, ptiT->pq));
#endif
            /*
             * Set the 'idSysPeek' of this queue to 0 since
             * we moved the idSysPeek to other queue
             */
            CheckPtiSysPeek(7, pqRedist, 0);
            pqRedist->idSysPeek = 0;

            /*
             * Preserve also 'ptiSysLock'
             */
            if (ptiT->pq->ptiSysLock == NULL) {
                CheckSysLock(4, ptiT->pq, pqRedist->ptiSysLock);
                ptiT->pq->ptiSysLock = pqRedist->ptiSysLock;
                CheckSysLock(5, pqRedist, NULL);
                pqRedist->ptiSysLock = NULL;
            }
#if DBG
            else
                KdPrint(("ptiSysLock %lx already set in pq %lx\n",
                    ptiT->pq->ptiSysLock, ptiT->pq));
#endif
        }

        /*
         * Don't want the prev pointer on our message list to point
         * to this message which is on a different list (doesn't
         * really matter because we're about to link it anyway,
         * but completeness shouldn't hurt).
         */
        if (pqmsgS != NULL) {
            pqmsgS->pqmsgPrev = NULL;
        }
    }
}
