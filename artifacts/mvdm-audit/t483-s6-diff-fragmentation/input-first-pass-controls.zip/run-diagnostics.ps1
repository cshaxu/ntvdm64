$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$p=Start-Process $env:ComSpec -ArgumentList '/d /c build\t483-s6-p13\diagnostics.cmd' -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/diagnostics.stdout" -RedirectStandardError "$PSScriptRoot/diagnostics.stderr"
$p.Id|Set-Content "$PSScriptRoot/diagnostics-child.pid"
if(!$p.WaitForExit(600000)){taskkill /pid $p.Id /t /f;124|Set-Content "$PSScriptRoot/diagnostics.exit";exit 124}
$p.ExitCode|Set-Content "$PSScriptRoot/diagnostics.exit"
exit $p.ExitCode
