from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s7-p1';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','targeted','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'assertions=16 failures=0' in log and 'SERVER_ENUM checks=37 failures=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=37,remaining_files=205,retired_reviewed_files=13,original_restoration_blocks=43,original_restoration_lines=1412,owner_retired_blocks=243,extraction_blocks=233,unused_removal_blocks=10,owner_retired_lines=24333,extraction_lines=22943,unused_removal_lines=1390,total_census_reduction_blocks=286,total_census_reduction_lines=25745)
assert (counts['files'],counts['blocks'],counts['lines'])==(1050,2047,28778)

q=r/'build/t483-s7-packstr'
assert (q/'verify.exit').read_text().strip()=='0'
control=(q/'full-control.log').read_text(encoding='utf-8',errors='replace')
assert 'C1083' in control and 'rpcutil.h' in control,control[-1200:]
m=(q/'VDMREDIR.map').read_text()
assert 'NetpCopyStringToBuffer' in m and 'NetpPackString' not in m and 'NetpCopyDataToBuffer' not in m
pub=j(b/'runtime-publication/result.json')
receipt=dict(packet='M0 T483 S7 P1',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},
 full='Targeted Redirector verification selected for these two source changes',
 global_counts=counts,restoration=dict(blocks=3,changed_lines=218),
 packstr_original_units=[{'symbol':'NetpPackString','lines':[60,155]},{'symbol':'NetpCopyDataToBuffer','lines':[286,406]}],
 packstr_limits='NetpAllocateEnumBuffer needs the omitted rpcutil.h and MIDL allocation provider. Both restored packing routines are discarded by the production link.',
 source_evidence={'class.c':'../t483-remaining-reaudit/p242-class-review.json','winmgrc.c':'../t483-remaining-reaudit/p237-winmgrc-review.json','profile.c':'../t483-remaining-reaudit/p243-profile-review.json','getset.c':'../t483-remaining-reaudit/p242-getset-review.json','clmsg.c':'clmsg-whole-file-review.json','server.c':'../t483-remaining-reaudit/p246-server-in-progress.json','dpmi32/data.c':'../t483-remaining-reaudit/r0134-r0136-requalification.json'})
wr(a/'s7-p1-checkpoint.json',json.dumps(receipt,indent=2)+'\n')
p=r/'docs/states/CURRENT.md';t=p.read_text(encoding='utf-8')
t=t.replace('The last published count is 2,050 non-error blocks and 28,996 changed lines.\nS7 starts with 213 remaining file reviews. No S7 production build or release\nhas been needed for the initial audit and format-only work.',f'S7 starts with 213 remaining file reviews. P1 package {pub["package"]}\nwas published and hash verified at both destinations. Cached x86/x64 and\nRedirector OEM capacity and server enumeration fixtures passed.\n[Delivery evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/s7-p1-checkpoint.json).')
t=t.replace('Local total before delivery:', 'Delivered total:').replace('Removed one added blank line locally.', 'Removed one added blank line.')
wr(p,t)
for name in ['file-worklist.csv','owner-review-order.csv']:
 p=a/name
 d=p.read_bytes().replace(b's7-restored-pending-delivery',b's7-restored-delivered-p1').replace(b's7-partial-restoration-pending-delivery',b's7-partial-restoration-delivered-p1-residual-pending')
 p.write_bytes(d)
p=r/'artifacts/mvdm-audit/t483-remaining-reaudit/pending-decisions.csv'
with p.open('a',encoding='utf-8',newline='') as f:
 csv.writer(f,lineterminator='\n').writerow(['T483-S7-P1-packstr-rpc','src/non-mvdm/ds/netapi/netlib/packstr.c',
  'Retain the omission of the unused original NetpAllocateEnumBuffer RPC allocation unit.',
  'Full original compiler control rejects rpcutil.h with C1083. The original allocator calls MIDL_user_allocate and MIDL_user_free. The two independent packing routines compile and are discarded by the real product link.',
  'Retain the current subset or separately recover the original RPC allocator dependency closure.',
  'Retain the current omission. Do not widen the product for this unused path.',
  'Residual 3 blocks / 261 deleted lines. 2 blocks / 217 lines restored in P1.',
  'artifacts/mvdm-audit/t483-s6-diff-fragmentation/s7-p1-checkpoint.json','pending-owner-decision-source-proof',''])
p=a/'README.md'
wr(p,p.read_text(encoding='utf-8')+'\n[S7 P1 receipt](s7-p1-checkpoint.json) and [verification evidence](s7-p1-verification-evidence.zip) record the packstr and illegalp restorations and file-by-file audit dispositions.\n')
with zipfile.ZipFile(a/'s7-p1-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  rel=p.relative_to(b)
  if p.is_file() and not set(rel.parts)&{'cache-final','candidate-final','runtime-publication'} and p.suffix in {'.json','.log','.txt','.exit','.py','.ps1','.cmd','.err'}:z.write(p,rel.as_posix())
 for name in ['verify.cmd','verify.log','verify.err','verify.exit','full-control.cmd','full-control.log','full-control.err','full-control.exit']:
  z.write(q/name,'isolated/'+name)
 z.write(b/'runtime-publication/result.json','publication/result.json')
print(counts)
