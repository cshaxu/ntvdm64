@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
cl @"O:\repos.hobby\ntvdm64\build\t483-s7-p1\redirector-server\original.rsp"
if errorlevel 1 exit /b %errorlevel%
cl @"O:\repos.hobby\ntvdm64\build\t483-s7-p1\redirector-server\fixture.rsp"
if errorlevel 1 exit /b %errorlevel%
link @"O:\repos.hobby\ntvdm64\build\t483-s7-p1\redirector-server\link.rsp"
