$ErrorActionPreference='Stop'
$exe=(Get-Process -Id $PID).Path
& $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-redirector-oem-capacity.ps1 -OutputRoot build/t483-s7-p1/redirector-oem -OriginalProviders -BuildCache build/.ninja/msvc-x86-release/worker
if($LASTEXITCODE){exit $LASTEXITCODE}
& $exe -NoProfile -ExecutionPolicy Bypass -File test/observation/verify-redirector-server-enum.ps1 -BuildRoot build/t483-s7-p1/redirector-server -BuildCache build/.ninja/msvc-x86-release/worker
exit $LASTEXITCODE
