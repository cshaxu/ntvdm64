from pathlib import Path
import json,csv,hashlib,zipfile
r=Path.cwd();b=r/'build/t483-s6-p13';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
for n in ['cached','publish','bitmap-final','message-final','dde','focused','full-isolated','review-check','verification','pipeline','delivery-supervisor','input-checks-3']:
 assert (b/(n+'.exit')).read_text().strip()=='0',n
for n in ['input-services-3','input-lifetime-3']:assert (b/n/'exit.txt').read_text().strip()=='0',n
full=j(b/'full-isolated/timings.json');assert len(full['Gates'])==20 and all(x['Passed'] for x in full['Gates'])
c=j(b/'source-checkpoint.json');pub=j(b/'runtime-publication/result.json')
for x in c['files']:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256']
assert hashlib.sha256((r/'assets/winnt.zip').read_bytes()).hexdigest().upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
manifest=j(b/'candidate-final/product-system32-manifest.json');assert len(manifest)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in manifest:assert hashlib.sha256((dest/x['Name']).read_bytes()).hexdigest().upper()==x['Sha256'].upper()
files=j(b/'census.json')['files'];path='src/non-mvdm/windows/core/ntuser/kernel/input.c';row=next(x for x in files if x['path']==path)
assert row['filtered']=={'blocks':25,'added':5,'deleted':5498},row['filtered']
counts={'files':len(files),'strict_equal':sum(x['original_sha256']==x['current_sha256'] for x in files),'filtered_zero':sum(not x['filtered']['blocks'] for x in files),'nonzero_files':sum(bool(x['filtered']['blocks']) for x in files),'blocks':sum(x['filtered']['blocks'] for x in files),'lines':sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),'reviewed_files':25,'remaining_files':230,'cumulative_reduction_blocks':24,'cumulative_reduction_lines':897}
assert counts['blocks']==2309 and counts['lines']==53626,counts
receipt={'packet':'M0 T483 S6 P13','status':'Verified and published;Git delivery accompanies receipt','source_checkpoint':c,'reduction':{'blocks':1,'lines':24},'publication':pub,'full':full,'compiler_lines':j(b/'line-proof.json'),'global':counts,'input_specialized':'Native input services and lifetime passed against actual cached product input.obj;existing positive and terminal negatives retained','failed_attempts':'Standalone input recompilation lacked newly reached headers;tests now link actual provider object. No assertion weakened. Initial inactive DBG line pins corrected before cached build.','winnt_zip_unchanged':True}
(a/'batch-p13-checkpoint.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
p=a/'input-whole-file-review.json';review=j(p);review['status']='Whole-file reviewed and verified;residual owner decisions remain pending';review['validation']='Cached full,publish11x2,bitmap/message/DDE,focused/task-order,Full20,native input services/lifetime and governance passed';review['delivery']='P13;Git delivery accompanies receipt';p.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
for p in [a/'file-worklist.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/review-register.csv',r/'artifacts/mvdm-audit/t483-remaining-reaudit/pending-decisions.csv']:
 rows=list(csv.DictReader(p.open(encoding='utf-8')));fields=list(rows[0])
 for x in rows:
  if x['path']!=path:continue
  if 'remaining_blocks' in fields:
   x.update(remaining_blocks=25,added=5,deleted=5498,status='reviewed-verified-p13-residuals-pending-owner',source_sha256=row['current_sha256'])
  elif 'review_status' in fields:
   x['mirror_diff_delta']='S6 P13 whole file non-error26->25 blocks,+3/-5524->+5/-5498;5527->5503(-24). Historical overlapping IDs are not summed.'
   x['line_mapping_proof']='S6 input-whole-file-review.json and p13 line-proof:active original85/98 resets;compiler anchors and function code identity verified'
   x['verification']='P13 cached full,publish11x2,Full20 and actual-provider native input services/lifetime passed'
   x['delivery']='P13;Git delivery accompanies receipt'
   if x['review_id']=='T483-R2583':x['change_plan']='Original declarations85-90,98-117 restored;remaining omitted kernel owners still pending,not full restoration'
   if x['review_id']=='T483-R2582':x['minimum_diff_option']='Reuse existing original-layout/ZONE declaration headers;no new types/helper. Original precomp kernel boundary remains pending.'
   if x['review_id'] in ['T483-R2588','T483-R2589','T483-R2594']:
    x['minimum_diff_option']='Native queue boundary remains;scattered MA_*/THRESHOLD/CTS_* macro omissions are not semantically necessary. Restoring all makes file27 blocks vsentry26;owner block-count approval requested separately.'
  else:
   x['mirror_diff_delta']='S6 P13 non-error26->25 blocks,5527->5503 lines;remaining file25 blocks/+5/-5498. Partial restoration does not close residual.'
   x['evidence']='t483-s6-diff-fragmentation/input-whole-file-review.json;input-first-pass-controls.zip;batch-p13-checkpoint.json'
   if x['review_id']=='T483-R2583':x['recommendation']='Declarations85-90,98-117 restored;review only residual kernel-owner omissions,do not re-propose these restored units.'
   if x['review_id']=='T483-R2582':x['recommendation']='Existing declaration headers now supply recovered original globals/prototypes;remaining include boundary pending owner.'
   if x['review_id'] in ['T483-R2588','T483-R2589','T483-R2594']:
    x['options']='Retain native queue ownership boundary;separate choice:allow harmless MA_*/THRESHOLD/CTS_* restoration with net file block increase26->27,or retain block-count target.'
    x['recommendation']='Do not call unused macro omissions semantic necessities;await owner block-count choice. Function ABI/native-owner differences have separate evidence.'
 with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fields,lineterminator='\n');w.writeheader();w.writerows(rows)
p=r/'docs/states/CURRENT.md';s=p.read_text(encoding='utf-8');start=s.index('24/255 initial');end=s.index('\n| File |',start)
s=s[:start]+'''25/255 initial difference files reviewed;230 remain. Nineteen changed files
verified across P2-P13;six reviewed unchanged. Current census:1063 files
(1054 host C/H plus9 other text mirrors),511 original-byte matches,808 zero
normalized/error-masked differences,and255 nonzero files.
Current total2309 blocks/53626 lines;cumulative delivered reduction24 blocks/
897 lines. Mouse's earlier two-line counting correction remains separate.
'''+s[end:]
pos=s.index('\n\n\nThe canonical pending');s=s[:pos]+'\n| kernel/input.c |26->25|5527->5503|P13 original declarations restored;Full20 and input services/lifetime passed|'+s[pos:]
start=s.index('P13 input.c candidate');end=s.index('## Current Technical Baseline',start)
s=s[:start]+'''P13 original input declarations are restored and verified. Seven scattered
harmless macros would increase file blocks26->27;owner approval remains pending.
No residual omission is silently approved. Next file is sevid001.c.

'''+s[end:]
start=s.index('## Current Technical Baseline');end=s.index('## Remaining Scope',start)
s=s[:start]+'''## Current Technical Baseline

P13 cached x86/x64 full passed. Package'''+pub['package']+''' contains11
images,published and hash-verified to assets/release and O:/winnt/system32.
Bitmap/message/DDE,controls/task-order,Full20 including real DOS4GW/NESticle,
shared-boundary/governance and actual-provider native input services/lifetime
passed. Original declaration anchors and existing function code identity checked.
Standalone fixture compile dependencies were corrected by using the cached
product object;no assertion waiver. No guest or winnt.zip changes.

[P13 receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p13-checkpoint.json)
and [evidence](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/p13-verification-evidence.zip)
bind final source,package and tests. [Whole-file review](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/input-whole-file-review.json)
records restorations and residual owner decisions. Git delivery accompanies receipt.

'''+s[end:];p.write_text(s.rstrip()+'\n',encoding='utf-8',newline='\n');assert p.stat().st_size<16384
with (a/'README.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n[P13 receipt](batch-p13-checkpoint.json) and [evidence](p13-verification-evidence.zip):input.c26->25 non-error blocks,5527->5503 lines. Original declarations restored,Full20 and actual-provider input services/lifetime passed;scattered macro block-count choice remains pending.\n')
with zipfile.ZipFile(a/'p13-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.exit','.cmd','.ps1','.py','.h','.c','.txt','.csv','.disasm'] and not any(x in ['cache-final','candidate-final','runtime-publication'] for x in p.relative_to(b).parts):z.write(p,p.relative_to(b).as_posix())
 z.write(b/'runtime-publication/result.json','publication/result.json')
print('P13 receipt ready',counts)
