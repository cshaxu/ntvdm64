$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 $owned=Get-Process -Id 4736 -ErrorAction SilentlyContinue
 if($owned -and !$owned.WaitForExit(1800000)){throw 'Cached owner still running after delivery observation budget; no restart'}
 if(!(Test-Path "$PSScriptRoot/cached.exit") -or (Get-Content "$PSScriptRoot/cached.exit").Trim() -ne '0'){throw 'Cached final result missing or failed'}
 & "$PSScriptRoot/run-pipeline.ps1"
 $LASTEXITCODE|Set-Content "$PSScriptRoot/delivery-supervisor.exit"
 exit $LASTEXITCODE
} catch {$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/delivery-supervisor.exit";exit 1}
