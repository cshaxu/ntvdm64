try {
$ErrorActionPreference='Stop'
$repo='O:\repos.hobby\ntvdm64'
$env:OPENNT_BROKER_PRODUCT_BUILD="O:\repos.hobby\ntvdm64\build\.ninja\msvc-x64-release\service"
$node='C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt\dependencies\node\bin\node.exe'
& "$repo\tools\audit\Invoke-ProductVerification.ps1" -RuntimeRoot "$repo\build\t483-s6-p13\candidate-final" -BuildCache "$repo\build\t483-s6-p13\cache-final" -Observer "$repo\build\.ninja\msvc-x64-release\message-probes\console-startup-observer.exe" -WindowObserver "$repo\build\t483-s5-p79-final\observers-x64\worker-window-snapshot.exe" -TerminalObserver "$repo\build\t483-s5-p79-final\observers-x64\terminal-observer.exe" -GuestFixture "$repo\build\M0-T420\S44\p79-fixture\G7.COM" -NativeHook64 "$repo\build\t483-s6-p13\cache-final\nthook64.dll" -NativeWorker "$repo\build\t483-s6-p13\cache-final\ntvwm.exe" -NativeFrontend "$repo\build\t483-s6-p13\cache-final\ntcon.exe" -NativeMonitor "$repo\build\t483-s6-p13\cache-final\ntmon.exe" -NativeLauncher "$repo\build\t483-s6-p13\cache-final\run16.exe" -NativeService "$repo\build\t483-s6-p13\cache-final\ntsrv.exe" -MonitorRpc "$repo\build\t483-s6-p13\cache-final\monitor-rpc-test.exe" -WowBaselineRoots "$repo\build\t483-s5-p78\full-final" -LogRoot "$repo\build\t483-s6-p13\full-isolated" -Suite Full -Node $node








$LASTEXITCODE | Set-Content build/t483-s6-p13/full-isolated.exit

exit $LASTEXITCODE

}catch{$_|Out-String|Write-Output;1|Set-Content O:/repos.hobby/ntvdm64/build/t483-s6-p13/full-isolated.exit;exit 1}
