$ErrorActionPreference='Stop'
$exe='C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/native/powershell/pwsh.exe'
$p=Start-Process $exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"$PSScriptRoot/input-checks-3.ps1") -WorkingDirectory O:/repos.hobby/ntvdm64 -WindowStyle Hidden -PassThru -RedirectStandardOutput "$PSScriptRoot/input-checks-3.log" -RedirectStandardError "$PSScriptRoot/input-checks-3.stderr"
$p.Id|Set-Content "$PSScriptRoot/input-checks-3-child.pid"
if(!$p.WaitForExit(600000)){ & taskkill.exe /PID $p.Id /T /F; 'timeout'|Set-Content "$PSScriptRoot/input-checks-3-supervisor.exit"; exit 1 }
$p.ExitCode|Set-Content "$PSScriptRoot/input-checks-3-supervisor.exit"
exit $p.ExitCode

