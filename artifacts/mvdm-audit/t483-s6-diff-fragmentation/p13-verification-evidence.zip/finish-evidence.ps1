$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
try {
 $ownedPid=[int](Get-Content "$PSScriptRoot/delivery.pid")
 $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
 if($owned -and !$owned.WaitForExit(2400000)){throw 'Owned verification still running at evidence deadline'}
 if((Get-Content "$PSScriptRoot/delivery-supervisor.exit").Trim() -ne '0'){throw 'Delivery verification failed'}
 & python "$PSScriptRoot/finalize.py"
 if($LASTEXITCODE){throw 'Receipt failed'}
 & "$PSScriptRoot/final-docs.ps1"
 if($LASTEXITCODE){throw 'Final governance failed'}
 0|Set-Content "$PSScriptRoot/finish-evidence.exit"
}catch{$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/finish-evidence.exit";exit 1}
