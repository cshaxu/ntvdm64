$ErrorActionPreference='Stop'
Set-Location O:/repos.hobby/ntvdm64
$hostExe=(Get-Process -Id $PID).Path
try {
 & $hostExe -NoProfile -File test/observation/verify-native-input-services.ps1 -ProviderBuildRoot O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32 -CompilerDriver O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32/msvc-x86.cmd -BuildRoot O:/repos.hobby/ntvdm64/build/t483-s6-p13/input-services-3
 if($LASTEXITCODE){throw 'Input services failed'}
 & $hostExe -NoProfile -File test/observation/verify-wow-input-lifetime.ps1 -ProviderBuildRoot O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32 -CompilerDriver O:/repos.hobby/ntvdm64/build/.ninja/msvc-x86-release/wow32/msvc-x86.cmd -BuildRoot O:/repos.hobby/ntvdm64/build/t483-s6-p13/input-lifetime-3
 if($LASTEXITCODE){throw 'Input lifetime failed'}
 0|Set-Content "$PSScriptRoot/input-checks-3.exit"
} catch {$_|Out-String|Write-Output;1|Set-Content "$PSScriptRoot/input-checks-3.exit";exit 1}
