from pathlib import Path
import json,hashlib,csv,zipfile
r=Path.cwd();b=r/'build/t483-s6-p29';a=r/'artifacts/mvdm-audit/t483-s6-diff-fragmentation'
j=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,s):p.write_text(s,encoding='utf-8',newline='\n')
steps=['cached','provider-proof','controls','lifecycle','stage','publish','pipeline','pipeline-supervisor']
for n in steps:assert (b/(n+'.exit')).read_text().strip()=='0',n
c=j(b/'source-checkpoint.json')
for x in c['files']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in c['deleted']:assert not (r/x).exists()
log=(b/'pipeline.log').read_text(encoding='utf-8-sig');assert 'WOW_USER_TASK_LIFECYCLE errors=0' in log
m=j(b/'candidate-final/product-system32-manifest.json');assert len(m)==11
for dest in [r/'assets/release',Path('O:/winnt/system32')]:
 for x in m:assert sha(dest/x['Name']).upper()==x['Sha256'].upper()
assert sha(r/'assets/winnt.zip').upper()=='61C79CBD7651A1C8C79AF9FB77E46C21E1E0981CCAA0D62ACAE017F6A91C0924'
files=j(b/'census.json')['files']
for x in files:assert sha(r/x['path'])==x['current_sha256']
counts=dict(files=len(files),strict_equal=sum(x['original_sha256']==x['current_sha256'] for x in files),filtered_zero=sum(not x['filtered']['blocks'] for x in files),nonzero_files=sum(bool(x['filtered']['blocks']) for x in files),blocks=sum(x['filtered']['blocks'] for x in files),lines=sum(x['filtered']['added']+x['filtered']['deleted'] for x in files),reviewed_live_files=29,remaining_files=216,retired_reviewed_files=10,prior_delivered_reduction_blocks=40,prior_delivered_reduction_lines=1194,owner_retired_blocks=228,extraction_blocks=222,unused_removal_blocks=6,owner_retired_lines=23519,extraction_lines=22303,unused_removal_lines=1216,total_census_reduction_blocks=268,total_census_reduction_lines=24713)
assert (counts['files'],counts['blocks'],counts['lines'])==(1053,2065,29810)
for name,count in [('review-register.csv',2619),('pending-decisions.csv',1576)]:
 with (r/'artifacts/mvdm-audit/t483-remaining-reaudit'/name).open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==count
pub=j(b/'runtime-publication/result.json');review=j(a/'inctlpan-compat-extraction.json');review['status']='Cached build,targeted verification and publish11x2 passed;governance and Git accompany receipt';wr(a/'inctlpan-compat-extraction.json',json.dumps(review,indent=2)+'\n')
receipt=dict(packet='M0 T483 S6 P29',status='Cached build,targeted verification and publication passed;governance and Git accompany receipt',source_checkpoint=c,publication=pub,verification={n:'passed' for n in steps},full='Not run: owner approved related targeted verification only',global_counts=counts,limits=['Owner-approved button style table extraction, not original restoration','All retained mirrors and original guest unchanged','Original static sysBmpStyles table preserved in WOW button resources','No next-file admission'])
wr(a/'batch-p29-checkpoint.json',json.dumps(receipt,indent=2)+'\n')

p=r/'docs/states/CURRENT.md';t=p.read_text(encoding='utf-8')
for x,y in [('38/255 initial difference files reviewed;217 remain. P19,P21-P28 retire nine','39/255 initial difference files reviewed;216 remain. P19,P21-P29 retire ten'),('29 reviewed/246,217 remain','29 reviewed/245,216 remain'),('census:1054 files','census:1053 files'),('(1045 host','(1044 host'),('and246 nonzero','and245 nonzero'),('total2069 blocks/30691 lines','total2065 blocks/29810 lines'),('backlog has1588 rows after retiring nine','backlog has1576 rows after retiring ten')]:
 assert x in t,x
 t=t.replace(x,y,1)
i=t.index('| kernel/miscutil.c')
t=t[:i]+'| kernel/inctlpan.c |4->retired|881->retired|P29 sysBmpStyles extraction; targeted WOW validation passed|\n'+t[i:]
i=t.index('## Current Technical Baseline'); k=t.index('## Remaining Scope',i)
t=t[:i]+f'''## Current Technical Baseline

P29 cached x86/x64 build, link provider and import checks, WOW formal graph,
control fixtures and WOW lifecycle passed. Package {pub['package']} contains
11 images published and hash verified in assets/release and O:/winnt/system32.
[Receipt](../../artifacts/mvdm-audit/t483-s6-diff-fragmentation/batch-p29-checkpoint.json).
Full was outside the owner-approved targeted scope.

'''+t[k:]
wr(p,t)
p=a/'README.md';wr(p,p.read_text(encoding='utf-8')+'\n[P29 button style table extraction](inctlpan-compat-extraction.json), [receipt](batch-p29-checkpoint.json) and [verification evidence](p29-verification-evidence.zip). The live census is 1053 files, 245 nonzero, 2065 blocks and 29810 lines.\n')
with zipfile.ZipFile(a/'p29-verification-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  rel=p.relative_to(b)
  if p.is_file() and not set(rel.parts)&{'cache-final','candidate-final','runtime-publication'} and p.suffix in {'.json','.log','.txt','.exit','.py','.ps1','.cmd','.c'}:z.write(p,rel.as_posix())
print(counts)
