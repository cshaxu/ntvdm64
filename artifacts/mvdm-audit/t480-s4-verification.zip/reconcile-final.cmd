@echo off
python tests/build/verify-t480-s4-reconciliation.py --output build/t480-s4/reconcile-r2
exit /b %errorlevel%
