@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File tools/governance/Verify-DocumentationGovernance.ps1
if errorlevel 1 exit /b %errorlevel%
git diff --check
exit /b %errorlevel%
