@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File build/t480-s2/baseline-wow.ps1
exit /b %errorlevel%
