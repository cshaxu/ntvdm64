$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
. "$root/tests/observation/isolated_package_cleanup.ps1"
$runtime=New-PhysicalRuntimeStage "$root/build/t480-s2/media/WINNT"
$scope=New-IsolatedPackageScope $runtime
$log="$root/build/t480-s2/baseline-wow"
New-Item -ItemType Directory $log | Out-Null
try {
 $env:PATH=(Join-Path $runtime 'system32')+';'+(Join-Path $env:SystemRoot 'System32')
 $env:MVDM_OBSERVER_PRIVATE_DESKTOP='1'
 $env:MVDM_OBSERVER_SHORT_HISTORY='1'
 & "$root/tests/observation/observe-wow-frontiers.ps1" -Observer "$root/build/.ninja/msvc-x64-release/observers/console-startup-observer.exe" -WindowObserver "$root/build/.ninja/msvc-x64-release/observers/worker-window-snapshot.exe" -Prefix wow-restored -PackageRoot $runtime -ProcessPackageRoot $runtime -LogRoot $log -WaitTarget
} finally {
 Stop-IsolatedPackageScope $scope
 Remove-PhysicalRuntimeStage $runtime
}
