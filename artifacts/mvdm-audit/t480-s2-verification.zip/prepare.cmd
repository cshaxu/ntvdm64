@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File build/t480-s2/prepare.ps1
exit /b %errorlevel%
