import json
from pathlib import Path
r=Path('build/t480-s2');records=[]
for arch in ['x86','x64']:
 a={v['object']:v for v in json.loads((r/f'pp-before-{arch}/result.json').read_text())}
 b={v['object']:v for v in json.loads((r/f'pp-after-{arch}/result.json').read_text())}
 assert a.keys()==b.keys()
 for k in a:
  same=all(a[k][f]==b[k][f] for f in ['command_sha256','semantic_location_sha256','nonempty_lines','exit_code'])
  records.append({'object':k,'equal':same,'before':a[k]['semantic_location_sha256'],'after':b[k]['semantic_location_sha256']})
(r/'preprocessing-comparison.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
assert len(records)==819
bad=[v for v in records if not v['equal']]
assert not bad, [v['object'] for v in bad]
print('PASS all 819 actual consumers: emitted text and logical source locations identical')
p=Path('src/common/protocol/version.h');s=p.read_text(encoding='utf-8');assert '#define APP_VERSION "0.0.479"' in s
p.write_text(s.replace('#define APP_VERSION "0.0.479"','#define APP_VERSION "0.0.480"'),encoding='utf-8',newline='\n')
