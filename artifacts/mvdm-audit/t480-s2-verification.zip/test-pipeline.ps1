$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
$dir="$root/build/t480-s2"
$deadline=[DateTime]::UtcNow.AddMinutes(35)
while(!(Test-Path "$dir/compare-build.result.json")){if([DateTime]::UtcNow -gt $deadline){throw 'build prerequisite timeout'};Start-Sleep 3}
if((Get-Content "$dir/compare-build.result.json" -Raw|ConvertFrom-Json).exitCode -ne 0){throw 'build/comparison prerequisite failed'}
foreach($case in @(@{name='stage';timeout=300},@{name='full';timeout=1800},@{name='gameplay';timeout=300})) {
 $p=Start-Process pwsh -ArgumentList @('-NoProfile','-File',"$dir/supervise.ps1",'-CommandFile',"$($case.name).cmd",'-Name',$case.name,'-TimeoutSeconds',$case.timeout) -WindowStyle Hidden -PassThru
 $p.WaitForExit()
 if($p.ExitCode -ne 0){throw "$($case.name) supervisor failed"}
 if((Get-Content "$dir/$($case.name).result.json" -Raw|ConvertFrom-Json).exitCode -ne 0){throw "$($case.name) failed"}
}
