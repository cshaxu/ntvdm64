$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
$dir="$root/build/t480-s2"
foreach($name in @('semantic-test','build-x86','build-x64','full','gameplay')){
 if((Get-Content "$dir/$name.result.json" -Raw|ConvertFrom-Json).exitCode -ne 0){throw "Missing/failed gate: $name"}
}
$timings=Get-Content "$dir/full-r1/timings.json" -Raw|ConvertFrom-Json
if($timings.Gates.Count -ne 16 -or @($timings.Gates|Where-Object {!$_.Passed}).Count){throw 'Require all 16 Full gates'}
if((Get-Content "$dir/gameplay-r1/result.txt" -Raw) -notmatch '^PASS flag/counter, reset, open cell, WM_CLOSE and run16 completion'){throw 'Missing gameplay contract'}
$rows=@(Get-Content "$dir/package-r1/product-system32-manifest.json" -Raw|ConvertFrom-Json)
$tested=@(Get-Content "$dir/full-r1/runtime-manifest.json" -Raw|ConvertFrom-Json)
if($rows.Count -ne 11 -or $tested.Count -ne 11){throw 'Require eleven coherent images'}
foreach($row in $rows){
 $test=@($tested|Where-Object Name -eq $row.Name)
 if($test.Count -ne 1 -or $test[0].Sha256 -ne $row.Sha256){throw 'Tested/staged image mismatch'}
 if((Get-FileHash "$dir/package-r1/$($row.RelativePath)").Hash -ne $row.Sha256){throw 'Staged image changed'}
}
$destination=(Resolve-Path "$root/assets/release").Path
if($destination -ne [IO.Path]::GetFullPath("$root/assets/release")){throw 'Unexpected release destination'}
foreach($row in $rows){Copy-Item -LiteralPath "$dir/package-r1/$($row.RelativePath)" -Destination "$destination/$($row.Name)" -Force}
Copy-Item -LiteralPath "$dir/package-r1/product-system32-manifest.json" -Destination "$destination/release-manifest.json" -Force
foreach($row in $rows){if((Get-FileHash "$destination/$($row.Name)").Hash -ne $row.Sha256){throw 'Release hash mismatch'}}
[ordered]@{published=[DateTime]::UtcNow;destination=$destination;packageId=$rows[0].PackageId;images=$rows;gates=16;gameplay='passed';push=$false;installedWindowsWrite=$false}|ConvertTo-Json -Depth 6|Set-Content "$dir/publication.json"
'PASS worktree-only publication: all eleven tested image hashes match assets/release'
