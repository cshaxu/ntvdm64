$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
$dir="$root/build/t480-s2"
$p=Start-Process pwsh -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/governance/Verify-DocumentationGovernance.ps1') -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput "$dir/governance-r2.stdout.log" -RedirectStandardError "$dir/governance-r2.stderr.log" -PassThru
@{pid=$p.Id;started=[DateTime]::UtcNow;timeoutSeconds=180}|ConvertTo-Json|Set-Content "$dir/governance-r2.started.json"
if(-not $p.WaitForExit(180000)){ & taskkill /PID $p.Id /T /F; $code=124 }else{ $code=$p.ExitCode }
@{pid=$p.Id;exitCode=$code;finished=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content "$dir/governance-r2.result.json"


