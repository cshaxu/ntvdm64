param([string]$CommandFile,[string]$Name,[int]$TimeoutSeconds=3600)
$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
$dir="$root/build/t480-s2"
$p=Start-Process $env:ComSpec -ArgumentList @('/d','/c',"$dir/$CommandFile") -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput "$dir/$Name.stdout.log" -RedirectStandardError "$dir/$Name.stderr.log" -PassThru
@{pid=$p.Id;started=[DateTime]::UtcNow;command=$CommandFile;timeoutSeconds=$TimeoutSeconds}|ConvertTo-Json|Set-Content "$dir/$Name.started.json"
if(-not $p.WaitForExit($TimeoutSeconds*1000)){ & taskkill /PID $p.Id /T /F; $code=124 }else{ $code=$p.ExitCode }
@{pid=$p.Id;exitCode=$code;finished=[DateTime]::UtcNow}|ConvertTo-Json|Set-Content "$dir/$Name.result.json"
exit $code
