@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File tools/governance/Verify-DocumentationGovernance.ps1
exit /b %errorlevel%
