@echo off
python tests/build/verify-t480-s2-preprocessor-equivalence.py build/t480-s2
exit /b %errorlevel%
