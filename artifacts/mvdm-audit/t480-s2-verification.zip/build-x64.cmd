@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
cmake --preset msvc-x64-release -DCMAKE_C_COMPILER=cl
if errorlevel 1 exit /b %errorlevel%
cmake --build --preset msvc-x64-release --target native-worker native-frontend native-monitor native-launcher native-service hook64
if errorlevel 1 exit /b %errorlevel%
call build\.ninja\msvc-x64-release\monitor\run-ninja.cmd monitor-rpc-test.exe
exit /b %errorlevel%
