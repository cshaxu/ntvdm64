@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File build/t480-s2/full.ps1
exit /b %errorlevel%
