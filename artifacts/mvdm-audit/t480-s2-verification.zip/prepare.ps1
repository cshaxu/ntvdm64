$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
$dest="$root/build/t480-s2/media"
if(Test-Path $dest){throw 'fresh media destination required'}
Expand-Archive -LiteralPath assets/winnt.zip -DestinationPath $dest
$baseline="$dest/WINNT"
$rows=Get-Content assets/release/release-manifest.json -Raw|ConvertFrom-Json
foreach($row in $rows){
 Copy-Item -LiteralPath "assets/release/$($row.Name)" -Destination "$baseline/system32/$($row.Name)"
 if((Get-FileHash "$baseline/system32/$($row.Name)").Hash -ne $row.Sha256){throw 'baseline hash mismatch'}
}
Copy-Item assets/release/release-manifest.json "$baseline/product-system32-manifest.json"
& tools/build/Build-T420S44CommandFixture.ps1 -BuildRoot "$root/build/M0-T420/S44/t480-s2-fixture"
Copy-Item -LiteralPath assets/release -Destination build/t480-s2/release-before -Recurse
