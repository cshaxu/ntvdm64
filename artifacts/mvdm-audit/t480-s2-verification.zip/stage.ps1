$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
$x86="$root/build/.ninja/msvc-x86-release/worker"
$x64="$root/build/.ninja/msvc-x64-release"
$dir="$root/build/t480-s2"
foreach($arch in @('x86','x64')){if((Get-Content "$dir/build-$arch.result.json" -Raw|ConvertFrom-Json).exitCode -ne 0){throw 'build prerequisite failed'}}
& tools/build/Stage-System32ProductPackage.ps1 -BaselineRoot "$dir/media/WINNT" -BuildCache $x86 -Wow32 "$root/build/.ninja/msvc-x86-release/wow32/wow32.dll" -OutputRoot "$dir/package-r1" -Vcdex "$x86/VCDEX.DLL" -NativeHook "$x86/nthook32.dll" -NativeHook64 "$x64/hook/nthook64.dll" -NativeWorker "$x64/worker/ntvwm.exe" -NativeFrontend "$x64/frontend/ntcon.exe" -NativeMonitor "$x64/monitor/ntmon.exe" -NativeLauncher "$x64/launcher/run16.exe" -NativeService "$x64/service/ntsrv.exe"
$control="$dir/control-cache"
New-Item -ItemType Directory $control|Out-Null
$rows=Get-Content "$dir/package-r1/product-system32-manifest.json" -Raw|ConvertFrom-Json
foreach($row in $rows){Copy-Item -LiteralPath "$dir/package-r1/$($row.RelativePath)" -Destination "$control/$($row.Name)"}
foreach($name in @('frontend-request-client-test.exe','broker-frontend-bootstrap-test.exe','native-gui-startup-probe.exe')){Copy-Item -LiteralPath "$x86/$name" -Destination $control}
Copy-Item "$x64/monitor/monitor-rpc-test.exe" $control
