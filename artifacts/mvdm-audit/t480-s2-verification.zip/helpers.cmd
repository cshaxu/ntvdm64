@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
cl.exe /nologo /O2 /MT /W4 /I src /Fobuild/.ninja/msvc-x64-release/observers/console.obj /Febuild/.ninja/msvc-x64-release/observers/console-startup-observer.exe tests/observation/console_startup_observer.c /link dbghelp.lib user32.lib gdi32.lib
if errorlevel 1 exit /b %errorlevel%
cl.exe /nologo /O2 /MT /W4 /Fobuild/.ninja/msvc-x64-release/observers/window.obj /Febuild/.ninja/msvc-x64-release/observers/worker-window-snapshot.exe tests/observation/worker_window_snapshot.c /link user32.lib
if errorlevel 1 exit /b %errorlevel%
cl.exe /nologo /O2 /MT /W4 /I src /Fobuild/.ninja/msvc-x64-release/observers/terminal.obj /Febuild/.ninja/msvc-x64-release/observers/console-terminal-observer.exe tests/observation/console_terminal_observer.c /link user32.lib gdi32.lib
exit /b %errorlevel%
