$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
$dir="$root/build/t480-s2"
$deadline=[DateTime]::UtcNow.AddMinutes(30)
foreach($arch in @('x86','x64')) {
 while(!(Test-Path "$dir/pp-after-$arch.result.json")){if([DateTime]::UtcNow -gt $deadline){throw 'preprocess timeout'};Start-Sleep 2}
 if((Get-Content "$dir/pp-after-$arch.result.json" -Raw|ConvertFrom-Json).exitCode -ne 0){throw 'preprocess failed'}
}
python build/t480-s2/compare-and-version.py
if($LASTEXITCODE){throw 'semantic/location comparison failed'}
$jobs=@()
foreach($arch in @('x86','x64')) {
 $jobs+=Start-Process pwsh -ArgumentList @('-NoProfile','-File',"$dir/supervise.ps1",'-CommandFile',"build-$arch.cmd",'-Name',"build-$arch",'-TimeoutSeconds','1800') -WindowStyle Hidden -PassThru
}
foreach($p in $jobs){$p.WaitForExit();if($p.ExitCode){throw "build supervisor failed $($p.Id)"}}
foreach($arch in @('x86','x64')){if((Get-Content "$dir/build-$arch.result.json" -Raw|ConvertFrom-Json).exitCode){throw "$arch build failed"}}
