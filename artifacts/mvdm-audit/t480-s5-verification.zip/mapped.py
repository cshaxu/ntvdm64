import csv,json,re
from pathlib import Path
result=[]
for r in csv.DictReader(open('artifacts/mvdm-audit/t480-s1-files.csv',encoding='utf-8-sig')):
 a=Path(r['original']).read_bytes().decode('latin1').replace('\r\n','\n').split('\n')
 b=Path(r['path']).read_bytes().decode('latin1').replace('\r\n','\n').split('\n')
 logical=1
 for physical,line in enumerate(b,1):
  m=re.match(r'^\s*#line\s+(\d+)\s*$',line)
  if m:logical=int(m[1]);continue
  if 0<logical<=len(a):
   old=a[logical-1]
   if old!=line and old.strip() and old.strip()==line.strip() and not line.lstrip().startswith('#') and not line.rstrip().endswith('\\'):
    result.append(dict(path=r['path'],line=physical,original_line=logical,before=line,after=old))
  logical+=1
Path('build/t480-s5/mapped-spacing.json').write_text(json.dumps(result,indent=2))
print('candidates',len(result),'files',len({r['path'] for r in result}))
for r in result[:100]:print(r['path'],r['line'],repr(r['before']),'=>',repr(r['after']))
