import gzip,hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();work=root/'build/t480-s5';art=root/'artifacts/mvdm-audit'
def read(name):return json.loads((work/name).read_text(encoding='utf-8-sig'))
names=['admission','pp-before-x86','pp-before-x64','pp-after-x86','pp-after-x64','equivalence','inventory-final','build-x86','build-x64','stage','full','gameplay','publish','governance-final']
runs={n:{'start':read(n+'.started.json'),'result':read(n+'.result.json')} for n in names}
assert all(r['result']['exitCode']==0 for r in runs.values())
assert read('equivalence.json')['consumers']==819
full=read('full-r1/timings.json');assert len(full['Gates'])==16 and all(g['Passed'] for g in full['Gates'])
assert read('inventory-final/inventory.json')['passed']
paths=[p for p in work.iterdir() if p.is_file() and p.suffix in ('.json','.log','.cmd','.ps1','.py')]
for folder in ('pp-before-x86','pp-before-x64','pp-after-x86','pp-after-x64','inventory-final','full-r1','gameplay-r1'):
 paths += [p for p in (work/folder).rglob('*') if p.is_file() and p.suffix.lower() in ('.json','.log','.txt')]
out=art/'t480-s5-verification.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(work).as_posix())
record=dict(task='T480 S5',baseline='7f683ca81',runs=runs,equivalence=read('equivalence.json'),
 full=full,gameplay=(work/'gameplay-r1/result.txt').read_text(encoding='utf-8-sig').strip(),publication=read('publication.json'),
 archive=dict(path=out.relative_to(root).as_posix(),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),files=len(set(paths))),
 inventory_sha256=hashlib.sha256((art/'t480-s5-final-inventory.json.gz').read_bytes()).hexdigest(),
 limits=['No guest source/ASM/new functionality or tolerance. No O:/winnt write or push.',
 'DOS4GW/NESticle remains the prior excluded case, not a pass.',
 'Conservative retained adaptations and text metrics do not establish global mathematical minimality.',
 'Historical S3 first Full failure remains recorded; no root cause is claimed by S5.'])
(art/'t480-s5-delivery.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('Sealed',len(set(paths)),'S5 receipts;',out.stat().st_size,'bytes')
