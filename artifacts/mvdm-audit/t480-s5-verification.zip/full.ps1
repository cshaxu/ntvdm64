$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
$dir="$root/build/t480-s5"
$cache="$dir/control-cache"
$observers="$root/build/.ninja/msvc-x64-release/observers"
$env:OPENNT_BROKER_PRODUCT_BUILD="$root/build/.ninja/msvc-x64-release/service"
& tools/audit/Invoke-ProductVerification.ps1 -RuntimeRoot "$dir/package-r1" -BuildCache $cache -Observer "$observers/console-startup-observer.exe" -LogRoot "$dir/full-r1" -Suite Full -GuestFixture "$root/build/M0-T420/S44/t480-s2-fixture/G7.COM" -WindowObserver "$observers/worker-window-snapshot.exe" -TerminalObserver "$observers/console-terminal-observer.exe" -NativeHook64 "$cache/nthook64.dll" -NativeWorker "$cache/ntvwm.exe" -NativeFrontend "$cache/ntcon.exe" -NativeMonitor "$cache/ntmon.exe" -NativeLauncher "$cache/run16.exe" -NativeService "$cache/ntsrv.exe" -MonitorRpc "$cache/monitor-rpc-test.exe" -WowBaselineRoots "$root/build/t480-s2/baseline-wow"

