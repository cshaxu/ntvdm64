import json,re,csv
from pathlib import Path
pins={r['path']:r for r in csv.DictReader(open('artifacts/mvdm-audit/t480-s1-files.csv',encoding='utf-8-sig'))}
rows=json.loads(Path('build/t480-s5/mapped-spacing.json').read_text())
for r in rows:
 current=Path(r['path']).read_bytes().decode('latin1').splitlines();orig=Path(pins[r['path']]['original']).read_bytes().decode('latin1').splitlines()
 r['current_context']='\n'.join(current[max(0,r['line']-9):r['line']+7]);r['original_context']='\n'.join(orig[max(0,r['original_line']-9):r['original_line']+7])
 r['disposition']='retain-current-layout'
 r['reason']='Logical-line/text coincidence alone does not identify the same statement scope; preserve indentation of current adapted blocks and original-source diagnostics.'
 if r['path'].endswith('nt_unix.c'):r['reason']='Original error-index conditional body became an unconditional strerror fallback; old indentation describes a removed scope.'
 if r['path'].endswith('sim32.c'):r['reason']='Coincident comment terminator belongs to a new CPU40 adapter explanation, not the original CPU30 algorithm comment.'
 if r['path'].endswith('nt_sound.c'):r['reason']='No original line anchor before this shifted introductory comment; mapped blank-comment line is not an established original counterpart.'
 if r['path'].endswith('vga_prts.c'):r['reason']='DIV-358 removes the former geometry-only gating; cursor assignment retains the current scope indentation.'
 if r['path'].endswith('nt_fulsc.c'):r['reason']='Original X86GFX conditional content is excluded; current selected enableUpdates scope remains. Whitespace-only mismatch is not a capability gap.'
Path('build/t480-s5/layout-dispositions.json').write_text(json.dumps(rows,indent=2))
leads=json.loads(Path('build/t480-s5/candidates.json').read_text())
reasons=['wuman dereference is executable guest-domain binding, not a comment; leading star fooled the comment heuristic.', 'Original and current comments belong to different functions: dialog version validation versus ChangeDibColors.', 'Original WOW uniqueness-mask comment is not the retained LOOKASIDE declaration heading.', 'Original missing-key fallback comment is not FastGetProfileIntW integer conversion.', 'History line belongs to xxxUserYield, not the different function aligned by textual comparison.']
assert len(leads)==len(reasons)==5
for r,reason in zip(leads,reasons):r.update(disposition='retain-false-alignment',reason=reason)
Path('build/t480-s5/alignment-dispositions.json').write_text(json.dumps(leads,indent=2))
