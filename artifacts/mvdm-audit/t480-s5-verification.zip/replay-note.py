from pathlib import Path
p=Path('docs/etc/evidence/m0-t480-s5-final-minimization.md');s=p.read_text(encoding='utf-8-sig');s=s.replace('## Verification and delivery','''## Historical verifier applicability

S2/S3/S4 source-hash checks intentionally bind their own accepted revisions.
S5 supersedes five previously checked file identities and adds nturtl.h to the
restored-file union. Replaying an old verifier directly on the new source can
therefore reject its hash, correctly. Do not rewrite old receipts or weaken
those assertions. The S5 inventory composes the exact stage chain and supplies
the final current-source acceptance; historical stage replay uses its recorded
revision. Runtime regression still exercises the current coherent package.

## Verification and delivery''');p.write_text(s,encoding='utf-8')
