from pathlib import Path
w=Path('build/t480-s5')
for n in ('build-x86','build-x64'):
 s=Path('build/t480-s3/'+n+'.cmd').read_text().replace('cmake --preset msvc-x86-release -DCMAKE_C_COMPILER=cl\n','').replace('cmake --preset msvc-x64-release -DCMAKE_C_COMPILER=cl\n','')
 (w/(n+'.cmd')).write_text(s)
for n in ('stage','full'):
 s=Path('build/t480-s3/'+n+'.ps1').read_text().replace('build/t480-s3','build/t480-s5')
 (w/(n+'.ps1')).write_text(s)
 (w/(n+'.cmd')).write_text('@echo off\npwsh -NoProfile -ExecutionPolicy Bypass -File build/t480-s5/'+n+'.ps1\nexit /b %errorlevel%\n')
s=Path('build/t480-s3/gameplay.cmd').read_text().replace('build/t480-s3','build/t480-s5');(w/'gameplay.cmd').write_text(s)
(w/'equivalence.cmd').write_text('@echo off\npython tests/build/verify-t480-s5-comments.py build/t480-s5\nexit /b %errorlevel%\n')
s=Path('build/t480-s2/publish.ps1').read_text().replace('build/t480-s2','build/t480-s5').replace("'semantic-test'","'equivalence'")
s=s.replace('foreach($row in $rows){Copy-Item', 'Copy-Item -LiteralPath $destination -Destination "$dir/release-before-publication" -Recurse\nforeach($row in $rows){Copy-Item')
(w/'publish.ps1').write_text(s)
(w/'publish.cmd').write_text('@echo off\npwsh -NoProfile -ExecutionPolicy Bypass -File build/t480-s5/publish.ps1\nexit /b %errorlevel%\n')
