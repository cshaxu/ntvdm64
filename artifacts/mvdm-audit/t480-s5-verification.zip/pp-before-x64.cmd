@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
python tools/audit/verify-t480-s2-preprocessing.py build/t480-s5/restore-plan.json build/t480-s5/pp-before-x64 --arch x64
exit /b %errorlevel%
