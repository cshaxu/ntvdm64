@echo off
python tests/build/verify-t480-s5-comments.py build/t480-s5
exit /b %errorlevel%
