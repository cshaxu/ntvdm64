from pathlib import Path
p=Path('docs/states/CURRENT.md');s=p.read_text(encoding='utf-8-sig');needle='a restatement of conservative S3 retentions.';s=s.replace(needle,needle+'''

The full pinned inventory remains1060 host C/H files,581 text-different.
Five original terminal guard comments and one RapStructureSize closing comment
are admitted as same-line restorations. All819 actual consumers are captured
before/after; coherent build, Full, gameplay and local publication follow only
passing gates. Alignment and diagnostic-line probes are retained as leads,
not automatically applied or reported as semantic proof.''');p.write_text(s,encoding='utf-8')
