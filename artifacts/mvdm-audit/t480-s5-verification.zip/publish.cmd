@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File build/t480-s5/publish.ps1
exit /b %errorlevel%
