import json
from pathlib import Path
w=Path('build/t480-s5')
for name in ('equivalence','inventory-final','build-x86','build-x64','stage','full','gameplay','publish'):
 r=json.loads((w/(name+'.result.json')).read_text(encoding='utf-8-sig'));assert r['exitCode']==0,name
p=Path('docs/etc/evidence/m0-t480-s5-final-minimization.md');s=p.read_text(encoding='utf-8-sig')
s=s.replace('The final-inventory verifier passed all1060 identities, exact baseline/current\ncoverage and historical classification coverage. Comment verification and the\ncoherent product pipeline are in progress; this report is not yet closure.\nRequired delivery:819 before/after consumer comparisons; both architecture\nbuilds; Full16 gates; WINMINE interaction; eleven-image worktree-only publication;\nfinal governance, evidence sealing and local commit. No O:/winnt write or push.', '''The final-inventory verifier passed all1060 identities, exact baseline/current
coverage and historical classification coverage. All819 before/after consumers
have identical emitted text, tokens and logical source locations. Both coherent
architecture builds passed, followed by all16 Full gates and WINMINE interaction.
All11 tested image hashes match this worktree assets/release after publication.
The final package retains version0.0.480 and protocol67. No O:/winnt write or push.

`artifacts/mvdm-audit/t480-s5-delivery.json` and `t480-s5-verification.zip` retain
exact commands, supervisor identities, deadlines, results, package hashes and
source/consumer evidence. Final documentation governance and staged diff checks
are required before the local P commit. This closes the bounded T480 program;
its conservative proof limits above remain explicit rather than being promoted
to a claim of complete semantic minimality.''')
p.write_text(s,encoding='utf-8')
Path('docs/history/m0-t480-closure.md').write_text('''# M0 T480 closure: host mirror difference minimization

## Owner contract

Dedicated worktree from main157c31855. Review and minimize host mirror C/H
against pinned originals, preserve product behavior and required modern-host
boundaries. Do not touch guest, ASM or unsupported configurations, add capability
or tolerance, or redo prior repairs. Owner authorizes local build, test,
assets/release publication and commit, expressly excluding O:/winnt and push.

## Completed stages

| Stage | Bounded outcome | Evidence |
| --- | --- | --- |
| S1 |1060-file source inventory and actual build/include/link consumers;581 differing files all connected. | [S1](../etc/evidence/m0-t480-s1-build-consumers-closure.md) |
| S2 |53 whitespace restorations in30 files; all146 candidates dispositioned;819-consumer and product delivery checks. | [S2](../etc/evidence/m0-t480-s2-whitespace-restoration.md) |
| S3 |3 expressions,10 comment/spelling fragments, RTL1970 and3 environment function structures restored; required wrappers retained. | [S3](../etc/evidence/m0-t480-s3-connected-restoration.md) |
| S4 |39-file stage identity, registration and historical replay reconciliation; no product changes. | [S4](../etc/evidence/m0-t480-s4-registration-reconciliation.md) |
| S5 |6 further original comments; final1060-file accounting;819-consumer equivalence; coherent build/test/publication. | [S5](../etc/evidence/m0-t480-s5-final-minimization.md) |

## Delivery and limits

Final product version0.0.480, protocol67. Both architecture builds, all16 Full
gates and WINMINE flag/counter/reset/open-cell/close/launcher completion passed.
Eleven tested images were published and hash-verified only in this worktree
assets/release. Local P commit is the owner-approved delivery boundary; no push.
The earlier separate guest commit806bf1608 is preserved and was not audited or
modified by this host-only program.

The union of restored files is40. Final lexical edit blocks are9330 versus9376
at S1;581 files still differ. Changed-line totals increase because original
Base environment structure restoration changes greedy alignment. These metrics
are reported honestly and are not semantic distance or bug counts.

S3's3,641 conservative retained blocks are not an independent proof that every
remaining edit is necessary or mathematically minimal. Preserve the documented
CPU40/host ABI, guest-memory, callback/lifetime, native USER/CSR, original-bug
repair and exclusion boundaries. The finite program closes its measured safe
restorations and audit, not an unrestricted implementation redesign. That
broader work remains its separately queued proposal.

Historical S3 first Full scripted relaunch failure remains non-passing evidence;
its later unchanged test and12 immediate pairs passed. No intermittent root
cause is claimed. Existing DOS4GW/NESticle exclusion remains, never a pass.
No guest or new feature/tolerance work is included in this closure.
''',encoding='utf-8')
Path('docs/states/CURRENT.md').write_text('''# Project Status

## Current Work

**No active M/T/S packet.** T480 S5 is closed; T480 is closed by this local P delivery.
[Task closure](../history/m0-t480-closure.md) records the bounded host-mirror
program, final delivery and explicit proof limits.

## Latest Delivery

[S5 evidence](../etc/evidence/m0-t480-s5-final-minimization.md): six original
same-line comments restored; all1060 host C/H identities and prior coverage
verified;819 actual consumers preserve emitted text/tokens/logical positions.
Both architecture builds, Full16/16 and WINMINE interaction passed. All11 tested
images are published and hash-verified in this worktree assets/release.
No O:/winnt writes, push, guest changes, new features or additional tolerance.

## Current Technical Baseline

S1 d08e0ffc7; S2 b35effafd; S3 511f23fc0; S4 465ba5dcb; S5 admission7f683ca81.
Product version0.0.480, protocol67. Dedicated branch codex/t480-mirror-diff-audit
started at main157c31855. Main T479 remains independently owned. Earlier guest
commit806bf1608 remains untouched.

The T restored fragments in40 host files.581 files still differ; lexical blocks
fall9376 to9330, while greedy line-accounting totals increase due to restored
Base environment structure. Neither metric is semantic minimality. The3,641
conservative S3 retentions remain explicitly unproved as global minimum diff.

## Execution Boundary

T480 is closed with its original host-only and no-feature-growth limits.
No following task is admitted. Broader autonomous implementation minimization
remains its separate queue candidate. Preserve completed fixes and necessary
CPU40, ABI, guest-memory, callback/lifetime and native-host bindings.
First S3 scripted relaunch failure and prior DOS4GW/NESticle exclusion remain
in evidence; no new pass or root-cause claim is invented for those limits.

## Recent M0 Closures

- [T480](../history/m0-t480-closure.md): bounded mirror review, original recovery and worktree-only product delivery.
- [T478](../history/m0-t478-closure.md): prior host recovery scope remains closed.

## Recent Governance

S5 evidence is indexed. Final governance and staged diff checks precede the
local commit. Queue and main-worktree state remain unchanged. Historical
receipts remain immutable and stage-specific; final S5 identity is explicit.
''',encoding='utf-8')
p=Path('docs/etc/operations/m0-t480-mirror-diff-plan.md');s=p.read_text(encoding='utf-8-sig');s+='''

## S5 and task closure

[S5 evidence](../evidence/m0-t480-s5-final-minimization.md) records the final
1060-file review, six further original comments, all819 consumer comparisons,
coherent builds, Full16/16, gameplay and11-image worktree publication. The
[task closure](../../history/m0-t480-closure.md) supersedes this completed plan.
No further stage is admitted. Conservative retained differences and the
alignment-sensitive metric limits remain explicit; no guest, new functionality,
O:/winnt write or push was introduced.
''';p.write_text(s,encoding='utf-8')
