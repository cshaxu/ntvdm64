from pathlib import Path
p=Path('src/non-mvdm/README.md');b=p.read_bytes();nl=b'\r\n' if b'\r\n' in b else b'\n'
b+=('''

## T480 S5 original comment restoration

Restore only original same-line terminal comments on the matching outer guards
in ntexapi.h, ntregapi.h, ntrtl.h, nturtl.h and userk.h, plus the closing
RapStructureSize comment in strucsiz.c. Guard nesting was checked before edit.
No line insertion, condition, declaration, implementation or #line/#error change
is introduced. Source identities and all actual consumer comparisons are in the
T480 S5 evidence. Earlier behavioral registrations remain unchanged.
''').replace('\n',nl.decode()).encode();p.write_bytes(b)
