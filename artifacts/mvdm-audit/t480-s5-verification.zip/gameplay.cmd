@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File tests/observation/verify-wow-mine-gameplay.ps1 -PackageRoot build/t480-s5/package-r1 -Observer build/.ninja/msvc-x64-release/observers/console-startup-observer.exe -CompilerDriver build/t480-s2/msvc-x64.cmd -BuildRoot build/t480-s5/gameplay-r1
exit /b %errorlevel%

