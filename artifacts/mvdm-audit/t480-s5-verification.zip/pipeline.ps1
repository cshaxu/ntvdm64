$ErrorActionPreference='Stop'
$root='O:/repos.hobby/ntvdm64/.worktrees/t480-mirror-diff-audit'
Set-Location $root
$dir="$root/build/t480-s5"
function Wait-Receipt([string]$name,[int]$seconds=1900){
 $end=[DateTime]::UtcNow.AddSeconds($seconds)
 while(!(Test-Path "$dir/$name.result.json")){
  if([DateTime]::UtcNow -gt $end){throw "Receipt deadline: $name"}
  Start-Sleep -Seconds 5
 }
 $r=Get-Content "$dir/$name.result.json" -Raw|ConvertFrom-Json
 if($r.exitCode -ne 0){throw "Failed $name : $($r.exitCode)"}
}
function Start-Phase([string]$name,[int]$seconds=1800){
 $p=Start-Process pwsh -ArgumentList @('-NoProfile','-File',"$dir/supervise.ps1",'-CommandFile',"$name.cmd",'-Name',$name,'-TimeoutSeconds',"$seconds") -WindowStyle Hidden -PassThru
 "$name supervisor=$($p.Id)" | Tee-Object -FilePath "$dir/pipeline-phases.txt" -Append
}
Wait-Receipt 'pp-before-x86'
Wait-Receipt 'pp-before-x64'
python tools/audit/restore-t480-s5-comments.py
if($LASTEXITCODE -ne 0){throw 'Restoration rejected'}
Start-Phase 'pp-after-x86'
Start-Phase 'pp-after-x64'
Wait-Receipt 'pp-after-x86'
Wait-Receipt 'pp-after-x64'
Start-Phase 'equivalence' 300
Wait-Receipt 'equivalence'
Start-Phase 'build-x86'
Start-Phase 'build-x64'
Wait-Receipt 'build-x86'
Wait-Receipt 'build-x64'
foreach($name in @('stage','full','gameplay','publish')){
 Start-Phase $name
 Wait-Receipt $name
}
'PASS product pipeline; evidence/document closure still required'
