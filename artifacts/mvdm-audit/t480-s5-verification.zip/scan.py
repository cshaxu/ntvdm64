import csv,difflib,hashlib,json,re
from pathlib import Path
rows=list(csv.DictReader(open('artifacts/mvdm-audit/t480-s1-files.csv',encoding='utf-8-sig')))
result=[];candidates=[]
for r in rows:
 p=Path(r['path']);a=Path(r['original']).read_bytes();b=p.read_bytes()
 assert hashlib.sha256(a).hexdigest()==r['original_sha256'],r['path']
 x=a.decode('latin1').splitlines();y=b.decode('latin1').splitlines()
 ops=[o for o in difflib.SequenceMatcher(None,x,y,autojunk=False).get_opcodes() if o[0]!='equal']
 result.append({'path':r['path'],'original_sha256':r['original_sha256'],'current_sha256':hashlib.sha256(b).hexdigest(),'blocks':len(ops),'added':sum(o[4]-o[3] for o in ops),'removed':sum(o[2]-o[1] for o in ops)})
 for _,i,j,k,l in ops:
  if j-i==l-k==1 and x[i].strip() and y[k].strip() and not x[i].lstrip().startswith('#') and not y[k].lstrip().startswith('#'):
   old=x[i];new=y[k]
   # Only a triage: full preprocessing/string/macro context must be checked.
   if re.sub(r'\s+','',old)==re.sub(r'\s+','',new):
    candidates.append({'path':r['path'],'original_line':i+1,'current_line':k+1,'original':old,'current':new,'kind':'single-line-spacing'})
   elif old.lstrip().startswith(('//','/*','*')) and new.lstrip().startswith(('//','/*','*')):
    candidates.append({'path':r['path'],'original_line':i+1,'current_line':k+1,'original':old,'current':new,'kind':'comment-lead'})
Path('build/t480-s5/inventory.json').write_text(json.dumps(result,indent=2))
Path('build/t480-s5/candidates.json').write_text(json.dumps(candidates,indent=2))
print('files',len(rows),'differing',sum(r['blocks']>0 for r in result),'blocks',sum(r['blocks'] for r in result),'candidates',len(candidates))
for c in candidates:print(c['path'],c['current_line'],repr(c['current']),'=>',repr(c['original']))
