@echo off
python tests/build/verify-t480-s5-inventory.py --output build/t480-s5/inventory-final
exit /b %errorlevel%
