import csv,json,re,hashlib
from pathlib import Path
rows={r['path']:r for r in csv.DictReader(open('artifacts/mvdm-audit/t480-s1-files.csv',encoding='utf-8-sig'))}
changes=[]
for r in json.loads(Path('build/t480-s5/end-comments.json').read_text()):
 p=Path(r['path']);lines=p.read_bytes().splitlines(keepends=True);last=max(i for i,s in enumerate(lines) if s.strip());stack=[];closed=None
 for i,line in enumerate(lines):
  m=re.match(rb'\s*#\s*(if|ifdef|ifndef|endif)\b(.*)',line)
  if not m:continue
  if m[1]==b'endif':
   assert stack
   closed=stack.pop()
   if i==last:assert not stack and closed[1].startswith(b'#ifndef '),closed
  else:stack.append((i,line.strip()))
 assert not stack
 changes.append(dict(path=r['path'],line=last+1,before=r['current'],after=r['original'],reason='restore original matching outer include-guard comment',matching_guard=closed[1].decode(),before_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),original_sha256=rows[r['path']]['original_sha256']))
p=Path('src/non-mvdm/ds/netapi/rap/strucsiz.c');lines=p.read_bytes().splitlines(keepends=True);i=next(i for i,s in enumerate(lines) if s.strip()==b'}');assert lines[i+1].strip()==b'#line 93'
changes.append(dict(path=p.as_posix(),line=i+1,before='}',after='} // RapStructureSize',reason='restore original function-ending comment without inserting original blank line',before_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),original_sha256=rows[p.as_posix()]['original_sha256']))
Path('build/t480-s5/restore-plan.json').write_text(json.dumps({'changes':changes},indent=2))
p=Path('tools/audit/verify-t480-s2-preprocessing.py');s=p.read_text();s=s.replace("('t480-s2', 't480-s3')","('t480-s2', 't480-s3', 't480-s5')").replace('under build/t480-s2 or build/t480-s3','under build/t480-s2, build/t480-s3 or build/t480-s5');p.write_text(s,encoding='utf-8')
for arch in ('x86','x64'):
 for phase in ('before','after'):
  cmd=f'''@echo off
call "C:\\Program Files (x86)\\Microsoft Visual Studio\\2022\\BuildTools\\Common7\\Tools\\VsDevCmd.bat" -arch={arch} -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
python tools/audit/verify-t480-s2-preprocessing.py build/t480-s5/restore-plan.json build/t480-s5/pp-{phase}-{arch} --arch {arch}
exit /b %errorlevel%
'''
  Path(f'build/t480-s5/pp-{phase}-{arch}.cmd').write_text(cmd)
print('Planned',len(changes),'same-line comment restorations; all five closing guards matched')
