import csv,difflib,json,hashlib,subprocess
from pathlib import Path
rows=list(csv.DictReader(open('artifacts/mvdm-audit/t480-s1-files.csv',encoding='utf-8-sig')))
paths=[r['path'] for r in rows]
raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join('d08e0ffc7:'+p+'\n' for p in paths).encode());pos=0;base={}
for p in paths:
 end=raw.index(b'\n',pos);n=int(raw[pos:end].split()[-1]);pos=end+1;base[p]=raw[pos:pos+n];pos+=n+1
out=[]
for r in rows:
 a=Path(r['original']).read_bytes();assert hashlib.sha256(a).hexdigest()==r['original_sha256'];p=r['path']
 def metrics(b):
  x=a.decode('latin1').replace('\r\n','\n').replace('\r','\n').splitlines(keepends=True);y=b.decode('latin1').replace('\r\n','\n').replace('\r','\n').splitlines(keepends=True)
  ops=[v for v in difflib.SequenceMatcher(None,x,y,autojunk=True).get_opcodes() if v[0]!='equal']
  return dict(blocks=len(ops),added=sum(v[4]-v[3] for v in ops),removed=sum(v[2]-v[1] for v in ops))
 out.append(dict(path=p,original_sha256=r['original_sha256'],current_sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest(),S1=metrics(base[p]),current=metrics(Path(p).read_bytes())))
Path('build/t480-s5/metrics-before.json').write_text(json.dumps(out,indent=2))
for name in ('S1','current'):print(name,{k:sum(r[name][k] for r in out) for k in ('blocks','added','removed')})
