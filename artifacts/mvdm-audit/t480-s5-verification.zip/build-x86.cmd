@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x86 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
if errorlevel 1 exit /b %errorlevel%
cmake --build --preset msvc-x86-release --target wow32
if errorlevel 1 exit /b %errorlevel%
call build\.ninja\msvc-x86-release\worker\run-ninja-parallel.cmd ntvdm.exe VCDEX.DLL VDMREDIR.dll nthook32.dll frontend-request-client-test.exe broker-frontend-bootstrap-test.exe native-gui-startup-probe.exe
exit /b %errorlevel%
