import json,subprocess,difflib,hashlib,csv
from pathlib import Path
rows={x['path']:x for x in csv.DictReader(open('artifacts/mvdm-audit/t480-s1-files.csv',encoding='utf-8-sig'))}; changes=[]; planned={}
for h in json.loads(Path('build/t480-s3/spelling-leads.json').read_text()):
 p=Path(h['path']);raw=planned.get(h['path'],p.read_bytes());nl=b'\r\n' if b'\r\n' in raw else b'\n';old=h['replace_from'].encode('latin1');new=h['replace_to'].encode('latin1');pin=rows[h['path']];assert hashlib.sha256(Path(pin['original']).read_bytes()).hexdigest()==pin['original_sha256']
 needle=h['new'].replace('\n',nl.decode()).encode('latin1');replacement=needle.replace(old,new)
 if raw.count(needle)!=1:
  base=subprocess.check_output(['git','show','d08e0ffc7:'+h['path']]).decode('latin1').splitlines(keepends=True);start=h['line']-1;end=start+len(h['new'].splitlines());ctx=''.join(base[max(0,start-2):end+2]);needle=ctx.replace('\r\n','\n').replace('\n',nl.decode()).encode('latin1');prefix=''.join(base[max(0,start-2):start]).replace('\r\n','\n').replace('\n',nl.decode()).encode('latin1'); pos=len(prefix); assert needle[pos:pos+len(old)]==old; replacement=needle[:pos]+new+needle[pos+len(old):]
 assert raw.count(needle)==1,h['id'];result=raw.replace(needle,replacement);planned[h['path']]=result;changes.append({'id':h['id'],'path':h['path'],'before':h['replace_from'],'after':h['replace_to']})
files=[]
for name,result in planned.items():
 p=Path(name);files.append({'path':name,'before_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(result).hexdigest()});p.write_bytes(result)
Path('build/t480-s3/spelling-restorations.json').write_text(json.dumps({'changes':changes,'files':files},indent=2))
