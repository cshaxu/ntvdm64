@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
if errorlevel 1 exit /b %errorlevel%
cmake --build --preset msvc-x64-release --target native-launcher hook64
if errorlevel 1 exit /b %errorlevel%
exit /b %errorlevel%

