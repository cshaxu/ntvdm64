@echo off
python tests/build/verify-t480-s3-environment.py build/t480-s3
exit /b %errorlevel%
