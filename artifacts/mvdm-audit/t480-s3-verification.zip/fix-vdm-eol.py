import hashlib,json,subprocess
from pathlib import Path
p=Path('src/non-mvdm/base/win32/client/vdm.c')
old=subprocess.check_output(['git','show','HEAD:'+p.as_posix()])
current=p.read_bytes().replace(b'\r\n',b'\n')
base=old.replace(b'\r\n',b'\n')
a=base.index(b'#line 3022\n'); b=base.index(b'\n#endif\n',a)
c=current.index(b'#line 3022\n');d=current.index(b'\n#endif\n',c)
assert old == base, 'baseline is not LF-only; preserve mixed endings explicitly'
fixed=old[:a]+current[c:d]+old[b:]
assert fixed.replace(b'\r\n',b'\n') == current
p.write_bytes(fixed)
r=Path('build/t480-s3/vdm-line-ending-correction.json')
r.write_text(json.dumps({'before_sha256':hashlib.sha256(current.replace(b'\n',b'\r\n')).hexdigest(),'after_sha256':hashlib.sha256(fixed).hexdigest(),'proof':'Only CRLF-to-LF; baseline bytes outside restored owner preserved exactly'},indent=2))
print(r.read_text())
